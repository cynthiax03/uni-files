package example;

/**
 * Prints "Hello World" to the console.
 *
 * @author Robert Clifton-Everest
 *
 */
public class HelloWorld {

    public static void main(String[] args) {
        // TODO Complete this method

    }

}
