package thrones;

public class CharacterFactory {
    public static Character createDragon(int x, int y) {
        return new Character(0, 0, 20, 15);
    }
}