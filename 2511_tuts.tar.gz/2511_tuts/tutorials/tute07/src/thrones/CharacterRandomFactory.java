package thrones;

public class CharacterRandomFactory {
    private static Random rng = new Random();

    public static Dragon createDragon() {
        return new Dragon(rng.netxInt(5), rng.nextInt(5));
    }

    public static King createKing() {
        return new King(rng.nextInt(5), rng.nextInt(5));
    }

    public static Queen createQueen() {
        return new Queen(rng.nextInt(5), rng.nextInt(5));
    }

    public static Knight createKnight() {
        return new Knight(rng.nextInt(5), rng.nextInt(5));
    }
}