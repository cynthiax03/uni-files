package thrones;

// Abstract factory pattern could have a factory method on easy, med, hard 
// modes, each style creates a family of objects
public class Game {

    public static void main(String[] args) {
        King king = new King(0, 0);
        Queen queen = new Queen(0, 1);
        Knight knight = new Knight(0, 2);
        Dragon dragon = new Dragon(-1, 0);

        knight.attack(dragon);
    }

}