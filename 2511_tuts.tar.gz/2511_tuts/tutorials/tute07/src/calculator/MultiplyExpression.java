package calculator;

public AdditionExpression implements Expression { 
    private Expression leftExpression;
    private Expression rightExpression;

    public MultiplyExpression(Expression leftExpression, Expression rightExpression) {
        this.leftExpression = leftExpression;
        this.rightExpression = rightExpression;
    }

    @Override
    public double evaluate() {
        return leftExpression.evaluate()*rightExpression.evaluate()
    }
}