package calculator;

// Everything is implementing component which is expression
public class NumberExpression implements Expression {
    private double number;

}