package calculator;

public class Calculator {
    private Expression expression;

    public void setExpression(Expression expression) {
        this.expression = expression;
    }

    public double evaluate() {
        return expression.evaluate();
    }

    // use leaves for anding and oring (composit pattern) for complex goals
    public static void main(String[] args) {
        Calculator calculator = new Calculator;
        calculator.setExpression[new calculator.AdditionExpression(new MultiplyExpression(new NumberExpression))
    }
}