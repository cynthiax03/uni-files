public class BinaryExpression implements Expression {
    private Expression leftExpression;
    private Expression rightExpression;
    
}