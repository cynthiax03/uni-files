package calculator;

/**
 * A simple mathematical expression
 * @author Nick Patrikeos
 */
public interface Expression {
    public double compute();
}