package thrones;

public class Game {

    public static void main(String[] args) {
        CharacterBase king = CharacterFactory.createKing();
        CharacterBase queen = CharacterFactory.createQueen();
        CharacterBase knight = CharacterFactory.createKnight();
        CharacterBase dragon = CharacterFactory.createDragon();

        knight.attack(dragon);
    }

}