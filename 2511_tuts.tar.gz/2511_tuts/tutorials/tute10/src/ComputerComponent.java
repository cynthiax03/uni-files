public interface ComputerComponent {

}


