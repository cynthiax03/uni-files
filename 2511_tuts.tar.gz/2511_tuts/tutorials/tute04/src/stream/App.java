package stream;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class App {
    public static void main(String[] args) {
        List<String> strings = new ArrayList<String>(Arrays.asList(new String[] {"1", "2", "3", "4", "5"}));
        // for (String string : strings) {
        //     System.out.println(string);
        // }

        strings.forEach((String s) -> System.out.println(s));

        List<String> strings2 = new ArrayList<String>(Arrays.asList(new String[] {"1", "2", "3", "4", "5"}));
        List<Integer> ints = new ArrayList<Integer>();
        // for (String string : strings2) {
        //     ints.add(Integer.parseInt(string));
        // }

        // creating a closure for a lambda, using vars defined outside
        // strings2.forEach((String s) -> ints.add(Integer.parseInt(s)));

        // map, applies a function to every element, returns something we can do something else with
        // this is more functional than a bunch of loops
        List<Integer> ints2 = strings2.stream().map(Integer::parseInt).map((int num) -> num += 5).collect(Collectors.toList);
        System.out.println(ints);
    }


}