package unsw.training;

import java.util.List;

/**
 * A trainer that runs in person seminars.
 *
 * @author Robert Clifton-Everest
 *
 */
public class Trainer {

    private String name;
    private String room;

    private List<Seminar> seminars;

    public List<Seminar> getSeminars() {
        return seminars;
    }

    public LocalDate bookSeminar(List<LocalDate> availabilities, String employee) {
        for (Seminar seminar : seminars) {
            for (LocalDate available : availabilities) {
                if (seminar.addAtendee(available, employee)) {
                    return available;
                }
            }
        }

        return null;
    }
}
