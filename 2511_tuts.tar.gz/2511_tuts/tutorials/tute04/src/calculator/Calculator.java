package calculator;

public class Calculator {
    
    /**
     * @precondition: a, b != null
     * @postcondition return a + b
     * @param a
     * @param b
     * @return
     */

    public static Double add(Double a, Double b) {
        return a + b;
    }

    public static Double subtract(Double a, Double b) {
        return a - b;
    }

    public static Double multiply(Double a, Double b) {
        return a * b;
    }
    /**
         * @precondition: b > 0
         * @postcondition: return a/b
         * @param a
         * @param b
         * @return
         */
    public static Double divide(Double a, Double b) {
        return a / b;
    }

    public static Double sin(Double angle) {
        return Math.sin(angle);
    }

    public static Double cos(Double angle) {
        return Math.cos(angle);
    }

    /**
     * @precondition: angle != 90
     * @param angle
     * @return
     */
    public static Double tan(Double angle) {
        return Math.tan(angle);
    }

}