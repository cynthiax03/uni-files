public class Character {

}
