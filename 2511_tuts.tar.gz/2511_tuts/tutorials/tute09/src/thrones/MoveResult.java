package thrones;

public enum MoveResult {
    INVALID,
    ATTACK,
    SUCCESS
}