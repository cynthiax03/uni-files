package thrones;

public class Helmet {
    private CharacterBase character;

    public void damage(int points) {
        character.damage(points - 1);
    }
}
