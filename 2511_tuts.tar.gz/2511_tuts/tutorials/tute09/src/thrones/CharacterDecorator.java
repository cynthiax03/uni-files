package throne;

public abstract class CharacterDecorator implements Character {
    private CharacterBase character;
}
