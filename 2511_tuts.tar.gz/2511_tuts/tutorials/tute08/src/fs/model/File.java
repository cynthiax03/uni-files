package fs.model;

public class File {
    
}
