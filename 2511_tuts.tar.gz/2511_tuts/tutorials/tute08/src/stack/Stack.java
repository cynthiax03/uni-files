package stack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * A Simple Stack.
 * 
 * @param <E>
 * 
 */
public class Stack<E> implements Iterable<E> {
    private List<E> items = new ArrayList<>();

    /**
     * Pushes an element onto the top of the stack.
     * 
     * @param element
     */
    public void push(E element) {
        items.add(element);
    }

    /**
     * Removes the top element of the stack, and returns that element.
     * 
     * @precondition The stack is not empty.
     */
    public E pop() {
        return items.remove(items.size() - 1);
    }

    /**
     * Returns the top element of the stack, without removing it.
     */
    public E peek() {
        return items.get(items.size() - 1);
    }

    /**
     * Returns an iterator to the internal data structure of the stack.
     */
    public Iterator<E> iterator() {
        // check next element, move on, remove element must implement hasNext
        // and next shouldn't return items.iterator();
        // lol that would suck dont do that
        // iterator can change things in internal stack going in reverse order
        // from bottom of stack
        List<E> toIterator = new ArrayList<>(items);
        collections.reverse(toIterator);
        return toIterate.iterator();
        // return items.iterator();
        // List<E> toiteratre = to arraylist
        // return Collections.reverse(toiterate);
    }

    /**
     * Returns the size of the stack.
     */
    public int size() {
        return items.size();
    }

    /**
     * Returns the stack as an ArrayList
     */
    public ArrayList<E> toArrayList() {
        return new ArrayList<>(items);
    }

    public static Integer sumStack(Stack<? extends Integer> stack) {
        // only sum if an integer or a subclass of integer, then okay to use
        // Integer
        int total = 0;
        for (Integer integer : stack) {
            total += integer;
        }
        return total;
    }

    public static void prettyPrint(Stack<?> stack) {
        // ? dont care what it is, print in reverse order
        // FILO order
        // if ? was an object, ? stores of any type, but anything is a subclass of obj
        // but must be ? as it expects stack of obj not stack of string in main
        // How to loop if don't know type

        // singleton pattern easily abused, not great to use, even if you only 
        // want one instance of something, don't make it a singleton good for 
        // a shared resource, global, alternative is passing down obj to each level
        // constructor is private, singleton.getinstance() returns instance, if first 
        // time accessing, will create it, unless just returns the same instance
        // makes code tightly coupled to singleton, as use singleton.getinstance
        // can't really do inheritance, kind of an antipattern, harder to test

        System.out.println("[");
        Iterator<?> = stack.iterator();
        Object last = null;
        while(iterator.hasNext()) {
            last = iterator.next();
            if (!iterator.hasNext()) break;
            system.out.print(last + ", ");
        }
        system.out.println(last + "]");
        // for (Object o : stack) {
        //     System.out.println(o);
        // }
        // System.out.println("]");
    }

    public static void main(String[] args) {
        Stack<String> stack = new Stack<String>();
        stack.push("hello");
        stack.push("how");
        stack.push("are");
        stack.push("you");
        stack.push("today");
        prettyPrint(stack);
    }

}