public class Scratch {
    public static void main(String[] args) {
        // Stack can be created, E is a generic parameter, it doesn't refer to
        // a type, parametised at runtime, none of the code depends on what
        // type is, when stack is created, E is replaced with type

        // Iterable allows you to use your collection in a for each loop,
        // forces you to return iterator, then can use for each loop (doesn't
        // makes sense atm - adam)
        List<String> words = new ArrayList<String>();
        List<Integer> nums = new ArrayList<>();
    }
}
