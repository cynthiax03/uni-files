package restaurant;

import java.util.List;

public class HappyHourCharging implements ChargingStrategy {

    @Override
    public double calcCost(List<Meal> order, boolean isMember) {

    }
}
