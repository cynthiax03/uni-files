package restaurant;

import java.util.List;

public class HolidayCharging {

    @Override
    public double calcCost(List<Meal> order, boolean isMember) {

    }
}
