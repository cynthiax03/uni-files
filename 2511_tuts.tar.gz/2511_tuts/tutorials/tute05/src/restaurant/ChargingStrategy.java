package restaurant;

import java.util.List;

public class ChargingStrategy {

    @Override
    public double calcCost(List<Meal> order, boolean isMember) {

    }
}
