public class Producer {
    private List<Video> videos;
    private List<User> subscribers;
    private String name;

    private List<UserObserver>;

    public Producer(String name) {
        this.name = name;
        this.subscribers = new ArrayList<>();
        this.videos = new ArrayList<>();
    }

    public void publishVideo(Video video) {
        videos.add(video);
        for (User subscriber : subscribers) {
            subscriber.notifySubscriber(this.getName(), video.getTitle());
        }
    }

    public String getName() {
        retuen name;
    }

}
