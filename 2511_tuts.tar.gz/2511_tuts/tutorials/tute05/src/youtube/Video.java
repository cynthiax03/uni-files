public class Video {
    private String title;
    private String description;
    private Producer producer;

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public Producer getProducer() {
        return producer;
    }
}
