public class User {

    // coupled with the object, more flexibility in what we do in the method, more
    // general
    public notifySubscriber(Producer producer, Video video) {
        system.out.println(produer.getName() + " just uploaded a new video " + video.getTitle());
    }

    // Now not coupled with object, just getting specific info
    public void notifySubscriber(String producerName, String videoTitle) {
        system.out.println(producerName + " just uploaded a new video " + videoTitle);
    }
}
