import socket
from datetime import datetime
import time
import sys

host = sys.argv[1]
port = int(sys.argv[2])

rtts = []
seq = 3331

for ping in range(15) :

    # Create the socket and set timeout to be 600ms
    # AF_INET indicates that the underlying network is using IPv4
    # The second parameter indicates that the socket is a UDP socket 
    # A TCP socket would use SOCK_STREAM
    clientSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    clientSocket.settimeout(0.6)

    message = f"PING {seq} {datetime.now()} \r\n"
    
    # Save start time and send message to the server
    start = time.time()
    clientSocket.sendto(message.encode('utf-8'), (host, port))

    try:
        # UDP: serverSocketUDP.recvfrom(2048)
        # TCP: serverSocketTCP.recv(1024)
        message, server = clientSocket.recvfrom(2048)
        end = time.time()

        # get RTT in ms and add to RTT list
        RTT = round((end - start) * 1000)
        rtts.append(RTT)

        print(f"ping to {host}, seq = {seq}, rtt = {RTT} ms")

    except socket.timeout:
        print(f"ping to {host}, seq = {seq}, rtt = * time out *")

    seq += 1

# Close the socket
clientSocket.close()

# Print min, max and avg RTT at the end
print(f"minimum RTT = {min(rtts)} ms, maximum RTT = {max(rtts)} ms, average \
RTT = {round(sum(rtts)/len(rtts))} ms")

    
