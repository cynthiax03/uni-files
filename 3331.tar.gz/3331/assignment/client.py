"""
    Python 3
    Usage: python3 client.py server_ip server_port udp_server_port 
    coding: utf-8
    
    Author: Cynthia Li
    Sample code taken from Wei Song (Tutor for COMP3331/9331) https://webcms3.cse.unsw.edu.au/COMP3331/22T2/resources/75949
"""
# python3 client.py 127.0.0.1 4000 8000
from threading import Thread
from socket import *
import sys

# Global variables
username = ""
password = ""

# Login process for the user
def userLogin(clientSocket, serverAddress):
    while True:
        global username
        global password

        # Get the response from the server
        serverResponse = clientSocket.recv(1024)
        serverResponse = serverResponse.decode()

        if serverResponse == "Enter username: ":
            # Send username
            username = input(serverResponse)
            clientSocket.sendto(username.encode("utf-8"), serverAddress)

        elif serverResponse == "Invalid username":
            # If username invalid, close client terminal
            print(serverResponse)
            exit(0)

        elif serverResponse == "Enter password: ":
            # Username valid, send password
            password = input(serverResponse)
            clientSocket.sendto(password.encode("utf-8"), serverAddress)

        elif serverResponse == "Invalid password. Please try again":
            print(serverResponse)
            password = input("Enter password: ")
            clientSocket.sendto(password.encode("utf-8"), serverAddress)

        elif serverResponse == "Invalid password. Your account has been blocked. Please try again later":
            # If 5 consecutive failed password attempts, close client terminal
            print(serverResponse)
            exit(0)

        elif serverResponse == "Login successful! Welcome to TOOM!\n":
            # Successful login
            print(serverResponse)
            return

        elif serverResponse == "Your account is blocked due to multiple login failures. Please try again later":
            print(serverResponse)
            exit(0)

        else:
            print(serverResponse)

# Audience thread listens for any videos other users (presenters) send and 
# receives it
class AudienceThread(Thread):
    def __init__(self, udpPort):
        Thread.__init__(self)
        self.udpPort = udpPort
        self.userAlive = True

    def run(self):
        audienceSocket = socket(AF_INET, SOCK_DGRAM)
        audienceSocket.bind(("", self.udpPort))

        while self.userAlive:

            # Receive username and filename from the presenter
            data, presenterAddress = audienceSocket.recvfrom(1024)
            presenter = data.decode('utf-8')

            data, presenterAddress = audienceSocket.recvfrom(1024)
            filename = data.decode('utf-8')

            print(f"\n\nReceiving video: {filename} from {presenter}")

            # Receive the video from the presenter and write to the video
            newFilename = f"{presenter}_{filename}"
            with open(newFilename, "wb") as videoFile:
                # data, presenterAddress = audienceSocket.recvfrom(2048)
                # videoFile.write(data)

                # Some logic taken from: https://www.thepythoncode.com/article/send-receive-files-using-sockets-python
                while True:
                    # Receive bytes and write them to the new file until there 
                    # are no bytes left
                    videoBytes, presenterAddress = audienceSocket.recvfrom(2048)
                    if len(videoBytes) == 0:
                        break
                    videoFile.write(videoBytes)

            print(f"Successfully received {filename} from {presenter}, it is named {newFilename}\n")

            print("Enter one of the following commands (BCM, ATU, SRB, SRM, RDM, OUT, UPD): ")

# Presenter thread sends a video to a given user (audience)
class PresenterThread(Thread):
    def __init__(self, audienceName, audienceAddress, filename):
        Thread.__init__(self)
        self.audienceName = audienceName
        self.audienceAddress = audienceAddress
        self.filename = filename

    def run(self):
        # Create a new socket for presenter
        presenterSocket = socket(AF_INET, SOCK_DGRAM)

        print(f"Uploading {self.filename} to {self.audienceName}")
        presenterSocket.sendto(username.encode('utf-8'), self.audienceAddress)
        presenterSocket.sendto(self.filename.encode('utf-8'), self.audienceAddress)

        # Open the video file and send to the audience
        with open(self.filename, "rb") as videoFile:
            # video = videoFile.read(2048)
            # presenterSocket.sendto(video, self.audienceAddress)

            # Some logic taken from: https://www.thepythoncode.com/article/send-receive-files-using-sockets-python
            while True:
                # Read 2048 bytes and send until there are no bytes left
                videoBytes = videoFile.read(2048)
                if len(videoBytes) == 0:
                    presenterSocket.sendto(videoBytes, self.audienceAddress) 
                    break
                presenterSocket.sendto(videoBytes, self.audienceAddress) 

        print(f"{self.filename} has successfully been uploaded to {self.audienceName}\n")

        # Close connection and stop thread
        presenterSocket.close()
        return

# Checks whether the user is active, and sends video to user if they are active
def uploadFile(clientSocket, serverAddress, commandArgs):
    # Check correct usage of UPD
    if len(commandArgs) != 3:
        print("Incorrect command usage. The UPD command should include a user and a video filename that you wish to send to the user\n")
        return

    user = commandArgs[1]
    filename = commandArgs[2]

    # Get list of current users
    command = "ATU"
    clientSocket.sendall(command.encode())
    data = clientSocket.recv(1024)
    serverResponse = data.decode()

    userIP = ""
    userUDPPort = ""

    # Loop through each active user to see if "user" is active
    activeUsers = serverResponse.split("\n")
    for activeUser in activeUsers:
        activeUserInfo = activeUser.split(", ")

        # If user is found to be active, get its ip and udp port
        if activeUserInfo[0] == user:
            userIP = activeUserInfo[1]
            userUDPPort = int(activeUserInfo[2])

    # If user was not found to be active
    if userIP == "":
        print(f"Error. {user} is offline or not a valid user\n")
        return

    # If the user is active, create a new presenter thread to send the video to
    # the user (audience)
    print(f"User {user} validated")
    userAddress = (userIP, userUDPPort)
    presenterThread = PresenterThread(username, userAddress, filename)
    presenterThread.start()
    presenterThread.join()

if __name__ == "__main__":

    if len(sys.argv) != 4:
        print("\n===== Error usage, python3 client.py server_ip server_port client_udp_server_port======\n")
        exit(0)

    serverHost = sys.argv[1]
    serverPort = int(sys.argv[2])
    udpServerPort = int(sys.argv[3])

    serverAddress = (serverHost, serverPort)

    # define a socket for the client side, used to communicate with the server
    clientSocket = socket(AF_INET, SOCK_STREAM)

    # build connection with the server
    clientSocket.connect(serverAddress)

    # Log the user in if their credentials are valid
    userLogin(clientSocket, serverAddress)

    # Upload the udp port and clients ip address to the server
    clientSocket.sendto(str(udpServerPort).encode("utf-8"), serverAddress)

    # Create a udp server/audience thread to listen for video uploads
    audienceThread = AudienceThread(udpServerPort)
    audienceThread.daemon = True
    audienceThread.start()

    while True:

        command = input("Enter one of the following commands (BCM, ATU, SRB, SRM, RDM, OUT, UPD): ")
        
        # If the command is UPD, do not send command to server
        commandArgs = command.split()
        if commandArgs[0] == "UPD":
            # Start presenter thread
            uploadFile(clientSocket, serverAddress, commandArgs)
            continue

        # Else send command to server
        clientSocket.sendall(command.encode())

        # receive response from the server
        data = clientSocket.recv(1024)
        serverResponse = data.decode()

        # parse the message received from server and take corresponding actions
        if serverResponse == "":
            print("Message from server is empty!")

        elif serverResponse == f"Bye {username}":
            print(serverResponse)
            clientSocket.close()
            exit(0)

        else:
            print(serverResponse)

    clientSocket.close()
