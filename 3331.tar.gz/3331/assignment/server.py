"""
    Python 3
    Usage: python3 server.py serverPort numConsecutiveFailedAttempts
    coding: utf-8

    Author: Cynthia Li
    Sample code for multi-threaded server taken from Wei Song (Tutor for COMP3331/9331)
    https://webcms3.cse.unsw.edu.au/COMP3331/22T2/resources/75946 
"""

from socket import *
from threading import Thread
from datetime import datetime
import sys, select
import collections
import time
import os

# SERVER INITIATION ###########################################################

# Check correct number of arguments were entered
if len(sys.argv) != 3:
    print("\n===== Error usage, python3 server.py serverPort numConsecutiveFailedAttempts ======\n")
    exit(0)

serverHost = ""
serverPort = int(sys.argv[1])
numConsecutiveFailedAttempts = sys.argv[2]
serverAddress = (serverHost, serverPort)

# If the numConsecutiveFailedAttempts is not an integer between 1 and 5
if (not numConsecutiveFailedAttempts.isdigit()) or ((not int(numConsecutiveFailedAttempts) in range(1, 6))):
    print(f"\nInvalid number of allowed failed consecutive attempts: {numConsecutiveFailedAttempts}. The valid value of argument number is an integer between 1 and 5\n")
    exit(0)

numConsecutiveFailedAttempts = int(numConsecutiveFailedAttempts)

# define socket for the server side and bind address
serverSocket = socket(AF_INET, SOCK_STREAM)
serverSocket.bind(serverAddress)

# Create a dictionary for usernames and their corresponding block times, blocked
# users will be added to this dict
blockedUsers = {}
activeUserCount = 0

# MULTI THREAD CLASS FOR CLIENT ###############################################
"""
    Define multi-thread class for client
    This class would be used to define the instance for each connection from each client
    For example, client-1 makes a connection request to the server, the server will call
    class (ClientThread) to define a thread for client-1, and when client-2 make a connection
    request to the server, the server will call class (ClientThread) again and create a thread
    for client-2. Each client will be runing in a separate therad, which is the multi-threading
"""

class ClientThread(Thread):
    def __init__(self, clientAddress, clientSocket):
        Thread.__init__(self)
        self.clientAddress = clientAddress
        self.clientSocket = clientSocket
        self.clientAlive = False
        self.username = ""

        print("===== New connection created for: ", clientAddress)
        self.clientAlive = True

    # Checks if the username is a valid username
    def checkUsername(self, username):
        f = open("credentials.txt", "r")
        credentials = f.readlines()
        f.close()

        for credential in credentials:
            # Split the line by whitespace
            info = credential.split()
            if info[0] == username:
                return True

        # If no user has the corresponding username
        return False

    # Checks if the password matches the password stored in credentials
    def checkPassword(self, username, password):
        f = open("credentials.txt", "r")
        credentials = f.readlines()
        f.close()

        for credential in credentials:
            # Split the line by whitespace
            info = credential.split()
            if info[0] == username and info[1] == password:
                return True

        # If the password is not correct
        return False

    def userLogin(self):
        # Prompt user to enter username
        loginMessage = "Enter username: "
        self.clientSocket.send(loginMessage.encode())

        # Receive username from client and check if it is valid
        username = self.clientSocket.recv(1024)
        username = username.decode()
        print(f"{username} is attempting to login")

        # If username does not exist, terminate connection
        if self.checkUsername(username) is False:
            print(f"{username} tried to login but username is invalid")
            message = "Invalid username"
            self.clientSocket.send(message.encode())
            self.clientAlive = False
            return

        # If the user is in the blockedUsers and they are currently blocked
        if username in blockedUsers and (blockedUsers[username] + 10) > time.time():
            print(f"{username} tried to login but their account is blocked due to multiple login failures\n")
            message = "Your account is blocked due to multiple login failures. Please try again later"
            self.clientSocket.send(message.encode())
            self.clientAlive = False
            return

        # Username is valid, prompt user to enter password
        message = "Enter password: "
        self.clientSocket.send(message.encode())

        for numAttempts in range(0, numConsecutiveFailedAttempts):
            # Receive password from client and check if it's correct
            password = self.clientSocket.recv(1024)
            password = password.decode()

            # If password is correct
            if self.checkPassword(username, password) is True:
                print(f"{username} successfully logged in\n")
                message = "Login successful! Welcome to TOOM!\n"
                self.clientSocket.send(message.encode())
                self.addActiveUser(username)
                self.username = username
                break

            # If the number of numAttempts reaches numConsecutiveFailedAttempts,
            # terminate connection and block account for 10 seconds
            elif (numAttempts + 1) == numConsecutiveFailedAttempts:
                print(f"{username} has attempted to login unsuccessfully {numConsecutiveFailedAttempts} times, their account has been blocked for 10 seconds\n")
                message = "Invalid password. Your account has been blocked. Please try again later"
                self.clientSocket.send(message.encode())
                blockedUsers[username] = time.time()
                self.clientAlive = False

            else:
                # Prompt the user to re-enter password
                print(f"{username} has entered an incorrect password")
                message = "Invalid password. Please try again"
                self.clientSocket.send(message.encode())

    # Once user successfully logs in, add active user to userlog
    def addActiveUser(self, username):
        # Receive the udp port and client ip from client after login
        udpPort = self.clientSocket.recv(1024)
        udpPort = int(udpPort.decode())

        clientIP = clientSocket.getsockname()[0]

        # Get active user seq number
        global activeUserCount
        activeUserCount = activeUserCount + 1
        userSeqNum = activeUserCount

        # Get current timestamp
        timestamp = datetime.now()
        timestamp = timestamp.strftime("%d %b %Y %H:%M:%S")

        file = open("userlog.txt", "a")
        file.write(f"{userSeqNum}; {timestamp}; {username}; {clientIP}; {udpPort}\n")
        file.close()

    # Logs a user out
    def userLogout(self):
        self.clientAlive = False
        print(f"{self.username} has logged out")
        self.removeActiveUser()
        logoutMessage = f"Bye {self.username}"
        self.clientSocket.send(logoutMessage.encode())

    # Removes an active user from userlog when they log out
    def removeActiveUser(self):
        print(f"Removing {self.username} from userlog")
        global activeUserCount
        activeUserCount -= 1

        # Remove active user from userlog
        # Some logic taken from: https://stackoverflow.com/questions/4710067/how-to-delete-a-specific-line-in-a-file 
        with open("userlog.txt", "r+") as file:
            activeUsers = file.readlines()
            file.seek(0)
            for user in activeUsers:
                # split the user information into a list
                userInfo = user.split("; ")
                if userInfo[2] != self.username:
                    file.write(user)
            file.truncate()

        self.updateActiveUsers()

    # Updates active user sequence numbers in userlog after a user logs out
    def updateActiveUsers(self):
        print("Updating active users\n")
        with open("userlog.txt", "r") as file:
            # read all lines in userlog
            activeUsers = file.readlines()

        # Update each active user seq number
        for i in range(0, len(activeUsers)):
            userInfo = activeUsers[i]
            userInfoList = userInfo.split("; ")
            userInfoList[0] = i + 1
            userInfo = "; ".join(str(info) for info in userInfoList)
            activeUsers[i] = userInfo

        # Write updated info back to the file
        activeUsers = "".join(str(user) for user in activeUsers)
        with open("userlog.txt", "w") as file:
            file.writelines(activeUsers)

    # Downloads all active users (not including current user) if there are any
    def DownloadActiveUsers(self):
        print("Downloading active users")

        with open("userlog.txt", "r") as file:
            # read all lines in userlog
            activeUsers = file.readlines()

        # If current user is the only active user
        if len(activeUsers) == 1:
            returnMessage = "There are currently no other active users\n"
            print(f"Return message:\n{returnMessage}")
            self.clientSocket.send(returnMessage.encode())
            return

        # Create a list of active users to return
        returnList = []

        for user in activeUsers:
            # Split the user info into a list
            userInfo = user.split("; ")

            # If user is current user, do not add to list
            if userInfo[2] != self.username:
                # Add user to return list in the format f"{user}, {ipAddress}, {udpPort}, active since {datetime}"
                returnInfo = f"{userInfo[2]}, {userInfo[3]}, {userInfo[4].strip()}, has been active since {userInfo[1]}\n"
                returnList.append(returnInfo)

        returnMessage = "".join(str(user) for user in returnList)
        print(f"Return message:\n{returnMessage}")
        self.clientSocket.send(returnMessage.encode())

    def broadcastMessage(self, message):
        # Get current timestamp
        timestamp = datetime.now()
        timestamp = timestamp.strftime("%d %b %Y %H:%M:%S")

        # Get message number and add message to messagelog
        with open("messagelog.txt", "a+") as file:
            file.seek(0)
            messages = file.readlines()
            messageNumber = len(messages) + 1

        with open("messagelog.txt", "a+") as file:
            file.write(f"{messageNumber}; {timestamp}; {self.username}; {message}\n")   

        print(f"{self.username} broadcasted BCM #{messageNumber} \"{message}\" at {timestamp}\n")
        returnMessage = f"BCM #{messageNumber} \"{message}\" successfully broadcasted at {timestamp}\n"
        self.clientSocket.send(returnMessage.encode())

    # Checks if a user is currently active
    def checkCurrentlyActive(self, user):
        # Get all active users from userlog
        with open("userlog.txt", "r") as file:
            activeUsers = file.readlines()
        
        for activeUser in activeUsers:
            # Split the user info into a list
            userInfo = activeUser.split("; ")
            if userInfo[2] == user:
                return True

        # User is not currently active
        return False

    # Builds a separate room for the list of users if they are all valid users
    # and are currently active
    def separateRoomBuild(self, users):
        # Remove current user if they are in the list
        if self.username in users:
            users.remove(self.username)
            # If they were the only user in the list 
            if len(users) == 0:
                returnMessage = "Error. cannot create a room with only one person\n"
                print(returnMessage)
                self.clientSocket.send(returnMessage.encode())
        
        # Else add the current user to users list
        else:
            users.append(self.username)

        print("Validating users")

        # Check all users exist and are currently active
        for user in users:
            if self.checkUsername(user) is False:
                returnMessage = f"Error. {user} is not a valid user. Users must be valid and currently active\n"
                print(returnMessage)
                self.clientSocket.send(returnMessage.encode())
                return

            elif self.checkCurrentlyActive(user) is False:
                returnMessage = f"Error. {user} is not currently active. Users must be valid and currently active\n"
                print(returnMessage)
                self.clientSocket.send(returnMessage.encode())
                return

        # All users are valid and active
        print("All users validated")   

        # Get list of all chatroom files in the directory
        chatRooms = []
        for file in os.listdir():
            if file.endswith("_messagelog.txt"):
                chatRooms.append(file)

        # Loop through all chat rooms to check if the users already have a chat
        # room together
        for chatRoom in chatRooms:
            # Open chatroom file and get members
            with open(chatRoom, "r") as chatRoomFile:
                members = chatRoomFile.readlines()[0]
                members = members.strip()
                members = members.split(", ")
            
            # If a room with these users already exists
            print(members)
            print(users)
            if (collections.Counter(members) == collections.Counter(users)):
                # get room id
                roomID = chatRoom.split("_")[1]
                returnMessage = f"Error. A separate room with ID: {roomID} has already been created for these users\n"
                print(returnMessage)
                self.clientSocket.send(returnMessage.encode())
                return

        # No chat room with these users exists
        print("Creating new separate room")

        # Create new separate room and messagelog
        roomID = len(chatRooms) + 1
        with open(f"SR_{roomID}_messagelog.txt", "w") as newChatRoom: 
           # Change users list to a string of usernames separated by a comma
           # and write it as the first line in the messagelog
           users = ", ".join(user for user in users)
           newChatRoom.write(f"{users}\n")

        returnMessage = f"Separate chat room has successfully been created, with ID: {roomID}, and users: {users}\n"
        print(returnMessage)
        self.clientSocket.send(returnMessage.encode())

    # Sends a message into a chatroom if the room exists and the user is a
    # a member of that chatroom
    def separateRoomMessage(self, roomID, message):
        # Get list of all chatroom files in the directory
        chatRooms = []
        for file in os.listdir():
            if file.endswith("_messagelog.txt"):
                chatRooms.append(file)

        print(f"Validating chat room ID: {roomID}")

        # Validate the roomID exists
        chatRoom = f"SR_{roomID}_messagelog.txt"
        if chatRoom not in chatRooms:
            returnMessage = f"The separate chat room with ID: {roomID} does not exist\n"
            print(returnMessage)
            self.clientSocket.send(returnMessage.encode())
            return

        print(f"Validating user is a member of chat room {roomID}")

        # Open chatroom file and get members
        with open(chatRoom, "r") as chatRoomFile:
            chatMembers = chatRoomFile.readlines()[0]
            chatMembers = chatMembers.strip()
            chatMembers = chatMembers.split(", ")

        # Validate user is a member of chat room
        if self.username not in chatMembers:
            print(f"{self.username} is not a member of chat room with ID: {roomID}\n")
            returnMessage = f"You are not a member of this chat room\n"
            self.clientSocket.send(returnMessage.encode())
            return

        # Get current timestamp
        timestamp = datetime.now()
        timestamp = timestamp.strftime("%d %b %Y %H:%M:%S")

        # Get message number
        with open(chatRoom, "r+") as file:
            messageList = file.readlines()
            # No need to add one to length as first line is members of the chat
            messageNumber = len(messageList)

        # Add message to messagelog
        with open(chatRoom, "a+") as file:
            file.write(f"{messageNumber}; {timestamp}; {self.username}; {message}\n") 

        # Message successfully sent
        print(f"{self.username} sent SRM #{messageNumber} \"{message}\" at {timestamp} in separate room {roomID}\n")
        returnMessage = f"SRM #{messageNumber} \"{message}\" successfully sent at {timestamp} in separate room {roomID}\n"
        self.clientSocket.send(returnMessage.encode())
    
    # Gets all broadcast messages after timestamp
    def getBroadCastMessages(self, timestamp, timestampStr):
        print(f"Fetching broadcast messages after {timestampStr}")
        # Open messagelog and get all messages
        with open("messagelog.txt", "a+") as file:
            file.seek(0)
            messageList = file.readlines()

        # Create return list
        returnList = []

        # Loop through the messageList
        for message in messageList:
            # Get curr message timestamp and user that sent the message
            messageInfo = message.split("; ")
            currMessageTimestamp = datetime.strptime(messageInfo[1], "%d %b %Y %H:%M:%S")
            currMessageUsername = messageInfo[2]
            if currMessageTimestamp > timestamp and currMessageUsername != self.username:
                returnList.append(message)

        # If no new messages
        if (len(returnList) == 0):
            print(f"No new broadcast messages for {self.username}\n")
            returnMessage = "You have no new broadcast messages\n"
            self.clientSocket.send(returnMessage.encode())
            return

        # Join the list and send to client
        returnMessages = "".join(str(message) for message in returnList)
        print(f"Broadcast messages for {self.username} since {timestampStr}:\n{returnMessages}")
        returnMessage = f"Messages broadcasted since {timestampStr}:\n{returnMessages}"
        self.clientSocket.send(returnMessage.encode())
        return

    # Gets all the messages from separate rooms the user is a part of after the
    # given timestamp
    def getSeparateRoomMessages(self, timestamp, timestampStr):
        print(f"Fetching messages from separate rooms after {timestampStr}")
        
        # Get a list of all separate rooms the user is a part of 
        separateRooms = []
        for file in os.listdir():
            if file.endswith("_messagelog.txt"):
                # Get members in this separate room
                with open(file, "r+") as separateRoom:
                    members = separateRoom.readlines()[0]
                    members = members.strip()
                    members = members.split(", ")

                # Check if user is a member
                if self.username in members:
                    separateRooms.append(file)

        # Loop through all separate rooms the user is a member of and get any
        # messages after the timestamp
        returnMessages = []
        for separateRoom in separateRooms:
            with open(separateRoom, "r+") as file:
                roomMessages = file.readlines()
            
            # Skip first line as it is the list of users
            roomMessages = roomMessages[1:]

            for message in roomMessages:
                # Get curr message timestamp and user that sent the message
                message = message.strip()
                messageInfo = message.split("; ")
                currMessageTimestamp = datetime.strptime(messageInfo[1], "%d %b %Y %H:%M:%S")
                currMessageUsername = messageInfo[2]

                # If current user did not send the message and the message was
                # sent after the timestamp
                if currMessageTimestamp > timestamp and currMessageUsername != self.username:
                    # Get room number
                    roomNumber = separateRoom.split("_")[1]
                    returnMessages.append(f"Room {str(roomNumber)}: #{messageInfo[0]}, {messageInfo[2]}: \"{messageInfo[3]}\" at {messageInfo[1]}\n")

        # If no new messages
        if (len(returnMessages) == 0):
            print(f"No new separate room messages for {self.username}\n")
            returnMessage = "You have no new separate room messages\n"
            self.clientSocket.send(returnMessage.encode())
            return

        # Join the list and send to client
        returnMessages = "".join(str(message) for message in returnMessages)
        print(f"Separate room messages for {self.username} since {timestampStr}:\n{returnMessages}")
        returnMessage = f"Separate room messages since {timestampStr}:\n{returnMessages}"
        self.clientSocket.send(returnMessage.encode())
        return

    # Reads all messages of messageType after the given timestamp
    def readMessages(self, messageType, timestampStr):
        # Check messageType is a valid (either "b" or "s")
        if (messageType != "b" and messageType != "s"):
            print(f"Error. {messageType} is not a valid message type for RDM\n")
            returnMessage = f"Error. Message type was {messageType} but must be \"b\" for BCM or \"s\" for SRM\n"
            self.clientSocket.send(returnMessage.encode())
            return

        # Check timestamp is valid, some logic taken from: https://www.codegrepper.com/code-examples/python/python+check+if+valid+date+format
        try:
            timestamp = datetime.strptime(timestampStr, "%d %b %Y %H:%M:%S")
        except ValueError:
            returnMessage = f"Error. {timestampStr} is not a valid timestamp\n"
            print(returnMessage)
            self.clientSocket.send(returnMessage.encode())
            return

        # If the messageType is broadcast messages
        if (messageType == "b"):
            self.getBroadCastMessages(timestamp, timestampStr)
        
        # Else the messageType is separate room messages
        else:
            self.getSeparateRoomMessages(timestamp, timestampStr)

    # Checks if the command has the right amount of args
    def correctCommandUsage(self, arguments):
        # Incorrect usage for OUT command
        if arguments[0] == "OUT" and len(arguments) != 1:
            returnMessage = "Incorrect command usage. The OUT command should have no arguments\n"
            print(returnMessage)
            self.clientSocket.send(returnMessage.encode())
            return False

        # Incorrect usage for ATU command
        elif arguments[0] == "ATU" and len(arguments) != 1:
            returnMessage = "Incorrect command usage. The ATU command should have no arguments\n"
            print(returnMessage)
            self.clientSocket.send(returnMessage.encode())
            return False

        elif arguments[0] == "BCM" and len(arguments) < 2:
            returnMessage = "Incorrect command usage. The BCM command should include a message to be broadcasted\n"
            print(returnMessage)
            self.clientSocket.send(returnMessage.encode())
            return False

        elif arguments[0] == "SRB" and len(arguments) < 2:
            returnMessage = "Incorrect command usage. The SRB command should include the users you wish to include in the separate chat room\n"
            print(returnMessage)
            self.clientSocket.send(returnMessage.encode())
            return False

        elif arguments[0] == "SRM" and len(arguments) < 3:
            returnMessage = "Incorrect command usage. The SRM command should include the room ID followed by a message to send\n"
            print(returnMessage)
            self.clientSocket.send(returnMessage.encode())
            return False

        elif arguments[0] == "RDM" and len(arguments) != 6:
            returnMessage = "Incorrect command usage. The RDM command should include the message type and the timestamp after which the messages are to be read\n"
            print(returnMessage)
            self.clientSocket.send(returnMessage.encode())
            return False

        return True

    def run(self):
        # Start the login process
        self.userLogin()

        message = ""

        while self.clientAlive:

            # use recv() to receive message from the client and split by space
            data = self.clientSocket.recv(1024)
            message = data.decode()
            messageArgs = message.split()

            print(f"{self.username} entered command \"{message}\"")

            # if the message from client is empty, the client would be off-line then set the client as offline (alive=Flase)
            if len(messageArgs) == 0:
                self.clientAlive = False
                print("===== the user disconnected - ", clientAddress)
                break

            # User requests to logout
            elif messageArgs[0] == "OUT":
                # If incorrect usage of OUT
                if self.correctCommandUsage(messageArgs) is False:
                    continue

                # If correct usage
                self.userLogout()

            # User request all other active users (not including themselves)
            elif messageArgs[0] == "ATU":
                if self.correctCommandUsage(messageArgs) is False:
                    continue

                # If correct usage
                self.DownloadActiveUsers()

            # User requests to broadcast a message
            elif messageArgs[0] == "BCM":
                if self.correctCommandUsage(messageArgs) is False:
                    continue

                # If correct usage, remove BCM from Args
                messageArgs.pop(0)
                message = " ".join(str(word) for word in messageArgs)
                self.broadcastMessage(message)

            # User requests a separate chat room to be built for a list of users
            elif messageArgs[0] == "SRB":
                if (self.correctCommandUsage(messageArgs)) is False:
                    continue

                # If correct usage, remove SRB from args
                users = messageArgs[1:]
                self.separateRoomBuild(users)

            # User requests to send a message in a separate chat room
            elif messageArgs[0] == "SRM":
                if (self.correctCommandUsage(messageArgs)) is False:
                    continue

                # If correct usage, remove SRM from args and split into roomID and message
                roomID = messageArgs[1]
                # TODO turn this into a string not a list
                message = messageArgs[2:]
                message =  " ".join(str(word) for word in message)
                self.separateRoomMessage(roomID, message)

            elif messageArgs[0] == "RDM":
                if (self.correctCommandUsage(messageArgs)) is False:
                    continue
                
                # If correct usage, get messageType and timestamp
                messageType = messageArgs[1]
                timestamp = messageArgs[2:]
                timestamp =  " ".join(str(word) for word in timestamp)
                self.readMessages(messageType, timestamp)

            # Else command is not valid
            else:
                returnMessage = "Error. Invalid command!\n"
                print(returnMessage)
                self.clientSocket.send(returnMessage.encode())

print("\n===== Server is running =====")
print("===== Waiting for connection request from clients...=====\n")

while True:
    serverSocket.listen()
    clientSocket, clientAddress = serverSocket.accept()
    clientThread = ClientThread(clientAddress, clientSocket)
    clientThread.start()
