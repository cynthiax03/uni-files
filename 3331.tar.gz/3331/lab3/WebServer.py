#coding: utf-8
from socket import *
import sys

# Get the port number from input
serverPort = int(sys.argv[1])

# Create the server socket
serverSocket = socket(AF_INET, SOCK_STREAM)

# Binds the port to the server socket
serverSocket.bind(('localhost', serverPort))

# Server listens for client connection requests
serverSocket.listen(1)

print "The server is ready to receive"

while 1:
    # Accepts the client connection, this creates a new socket in the server so
    # that a TCP connection can be established between the client and server
    # sockets. Bytes can now be exchanged (not gauranteed to arrive but will 
    # arrive in order)
    connectionSocket, addr = serverSocket.accept()

    # Get client request and decode (This includes entire HTML response)
    request = connectionSocket.recv(1024).decode()
    # print(request)

    # Split the header up by line and get the first line (GET /index.html HTTP/1.1)
    request = request.split('\r\n')[0]
    # Split by space and get the requested file "/index.html"
    request = request.split(' ')[1]
    # Remove the "/" in front of the file name
    request = request[1:]

    try:
        # Read the file
        file = open(request, "rb")
        f = file.read()

        # Send the HTTP header
        connectionSocket.send("HTTP/1.1 200 OK\r\n")

        
        if "png" in request :
            # If the file was an image
            connectionSocket.send("Content-Type: image/png\r\n\r\n")
        else :
            # If the file was a html
            connectionSocket.send("Content-Type:text/html\r\n\r\n")

        # Send file data
        connectionSocket.send(f)
    
    except:
        # If file is not found, send a 404 not found header
        connectionSocket.send("HTTP/1.1 404 Not Found\r\n")
        connectionSocket.send("Content-Type: text/html \r\n\r\n")
        connectionSocket.send("404 Not Found")
    
    connectionSocket.close()