-- COMP3311 22T3 Final Exam Q5
-- Helper views and functions to support q5
-- You must submit this, even if you don't change it

