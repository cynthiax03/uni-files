python3 ./q5 Flemington abc
