python3 ./q5 xyz 2020-01-01
