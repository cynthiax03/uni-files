python3 ./q5 Flemington 2019-11-02
