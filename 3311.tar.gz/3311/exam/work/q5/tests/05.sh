python3 ./q5 Rosehill 2019-08-10
