python3 ./q5 Flemington 2019-08-10
