-- COMP3311 22T3 Final Exam Q2
-- List of races with only Mares

-- put helper views (if any) here

-- answer: Q2(name,course,date)


create or replace view Q2(name,course,date)
as
select races.name, racecourses.name, meetings.run_on
from horses
join runners on horses.id = runners.horse
join races on runners.race = races.id
join meetings on races.part_of = meetings.id
join racecourses on meetings.run_at = racecourses.id
where horses.gender = 'M'
except
select races.name, racecourses.name, meetings.run_on
from horses
join runners on horses.id = runners.horse
join races on runners.race = races.id
join meetings on races.part_of = meetings.id
join racecourses on meetings.run_at = racecourses.id
where horses.gender != 'M'
;
