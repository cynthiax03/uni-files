-- COMP3311 22T3 Final Exam Q4
-- Function to return average winnings for horses matching a partial name

drop type if exists horse_winnings cascade;
create type horse_winnings as (horse text, average integer);

-- put helper views (if any) here

-- answer: Q4(part_name text) -> setof horse_winnings

create or replace function
    Q4(part_name text) returns setof horse_winnings
as $$
declare 
    tmp horse_winnings;
    currHorse record;
    currWin record;
    total integer;
    races integer;

begin
    for currHorse in 
        select * from horses 
        where lower(horses.name) like ('%' || lower(part_name) || '%')
    loop
        total := 0;
        races := 0;
        tmp.horse = currHorse.name;
        for currWin in 
            select races.prize, runners.finished from horses 
            join runners on runners.horse = horses.id
            join races on runners.race = races.id
            where horses.id = currHorse.id
        loop
            races := races + 1;
            if currWin.finished = 1 then
                total := total + currWin.prize;
            end if;
        end loop;
        tmp.average := total / races;
        if tmp.average > 0 then 
            return next tmp;
        end if;
    end loop;
end;
$$ language plpgsql;
