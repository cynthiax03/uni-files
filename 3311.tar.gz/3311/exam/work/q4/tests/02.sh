psql racing -c "select * from q4('Eddie') order by horse;"
