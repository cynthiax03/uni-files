psql racing -c "select * from q4('sun') order by horse;"
