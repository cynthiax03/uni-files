psql racing -c "select * from q4('x') order by horse;"
