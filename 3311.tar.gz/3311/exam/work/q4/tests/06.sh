psql racing -c "select * from q4('oo') order by horse;"
