psql racing -c "select * from q4('ss') order by horse;"
