psql racing -c "select * from q4('trot') order by horse;"
