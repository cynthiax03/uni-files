psql racing -c "select * from q4('neigh') order by horse;"
