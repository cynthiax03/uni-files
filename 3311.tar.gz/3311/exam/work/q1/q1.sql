-- COMP3311 22T3 Final Exam Q1
-- Horse(s) that have won the most Group 1 races

-- put helper views (if any) here

-- answer: Q1(horse)

create or replace view Q1a(name, wins)
as
select horses.name, count(*) as wins
from horses
join runners on horses.id = runners.horse
join races on runners.race = races.id
where races.level = 1 and runners.finished = 1
group by horses.name
;

create or replace view Q1(horse) 
as
select Q1a.name
from Q1a
where Q1a.wins = (select max(Q1a.wins) from Q1a)
;
