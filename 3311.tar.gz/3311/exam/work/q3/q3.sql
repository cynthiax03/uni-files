-- COMP3311 22T3 Final Exam Q3
-- List Gender/Age for all horses for all races of a specified type

drop type if exists race_horses cascade;
create type race_horses as (race text, horses text);

-- put helper views (if any) here

-- answer: Q3(text) -> setof race_horses

create or replace function Q3(rname text) returns setof race_horses
as
$$

select races.name, stringagg((horses.gender || horses.age), ',' order by horses.gender || horses.age) 
from races
join runners on runners.race = races.id
join horses on runners.horse = horses.id
where races.name like ('%' || rname || '%')
group by races.name;
-- declare
--     currRace text;
--     currHorse text;
--     horses text;
--     tmp race_horses;

-- begin 
--     for currRace in 
--         select races.name from races
--         were races.name like '%' || text || '%'
--     loop
--         for currHorse in 
--         select horses.
--     end loop;

$$
language sql;
