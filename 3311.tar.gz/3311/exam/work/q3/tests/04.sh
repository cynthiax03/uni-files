psql racing -c "select * from q3('Plate') order by race;"
