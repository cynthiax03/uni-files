psql music -c 'select * from q2 order by "group"'
