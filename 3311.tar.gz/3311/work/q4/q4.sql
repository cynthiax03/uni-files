-- COMP3311 20T3 Final Exam
-- Q4: list of long and short songs by each group

-- ... helper views and/or functions (if any) go here ...

drop function if exists q4();
drop type if exists SongCounts;
create type SongCounts as ( "group" text, nshort integer, nlong integer );

create or replace function
	q4() returns setof SongCounts
as $$
declare
	tmp SongCounts;
	currSong record;
	currGroup record;

begin
	for currGroup in 
		select * from groups
		order by groups.name
	loop
		tmp.group := currGroup.name;
		tmp.nshort := 0;
		tmp.nlong := 0;

		for currSong in 
			select * from songs 
			join albums on songs.on_album = albums.id
			join groups on albums.made_by = groups.id
			where albums.made_by = currGroup.id
		loop
			if currSong.length < 180 then
				tmp.nshort := tmp.nshort + 1;
			end if;

			if currSong.length > 360 then
				tmp.nlong := tmp.nlong + 1;
			end if;

		end loop;

		return next tmp;
	end loop;
end;
$$ language plpgsql
;
