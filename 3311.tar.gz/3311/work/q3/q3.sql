-- COMP3311 20T3 Final Exam
-- Q3:  performer(s) who play many instruments

-- ... helper views (if any) go here ...

create or replace view instrumentPlayers(performer, instrument)
as
select performer, instrument
from playson
except
select performer, instrument
from playson
where (playson.instrument = 'vocals' 
or playson.instrument = 'lead guitar'
or playson.instrument = 'rhythym guitar'
or playson.instrument = 'acoustic guitar'
or playson.instrument = 'guitars')
;

create or replace view guitarPlayers(performer)
as
select distinct performer
from playson
where (playson.instrument = 'lead guitar'
or playson.instrument = 'rhythym guitar'
or playson.instrument = 'acoustic guitar'
or playson.instrument = 'guitars')
;

create or replace view q3a(performer, ninstruments)
as
select performers.name as performer, count(playson.instrument)
from playson
join performers on playson.performer = performers.id
join instrumentPlayers on playson.performer = instrumentPlayers.performer
group by performers.name
;

create or replace view q3(performer,ninstruments)
as
select performers.name as performer, count(*) as ninstruments
from playson
join performers on playson.performer = performers.id
join instrumentPlayers on playson.performer = instrumentPlayers.performer
join guitarPlayers on playson.performer = guitarPlayers.performer
group by performers.name
;

