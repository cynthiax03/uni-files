psql music -c 'select * from q3 order by ninstruments desc, performer;'
