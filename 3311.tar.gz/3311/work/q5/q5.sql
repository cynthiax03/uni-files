-- COMP3311 20T3 Final Exam
-- Q5: find genres that groups worked in

-- ... helper views and/or functions go here ...

create or replace view groupGenreCounts ("group", genre, count) as
select groups.name as group, albums.genre, count(albums.genre)
from groups 
join albums on albums.made_by = groups.id
group by groups.name, albums.genre
;

drop function if exists q5();
drop type if exists GroupGenres;

create type GroupGenres as ("group" text, genres text);

create or replace function
    q5() returns setof GroupGenres
as $$
declare
    tmp GroupGenres;
    currGroup record;
    currAlbum record;

begin
    for currGroup in
        select groupGenreCounts.group, string_agg(groupGenreCounts.genre, ',' order by groupGenreCounts.genre) as genres
        from groupGenreCounts
        group by groupGenreCounts.group
    loop
        tmp.group := currGroup.group;
        
        if currGroup.genres is null then
            tmp.genres := '';
            return next temp;
        end if;
        
        if currGroup.genres is not null then
            tmp.genres := currGroup.genres;
            return next tmp;
        end if;
    end loop;
end;
$$ language plpgsql
;

