psql music -c 'select * from Q1 order by album;'
