-- COMP3311 20T3 Final Exam
-- Q1: longest album(s)

-- ... helper views (if any) go here ...

create or replace view albumTimes(id, length)
as
select albums.id, sum(songs.length) as length
from albums
join songs on albums.id = songs.on_album
group by albums.id;

create or replace view q1("group",album,year)
as
select groups.name as group, albums.title as album, albums.year
from groups
join albums on groups.id = albums.made_by
join (select albumTimes.id, albumTimes.length from albumTimes) as lengths 
on lengths.id = albums.id
where lengths.length = (select max(length) from albumTimes)
;

