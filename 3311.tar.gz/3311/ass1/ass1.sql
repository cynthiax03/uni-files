-- COMP3311 22T3 Assignment 1
--
-- Fill in the gaps ("...") below with your code
-- You can add any auxiliary views/function that you like
-- The code in this file *MUST* load into an empty database in one pass
-- It will be tested as follows:
-- createdb test; psql test -f ass1.dump; psql test -f ass1.sql
-- Make sure it can load without error under these conditions


-- Q1: new breweries in Sydney in 2020

create or replace view Q1(brewery,suburb) as
select breweries.name as brewery, locations.town as suburb
from    breweries
    inner join locations on breweries.located_in = locations.id
where   breweries.founded = 2020 and locations.metro = 'Sydney';

-- Q2: beers whose name is same as their style

create or replace view Q2(beer,brewery) as
select beers.name as beer, breweries.name as brewery
from  	brewed_by
    inner join beers on brewed_by.beer = beers.id
    inner join breweries on brewed_by.brewery = breweries.id
    inner join styles on styles.id = beers.style
where 	beers.name = styles.name;

-- Q3: original Californian craft brewery

create or replace view breweries_in_Cali as
select breweries.name, breweries.founded
from 	breweries
    inner join locations on locations.id = breweries.located_in
where  locations.region = 'California';

create or replace view Q3(brewery,founded) as
select 	name as brewery, founded
from 	breweries_in_Cali
where 	founded = (select min(founded) from breweries_in_Cali);

-- Q4: all IPA variations, and how many times each occurs

create or replace view Q4(style,count) as
select styles.name as style, count(*)
from 	styles
    inner join beers on beers.style = styles.id
where	styles.name like '%IPA%'
group 	by styles.name;

-- Q5: all Californian breweries, showing precise location

create or replace view Q5(brewery,location) as
select breweries.name as brewery, coalesce(locations.town, locations.metro) as location
from 	breweries
    inner join locations on breweries.located_in = locations.id
where	locations.region = 'California';

-- Q6: strongest barrel-aged beer

create or replace view barrel_aged_beers as
select beers.abv
from 	beers
    inner join brewed_by on beers.id = brewed_by.beer
    inner join breweries on brewed_by.brewery = breweries.id
where 	beers.notes like '%aged%' and (beers.notes like '%barrel%' or beers.notes like '%barrels%');

create or replace view Q6(beer,brewery,abv) as
select beers.name as beer, breweries.name as brewery, beers.abv
from 	beers
    inner join brewed_by on beers.id = brewed_by.beer
    inner join breweries on brewed_by.brewery = breweries.id
where 	beers.abv = (select max(abv) from barrel_aged_beers);

-- Q7: most popular hop

create or replace view hop_usage as
select ingredients.name, count(*)
from	ingredients
    inner join contains on contains.ingredient = ingredients.id
    inner join beers on contains.beer = beers.id
where 	ingredients.itype = 'hop'
group 	by ingredients.name;

create or replace view Q7(hop) as
select hop_usage.name as hop
from 	hop_usage
where 	hop_usage.count = (select max(hop_usage.count) from hop_usage);

-- Q8: breweries that don't make IPA or Lager or Stout (any variation thereof)

create or replace view Q8(brewery) as
select breweries.name as brewery
from 	breweries
except
select breweries.name as brewery
from 	breweries
    inner join brewed_by on breweries.id = brewed_by.brewery
    inner join beers on brewed_by.beer = beers.id
    inner join styles on styles.id = beers.style
where  (styles.name like '%IPA%')
    or (styles.name like '%Lager%')
    or (styles.name like '%Stout%');

-- Q9: most commonly used grain in Hazy IPAs

create or replace view Hazy_IPA_grains as
select ingredients.name as grain, count(*)
from 	ingredients
    inner join contains on ingredients.id = contains.ingredient
    inner join beers on contains.beer = beers.id
    inner join styles on beers.style = styles.id
where	styles.name = 'Hazy IPA'
    and ingredients.itype = 'grain'
group 	by ingredients.name;

create or replace view Q9(grain) as
select Hazy_IPA_grains.grain
from 	Hazy_IPA_grains
where 	Hazy_IPA_grains.count = (select max(count) from Hazy_IPA_grains);

-- Q10: ingredients not used in any beer

create or replace view Q10(unused) as
select ingredients.name as unused
from 	ingredients
except
select ingredients.name as used
from 	ingredients
    inner join contains on ingredients.id = contains.ingredient
    inner join beers on contains.beer = beers.id;

-- Q11: min/max abv for a given country

drop type if exists ABVrange cascade;
create type ABVrange as (minABV float, maxABV float);

create or replace function
	Q11(_country text) returns ABVrange
as $$
declare
    min float := 100.0;
    max float := 0.0;
    currABV float;
    foundCountry boolean := false;
    ranges ABVrange;

begin
    for currABV in
        select beers.abv from beers
	inner join brewed_by on beers.id = brewed_by.beer
	inner join breweries on brewed_by.brewery = breweries.id
        inner join locations on breweries.located_in = locations.id
        where locations.country = _country
    loop
        foundCountry := true;

        if currABV > max then
            max := currABV;
        end if;

        if currABV < min then
            min := currABV;
        end if;

    end loop;

    if not foundCountry then
        ranges.minABV := 0;
        ranges.maxABV := 0;
        return ranges;
    end if;

    ranges.minABV := min::numeric(4,1);
    ranges.maxABV := max::numeric(4,1);
    return ranges;

end;
$$
language plpgsql;

-- Q12: details of beers

drop type if exists BeerData cascade;
create type BeerData as (beer text, brewer text, info text);

create or replace function
	Q12(partial_name text) returns setof BeerData
as $$
declare
    tmp BeerData;
    beerRec record;
    breweryRec record;
    tmpBreweries text;
    IngredientRec record;
    tmpIngredients text;

begin
    for beerRec in
        select beers.name, beers.id
	from   beers
        where  lower(beers.name) like '%' || lower(partial_name) || '%'

    loop
        tmp.info := '';
	for breweryRec in
	    select string_agg(breweries.name, ' + ') as tmpBreweries
	    from   breweries
	        inner join brewed_by on breweries.id = brewed_by.brewery
	        inner join beers on brewed_by.beer = beers.id
	    where  beers.id = beerRec.id

	loop
	    tmp.brewer := breweryRec.tmpBreweries;
	end loop;

        for ingredientRec in
            select ingredients.itype, string_agg(ingredients.name, ',' order by ingredients.name) as tmpIngredients
            from   ingredients
                inner join contains on ingredients.id = contains.ingredient
                inner join beers on contains.beer = beers.id
            where  beers.id = beerRec.id
            group  by ingredients.itype

        loop
            if found and ingredientRec.itype = 'hop' then
                tmp.info := 'Hops: ' || ingredientRec.tmpIngredients || E'\n';
            end if;

            if found and ingredientRec.itype = 'grain' then
	         tmp.info := tmp.info || 'Grain: ' || ingredientRec.tmpIngredients || E'\n';
            end if;

            if found and ingredientRec.itype = 'adjunct' then
	         tmp.info := tmp.info || 'Extras: ' || ingredientRec.tmpIngredients || E'\n';
            end if;
	    end loop;

        tmp.beer := beerRec.name;
	tmp.info := rtrim(tmp.info, E'\n');

	if tmp.info = '' then
	    tmp.info := null;
	end if;

        return next tmp;
    end loop;
end;
$$
language plpgsql;

