#define CATCH_CONFIG_MAIN
#include <catch2/catch.hpp>

// main entry point of a test suite;
// do not add anything else to this file!
