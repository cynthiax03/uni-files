#include "word_ladder.h"
#include <fstream> 
#include <iostream> 
#include <string> 
#include <queue>
#include <unordered_set>
#include <unordered_map>

// Function to read a dictionary file and convert it into an unordered set of
// strings. Assumption: the path always leads to a file in the valid format.
auto word_ladder::read_lexicon(const std::string &path) -> std::unordered_set<std::string> {

	// Declare an unordered set of strings
	std::unordered_set<std::string> lexicon = {};

	// Open the file specified by path and check it opened properly
	std::ifstream lexicon_file (path);
	if (lexicon_file.is_open()) {

		// Declare a string variable to store the word on each line then loop
		// through each line
		std::string line;
		while(std::getline(lexicon_file, line)) {
			// Store each word into the unordered_set
			lexicon.insert(line);
		}
	}

	// Close the file and return lexicon set
	lexicon_file.close();

	return lexicon;
}

auto word_ladder::generate(
	const std::string &from,
	const std::string &to,
	const std::unordered_set<std::string> &lexicon
) -> std::vector<std::vector<std::string>> {

	// Create a vector of a vector of strings to store final solutions
	std::vector<std::vector<std::string>> solutions = {};

	// Create a queue to store partial ladders (possible solutions)
	std::queue<std::vector<std::string>> q;
	q.push({from});

	// Get the length of the word
	const int word_len = static_cast<int>(from.length());

	// Create an unordered set to track found words on the previous levels (to 
	// prevent cycles)
	std::unordered_set<std::string> found_words = {from};
	std::unordered_set<std::string> curr_level_words = {};

	bool found = false;
	int shortest_hops = 0;
	int curr_hops = 0;

	// Traverse while queue is not empty
	while (q.size() != 0) {
		// Get the partial ladder from the front of the queue, get the last
		// word from it and remove the ladder from the queue
		std::vector<std::string> partial_ladder = q.front();
		std::string curr_word = partial_ladder.back();
		int ladder_size = static_cast<int>(partial_ladder.size());
		q.pop();

		// Stop loop once we find all shortest solutions
		if (found and ladder_size > shortest_hops) {
			break;
		}

		// If the current ladder length is greater than the previous ladder
		// length, add curr_level_words to found_words
		if (ladder_size - 1 > curr_hops) {
			found_words.insert(curr_level_words.begin(), curr_level_words.end());
			curr_level_words.clear();
			curr_hops++;
		}

		// For the current word iterate through each character
		for (int curr_pos = 0; curr_pos < word_len; curr_pos++) {
			// For each letter of the alphabet, check if inserting it into the
			// current position would make a valid word
			for (char c = 'a'; c <= 'z'; c++) {
				std::string possible_word = curr_word;
				possible_word[static_cast<unsigned int>(curr_pos)] = c;

				// If the word is equal to the 'to' word
				if (possible_word == to) {
					// Complete the ladder and get its size
					partial_ladder.push_back(possible_word);
					int hops = static_cast<int>(partial_ladder.size());

					// If a ladder has not been found previously or is the same
					// length as the shortest path
					if (!found or (found and hops <= shortest_hops)) {
						shortest_hops = hops;
						found = true;
						solutions.push_back(partial_ladder);
					} 

				} else {
					// If the word is valid and not found on previous levels add
					// it to the partial ladder and add the partial ladder back 
					// in the queue
					if (lexicon.count(possible_word) and 
					found_words.count(possible_word) == 0) {
						std::vector<std::string> new_ladder = partial_ladder;
						new_ladder.push_back(possible_word);
						q.push(new_ladder);
						curr_level_words.insert(possible_word);
					}
				}
			}
		}
	}

	return solutions;
}