#include "word_ladder.h"

#include <catch2/catch.hpp>
#include <filesystem>
#include <iostream>
#include <fstream>
#include <unistd.h>

TEST_CASE("word_ladder::read_lexicon works as expected") {
	// Test case does not work due to issues writing to file
	// char filename[] = "tmpXXXXXX";
	// int f = mkstemp(filename);
	// close(f);

	// std::ofstream file_ptr (filename);
	// if (file_ptr.is_open()) {
	// 	file_ptr << "hello\n";
		
	// 	const auto expected = std::unordered_set<std::string>{
	// 		{"hello", "world", "post", "man"}
	// 	};

	// 	auto const lexicon = word_ladder::read_lexicon("tmp");

	// 	CHECK(lexicon == expected);
	// }

	// unlink("tmp");
	// file_ptr.close();
}

TEST_CASE("x -> a") {
	auto const lexicon = std::unordered_set<std::string>{
		"x",
		"a"
	};

	const auto expected = std::vector<std::vector<std::string>>{
		{"x", "a"}
	};

	auto const ladders = word_ladder::generate("x", "a", lexicon);

	CHECK(ladders == expected);
}

TEST_CASE("m -> o") {
	auto const lexicon = std::unordered_set<std::string>{
		"m",
		"ate"
		"b",
		"o",
		"h",
		"hi",
		"mole",
		"x"
	};

	const auto expected = std::vector<std::vector<std::string>>{
		{"m", "o"}
	};

	auto const ladders = word_ladder::generate("m", "o", lexicon);

	CHECK(ladders == expected);
}

TEST_CASE("at -> it") {
	auto const lexicon = std::unordered_set<std::string>{
		"at",
		"it"
	};

	const auto expected = std::vector<std::vector<std::string>>{
		{"at", "it"}
	};

	auto const ladders = word_ladder::generate("at", "it", lexicon);

	CHECK(ladders == expected);
}

TEST_CASE("airplane -> bicycle") {
	auto const lexicon = word_ladder::read_lexicon("english.txt");

	const auto expected = std::vector<std::vector<std::string>>{};

	auto const ladders = word_ladder::generate("airplane", "bicycle", lexicon);

	CHECK(ladders == expected);
}

TEST_CASE("abc -> xyz") {
	auto const lexicon = std::unordered_set<std::string>{
		"abc",
		"xyz",
		"bbc",
		"abz",
		"aoz",
	};

	const auto expected = std::vector<std::vector<std::string>>{};

	auto const ladders = word_ladder::generate("abc", "xyz", lexicon);

	CHECK(ladders == expected);
}

TEST_CASE("ecu -> zoo") {
	auto const lexicon = word_ladder::read_lexicon("english.txt");

	const auto expected = std::vector<std::vector<std::string>>{
		{"ecu", "eau", "tau", "tao", "too", "zoo"}
	};

	auto const ladders = word_ladder::generate("ecu", "zoo", lexicon);

	CHECK(ladders == expected);
}

TEST_CASE("hit -> cog") {
	auto const lexicon = word_ladder::read_lexicon("english.txt");

	const auto expected = std::vector<std::vector<std::string>>{
		{"hit","hot","cot","cog"},
		{"hit","hot","hog","cog"}
	};

	auto const ladders = word_ladder::generate("hit", "cog", lexicon);

	CHECK(ladders == expected);
}

TEST_CASE("post -> card") {
	auto const lexicon = word_ladder::read_lexicon("english.txt");

	const auto expected = std::vector<std::vector<std::string>>{
		{ "post", "cost", "cast", "cart", "card" }, 
		{ "post", "past", "cast", "cart", "card" },
		{ "post", "past", "part", "cart", "card" },
		{ "post", "past", "part", "pard", "card" },
		{ "post", "port", "part", "cart", "card" },
		{ "post", "port", "part", "pard", "card" }
	};

	auto const ladders = word_ladder::generate("post", "card", lexicon);

	CHECK(ladders == expected);
}

TEST_CASE("lucky -> charm") {
	auto const lexicon = word_ladder::read_lexicon("english.txt");
	
	const auto expected = std::vector<std::vector<std::string>>{
		{"lucky", "lucks", "locks", "cocks", "cooks", "coops", "chops", "chaps", "chars", "charm"},
		{"lucky", "lucks", "locks", "cocks", "cooks", "coots", "coats", "chats", "chars", "charm"},
		{"lucky", "lucks", "locks", "looks", "cooks", "coops", "chops", "chaps", "chars", "charm"},
		{"lucky", "lucks", "locks", "looks", "cooks", "coots", "coats", "chats", "chars", "charm"},
		{"lucky", "lucks", "locks", "looks", "loops", "coops", "chops", "chaps", "chars", "charm"},
		{"lucky", "lucks", "locks", "looks", "loots", "coots","coats", "chats", "chars", "charm"}
	};

	auto const ladders = word_ladder::generate("lucky", "charm", lexicon);

	CHECK(ladders == expected);
}

// TEST_CASE("atlases -> cabaret") {

// 	auto const lexicon = word_ladder::read_lexicon("english.txt");

// 	const auto expected_ladders = 840;
//  	const auto expected_ladder_length = 58;

// 	auto const ladders = word_ladder::generate("atlases", "cabaret", lexicon);

// 	CHECK(ladders.size() == expected_ladders);
// 	CHECK(ladders[0].size() == expected_ladder_length);
// }
