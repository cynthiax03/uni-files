package main.java.unsw.blackout;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import unsw.utils.Angle;
import main.java.unsw.blackout.Device;
import main.java.unsw.blackout.Satellite;
import static unsw.utils.MathsHelper.getDistance;
import static unsw.utils.MathsHelper.isVisible;

public class RelaySatellite extends Satellite {

    public static final int maxRange = 300000;

    public RelaySatellite(String satelliteId, String type, double height, Angle position) {
        super(satelliteId, type, height, position);
    }

    @Override
    public void setNewPos(int linearV, double height) {
    }

    @Override 
    public ArrayList<String> getEntitiesInRange(Map<String, Satellite> satellites, 
        Map<String, Device> devices) {
        ArrayList<String> inVisibleRange = new ArrayList<>();

        for (String satelliteId : satellites.keySet()) {
            Satellite satellite = satellites.get(satelliteId);
            // if (satellite.getType().equals("RelaySatellite")) {
            //     // Get list of objects in range of relay satellite and check
            //     // if they are visible to the current device
            // }
            // if in range and visible, add to the inRange list
            if (getDistance(satellite.getHeight(), satellite.getPosition(), this.getHeight(), this.getPosition()) < maxRange && 
                    isVisible(satellite.getHeight(), satellite.getPosition(), this.getHeight(), this.getPosition()) &&
                    this.getId() != satelliteId) {
                inVisibleRange.add(satelliteId);
            }
        }

        for (String deviceId : devices.keySet()) {
            Device device = devices.get(deviceId);
            if (getDistance(this.getHeight(), this.getPosition(), device.getPosition()) < maxRange && 
                    isVisible(this.getHeight(), this.getPosition(), device.getPosition())) {
                inVisibleRange.add(deviceId);
            }
        }
        return inVisibleRange; 
    }

    @Override
    public void checkTarget(File file) {
    }

    @Override
    public void checkSender(String filename) {
    }

    @Override
    public int sendSpeed(Satellite receiver) {
        return 0;
    }
}