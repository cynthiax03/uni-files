package main.java.unsw.blackout;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import unsw.utils.Angle;
import unsw.utils.MathsHelper;
import unsw.response.models.EntityInfoResponse;
import unsw.response.models.FileInfoResponse;
import unsw.blackout.FileTransferException;

public abstract class Satellite {
    private String satelliteId;
    private String type;
    private double height;
    private Angle position;
    private int numFilesStored;
    private int numBytesStored;
    private int sendingBandwidthInUse;
    private int receivingBandwidthInUse;
    protected int linearV, direction, maxReceivingBandwidth, maxSendingBandwidth;

    ArrayList<File> files = new ArrayList<File>();

    public Satellite(String satelliteId, String type, double height, Angle position) {
        this.satelliteId = satelliteId;
        this.type = type;
        this.height = height;
        this.position = position;
        this.direction = MathsHelper.CLOCKWISE;
    }

    public String getId() {
        return satelliteId;
    }

    public String getType() {
        return type;
    }

    public double getHeight() {
        return height;
    }

    public Angle getPosition() {
        return position;
    }

    public int getDirection() {
        return direction;
    }

    public int getMaxReceivingBandwidth() {
        return maxReceivingBandwidth;
    }

    public int getMaxSendingBandwidth() {
        return maxSendingBandwidth;
    }


    public void setDirection(int direction) {
        this.direction = direction;
    }

    public boolean isFileInSatellite(String filename) {
        for (File file : files) {
            if ((file.getFilename()).equals(filename)) return true;
        }
        return false;
    }

    public int getNumFilesStored() {
            return numFilesStored;
    }

    public int NumFilesTransferring() {
        int numFiles = 0;
        for (File file : files) {
            if (!file.getHasTransferCompleted()) numFiles++;
        }
        return numFiles;
    }

    public int getNumBytesStored() {
        return numBytesStored;
    }

    public int getSendingBandwidthInUse() {
        return sendingBandwidthInUse;
    }

    public int getReceivingBandwidthInUse() {
        return receivingBandwidthInUse;
    }

    public void updateReceivingBandwidthInUse(int newBandwidth) {
        this.receivingBandwidthInUse = newBandwidth;
    }

    public void updateSendingBandwidthInUse(int newBandwidth) {
        this.sendingBandwidthInUse = newBandwidth;
    }

    public abstract int sendSpeed(Satellite receiver);

    public void addFile(File oldFile, int sendSpeed) {
        File newFile = new File(oldFile.getFilename(), "", oldFile.getFileSize());
        newFile.setSendSpeed(sendSpeed);
        files.add(newFile);
    }

    public File getFile(String filename) {
        for (File file : files) {
            if ((file.getFilename()).equals(filename)) return file;
        }
        return null;
    }

    public EntityInfoResponse getEntityInfoResponse() {
        Map<String, FileInfoResponse> fileMap = new HashMap<>();
        for (File file : files) {
            fileMap.put(file.getFilename(), file.getResponse());
        }
        return new EntityInfoResponse(satelliteId, position, height, type, fileMap);
    }

    public abstract ArrayList<String> getEntitiesInRange(Map<String, Satellite> satellites, 
        Map<String, Device> devices);

    public abstract void checkTarget(File file) throws FileTransferException;

    public abstract void checkSender(String filename) throws FileTransferException;

    public abstract void setNewPos(int linearV, double height);

    public void setPosition(Angle position) {
        this.position = position;
    }

    public void simulate() {
        setNewPos(linearV, height);
    }

}