package main.java.unsw.blackout;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.lang.Math;

import unsw.utils.Angle;
import unsw.utils.MathsHelper;
import main.java.unsw.blackout.Device;
import main.java.unsw.blackout.Satellite;
import static unsw.utils.MathsHelper.getDistance;
import static unsw.utils.MathsHelper.isVisible;
import unsw.blackout.FileTransferException;

public class TeleportingSatellite extends Satellite {

    private final static int maxRange = 200000;
    private final static int maxBytes = 200;

    public TeleportingSatellite(String satelliteId, String type, double height, Angle position) {
        super(satelliteId, type, height, position);
        this.linearV = 1000;
        this.direction = MathsHelper.ANTI_CLOCKWISE;
        this.maxReceivingBandwidth = 15;
        this.maxSendingBandwidth = 10;
    }

    @Override
    public void setNewPos(int linearV, double height) {
        Angle position = super.getPosition();
        Angle movement = Angle.fromRadians((linearV / height));
        Angle newPos;

        if (super.getDirection() == MathsHelper.CLOCKWISE) {
            newPos = position.subtract(movement);
        } else {
            newPos = position.add(movement);
        }

        if (super.getDirection() == MathsHelper.CLOCKWISE 
            && newPos.toDegrees() <= 180) {
            // Change direction to opposite
            super.setDirection(MathsHelper.ANTI_CLOCKWISE);
            super.setPosition(Angle.fromDegrees(0));

        } else if (super.getDirection() == MathsHelper.ANTI_CLOCKWISE
            && newPos.toDegrees() >= 180) {
            super.setDirection(MathsHelper.CLOCKWISE);
            super.setPosition(Angle.fromDegrees(0));

        } else {
            super.setPosition(newPos);
        }

    }

    @Override 
    public ArrayList<String> getEntitiesInRange(Map<String, Satellite> satellites, 
        Map<String, Device> devices) {
        ArrayList<String> inVisibleRange = new ArrayList<>();

        for (String satelliteId : satellites.keySet()) {
            Satellite satellite = satellites.get(satelliteId);
            // if (satellite.getType().equals("RelaySatellite")) {
            //     // Get list of objects in range of relay satellite and check
            //     // if they are visible to the current device
            // }
            // if in range and visible, add to the inRange list
            if (getDistance(satellite.getHeight(), satellite.getPosition(), this.getHeight(), this.getPosition()) < maxRange && 
                    isVisible(satellite.getHeight(), satellite.getPosition(), this.getHeight(), this.getPosition()) &&
                    this.getId() != satelliteId) {
                inVisibleRange.add(satelliteId);
            }
        }

        for (String deviceId : devices.keySet()) {
            Device device = devices.get(deviceId);
            if (getDistance(this.getHeight(), this.getPosition(), device.getPosition()) < maxRange && 
                    isVisible(this.getHeight(), this.getPosition(), device.getPosition())) {
                inVisibleRange.add(deviceId);
            }
        }
        return inVisibleRange; 
    }

    @Override
    public void checkTarget(File file) throws FileTransferException {
        String filename = file.getFilename();
        if (super.isFileInSatellite(filename)) {
            throw new FileTransferException.VirtualFileAlreadyExistsException(filename);
        }
        if (super.getReceivingBandwidthInUse() == maxReceivingBandwidth) {
            throw new FileTransferException.VirtualFileNoBandwidthException(super.getId());
        }
        if (super.getNumBytesStored() + file.getFileSize() > maxBytes) {
            throw new FileTransferException.VirtualFileNoStorageSpaceException("Max Storage Reached");
        }
    }

    @Override
    public void checkSender(String filename) throws FileTransferException {
        if (!super.isFileInSatellite(filename)) {
            throw new FileTransferException.VirtualFileNotFoundException(filename);
        }
        if (super.getSendingBandwidthInUse() == maxSendingBandwidth) {
            throw new FileTransferException.VirtualFileNoBandwidthException(super.getId());
        }
    }

    @Override
    public int sendSpeed(Satellite receiver) {
        // If the sender is a device, just use the receiver's bandwidth to 
        // determine speed
        if (receiver == null) {
            return this.maxSendingBandwidth - super.getSendingBandwidthInUse();
        } else {
            // Return the minimum of the receivers avail bandwidth and the 
            // senders avail bandwidth
            int receiverAvailBandwidth = receiver.getMaxReceivingBandwidth() - receiver.getReceivingBandwidthInUse();
            int senderAvailBandwidth = this.maxSendingBandwidth - super.getSendingBandwidthInUse();
            return Math.min(receiverAvailBandwidth, senderAvailBandwidth);
        }
    }
}