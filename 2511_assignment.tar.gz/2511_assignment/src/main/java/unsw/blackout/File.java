package main.java.unsw.blackout;

import unsw.response.models.FileInfoResponse;

public class File {
    private String filename;
    private String data;
    private int fileSize;
    private boolean hasTransferCompleted;
    private int sendSpeed;

    public File(String filename, String data, int fileSize) {
        this.filename = filename;
        this.data = data;
        this.fileSize = fileSize;

        if (data.length() == fileSize) {
            this.hasTransferCompleted = true;
        } else {
            this.hasTransferCompleted = false;
        }
    }

    public String getFilename() {
        return filename;
    }

    public String getData() {
        return data;
    }

    public int getFileSize() {
        return fileSize;
    }

    public boolean getHasTransferCompleted() {
        return hasTransferCompleted;
    }

    public FileInfoResponse getResponse() {
        return new FileInfoResponse(filename, data, fileSize, hasTransferCompleted);
    }

    public void setSendSpeed(int newSpeed) {
        sendSpeed = newSpeed;
    }
}