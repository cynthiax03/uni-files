package unsw.blackout;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import main.java.unsw.blackout.Device;
import main.java.unsw.blackout.HandheldDevice;
import main.java.unsw.blackout.LaptopDevice;
import main.java.unsw.blackout.DesktopDevice;
import main.java.unsw.blackout.Satellite;
import main.java.unsw.blackout.StandardSatellite;
import main.java.unsw.blackout.RelaySatellite;
import main.java.unsw.blackout.TeleportingSatellite;
import unsw.response.models.EntityInfoResponse;
import unsw.utils.Angle;
import unsw.blackout.FileTransferException;

public class BlackoutController {

    private Map<String, Device> deviceMap = new HashMap<>();
    private Map<String, Satellite> satelliteMap = new HashMap<>();

    public void createDevice(String deviceId, String type, Angle position) {
        switch(type) {
            case "HandheldDevice":
                deviceMap.put(deviceId, new HandheldDevice(deviceId, type, position));
                break;
            case "DesktopDevice":
                deviceMap.put(deviceId, new DesktopDevice(deviceId, type, position));
                break;
            case "LaptopDevice":
                deviceMap.put(deviceId, new LaptopDevice(deviceId, type, position));
        }
    }

    public void removeDevice(String deviceId) {
        deviceMap.remove(deviceId);
    }

    public void createSatellite(String satelliteId, String type, double height, Angle position) {
        switch(type) {
            case "StandardSatellite":
                satelliteMap.put(satelliteId, new StandardSatellite(satelliteId, type, height, position));
                break;
            case "RelaySatellite":
                satelliteMap.put(satelliteId, new RelaySatellite(satelliteId, type, height, position));
                break;
            case "TeleportingSatellite":
                satelliteMap.put(satelliteId, new TeleportingSatellite(satelliteId, type, height, position));
        }
    }

    public void removeSatellite(String satelliteId) {
        satelliteMap.remove(satelliteId);
    }

    public List<String> listDeviceIds() {
        ArrayList<String> deviceIds = new ArrayList<>();
        deviceMap.forEach((id, device) -> deviceIds.add(id));

        return deviceIds;
    }

    public List<String> listSatelliteIds() {
        ArrayList<String> satelliteIds = new ArrayList<>();
        satelliteMap.forEach((id, satellite) -> satelliteIds.add(id));

        return satelliteIds;
    }

    public void addFileToDevice(String deviceId, String filename, String content) {
        Device device = deviceMap.get(deviceId);
        device.addFile(filename, content, 0);
    }

    public EntityInfoResponse getInfo(String id) {
        Device device = deviceMap.get(id);
        if (device != null) return device.getEntityInfoResponse();

        Satellite satellite = satelliteMap.get(id);
        if (satellite != null) return satellite.getEntityInfoResponse();

        return null;
    }

    public void simulate() {
        for (String satelliteId : satelliteMap.keySet()) {
            Satellite satellite = satelliteMap.get(satelliteId);
            satellite.simulate();
        }
    }

    /**
     * Simulate for the specified number of minutes.
     * You shouldn't need to modify this function.
     */
    public void simulate(int numberOfMinutes) {
        for (int i = 0; i < numberOfMinutes; i++) {
            simulate();
        }
    }

    public List<String> communicableEntitiesInRange(String id) {
        // ArrayList<String> entities = new ArrayList<>();

        Device device = deviceMap.get(id);
        if (device != null) {
            // Get entities in range
            return device.getEntitiesInRange(satelliteMap);
        }

        Satellite satellite = satelliteMap.get(id);
        if (satellite != null) {
            return satellite.getEntitiesInRange(satelliteMap, deviceMap);
        }
        // return entities;
        return null;
    }

    public void sendFile(String fileName, String fromId, String toId) throws FileTransferException {
        // Check if file exists in sender (fromId)
        Device device = deviceMap.get(fromId);
        Satellite satellite = satelliteMap.get(fromId);
        Satellite targetS = satelliteMap.get(toId);
        Device targetD = deviceMap.get(toId);

        // If device and target are valid, compatible and in range of one another
        if (device != null && targetS != null && device.isCompatabile(device, targetS)
            && communicableEntitiesInRange(fromId).contains(toId)) {
            // Check whether they are in range of each other and do not raise 
            // any file exceptions
            device.checkSender(fileName);
            targetS.checkTarget(device.getFile(fileName));
            targetS.addFile(device.getFile(fileName), targetS.sendSpeed(null));
            targetS.updateReceivingBandwidthInUse(targetS.sendSpeed(null));

        } else if (satellite != null && targetS != null 
            && communicableEntitiesInRange(fromId).contains(toId)) {
            satellite.checkSender(fileName);
            targetS.checkTarget(satellite.getFile(fileName));
            targetS.addFile(satellite.getFile(fileName), targetS.sendSpeed(satellite));
            satellite.updateSendingBandwidthInUse(targetS.sendSpeed(satellite));
            targetS.updateReceivingBandwidthInUse(targetS.sendSpeed(satellite));

        } else if (satellite != null && targetD != null && device.isCompatabile(device, satellite)
            && communicableEntitiesInRange(fromId).contains(toId)) {
            satellite.checkSender(fileName);
            targetD.checkTarget(fileName);
            targetD.addFile(fileName, "", targetD.sendSpeed(satellite));
            satellite.updateSendingBandwidthInUse(targetD.sendSpeed(satellite));
        }
    }

    public void createDevice(String deviceId, String type, Angle position, boolean isMoving) {
        createDevice(deviceId, type, position);
        // TODO: Task 3
    }

    public void createSlope(int startAngle, int endAngle, int gradient) {
        // TODO: Task 3
        // If you are not completing Task 3 you can leave this method blank :)
    }

}
