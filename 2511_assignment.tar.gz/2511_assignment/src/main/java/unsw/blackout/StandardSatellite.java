package main.java.unsw.blackout;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import unsw.utils.Angle;
import main.java.unsw.blackout.Device;
import main.java.unsw.blackout.Satellite;
import static unsw.utils.MathsHelper.getDistance;
import static unsw.utils.MathsHelper.isVisible;
import unsw.blackout.FileTransferException;

public class StandardSatellite extends Satellite{

    private static final int maxRange = 150000;
    private static final int maxBandwidth = 1;
    private static final int maxFiles = 3;
    private static final int maxBytes = 80;


    public StandardSatellite(String satelliteId, String type, double height, Angle position) {
        super(satelliteId, type, height, position);
        this.linearV = 2500;
    }

    @Override
    public void setNewPos(int linearV, double height) {
        Angle movement = Angle.fromRadians((linearV / height));
        Angle pos = super.getPosition();
        super.setPosition(pos.subtract(movement));
    }

    @Override 
    public ArrayList<String> getEntitiesInRange(Map<String, Satellite> satellites, 
        Map<String, Device> devices) {
        ArrayList<String> inVisibleRange = new ArrayList<>();

        for (String satelliteId : satellites.keySet()) {
            Satellite satellite = satellites.get(satelliteId);
            // if (satellite.getType().equals("RelaySatellite")) {
            //     // Get list of objects in range of relay satellite and check
            //     // if they are visible to the current device
            // }
            // if in range and visible, add to the inRange list
            if (getDistance(satellite.getHeight(), satellite.getPosition(), this.getHeight(), this.getPosition()) < maxRange && 
                    isVisible(satellite.getHeight(), satellite.getPosition(), this.getHeight(), this.getPosition()) &&
                    this.getId() != satelliteId) {
                inVisibleRange.add(satelliteId);
            }
        }

        for (String deviceId : devices.keySet()) {
            Device device = devices.get(deviceId);
            if (getDistance(this.getHeight(), this.getPosition(), device.getPosition()) < maxRange && 
                    isVisible(this.getHeight(), this.getPosition(), device.getPosition())) {
                inVisibleRange.add(deviceId);
            }
        }
        return inVisibleRange; 
    }

    @Override
    public void checkTarget(File file) throws FileTransferException {
        String filename = file.getFilename();
        if (super.isFileInSatellite(filename)) {
            throw new FileTransferException.VirtualFileAlreadyExistsException(filename);
        }
        if (super.getReceivingBandwidthInUse() == maxBandwidth) {
            throw new FileTransferException.VirtualFileNoBandwidthException(super.getId());
        }
        if (super.getNumFilesStored() == maxFiles) {
            throw new FileTransferException.VirtualFileNoStorageSpaceException("Max Files Reached");
        } 
        if (super.getNumBytesStored() + file.getFileSize() > maxBytes || super.getNumFilesStored() == 3) {
            throw new FileTransferException.VirtualFileNoStorageSpaceException("Max Storage Reached");
        }
    }

    @Override
    public void checkSender(String filename) throws FileTransferException {
        if (!super.isFileInSatellite(filename)) {
            throw new FileTransferException.VirtualFileNotFoundException(filename);
        }
        if (super.getSendingBandwidthInUse() == maxBandwidth) {
            throw new FileTransferException.VirtualFileNoBandwidthException(super.getId());
        }
    }

    @Override
    public int sendSpeed(Satellite receiver) {
        return maxBandwidth;
    }
}