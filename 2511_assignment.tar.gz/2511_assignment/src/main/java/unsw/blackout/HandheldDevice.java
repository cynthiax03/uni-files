package main.java.unsw.blackout;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import unsw.utils.Angle;
import main.java.unsw.blackout.Device;
import main.java.unsw.blackout.Satellite;
import static unsw.utils.MathsHelper.getDistance;
import static unsw.utils.MathsHelper.isVisible;


public class HandheldDevice extends Device {

    public static final int maxRange = 50000;

    public HandheldDevice(String deviceId, String type, Angle position) {
        super(deviceId, type, position);
    }

    @Override
    public ArrayList<String> getEntitiesInRange(Map<String, Satellite> satellites) {
        ArrayList<String> inRange = new ArrayList<>();
        for (String satelliteId : satellites.keySet()) {
            Satellite satellite = satellites.get(satelliteId);
            // if (satellite.getType().equals("RelaySatellite")) {
            //     // Get list of objects in range of relay satellite and check
            //     // if they are visible to the current device
            // }
            // if in range and visible, add to the inRange list
            if (getDistance(satellite.getHeight(), satellite.getPosition(), this.getPosition()) < maxRange && 
                    isVisible(satellite.getHeight(), satellite.getPosition(), this.getPosition())) {
                inRange.add(satelliteId);
            }
            
        }
        return inRange;  
    }
}
