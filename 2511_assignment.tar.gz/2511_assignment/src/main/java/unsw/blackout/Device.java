package main.java.unsw.blackout;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import unsw.utils.Angle;
import unsw.response.models.EntityInfoResponse;
import unsw.response.models.FileInfoResponse;
import static unsw.utils.MathsHelper.RADIUS_OF_JUPITER;
import main.java.unsw.blackout.Satellite;
import unsw.blackout.FileTransferException;

public abstract class Device {
    private String deviceId;
    private String type;
    private Angle position;

    private double height = RADIUS_OF_JUPITER;
    private ArrayList<File> files = new ArrayList<>();

    public Device(String deviceId, String type, Angle position) {
        this.deviceId = deviceId;
        this.type = type;
        this.position = position;
    }

    public String getId() {
        return deviceId;
    }

    public String getType() {
        return type;
    }

    public Angle getPosition() {
        return position;
    }

    public void addFile(String filename, String content, int sendSpeed) {
        File file = new File(filename, content, content.length());
        file.setSendSpeed(sendSpeed);
        files.add(file);
    }

    public ArrayList<File> getFiles() {
        return files;
    }

    public File getFile(String filename) {
        for (File file : files) {
            if ((file.getFilename()).equals(filename)) return file;
        }
        return null;
    }

    public boolean isFileInDevice(String filename) {
        for (File file : files) {
            if ((file.getFilename()).equals(filename)) return true;
        }
        return false;
    }

    public EntityInfoResponse getEntityInfoResponse() {
        Map<String, FileInfoResponse> fileMap = new HashMap<>();
        for (File file : files) {
            fileMap.put(file.getFilename(), file.getResponse());
        }
        return new EntityInfoResponse(deviceId, position, height, type, fileMap);
    }

    public abstract ArrayList<String> getEntitiesInRange(Map<String, Satellite> satellites);

    public boolean isCompatabile(Device device, Satellite target) {
        if (device.getType() == "DesktopDevice" && target.getType() == "StandardSatellite") {
            return false;
        }
        return true;
    }

    public void checkSender(String filename) throws FileTransferException {
        if (!isFileInDevice(filename)) {
            throw new FileTransferException.VirtualFileNotFoundException(filename);
        }
    }

    public void checkTarget(String filename) throws FileTransferException {
        if (isFileInDevice(filename)) {
            throw new FileTransferException.VirtualFileAlreadyExistsException(filename);
        }
    }

    public int sendSpeed(Satellite sender) {
        // If the receiver is a device, just use the sender's bandwidth to 
        // determine speed
        return sender.getMaxSendingBandwidth() - sender.getSendingBandwidthInUse();
    }
}