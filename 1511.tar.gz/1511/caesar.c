// z5359629
// COMP1511 Lab07 Encrypting Text With a Caesar Cipher
// A program that reads characters from its input and writes the 
// characters
// to its output with a caesar cipher.
// This program was written by Xinyue (Cynthia) Li (z5359629)
// on 6 April 2021

#include <stdio.h>
#include <stdlib.h>

int encrypt_uppercase(int character, int shift);
int encrypt_lowercase(int character, int shift);

int main(int argc, char *argv[]) {

    int shift = atoi(argv[1]);
    int character;
    while ((character = getchar()) != EOF) {
        if (character >= 'a' && character <= 'z') {
            putchar(encrypt_lowercase(character, shift));
        } else if (character >= 'A' && character <= 'Z') {
            putchar(encrypt_uppercase(character, shift));
        } else {
            putchar(character);
        }
    }
    
    return 0;
}

int encrypt_lowercase(int character, int shift) {
    while (shift < 0) {
        shift = shift + 26;
    }
    int alphabet_position = character - 'a';  
    int new_position = (alphabet_position + shift) % 26;
    int encrypted_character;
    encrypted_character = 'a' + new_position;
    return encrypted_character;
}

int encrypt_uppercase(int character, int shift) {
    while (shift < 0) {
        shift = shift + 26;
    }
    int alphabet_position = character - 'A';
    int new_position = (alphabet_position + shift) % 26;
    int encrypted_character;
    encrypted_character = 'A' + new_position;
    return encrypted_character;
}
