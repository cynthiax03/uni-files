//z5359629 comp1511 week 2 lab exercise 1
#include <stdio.h>

int main(void) {
    
    int input = -1;
    scanf ("%d", &input);
    
    if (input < 0) {
        printf("Don't be so negative!\n");
    } else if (input > 0) {
        printf("You have entered a positive number.\n");
    } else {
        printf("You have entered zero.\n");
    }
    return 0;
}

