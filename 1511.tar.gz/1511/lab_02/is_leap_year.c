//z5359629
//Feb 2021
//comp1511 week 2 lab exercise 2 leap year calculator

#include <stdio.h>

int main(void) {
    int year = -1;
    
    //Ask for year
    printf("Enter year:");
    scanf("%d\n", &year);
    
    //Calculate if it is a leap year
    int total1 = year % 4;
    int total2 = year % 100;
    int total3 = year % 400;
    
    if (total1 != 0) {
        printf("%d is not a leap year.\n", year);
    } else if (total2 != 0) {
        printf("%d is a leap year.\n", year);
    } else if (total3 != 0) {
        printf("%d is not a leap year.\n", year);
    } else {
        printf("%d is a leap year.\n", year);
    }
    
    return 0;
}


