//z5359629
//feb 2021
//week 2 lab exercise 2 addition

#include <stdio.h>

int main(void) {
    int students = -1;
    int tutors = -1;
    
    //Ask for number of students and tutors
    printf("Please enter the number of students and tutors:");
    scanf("%d %d", &students, &tutors);
    
    //Store sum
    int sum = students + tutors;
    
    //Display sum
    printf("%d + %d = %d\n", students, tutors, sum);
    
    return 0;
}
