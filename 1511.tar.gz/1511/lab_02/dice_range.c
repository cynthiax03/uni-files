/*z5359629
comp1511 lab 2 challenge exercise dice range
March 2021
a program that reads the number of sides on a set of dice and how
 many are being rolled, then outputs the range of possible totals 
 that these dice can produce and the average value. */

#include <stdio.h>

int main(void) {
    int number_of_sides = -1;
    int number_of_dice = -1;
    
    //Ask for the number of sides
    printf("Enter the number of sides on your dice:");
    scanf("%d\n", &number_of_sides);
    
    //Ask for number of dice
    printf("Enter the number of dice being rolled:");
    scanf("%d\n", &number_of_dice);
    
    if (number_of_sides > 0 && number_of_dice > 0) {
        //Find range
        int min_value = number_of_dice;
        int max_value = number_of_sides * number_of_dice;
    
        //Give dice range
        printf("Your dice range is %d to %d.\n", number_of_dice,
        number_of_dice * number_of_sides);
    
        //Give average value
        printf("The average value is %lf\n", (min_value + max_value)
        /(2 * 1.00) );
    } else {
        printf("These dice will not produce a range.\n");
    }
    
    return 0;
}
    
  
