//z5359629
//Feb 2021
//comp1511 week 2 lab exercise 3 Numbers to Words

#include <stdio.h>

int main(void) {
    
    int number = -1;
    
    //Ask for a number
    printf("Please enter an integer:");
    scanf ("%d\n", &number);
    
    //Word message
    if (number > 5) {
        printf("You entered a number greater than five.\n");
    } else if (number < 1) {
        printf ("You entered a number less than one.\n");
    } else if (number == 1) {
        printf("You entered one.\n");
    } else if (number == 2) {
        printf("You entered two.\n");
    } else if (number == 3) {
        printf("You entered three.\n");
    } else if (number == 4) {
        printf("You entered four.\n");
    } else {
        printf("You entered five.\n");
    }
        
    return 0;
}
        
        


    
