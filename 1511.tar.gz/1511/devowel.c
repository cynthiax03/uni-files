// z5359629
// Comp1511 Devowelling Text
// a program which reads characters from its input and writes the same 
// characters to its output except without any lower case vowels
// This program was written by xinyue (cynthia) li (z5359629)
// on 2 April 2021

#include <stdio.h>

int is_vowel(int character);

int main(void) {
    
    // Read characters until EOF
    int character = getchar();
    while (character != EOF) {
        // If the character is not a lowercase vowel, the character
        // will be printed through putchar
        if (is_vowel(character) != 1) {
            putchar(character);          
        }
        character = getchar();
    }
    
    return 0;
}

// A function that determines whether a character is a lower case vowel
// or not, If the chracter is a lower case vowel, it will return 1
// If not, it will return 0
int is_vowel(int character) {
    int lower_vowel = 0;
    if (character == 'a') {
        lower_vowel++;
    } else if (character == 'e') {
        lower_vowel++;
    } else if (character == 'i') {
        lower_vowel++;
    } else if (character == 'o') {
        lower_vowel++;
    } else if (character == 'u') {
        lower_vowel++;
    }
    
    return lower_vowel;
}
