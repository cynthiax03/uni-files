// exam_q6.c
//
// This program was written by Xinyue (Cynthia) Li (z5359629)
// on May 1st 2021
//
// This program reads characters from standard input and checks whether 
// the sequence has valid brackets

#include <stdio.h>
#include <stdlib.h>

int checker(char character);

// somehow use stacks

int main(void) {
    int valid = 1;
    char character;
    while ((character = getchar()) != EOF) {
        if (character == '(') {
            char next_char;
            while ((next_char = getchar()) != EOF && next_char != ')') {
                
            }
        }    
    }
    if (valid == 1) {
        printf("Valid Sequence!\n");
    } else {
        printf("Invalid Sequence, the correct closing sequence is:\n");
    }
}

int checker(char character) {
    if (character == '(') {
        while ((next_char = getchar()) != EOF && next_char != ')') {
            
        }   
    } else if (character == '{') {
        while ((next_char = getchar()) != EOF && next_char != '}') {
        
        }        
    } else if (character == '[') {
        while ((next_char = getchar()) != EOF && next_char != ']') {
        
        }       
    } else if (character == '<') {
        while ((next_char = getchar()) != EOF && next_char != '>') {
        
        }       
    }
    
}
