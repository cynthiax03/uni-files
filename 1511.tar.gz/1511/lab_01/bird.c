// Lab exercise 2: creating an ASCII Bird

#include <stdio.h>

int main(void) {

    printf("  ___\n"
          " ('v')\n"
         "((___))\n"
          " ^   ^\n");

    return 0;
}
