// z5359629
// COMP1511 lab07 Print out command line arguments in lower case
// A program that reads command line arguments then prints them out all 
// in lower case
// This program was written by Xinyue (Cynthia) Li (z5359629)
// on 2 April 2021

#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main(int argc, char *argv[]) {
    
    int i = 1;
    while (i < argc) {
        int j = 0;
        while (j < (strlen(argv[i]))) {
            // If the character is an upper case letter it will be 
            // changed to a lower case letter
            if (argv[i][j] >= 'A' && argv[i][j] <= 'Z') {
                argv[i][j] = argv[i][j] + 32;
            }
            printf("%c", argv[i][j]);
            j++;
        }
        i++;    
    }
    
    printf("\n");
    
    return 0;
}
