// exam_q5.c
//
// This program was written by Xinyue (Cynthia) Li (z5359629)
// on May 1st 2021
//
// this program reads command line arguments and returns the least common
// one

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define MAX_ARGS 1000

int main(int argc, char *argv[]) {

    int least_common = 100;
    int value = 1;
    int i = 1;
    while (i < argc) {
        int j = 0;
        int counter = 0;
        while (j < argc) {
            if ((strcmp(argv[i], argv[j])) == 0) {
                counter++;
            }
            j++;
        }
        if (least_common > counter) {
            least_common = counter;
            value = i;
        } 
        i++;
    }
    
    printf("%s", argv[value]);

    return 0;
}
