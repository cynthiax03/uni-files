// z5359629
// COMP1511 lab04 exercise 3: Painterbot
// A program that scans indices until EOF then prints a one dimensional
// array which has 36 0s, except the given indices has a 1

#include <stdio.h>

#define SIZE 36


int main(void) {
    int array[SIZE] = {0};
    
    int position = 35;
    int counter = 0;
    
    while (scanf("%d", &position) == 1 && counter < SIZE) {
        if (position < SIZE) {
            array[position] = 1;
        }
        counter++;
    }
    
    int i = 0;
    while (i < SIZE) {
        printf("%d", array[i]);
        i++;
    }
    
    printf("\n");
    
    return 0;
}
