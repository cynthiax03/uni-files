// Slide
// slide.c
//
// This program was written by Xinyue (Cynthia) Li (z5359629)
// on 14 March 2021
//
// Version 1.0.0 (2021-03-08): Initial Assignment Release

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define SIZE 15
#define EMPTY 0
#define STONE 1

void print_map(int map[SIZE][SIZE], int laser_y);
void shoot_laser (int laser_y, int map[SIZE][SIZE]);
void tnt_damage (int laser_y, int i, int map[SIZE][SIZE]);
void shift_everything_left (int map[SIZE][SIZE]);
int check_win (int map[SIZE][SIZE]);
int check_lose (int map[SIZE][SIZE]);
void rotate_clockwise (int map[SIZE][SIZE]);
void rotate_anticlockwise (int map[SIZE][SIZE]);

int main (void) {    
    
    // This line creates our 2D array called "map" and sets all
    // of the blocks in the map to EMPTY
    int map[SIZE][SIZE] = {EMPTY};

    // This line creates our laser_y variable. The laser starts in the
    // middle of the map, at position 7
    int laser_y = SIZE / 2;

    // Ask user for number of blocks and scan in number of blocks
    int num_blocks;
    printf("How many blocks? ");
    scanf("%d", &num_blocks);


    // Ask user for blocks and scan in blocks
    printf("Enter blocks:\n");
    int i = 0;
    int row;
    int column;
    int value;
    while (i < num_blocks) {
        scanf("%d %d %d", &row, &column, &value);
        // Place the blocks into the array
        // Blocks with value 1 will be stones, blocks with a value
        // >= 4 or <= 9 will be TNT blocks
        if (row >= 0 && row < 15)  {
            if (column >= 0 && column < 15) {
                map[row][column] = value;
            }
        }
        i++;
    } print_map(map, laser_y); 
    
    // Integer to determine whether game is lost
    int lose = 0;
    
    // Integer which will record the number of rotations of the map
    // when the number of rotations becomes 1, it will hit the rotate
    // limit and will not rotate again
    int rotate_limit = 0;
    
    // The game will stop scanning in commands and end when it is won
    // or lost
    int end = 0;
    int command;
    while (end == 0 && scanf("%d", &command) == 1) {
        if (command == 1) {
            // Command 1 shifts the laser pointer up or down by one unit
            int direction;
            scanf("%d", &direction);
            if (direction == 1 && laser_y < 14) {
                // Down
                laser_y++;
            } else if (direction == -1 && laser_y > 0) {
                // Up
                laser_y--;
            }   
        } else if (command == 2) {
            // Command 2 shoots the laser
            shoot_laser(laser_y, map);
            // Win conditions are checked
            check_win(map);
        } else if (command == 3) { 
            // Command 3 shifts everything on the map left one unit
            if (check_lose(map) == 1) {
                // Lose conditions are checked
                lose++;
            }
            shift_everything_left(map);                           
        } else if (command == 4) {
            // Command 4 rotates the map
            int direction;
            scanf("%d", &direction); 
            if (direction == 1 && rotate_limit == 0) {
                // Direction 1 rotates the map clockwise
                rotate_clockwise(map);
                rotate_limit++;                
            } else if (direction == 2 && rotate_limit == 0) {
                // Direction 2 rotates the map anticlockwise
                rotate_anticlockwise(map);
                rotate_limit++;
            }
        }

        print_map(map, laser_y);
        
        if (check_win(map) == 1) {
            printf("Game Won!\n");
            // Game is won so the game will end
            end++;
        } else if (lose == 1) {
            printf("Game Lost!\n");
            // Game is lost so the game will end
            end++;
        }         
    }
    return 0;
}

// Print out the contents of the map array 
// Also print out a > symbol to denote the current laser position
void print_map(int map[SIZE][SIZE], int laser_y) {
    int i = 0;
    while (i < SIZE) {
        if (i == laser_y) {
            printf("> ");
        } else {
            printf("  ");
        }
        int j = 0;
        while (j < SIZE) {
            printf("%d ", map[i][j]);
            j++;
        }
        printf("\n");
        i++;
    }
}

// A function that shoots the laser to destroy stones and TNT
// destroyed areas become empty or 0
// The laser can destroy at most 4 stones and they do not have to be 
// next to each other
// If the laser hits a TNT, the TNT will explode
// the laser cannot hit anything behind the TNT
// TNT explosions do not set off other TNT explosions
void shoot_laser (int laser_y, int map[SIZE][SIZE]) {
    int i = 0;
    int max_damage = 0;
    while (i < 15 && max_damage < 4) {
        if (map[laser_y][i] == STONE) {
            map[laser_y][i] = EMPTY;
            max_damage++;
        } else if (map[laser_y][i] >= 4 && map[laser_y][i] <= 9) {
            tnt_damage(laser_y, i, map);
            map[laser_y][i] = EMPTY;
            max_damage = 4;
        }     
        i++;
    }
    
}

// A function that determines the level of damage of TNT and causes
// the TNT damage
// The value of the TNT block determines its damage, the value is
// equivalent to the radius of a circle and everything in the radius
// will be destroyed if the TNT explodes
void tnt_damage (int laser_y, int i, int map[SIZE][SIZE]) {
    int row = 0;
    while (row < 15) {
        int column = 0;
        while (column < 15) {
            int x = row - laser_y;
            int y = column - i;
            int distance = sqrt((x*x) + (y*y));
            if (distance < map[laser_y][i] && distance != 0) {
                map[row][column] = EMPTY;
            }
            column++;
        }    
        row++;
    } 
}

// A function that shifts everything on the map left by one position
// If there is any object in the left most column, the map will not  
// shift
void shift_everything_left (int map[SIZE][SIZE]) {
    int row = 0; 
    while (row < 15) {
        int column = 0; 
        int shift_max = 0;          
        while (column < 15) {
            if (map[row][column] > 0 && shift_max > 0) {
                map[row][shift_max - 1] = map[row][column];
                map[row][column] = EMPTY;                
            }
            column++;
            shift_max++;
        }
        row++;
    }
}

// A function that checks win condition
// A game is won when there are no objects on the map
int check_win (int map[SIZE][SIZE]) {
    int row = 0;
    int objects = 0;
    int win = 0;
    while (row < 15) {
        int column = 0;
        while (column < 15) {
            objects += map[row][column]; 
            column++;
        }
        row++;
    }
    if (objects == 0) {
        win = 1;
    }
    return win;
}

// A function that checks the lose condition
// The lose condition is when there is any object in the left most column
int check_lose (int map[SIZE][SIZE]) {
    int row = 0;
    int column = 0;
    int objects = 0;
    int object_left = 0;
    while (row < 15) {
        objects += map[row][column];
        row++;
    }
    if (objects > 0) {
        object_left = 1;
    }
    return object_left;
}

// A function that rotates the map clockwise by 90 degrees
// A copy of the map is made to record the values of the map in the 
// rotated coordinates
// The normal map is cleared 
// The coordinates of the values in the copy are fed back into the
// normal map
void rotate_clockwise (int map[SIZE][SIZE]) {
    int copy[SIZE][SIZE] = {EMPTY};
    int row = 0;
    while (row < 15) {    
        int column = 0;
        while (column < 15) {
            if (map[row][column] > 0) {                
                copy[column][14 - row] = map[row][column]; 
            } 
            column++; 
        }
        row++;
    }    
    row = 0;
    while (row < 15) {    
        int column = 0;
        while (column < 15) {
            map[row][column] = 0;
            if (copy[row][column] > 0) {                
                map[row][column] = copy[row][column];
            }
            column++;
        }               
        row++;
    }           
}

// A function that rotates the map anticlockwise by 90 degrees
// A copy of the map is made to record the values of the map in the 
// rotated coordinates
// The normal map is cleared 
// the coordinates of the values in the copy are fed back into the 
// normal map
void rotate_anticlockwise(int map[SIZE][SIZE]) {
    int copy[SIZE][SIZE] = {EMPTY};
    int row = 0;
    while (row < 15) {    
        int column = 0;
        while (column < 15) {
            if (map[row][column] > 0) {                
                copy[14 - column][row] = map[row][column]; 
            }
            column++; 
        }
        row++;
    }
    row = 0;
    while (row < 15) {    
        int column = 0;
        while (column < 15) {
            map[row][column] = 0;
            if (copy[row][column] > 0) {                
                map[row][column] = copy[row][column];
            }
            column++;
        }               
        row++;
    }
}
