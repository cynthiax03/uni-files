// z5359629
// COMP1511 Lab07 Encrypting Text With a Substitution Cipher
// A program that reads characters from its input and writes the 
// characters to its output encrypted with a substitution cipher.
// This program was written by Xinyue (Cynthia) Li (z5359629)
// on 6 April 2021

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
    
    int character;
    int alphabet_position;
    int encrypted_character;
    while ((character = getchar()) != EOF) {
        if (character >= 'a' && character <= 'z') {
            alphabet_position = character - 'a';
            encrypted_character = argv[1][alphabet_position];
            putchar(encrypted_character);
        } else if (character >= 'A' && character <= 'Z') {
            alphabet_position = character - 'A';
            encrypted_character = argv[1][alphabet_position] - 32;
            putchar(encrypted_character);
        } else {
            putchar(character);
        }
    }
}


