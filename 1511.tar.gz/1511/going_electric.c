// z5359629
// COMP1511 lab04 challenge exercise 2: Help Route an Electric Car 
// Along a Long Road

#include <stdio.h>

int main(void) {
    
    //scan in litres of fuel at each stop
    while(scanf("%d", &litres) == 1) {
        
