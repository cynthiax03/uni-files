// z5359629
// COMP1511 lab04 exercise 4: cs calculator
// This program will scan in instructions until EOF
// If the first number in the instruction is 1, the program will print 
// out the square of the next number in the instruction
// If the first number in the instruction is 2, the program will print
// out the value of the the nest number raised to the power of the 
// number after that

#include <stdio.h>

// int answer_a(int integer_2);
int answer_b(int integer_2, int integer_3);

int main(void) {

    int instruction;
    int integer;
    int power = 0;
    
    // Ask user for instructions
    printf("Enter instruction: ");
    
    // Scan in first integer
    while (scanf("%d", &instruction) == 1) {
    
        // Answers for instrucrion 1 and 2
        if (instruction == 1) {
            scanf("%d", &integer);
            printf("%d\n", integer * integer);
        } else {
            scanf("%d", &integer);
            scanf("%d", &power);
            printf("%d\n", answer_b(integer, power));
        } 
        
        // Ask user for instructions again
        printf("Enter instruction: ");
    }
}

// Function for second instruction
int answer_b(int integer, int power) {
    int i = 0;
    int answer_b = 1;
    while (i < power) {
        answer_b = answer_b * integer;
        i++;
    }
    
    return answer_b;
}
