// z5359629
// COMP1511 swap_case.c
// A program that reads characters from its inputs and returns the same 
// characters to its output except all the lower case letters are 
// converted to upper case and all the upper case letters are converted //
// to lower case
// This program was written by Xinyue (Cynthia) Li (z5359629)
// on 2 April 2021
 
#include <stdio.h>

int swap_case(int character);

int main(void) {

    // Reads characters until EOF
    int character = getchar();
    while (character != EOF) {
        
        // Change lower case to upper case and upper case to lower case
        int new_character = swap_case(character);
        putchar(new_character);
        
        character = getchar();
    }

    return 0;
}

// A function that changes characters from upper case to lower case and 
// vice versa
// Returns character in lower case if it is an upper case letter
// Returns character in upper case if it is an lower case letter
// Returns the character unchanged otherwise
int swap_case(int character) {
    if (character >= 'a' && character <= 'z') {
        int alphabet_position = character - 'a';
        return 'A' + alphabet_position;
    } else if (character >= 'A' && character <= 'Z') {
        int alphabet_position = character - 'A';
        return 'a' + alphabet_position;
    } else {
        return character;
    }
}
