////////////////////////////////////////////////////////////////////////
// COMP1521 21t2 -- Assignment 2 -- shuck, A Simple Shell
// <https://www.cse.unsw.edu.au/~cs1521/21T2/assignments/ass2/index.html>
//
// Written by Xinyue(Cynthia) Li (z5359629) on 29/07/2021.
//
// 2021-07-12    v1.0    Team COMP1521 <cs1521@cse.unsw.edu.au>
// 2021-07-21    v1.1    Team COMP1521 <cs1521@cse.unsw.edu.au>
//     * Adjust qualifiers and attributes in provided code,
//       to make `dcc -Werror' happy.
//

#include <sys/types.h>

#include <sys/stat.h>
#include <sys/wait.h>

#include <assert.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <spawn.h>
#include <ctype.h>
#include <glob.h>

#define MAX_PATH_SIZE 256

//
// Interactive prompt:
//     The default prompt displayed in `interactive' mode --- when both
//     standard input and standard output are connected to a TTY device.
//
static const char *const INTERACTIVE_PROMPT = "shuck& ";

//
// Default path:
//     If no `$PATH' variable is set in Shuck's environment, we fall
//     back to these directories as the `$PATH'.
//
static const char *const DEFAULT_PATH = "/bin:/usr/bin";

//
// Default history shown:
//     The number of history items shown by default; overridden by the
//     first argument to the `history' builtin command.
//     Remove the `unused' marker once you have implemented history.
//
static const int DEFAULT_HISTORY_SHOWN __attribute__((unused)) = 10;

//
// Input line length:
//     The length of the longest line of input we can read.
//
static const size_t MAX_LINE_CHARS = 1024;

//
// Special characters:
//     Characters that `tokenize' will return as words by themselves.
//
static const char *const SPECIAL_CHARS = "!><|";

//
// Word separators:
//     Characters that `tokenize' will use to delimit words.
//
static const char *const WORD_SEPARATORS = " \t\r\n";

static void execute_command(char **words, char **path, char **environment);
static void do_exit(char **words);
static int is_executable(char *pathname);
static char **tokenize(char *s, char *separators, char *special_chars);
static void free_tokens(char **tokens);

// Functions
// subset 1 functions
static void run_program(char **words, char **path, char **environment);
static char *make_path(char *program, char **path);
static int number_of_args(char **file);

// subset 2 functions
static void save_history (char **words);
static char *get_shuck_history_path(void);
static void history_n_command(char **words);
static int number_of_lines(void);
static void print_all_history(int n_lines);
static void print_last_n_lines_of_history(int n_lines, int n);
static void run_last_command(char **words, char **path, char **environment);
static int too_many_args (char **args);
static void run_nth_command(char **words, char **path, char **environment);

// subset 3 functions
static char **globber(char **words);
static bool check_glob_chars(char *words);

// subset 4 functions
static bool input_redirection_initial_check (char **words);
static bool is_file(char *file);
static bool is_readable(char *file);
static void input_redirection(char **words, char **path, char **environment);
static bool is_builtin(char *command);
static bool check_output_redirection_command(char **words);
static int find_char(char **words, char *c);
static bool is_writable(char *file);
static void output_redirection(char **words, char **path, char **environment);

int main (void)
{
    // Ensure `stdout' is line-buffered for autotesting.
    setlinebuf(stdout);

    // Environment variables are pointed to by `environ', an array of
    // strings terminated by a NULL value -- something like:
    //     { "VAR1=value", "VAR2=value", NULL }
    extern char **environ;

    // Grab the `PATH' environment variable for our path.
    // If it isn't set, use the default path defined above.
    char *pathp;
    if ((pathp = getenv("PATH")) == NULL) {
        pathp = (char *) DEFAULT_PATH;
    }
    char **path = tokenize(pathp, ":", "");

    // Should this shell be interactive?
    bool interactive = isatty(STDIN_FILENO) && isatty(STDOUT_FILENO);

    // Main loop: print prompt, read line, execute command
    while (1) {
        // If `stdout' is a terminal (i.e., we're an interactive shell),
        // print a prompt before reading a line of input.
        if (interactive) {
            fputs(INTERACTIVE_PROMPT, stdout);
            fflush(stdout);
        }

        char line[MAX_LINE_CHARS];
        if (fgets(line, MAX_LINE_CHARS, stdin) == NULL)
            break;

        // Tokenise and execute the input line.
        char **command_words =
            tokenize(line, (char *) WORD_SEPARATORS, (char *) SPECIAL_CHARS);
        execute_command(command_words, path, environ);
        free_tokens(command_words);
    }

    free_tokens(path);
    return 0;
}


//
// Execute a command, and wait until it finishes.
//
//  * `words': a NULL-terminated array of words from the input command line
//  * `path': a NULL-terminated array of directories to search in;
//  * `environment': a NULL-terminated array of environment variables.
//
static void execute_command(char **words, char **path, char **environment)
{
    assert(words != NULL);
    assert(path != NULL);
    assert(environment != NULL);

    char *program = words[0];

    if (program == NULL) {
        // nothing to do
        return;
    }
    
    // subset 4: input/output redirection
    // input redirection
    // check if '<' exists anywhere in words
    if (find_char(words, "<")) {         
        // if < is in words but is not the first word, error
        if (strcmp(*words, "<") != 0) {
            fprintf(stderr, "invalid input redirection\n");
        }    
        // if < is the first word
        else {
            // if there are no initial errors, redirect input to the file
            if (input_redirection_initial_check(words)) {                
                save_history(words);
                input_redirection(words, path, environment);   
            }
        }         
    }
    
    // output redirection;
    // check whether > exists anywhere in words
    else if (find_char(words, ">")) {
        // check if there are any initial errors
        // if there are no initial errors, redirect output to the file
        if (check_output_redirection_command(words)) {
            save_history(words);
            output_redirection(words, path, environment);
        }
    }

    else if (strcmp(program, "exit") == 0) {
        do_exit(words);
        // `do_exit' will only return if there was an error.
        return;
    }
    
    // subset 0: cd and pwd
    // if command is pwd 
    else if (strcmp(*words, "pwd") == 0) {
        char pathname[MAX_PATH_SIZE];
        // find current directory and print
        char *curr_directory = getcwd(pathname, MAX_PATH_SIZE);
        printf("current directory is '%s'\n", curr_directory);
        save_history(words);
    } 
    
    // if command is cd
    else if (strcmp(*words, "cd") == 0) {
        // save commands to history, then check if any commands need to be 
        // globbered
        save_history(words);
        globber(words);
        // if there is more than one argument, change directories 
        char **new_directory = words;
        new_directory++;
        if (*new_directory != NULL) {
            // test if the directory exists
            // change directories to the given directory if it exists
            if (chdir(*new_directory) != 0) {
                fprintf(stderr, "cd: %s: No such file or directory\n", *new_directory);   
            }   
        } 
        // if no argument after cd command, the directory is changed to 
        // the directory in the HOME environment variable
        else if (*new_directory == NULL) {
            char *string = getenv("HOME");
            chdir(string);
        }
    } 
    
    // subset 2: making history
    // history command
    else if (strcmp(*words, "history") == 0) {
        char **arg = words;
        arg++;
        // if n is specified, print out the nth last commands 
        if (*arg != NULL) {
            history_n_command(words);
        }
        // if n is not specified, print out the last 10 commands
        if (*arg == NULL) {            
            // check if there are 10 lines in history
            int n_lines = number_of_lines();
            // if there are less than 10 lines in history, print all of history
            if (n_lines < 10) {
                print_all_history(n_lines);
            }
            // print the last 10 lines of history
            else {
                print_last_n_lines_of_history(n_lines, 10);
            }
        }
        save_history(words);  
    } 
    
    // ! command
    else if (strcmp(*words, "!") == 0) {
        words++;
        // if command is just "!" run the last command
        if (*words == NULL) {
            run_last_command(words, path, environment);
        } 
        // if there are args after !
        else {
            // check if there are too many args
            if (too_many_args(words)) {
                fprintf(stderr, "!: too many arguments\n");
            } 
            // if there is only one arg
            else {
                run_nth_command(words, path, environment);
            }
        }  
    }    
    
    // subset 1: running a program
    else {        
        // save words to history then globber
        save_history(words);
        globber(words);
        run_program(words, path, environment);
    }   
}

//
// Implement the `exit' shell built-in, which exits the shell.
//
// Synopsis: exit [exit-status]
// Examples:
//     % exit
//     % exit 1
//
static void do_exit(char **words)
{
    assert(words != NULL);
    assert(strcmp(words[0], "exit") == 0);

    int exit_status = 0;

    if (words[1] != NULL && words[2] != NULL) {
        // { "exit", "word", "word", ... }
        fprintf(stderr, "exit: too many arguments\n");

    } else if (words[1] != NULL) {
        // { "exit", something, NULL }
        char *endptr;
        exit_status = (int) strtol(words[1], &endptr, 10);
        if (*endptr != '\0') {
            fprintf(stderr, "exit: %s: numeric argument required\n", words[1]);
        }
    }

    exit(exit_status);
}


//
// Check whether this process can execute a file.  This function will be
// useful while searching through the list of directories in the path to
// find an executable file.
//
static int is_executable(char *pathname)
{
    struct stat s;
    return
        // does the file exist?
        stat(pathname, &s) == 0 &&
        // is the file a regular file?
        S_ISREG(s.st_mode) &&
        // can we execute it?
        faccessat(AT_FDCWD, pathname, X_OK, AT_EACCESS) == 0;
}


//
// Split a string 's' into pieces by any one of a set of separators.
//
// Returns an array of strings, with the last element being `NULL'.
// The array itself, and the strings, are allocated with `malloc(3)';
// the provided `free_token' function can deallocate this.
//
static char **tokenize(char *s, char *separators, char *special_chars)
{
    size_t n_tokens = 0;

    // Allocate space for tokens.  We don't know how many tokens there
    // are yet --- pessimistically assume that every single character
    // will turn into a token.  (We fix this later.)
    char **tokens = calloc((strlen(s) + 1), sizeof *tokens);
    assert(tokens != NULL);

    while (*s != '\0') {
        // We are pointing at zero or more of any of the separators.
        // Skip all leading instances of the separators.
        s += strspn(s, separators);

        // Trailing separators after the last token mean that, at this
        // point, we are looking at the end of the string, so:
        if (*s == '\0') {
            break;
        }

        // Now, `s' points at one or more characters we want to keep.
        // The number of non-separator characters is the token length.
        size_t length = strcspn(s, separators);
        size_t length_without_specials = strcspn(s, special_chars);
        if (length_without_specials == 0) {
            length_without_specials = 1;
        }
        if (length_without_specials < length) {
            length = length_without_specials;
        }

        // Allocate a copy of the token.
        char *token = strndup(s, length);
        assert(token != NULL);
        s += length;

        // Add this token.
        tokens[n_tokens] = token;
        n_tokens++;
    }

    // Add the final `NULL'.
    tokens[n_tokens] = NULL;

    // Finally, shrink our array back down to the correct size.
    tokens = realloc(tokens, (n_tokens + 1) * sizeof *tokens);
    assert(tokens != NULL);

    return tokens;
}


//
// Free an array of strings as returned by `tokenize'.
//
static void free_tokens(char **tokens)
{
    for (int i = 0; tokens[i] != NULL; i++) {
        free(tokens[i]);
    }
    free(tokens);
}

// subset 1 functions:
// executes a program
static void run_program(char **words, char **path, char **environment) {
    char *program = words[0];
    if (strrchr(program, '/') == NULL) {
        program = make_path(program, path);
    } 
      
    if (is_executable(program)) {
        char *file = program;
        pid_t pid;
            
        // Find the number of args there are 
        int number_of_words = number_of_args(words);
        
        // save args to argv
        char *argv[number_of_words + 1];
        int i = 0;
        for (char **curr = words; *curr != NULL && i < number_of_words; curr++) {
            argv[i] = *curr;
            i++;   
        }
        argv[number_of_words] = NULL;            
        
        // spawn process
        int spawn_error = posix_spawn(&pid, file, NULL, NULL, argv, environment); 
        
        if (spawn_error != 0) {
            perror("spawn");
        }
        
        int exit_status;
        if (waitpid(pid, &exit_status, 0) == -1) {
            perror("waitpid");
        }
            
        printf("%s exit status = %d\n", program, (exit_status >>= 8));
            
    } else {
        // If the program does not exist
        fprintf(stderr, "%s: command not found\n", program);
    }
}

// iterates through path and finds the path of a program if it exists
static char *make_path(char *program, char **path) {
    char *pathname = malloc(sizeof(char) * MAX_PATH_SIZE);
    int found = 0;            
    for (char **curr = path; *curr != NULL && found == 0; curr++) {
        // make a copy of the path
        pathname = strcpy(pathname, *curr);
        pathname = strcat(pathname, "/");
        pathname = strcat(pathname, program);
        if (is_executable(pathname)) {
            found++; 
            program = pathname;    
        }
    }
    return program;   
}

// counts the number of words there are and returns the amount
static int number_of_args(char **words) {
    int number_of_args = 0;
    for (char **curr = words; *curr != NULL; curr++) {
        number_of_args++;
    }
    return number_of_args;
}

// subset 2 functions
// saves words to history
static void save_history (char **words) {
    char *filepath = get_shuck_history_path();
    FILE *output = fopen(filepath, "a");
    for (char **curr = words; *curr != NULL; curr++) {
        fprintf(output, "%s ", *curr);  
    } 
    fprintf(output, "\n");
    free(filepath);
    fclose(output);
}

// returns the path for .shuck_history
static char *get_shuck_history_path(void) {
    char *filename = "/.shuck_history";
    char *home = getenv("HOME");
    char *filepath = malloc(sizeof(char) * MAX_PATH_SIZE);
    filepath = strcpy(filepath, home);
    filepath = strcat(filepath, filename);
    return filepath;
}    

// when command is history n, if valid command, prints the last n lines of 
// history        
static void history_n_command(char **words) {
    char **arg = words;
    arg += 2;
    // check if there is more than one command
    // if there is more than one command, error
    if (*arg != NULL) {
        fprintf(stderr, "history: too many arguments\n");
    } 
    
    // if there is only command
    else {
        arg--;     
        // check if the arg is numerical, if not, error
        if (isdigit(*arg[0]) == 0) {
            fprintf(stderr, "history: %s: numeric argument required\n", *arg);
        } 
        
        // there is one numerical arg, prints the last n commands
        // in history
        else {            
            // check if numerical arg > amount of lines in history
            int n_lines = number_of_lines();
            char **nth_command = words;
            nth_command++;
            int n = atoi(*nth_command);
            
            // if n > lines in history, print all of history
            if (n > n_lines) {
                print_all_history(n_lines);
            } 
            
            // if there are only n lines in history, print out the 
            // last n lines
            else {
                print_last_n_lines_of_history(n_lines, n);
            }  
        }
    }
}

// counts the number of lines in history
static int number_of_lines(void) {
    char *filepath = get_shuck_history_path();
    FILE *output = fopen(filepath, "r");
    int line_counter = 0;
    int byte = fgetc(output);
    while (byte != EOF) {
        if (byte == '\n') {
            line_counter++;
        }
        byte = fgetc(output);
    }
    fclose(output);
    free(filepath);
    return line_counter;
}

// prints all lines in stored in .shuck_history
static void print_all_history(int n_lines) {
    char *filepath = get_shuck_history_path();
    FILE *file = fopen(filepath, "r");
    char nth_line[MAX_LINE_CHARS];
    for (int line_count = 0; line_count < n_lines; line_count++) {
        fgets(nth_line, MAX_LINE_CHARS, file);
        printf("%d: %s", line_count, nth_line);
    }   
    fclose(file);
    free(filepath);
}

// prints the last n lines of .shuck_history
static void print_last_n_lines_of_history(int n_lines, int n) {
    char *filepath = get_shuck_history_path();
    FILE *file = fopen(filepath, "r");
    char nth_line[MAX_LINE_CHARS];
    for (int line_count = 0; line_count < n_lines; line_count++) {
        fgets(nth_line, MAX_LINE_CHARS, file);
        if (line_count >= (n_lines - n)) {
            printf("%d: %s", line_count, nth_line);
        }
    }   
    fclose(file);
    free(filepath);
}

// runs the last command stored in .shuck_history
static void run_last_command (char **words, char **path, char **environment) {
    // open history
    int n_lines = number_of_lines();
    char *filepath = get_shuck_history_path();
    FILE *file = fopen(filepath, "r");            
    
    // extract the last line from history
    char last_line[MAX_LINE_CHARS];
    for (int line_count = 0; line_count < n_lines; line_count++) {
        fgets(last_line, MAX_LINE_CHARS, file);
    } 
    
    // print the command
    printf("%s", last_line);

    char **command = tokenize(last_line, " \t\r\n", "!><|");
    words = command;
    
    // save to history then globber words
    save_history(command);
    globber(words);
    fclose(file);
    free(filepath);
    
    // execute the program
    run_program(words, path, environment);
}

// checks if the next arg is null, if it isn't there are too many args
static int too_many_args (char **args) {
    args++;
    if (*args != NULL) {
        return 1;
    } else {
        return 0;
    }
}

// executes the nth command stored in .shuck_history
static void run_nth_command(char **words, char **path, char **environment) {
    // check if the argument is numerical
    if (isdigit(*words[0]) == 0) {
        fprintf(stderr, "!: %s: numeric arguments required\n", *words);
    } 
    
    // if the arg is numerical
    else {
        int nth = atoi(*words);
        
        // check if the nth command exists
        if (nth > number_of_lines()) {
            fprintf(stderr, "!: invalid history reference\n");
        } 
        
        // run the nth command
        else {
            // open history
            char *filepath = get_shuck_history_path();
            FILE *file = fopen(filepath, "r");
            
            // find the nth line of history
            char nth_line[MAX_LINE_CHARS];
            for (int line_count = 0; line_count <= nth; line_count++) {
                fgets(nth_line, MAX_LINE_CHARS, file);
            }

            // print the nth command
            printf("%s", nth_line);
            
            char **command = tokenize(nth_line, " \t\r\n", "!><|"); 
            words = command;
            save_history(words);
            globber(command);
            fclose(file);
            free(filepath);
            
            // execute the command
            run_program(command, path, environment);
        }
    }
}

// subset 3 functions
// loops through **words and test whether '*', '?', '[', or '~' appear in a 
// word, if it does, replace the word with the matching pattern, if the word
// contains no glob chars or it does but has no matches, return the word 
// unchanged
static char **globber(char **words) {
    int n_words = 0;
    while (*words != NULL) {
        // check if the word contains any of the glob chars
        if (check_glob_chars(*words)) {
            
            // check if there is a match
            glob_t matches;
            int result = glob(*words, GLOB_NOCHECK|GLOB_TILDE, NULL, &matches);
            // if there is a match change words to the matches
            if (result == 0) {
                int size = 0;
                
                // find the size of the matches and add them
                for (int i = 0; i < matches.gl_pathc; i++) {
                    size += (strlen(matches.gl_pathv[i]) + 1);
                }                                                            
                
                // put together all the matches in *new_word   
                char *new_word = malloc(sizeof(char) * size);
                strcpy(new_word, matches.gl_pathv[0]);
                for (int i = 1; i < matches.gl_pathc; i++) {
                    new_word = strcat(new_word, " ");
                    new_word = strcat(new_word, matches.gl_pathv[i]);
                }
                
                // change words to new_word
                *words = new_word;                   
            }     
            globfree(&matches);
        }  
        words++;
        n_words++;
    } 
    // change pointer back to beginning
    words -= n_words;
    return words;
}

// check if a word contains any glob chars
static bool check_glob_chars(char *words) {
    int glob_chars = 0;
    if ((strrchr(words, '*')) != NULL ||
       (strrchr(words, '?')) != NULL ||
       (strrchr(words, '[')) != NULL ||
       (strrchr(words, '~')) != NULL) {
        glob_chars++;
    } 
    
    // does not contain glob chars, return 0
    if (glob_chars == 0) {
        return false;
    }
    // contains glob chars, return 1
    else {
        return true;
    }   
}

// subset 4 functions
// checks if a certain char exists in words
static int find_char(char **words, char *c) {
    int char_counter = 0;
    for (char **curr = words; *curr != NULL; curr++) {
        if (strcmp(*curr, c) == 0) {
            char_counter++;
        }
    }
    return char_counter;
}

// checks whether < occurs more than once, if < is the only word, if there
// is a word after <, check whether it is a file, if it is a file, check
// whether it is readable
static bool input_redirection_initial_check (char **words) {
    char *file = words[1];
    // check that '<' only appears once in the command line
    int counter = find_char(words, "<");
    
    // if there is more than one occurence of '<'
    if (counter > 1) {
        fprintf(stderr, "invalid input redirection\n");
        return false;
    } 
    
    // check if there are enough words
    if (number_of_args(words) < 3) {
        fprintf(stderr, "invalid input redirection\n");
        return false;
    }
    
    // check if there is a word after '<'
    // if there are no words after, error
    if (file == NULL) {
        fprintf(stderr, "invalid input direction\n");
        return false;
    } 
    
    // else there is a word after
    else {
        // check whether it is an inbuilt command;
        char *command = words[2];
        if (is_builtin(command)) {
            return false;
        }  
              
        // check whether it is a file
        if (is_file(file)) {            
            // check whether it is readable
            if (is_readable(file)) {
                return true;
            } else {
                fprintf(stderr, "%s: Permission denied\n", file);
                return false;
            }
        } else {
            fprintf(stderr, "%s: No such file or directory\n", file);
            return false;
        }
    }       
}

// checks whether a file exists
static bool is_file (char *file) {
    struct stat file_info;    
    
    // check if the file exists
    if (stat(file, &file_info) != 0) {
        return false;
    } else {
        return true;     
    }
}

// checks whether a user has read permissions for a file
static bool is_readable(char *file) {
    struct stat file_info;    
    stat(file, &file_info);
    
    // check if the file is readable
    if ((file_info.st_mode & S_IRUSR) == S_IRUSR) {
        return true;
    } else {
        return false;
    }   
}

// input redirection: redirects the input of a process to a given file
static void input_redirection(char **words, char **path, char **environment) {    
    // find the command
    words = globber(words);
    char *command = words[2];
    
    // make path for the command    
    if (strrchr(command, '/') == NULL) {
        command = make_path(command, path);
    }     

    // if the program is not executable, return  
    if (is_executable(command) == 0) {
        fprintf(stderr, "%s: command not found\n", command);
        return;
    }
    
    // create a pipe
    int pipe_file_descriptors[2];
    if (pipe(pipe_file_descriptors) == -1) {
        perror("pipe");
        return;
    }
    
    // create a list of file actions to be carried out on spawned process
    posix_spawn_file_actions_t actions;
    if (posix_spawn_file_actions_init(&actions) != 0) {
        perror("posix_spawn_file_actions_init");
        return;
    }
    
    // tell spawned process to close unused write end of pipe
    if (posix_spawn_file_actions_addclose(&actions, pipe_file_descriptors[1]) != 0) {
        perror("posix_spawn_file_actions_init");
        return;
    }
    
    // tell spawned process to replace file descriptor[0] (stdin)
    // with read end of the pipe
    if (posix_spawn_file_actions_adddup2(&actions, pipe_file_descriptors[0], 0) != 0) {
        perror("posix_spawn_file_actions_adddup2");
        return;
    }
    
    pid_t pid;      
    
    // find the number of args there are, disregard the first 2 args as they 
    // are "< filename"
    int number_of_words = number_of_args(words);
    char *argv[number_of_words];
    
    // move words pointer up two words so < and filename are not put into argv
    words += 2;
    
    // save command line input to args
    int i = 0;
    for (char **curr = words; *curr != NULL; curr++) {
        argv[i] = *curr;
        i++;   
    }
    
    argv[number_of_words - 2] = NULL;
    
    // move words pointer back to the start;
    words -= 2;
    
    // spawn process
    if (posix_spawn(&pid, command, &actions, NULL, argv, environment) != 0) {
        perror("spawn");
        return;
    }    
    
    // close unused read end of pipe
    close(pipe_file_descriptors[0]);
    
    // create a stdio stream from write-end of pipe
    FILE *f = fdopen(pipe_file_descriptors[1], "w");
    if (f == NULL) {
        perror("fdopen");
        return;
    }   
    
    // send input to the process, use the input from given file 
    char *filename = words[1];
    FILE *file = fopen(filename, "r");
    char line[MAX_LINE_CHARS];
    while (fgets(line, MAX_LINE_CHARS, file) != NULL) {
        fprintf(f, "%s", line);
    }   
    
    // close the file
    fclose(file);
    
    // close write-end of the pipe
    fclose(f);
    
    int exit_status;
    if (waitpid(pid, &exit_status, 0) == -1) {
        perror("waitpid");
        return;
    }
    
    printf("%s exit status = %d\n", command, (exit_status >>= 8));

    // free the list of file actions
    posix_spawn_file_actions_destroy(&actions);
    
    return;
}

// checks whether the command given is an in-built command
static bool is_builtin(char *command) {
    if (strcmp(command, "exit") == 0) {
        fprintf(stderr,
                "exit: I/O redirection not permitted for builtin commands\n");
        return true;
    } else if (strcmp(command, "pwd") == 0) {
        fprintf(stderr,
                "pwd: I/O redirection not permitted for builtin commands\n");
        return true;
    } else if (strcmp(command, "cd") == 0) {
        fprintf(stderr,
                "cd: I/O redirection not permitted for builtin commands\n");
        return true;
    } else if (strcmp(command, "history") == 0) {
        fprintf(stderr,
                "history: I/O redirection not permitted for builtin commands\n");
        return true;
    } else if (strcmp(command, "!") == 0) {
        fprintf(stderr,
                "!: I/O redirection not permitted for builtin commands\n");
        return true;
    } else {
        return false;
    }
}

// checks whether there > is the first char, if there are more than two
// occurences of >, whether it is the second last command, if the file exists, 
// and whether it is writable
static bool check_output_redirection_command(char **words) {
    // if '>' is the first word, error 
    if (strcmp(*words, ">") == 0) {
        fprintf(stderr, "invalid output redirection\n");
        return false;
    }
    
    // count the number of '>' that appears in words
    int char_counter = find_char(words, ">");
    
    // if '>' occurs more than twice in words
    if (char_counter > 2) {
        fprintf(stderr, "invalid output redirection\n");
        return false;
    }
    
    // if there is one >
    if (char_counter == 1) {
        // go to the second last command;
        char **curr = words;
        int number_of_words = number_of_args(words);
        curr += (number_of_words - 2);
        // if '>' is not the second last command, error
        if (strcmp(*curr, ">") != 0) {
            fprintf(stderr, "invalid output redirection\n");
            return false;    
        } 
        
        // if > is the second last command, check if the last word is a
        // file
        else {  
            curr++;
            // if the file exists
            if (is_file(*curr)) {
                // check whether is writable
                if (is_writable(*curr)) {
                    return true;
                } else {
                    fprintf(stderr, "%s: Permission denied\n", *curr);
                    return false;
                }                
            } 
            // if the file does not exist, true is still returned as the 
            // file will be created
            else {
                return true;
            }
        }       
    }
    
    // if there are two occurences of >
    else if (char_counter == 2) {
        int number_of_words = number_of_args(words);
        char *second_last = words[number_of_words - 2];
        char *third_last = words[number_of_words - 3];
        
        // if the 2nd and 3rd last words are >
        if (strcmp(second_last, ">") == 0 && strcmp(third_last, ">") == 0) {
            
            // if the file exists
            char *file = words[number_of_words - 1];
            if (is_file(file)) {    
                // if the file is writable
                if (is_writable(file)) {
                    return true;
                } 
                // if the file is not writable
                else {
                    fprintf(stderr, "%s: Permission denied\n", file);
                    return false;
                }
            }
            
            // if the file does not exist, the file will be created later
            else {
                return true;
            }
        } 
        
        // if the 2nd and 3rd last words are not <
        else {
            fprintf(stderr, "invalid output redirection\n");
            return false;
        }
    }
    return false;
}


// checks whether a user has write permissions for a file
static bool is_writable(char *file) {
    struct stat file_info;    
    stat(file, &file_info);
    
    // check if the file is writable
    if ((file_info.st_mode & S_IWUSR) == S_IWUSR) {
        return true;
    } else {
        return false;
    }   
}

// redirects output of a command to a file
static void output_redirection(char **words, char **path, char **environment) {
    words = globber(words);
    // check whether the command is an inbuilt command
    char *command = words[0];
    // if it is a builtin command, return
    if (is_builtin(command)) {
        return;
    }
    
    // check whether the program is executable
    if (strrchr(command, '/') == NULL) {
        command = make_path(command, path);
    } 
    
    // if the program is not executable, return  
    if (is_executable(command) == 0) {
        fprintf(stderr, "%s: command not found\n", command);
        return;
    }
    
    // create a pipe
    int pipe_file_descriptors[2];
    if (pipe(pipe_file_descriptors) == -1) {
        perror("pipe");
        return;
    }

    // create a list of file actions to be carried out on spawned process
    posix_spawn_file_actions_t actions;
    if (posix_spawn_file_actions_init(&actions) != 0) {
        perror("posix_spawn_file_actions_init");
        return;
    }

    // tell spawned process to close unused read end of pipe
    if (posix_spawn_file_actions_addclose(&actions, pipe_file_descriptors[0]) != 0) {
        perror("posix_spawn_file_actions_init");
        return;
    }

    // tell spawned process to replace file descriptor 1 (stdout)
    // with write end of the pipe
    if (posix_spawn_file_actions_adddup2(&actions, pipe_file_descriptors[1], 1) != 0) {
        perror("posix_spawn_file_actions_adddup2");
        return;
    }

    pid_t pid;
    
    // get the args for the command from words 
    int char_counter = find_char(words, ">");  
    int number_of_words = number_of_args(words);
    char *args[number_of_words];
    // for >filename
    if (char_counter == 1) {    
        
        // if there is only one command and no input
        if (number_of_words <= 3) {
            args[0] = NULL;
        }
        
        // if there is input for the command 
        int i = 0;   
        for (char **curr = words; strcmp(*curr, ">") != 0 && curr != NULL; curr++) {
            args[i] = *curr;
            i++;   
        }
        args[number_of_words - 2] = NULL; 
    } 
    
    // for >>filename
    else if (char_counter == 2) {        
        // if there is only one command and no input
        if (number_of_words <= 3) {
            args[0] = NULL;
        } 
        // else if there is input for the command 
        else {
            int i = 0;   
            for (char **curr = words; strcmp(*curr, ">") != 0 && curr != NULL; curr++) {
                args[i] = *curr;
                i++;      
            }            
            args[number_of_words - 3] = NULL;
        }
    }
    
    if (posix_spawn(&pid, command, &actions, NULL, args, environment) != 0) {;
        perror("spawn");
        return;
    }

    // close unused write end of pipe
    close(pipe_file_descriptors[1]);

    // create a stdio stream from read end of pipe
    FILE *f = fdopen(pipe_file_descriptors[0], "r");
    if (f == NULL) {
        perror("fdopen");
        return;
    }
    
    char *file = words[number_of_words - 1];
    
    // if >filename, write output to a file, overwriting if needed the file
    // already exists
    if (char_counter == 1) {
        FILE *output = fopen(file, "w");
        char line[MAX_LINE_CHARS];
        while (fgets(line, sizeof line, f) != NULL) {
            fprintf(output, "%s", line);
        }
        fclose(output);
    }
    
    // else if >>filename, append output to end of the file
    if (char_counter == 2) {
        FILE *output = fopen(file, "a");
        char line[MAX_LINE_CHARS];
        while (fgets(line, sizeof line, f) != NULL) {
            fprintf(output, "%s", line);
        }
        fclose(output);
    }

    // close read-end of the pipe
    fclose(f);

    int exit_status;
    if (waitpid(pid, &exit_status, 0) == -1) {
        perror("waitpid");
        return;
    }
    printf("%s exit status = %d\n", command, (exit_status >>= 8));

    // free the list of file actions
    posix_spawn_file_actions_destroy(&actions);

    return;
}
