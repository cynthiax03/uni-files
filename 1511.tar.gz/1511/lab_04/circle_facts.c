// z5359629
// COMP1511 lab 04 exercise 2: Fun facts about circles
// A program that takes the radius of the circle and returns its
// area, circumference and diameter

#include <stdio.h>

double area(double radius);
double circumference(double radius);
double diameter(double radius);

int main(void) {
    
    double radius = -1;
    
    // Ask for circle radius
    printf("Enter circle radius: ");
    scanf("%lf", &radius);
    
    // Return area
    printf("Area          = %lf\n", area(radius));
    
    // Return circumference
    printf("Circumference = %lf\n", circumference(radius));
    
    // Return diameter
    printf("Diameter      = %lf\n", diameter(radius));
}

// Calculate the area of a circle, given its radius.
double area(double radius) {
    double area = radius * radius * 3.141592653589;
    return area; 
}

// Calculate the circumference of a circle, given its radius.
double circumference(double radius) {
    double circumference = 2 * 3.141592653589 * radius;
    return circumference; 
}

// Calculate the diameter of a circle, given its radius.
double diameter(double radius) {
    double diameter = 2 * radius;
    return diameter; 
}


