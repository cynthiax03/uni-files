// z5359629
// COMP1511 lab04 exercise 3: Painterbot
// A program that scans indices until EOF then prints a one dimensional
// array which has 36 0s, except the given indices has a 1

/*#include <stdio.h>

# define SIZE 36

int double_sum(int array[SIZE], int size);

int main(void) {
    int array[SIZE] = {0};
    
    int size = 0;
    while (size < SIZE && scanf("%d", &array[size]) == 1) {
        size++;
    }
    
    printf("Double Sum: %d\n ", double_sum(array, size));
    printf("Size: %d\n", size);
    
    printf("The Array:\n");
    int i = 0;
    while (i < size) {
        printf("%d\n", array[i]);
        i++;
    }
    
    return 0;
}

int double_sum(int array[SIZE], int size) {
    int i = 0;
    while (i < size) {
        array[i]*= 1;
        i++;
    }
    
    i = 0;
    int sum = 0;
    while (i < size) {
        sum += array[i];
        i++;
    }
    
    return sum;
}
        
*/
    
#include <stdio.h>

#define SIZE 36


int main(void) {
    int array[SIZE] = {0};
    
    int size = 0;
    while (size < SIZE && scanf("%d", &array[size]) == 1) {
        size++;
    }
    
    int i = 0;
    while (i < SIZE) {
        printf("%d", array[i]);
        i++;
    }
    
    while (
    
    return 0;
}

        
     

    
    
    
