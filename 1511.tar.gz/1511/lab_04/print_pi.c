// z5359629
// COMP1511 lab 04 exercise 1: print pi
// Prints the first n digits of pi, where n is specified 
// by the user

#include <stdio.h>

#define MAX_DIGITS 10

int main(void) {
    int pi[MAX_DIGITS] = {3, 1, 4, 1, 5, 9, 2, 6, 5, 3};
    int digits = -1;
    
    // Ask user for number of digits
    printf("How many digits of pi would you like to print? ");
    scanf("%d", &digits);
    
    int i = 0;
    while (i < digits) {
        if (i == 1) {
            printf(".%d", pi[i]);
        } else if (i == digits - 1) {
            printf("%d", pi[i]);
        } else {
            printf("%d", pi[i]);
        } i++;
    }
    
    printf("\n");

    return 0;
}
