// z5359629
// COMP1511 lab04 Challenge exercise 1: Reverse and Array
// A program which reads integers line by line, and when it reaches 
// the end of input, prints those integers in reverse order, line by line

#include <stdio.h>

#define size 100

int main(void) {
    int array[size] = {0};
    
    // Ask user for numbers
    printf("Enter numbers forwards: \n");
    
    // Scan in numbers
    int i = 0;
    while(scanf("%d", &array[i]) == 1) {
        i++;
    }
    
    // Return numbers in reverse order
    int counter = 99;
    printf("Reversed: \n");
    while(counter > -1) {
        if (counter < i) {
            printf("%d\n", array[counter]);
        }
        counter--;
    }

    return 0;
}
