/*#include<stdio.h>

int main(void) {
    int x = 11;
    int y = 3;
    printf("%d\n", x / y);
    return 0;
} */

/*#include <stdio.h>

#define STOP_NUMBER 100

int main(int argc, char *argv[]) {
    int monkey = 1;
    int i = 0;
    while (i < STOP_NUMBER) {
        monkey += i;
    i++;
    }
    printf("Total is: %d\n", monkey);
}*/

#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *next;
};

int main(void) {
    struct node *head = malloc(<YOUR CODE HERE>);
}

