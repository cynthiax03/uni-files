// exam_q3.c
//
// This program was written by Xinyue (Cynthia) Li (z5359629)
// on 1st May 2021
//
// This program reads integers from standard input until EOF
// It will then recognise integers with the same value and find the
// minimum distance between them


#include <stdio.h>
#include <stdlib.h>

#define MAX_SIZE 10000

int main(void) {
    int array[MAX_SIZE] = {0};
    int size = 0;
    while (scanf("%d", &array[size]) != EOF && size < MAX_SIZE) {
        size++;
    } 
    int min_distance = MAX_SIZE;
    int x = 0;
    while (x < size) {
        int y = x;
        while (y < size) {
            if (array[x] == array[y] && y != x && y > x) {
                int distance = y - x;
                if (min_distance > distance) {
                    min_distance = distance;
                }
            }
            y++;
        }
        x++;
    }
    
    printf("The minimum distance was: %d\n", min_distance);

	return 0;
}
