// Assignment 2 21T1 COMP1511: Beats by CSE
// beats.c
//
// This program was written by Xinyue (Cynthia) Li (z5359629)
// on 14 April 2021
//
// Version 1.0.0: Assignment released.

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "beats.h"

#define VALID 1
#define INVALID 0

//////////////////////////////////////////////////////////////////////

// Structs
struct track {
    struct beat *head;
    struct beat *selected_beat;
};

struct beat {
    struct note *notes;
    struct beat *next;
};

struct note {
    int octave;
    int key;
    struct note *next;
};

//////////////////////////////////////////////////////////////////////

// My function prototypes
struct note *create_note(int octave, int key);
int is_octave_valid(int octave);
int is_key_valid(int key);
void print_helper(struct note *curr);

// Tests whether the octave given is valid
int is_octave_valid(int octave) {
    if (octave >= 0 && octave < 10) {
        return VALID;
    } else {
        return INVALID;
    }
}
    
// Tests whether the key given is valid
int is_key_valid(int key) {
    if (key >= 0 && key < 12) {
        return VALID;
    } else {
        return INVALID;
    }
}

// Creates a note struct and returns pointer to the new node
struct note *create_note(int octave, int key) {
    struct note *new_note = malloc(sizeof (struct note));
    new_note->next = NULL;
    new_note->octave = octave;
    new_note->key = key;
    return new_note;
}
              
// Return a malloced Beat with fields initialized.
Beat create_beat(void) {
    Beat new_beat = malloc(sizeof (struct beat));
    assert(new_beat != NULL);

    new_beat->next = NULL;
    new_beat->notes = NULL;

    return new_beat;
}

//////////////////////////////////////////////////////////////////////
//                        Stage 1 Functions                         //
//////////////////////////////////////////////////////////////////////

// Add a note to the end of a beat.
int add_note_to_beat(Beat beat, int octave, int key) {
    if (is_octave_valid(octave) == VALID && is_key_valid(key) == VALID) {
        // If both octave and key are valid
        if (beat->notes == NULL) {
            // If the beat is empty
            beat->notes = create_note(octave, key);
            return VALID_NOTE;
        } else {
            // If the beat has notes in it, loop to the end of the beat
            struct note *curr = beat->notes;
            while (curr->next != NULL) {                
                curr = curr->next;
            }
            if (curr->octave < octave) {
                // If the new octave is higher than the current octave,
                // it can be added
                curr->next = create_note(octave, key);
                return VALID_NOTE;
            } else if (curr->octave == octave && curr->key < key) {
                // If the new octave is the same as the current octave
                // and the key is higher, it can be added
                curr->next = create_note(octave, key);
                return VALID_NOTE;
            } else {
                // The new octave is lower than the current note's octave
                // or the the new octave is the same as the current
                // note's octave but it's key is lower, it cannot be 
                // added
                return NOT_HIGHEST_NOTE;
            }
        } 
    } else if (is_octave_valid(octave) == INVALID) {
        // The octave is invalid
        return INVALID_OCTAVE;
    } else {
        // The key is invalid
        return INVALID_KEY;
    }
}

// Print the contents of a beat.
void print_beat(Beat beat) {
    if (beat->notes == NULL) {
        // If the beat is empty
        printf("\n");
    } else {
        // If the beat is not empty
        // Loop through the beat printing out its notes
        struct note *curr = beat->notes;
        while (curr != NULL) {
            print_helper(curr);               
            curr = curr->next;
        } printf("\n");
    } 
    return;    
}

// Helps print the contents of a beat when the beat is not empty
void print_helper(struct note *curr) {
    if (curr->next == NULL) {
        // If the current note is the last note in the beat
        if (curr->key < 10) {
            printf("%d 0%d", curr->octave, curr->key);
        } else {
            printf("%d %d", curr->octave, curr->key);
        }
    } else {
        // If the current note is not the last note in the beat
        if (curr->key < 10) {
            printf("%d 0%d | ", curr->octave, curr->key);
        } else {
            printf("%d %d | ", curr->octave, curr->key);
        } 
    }  
}

// Count the number of notes in a beat that are in a given octave.
int count_notes_in_octave(Beat beat, int octave) {
    // Loop through the notes in the beat counting how many there are
    struct note *curr = beat->notes;
    int note_count = 0;
    while (curr != NULL) {
        if (curr->octave == octave) {
            note_count++;
        } 
        curr = curr->next;
    }
    return note_count;
}

//////////////////////////////////////////////////////////////////////
//                        Stage 2 Functions                         //
//////////////////////////////////////////////////////////////////////

// Return a malloced track with fields initialized.
Track create_track(void) {
    // Note: there is no fprintf in this function, as the
    // Stage 1 autotests call create_track but expect it to return NULL
    // (so this function should do nothing in Stage 1).
    Track new_track = malloc(sizeof (struct track));
    new_track->head = NULL;
    new_track->selected_beat = NULL;
    return new_track;
}

// Add a beat after the current beat in a track.
void add_beat_to_track(Track track, Beat beat) {
    if (track->head == NULL) {
        // Empty track
        track->head = beat;
        return;
    } else {
        // Track is not empty
        if (track->selected_beat == NULL) {
            // No currently selected beat
            struct beat *head = track->head;
            track->head = beat;
            beat->next = head;
            return;
        } else {
            // There is a currently selected beat
            struct beat *curr = track->selected_beat;
            if (curr->next == NULL) {
                // The currently selected beat is at the end of the 
                // track
                curr->next = beat;
                beat->next = NULL;
                return;
            } else {
                // If the currently selected beat is not at the end of 
                // the track
                curr = track->selected_beat;
                struct beat *next = curr->next;
                beat->next = next;
                curr->next = beat;
                return;
            }
        }
    }
}
        
// Set a track's current beat to the next beat.
int select_next_beat(Track track) {
    if (track->selected_beat == NULL) {
        // If there is no currently selected beat 
        if (track->head == NULL) {
            // There are no beats in the track
            return TRACK_STOPPED;
        } else {
            // There are no beats selected but there are beats in the 
            // track, the new current beat will be the first beat in 
            // the track
            track->selected_beat = track->head;
            return TRACK_PLAYING;
        }
    } else {
        // There is a currently selected beat
        struct beat *curr = track->selected_beat;
        if (curr->next == NULL) {
            // If the current beat is the last beat in the track
            track->selected_beat = NULL;
            return TRACK_STOPPED;
        } else {
            // All other cases
            track->selected_beat = curr->next;
            return TRACK_PLAYING;
        }
    } 
}

// Print the contents of a track.
void print_track(Track track) {
    if (track->head == NULL) {
        // If track has no beats
        return;
    } else {
        // If the track contains beats, loop through, printing out beats
        struct beat *curr = track->head;
        int beat_number = 1;
        while (curr != 0) {
            if (curr == track->selected_beat) {
                // If the beat is the selected beat, it is indicated by 
                // a '>'
                printf(">[%d] ", beat_number);
                print_beat(curr);
            } else {
                printf(" [%d] ", beat_number);
                print_beat(curr);
            }
            curr = curr->next;
            beat_number++;
        }
    }
    return;
}

// Count beats after the current beat in a track.
int count_beats_left_in_track(Track track) {
    if (track->selected_beat == NULL) {
        // If there are no selected beats, the number of beats in the
        // entire track are counted
        int beat_counter = 0;
        struct beat *curr = track->head;
        while (curr != NULL) {
            beat_counter++;
            curr = curr->next;
        }
        return beat_counter;
    } else {
        // There is a selected beat in the track
        int beats_left = -1;
        struct beat *curr = track->selected_beat;
        while (curr != NULL) {
            beats_left++;
            curr = curr->next;
        }
        return beats_left;
    }
    return 0;
}

//////////////////////////////////////////////////////////////////////
//                        Stage 3 Functions                         //
//////////////////////////////////////////////////////////////////////

// Free the memory of a beat, and any memory it points to.
void free_beat(Beat beat) {
    // Note: there is no printf in this function, as the
    // Stage 1 & 2 autotests call free_beat but don't check whether
    // the memory has been freed (so this function should do nothing in
    // Stage 1 & 2, rather than print an error).
    if (beat == NULL) {
        return;
    } else {
        // Beat is not null, loop through freeing the notes in the beat
        struct note *curr = beat->notes;
        while (curr != NULL) {
            struct note *free_note = curr;
            curr = curr->next;
            free(free_note);
        }
        // After all the notes in the beat are freed, we can free the
        // beat
        free(beat);
    }
    return;
}

// Free the memory of a track, and any memory it points to.
void free_track(Track track) {
    // Note: there is no printf in this function, as the
    // Stage 1 & 2 autotests call free_track but don't check whether
    // the memory has been freed (so this function should do nothing in
    // Stage 1 & 2, rather than print an error).
    if (track == NULL) {
        // If the track is empty
        return;
    } else {
        // If the track is not empty, loop through and free all beats 
        // including their notes
        struct beat *curr = track->head;
        while (curr != NULL) {
            struct beat *curr_beat = curr;
            curr = curr->next;
            free_beat(curr_beat);
        }
        // Free track after all the beats in it have been freed
        free(track);
    }   
    return;
}

// Remove the currently selected beat from a track.
int remove_selected_beat(Track track) {
    if (track->selected_beat == NULL) {
        // No currently selected beats
        return TRACK_STOPPED;
    } else {
        // There is a currently selected beat
        if (track->selected_beat == track->head) {
            // If the currently selected beat is at the head of the 
            //track
            if (track->selected_beat->next == NULL) {
                // If there is only one beat in the track, the track 
                // becomes empty
                free_beat(track->selected_beat);
                track->selected_beat = NULL;
                track->head = NULL;
                return TRACK_STOPPED;
            } else {
                // There are other beats in the track 
                // Remove the current beat, the next beat is the new 
                // head and the new selected beat 
                struct beat *curr = track->head;
                track->head = track->head->next;
                track->selected_beat = track->selected_beat->next;
                free_beat(curr);
                return TRACK_PLAYING;
            }          
        } else if (track->selected_beat->next == NULL) {
            // If the currently selected beat is at the end of the
            // track 
            // Loop until the beat before the selected beat
            struct beat *curr = track->head;
            struct beat *prev = NULL;
            while (curr != track->selected_beat) {
                prev = curr;
                curr = curr->next;
            } 
            // The prev beat becomes the last beat of the track
            prev->next = NULL;
            track->selected_beat = NULL;
            free_beat(curr);
            return TRACK_STOPPED;
        } else {
            // The currently selected beat is in the middle of the list
            struct beat *curr = track->head;
            struct beat *prev = NULL;
            // Loop until the currently selected beat is reached
            while (curr != track->selected_beat) {
                prev = curr;
                curr = curr->next;
            } 
            // The current beat is removed and the next beat in the track
            // becomes the new selected beat
            prev->next = curr->next;
            track->selected_beat = curr->next;
            free_beat(curr);
            return TRACK_PLAYING;
        }
    }
}
