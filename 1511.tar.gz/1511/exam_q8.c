// exam_q8.c
//
// This program was written by YOUR-NAME-HERE (z5555555)
// on INSERT-DATE-HERE
//
// One line summary of what this exercise does.

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

int main(void) {
    printf("Replace this with your solution!\n");
}
