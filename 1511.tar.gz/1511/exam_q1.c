// exam_q1.c
//
// This program was written by Xinyue (Cynthia) Li (z5359629)
// on 1st May 2021
//
// This function counts the number of decreasing pairs 
// ie: if the second number is lower than the first it will be counted
#include <stdio.h>

// Return the number of decreasing pairs in the array.
int count_decreasing(int size, int array[size][2]) {
    int pair_number = 0;
    int decreasing_pair_counter = 0;
    while (pair_number < size) {
        if (array[pair_number][1] < array[pair_number][0]) {
            decreasing_pair_counter++;
        }
        pair_number++;
    }
    return decreasing_pair_counter;
}

// This is a simple main function which could be used
// to test your count_decreasing function.
// It will not be marked.
// Only your count_decreasing function will be marked.

#define TEST_ARRAY_SIZE 5

int main(void) {
    int test_array[TEST_ARRAY_SIZE][2] = {{16, 7}, {8, 12}, {13, -9}, {-3, 12}, {1, 1}};

    int result = count_decreasing(TEST_ARRAY_SIZE, test_array);
    printf("%d\n", result);

    return 0;
}
