// z5359629
// COMP1511 lab03 exercise 3 three_five
// A program that reads a positive integer n and prints all the positive
// integers < n that are factors of 3 or 5 in ascending order

#include <stdio.h>

int main(void) {
    
    int n = -1;
    int counter = 1;
    
    // Ask user for number
    printf("Enter number: ");
    scanf("%d", &n);
    
    while (counter < n) {
        if (counter % 3 == 0) {
            printf("%d\n", counter);
        } else if (counter % 5 == 0 ) {
            printf("%d\n", counter);
        } else {
        } counter++;
        
    }
    
    return 0;
}


 

