// z5359629
// COMP1511 Lab 03 Exercise 2: countdown
// A program which counts down from 10 to 0

#include <stdio.h>

int main(void) {
    
    int counter = 10;
    while (counter >= 0) {
        printf("%d\n", counter);
        counter--;
    }
    
    return 0;
}
