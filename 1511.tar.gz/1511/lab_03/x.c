// z5359629
// COMP1511 lab03 exercise 5: draw and x
// A program that prints an nxn pattern of asterisks and stars in the shape
// of an x 

#include <stdio.h>

int main(void) {

    int n = -1; 
    int y = 0;

    // Ask user for integer n
    printf("Enter size: ");
    scanf("%d", &n);
    
    int number = n; 
    
    //print x
    while (y < n) {
        int x = 0;
        while (x < n) {
            if (x == y || x == number - 1) {
                printf("*");
            } else {
                printf("-");
            } x++;
        }
        // print a new line
        printf("\n");
        y++;
        number--;
    }
    
    return 0;
}
                
