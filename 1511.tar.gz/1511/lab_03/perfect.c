// z5359629
// COMP1511 lab03 exercise 4: Perfect numbers
// A program that reads a positive integer n and prints all 
// the factors of n, their sum and indicates whether n is a perfect number

#include <stdio.h>

int main(void) {

    int n = -1;
    int counter = 1;
    int sum = 0;
    
    // Ask for integer n
    printf("Enter number: ");
    scanf("%d", &n);
    
    // Print the factors of n and find sum of factors
    printf("The factors of %d are:\n", n);
    while (counter <= n) {
        if (n % counter == 0) {
            printf("%d\n", counter);
            sum += counter;
            } else { }
        counter++;
    }
    
    // Print sum of factors
    printf("Sum of factors = %d\n", sum);
    
    // Find  and print whether n is a perfect number
    if (sum == 2 * n) {
        printf("%d is a perfect number\n", n);
    } else {
        printf("%d is not a perfect number\n", n);
    }
    
    return 0;
}
     
        
