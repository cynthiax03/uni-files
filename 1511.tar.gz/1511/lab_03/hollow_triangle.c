// z5359629
// COMP1511 lab03 exercise 6: Hollow triangle
// A program which takes an integer n  and prints a pattern of asterisks
// that form a hollow triangle

#include <stdio.h>

int main(void) {

    int n = -1;
    int y = 0;
    int number = 0;

    // Ask user for size
    printf("Enter size: ");
    scanf("%d", &n);
    
    // Print triangle
    while (y < n) {
        if (y < n - 1) {
            int x = 0;
            while (x < n) {
                if (x == 0 || x == number) {
                    printf("*");
                } else {
                    printf(" ");
                } x++;
            } 
        } else {
            int x = 0;
            while (x < n) {
                printf("*");
                x++;
            }
        } // Print a new line
        printf("\n");
        y++;
        number++;
    }
        

    
    return 0;
}
            
        
    
    

