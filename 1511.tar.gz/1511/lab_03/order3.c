// z5359629
// March 2021 COMP1511 week 3, lab exercise 1: ordering 3 z5359629
// A program that takes 3 integers and orders them from smallest to largest

#include <stdio.h>

int main(void) {

    int integer_one = -1;
    int integer_two = -1;
    int integer_three = -1;

    // Ask user for 1st integer
    printf("Enter integer: ");
    scanf("%d", &integer_one);
    
    // Ask user for 2nd integer
    printf("Enter integer: ");
    scanf("%d", &integer_two);
    
    //Ask user for 3rd integer
    printf("Enter integer: ");
    scanf("%d", &integer_three);
    
    // Determine order of integers
    if (integer_one <= integer_two && integer_one <= integer_three) {
        printf("The integers in order are: %d ", integer_one);
        if (integer_two <= integer_three) {
            printf("%d %d\n", integer_two, integer_three);
        } else {
            printf("%d %d\n", integer_three, integer_two);
        }
    } else if (integer_two <= integer_one && integer_two <= integer_three) {
        printf("The integers in order are: %d ", integer_two);
        if (integer_one <= integer_three) {
            printf("%d %d\n", integer_one, integer_three);
        } else {
            printf("%d %d\n", integer_three, integer_one);
        }
    } else {
        printf("The integers in order are: %d ", integer_three);
        if (integer_one <= integer_two) {
            printf("%d %d\n", integer_one, integer_two);
        } else {
            printf("%d %d\n", integer_two, integer_one);
        }
    }  
    
    return 0;
}

