// z5359629
// COMP1511 lab03 xhallenge exercise 1: Ordering three integers without 
// if statements

#include <stdio.h>

int main(void) {
    
    int integer_1 =  -1;
    int integer_2 = -1;
    int integer_3 = -1;

    // Ask user for integers
    printf("Enter integer: ");
    scanf("%d", &integer_1);
    
    printf("Enter integer: ");
    scanf("%d", &integer_2);
    
    printf("Enter integer: ");
    scanf("%d", &integer_3);
    
    // Print integers in order
    printf("The integers in order are: %d %d %d", integer_1, integer_2,
    integer_3);
    


    return 0;
}
