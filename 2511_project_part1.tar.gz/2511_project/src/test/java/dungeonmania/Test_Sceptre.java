package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static dungeonmania.TestUtils.getEntities;
import static dungeonmania.TestUtils.getInventory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;

public class Test_Sceptre {

    @Test
    @DisplayName("mind control a mercenary with mind control duration")
    public void testBribeMercenaryWithMindControlDuration() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_bribeMercenary", "c_movementTest_testMovement");
        String mercenaryId = getEntities(res, "mercenary").get(0).getId();

        // collect 1 wood
        res = dmc.tick(Direction.DOWN);
        // collect 1 key
        res = dmc.tick(Direction.DOWN);
        // collect 1 sun stone
        res = dmc.tick(Direction.DOWN);
        // build a sceptre
        assertDoesNotThrow(() -> {dmc.build("sceptre");});

        res = dmc.tick(Direction.RIGHT);
 
        assertEquals(1, getInventory(res, "sceptre").size());

        assertDoesNotThrow(() -> {dmc.interact(mercenaryId);});
        boolean interactacble = getEntities(res, "mercenary").get(0).isInteractable();
        // assertEquals(false, interactacble);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);

        // assertEquals(true, interactacble);

    }
}
