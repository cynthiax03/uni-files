package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static dungeonmania.TestUtils.getEntities;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;

public class Test_Spawning {
    @Test 
    @DisplayName("Test zombie toast spawning")
    public void testZombieSpawning() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_zombieToastSpawnerTest", "c_enemySpawningTest");

        // Move down twice (2 ticks) and get the response from the second tick
        dmc.tick(Direction.DOWN);
        DungeonResponse res = dmc.tick(Direction.DOWN);

        // Check that two zombies have spawned
        assertEquals(2, getEntities(res, "zombie_toast").size());
    }

    @Test
    @DisplayName("Test zombie does not spawn if all cardinally adjacent squares are walls")
    public void testZombieSpawningIfSurroundedByWalls() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_zombieSpawnerWallsTest", "c_enemySpawningTest");

        // Move down 4 times (4 ticks) and get the response from the second tick
        dmc.tick(Direction.DOWN);
        dmc.tick(Direction.DOWN);
        dmc.tick(Direction.DOWN);
        DungeonResponse res = dmc.tick(Direction.DOWN);

        // Check that no zombies have spawned
        assertEquals(0, getEntities(res, "zombie_toast").size());
    }

    @Test
    @DisplayName("Test spider spawning")
    public void testSpiderSpawning() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_movementTest_testMovementBoulder", "c_enemySpawningTest");

        // Move down twice (2 ticks) and get the response from the second tick
        dmc.tick(Direction.DOWN);
        DungeonResponse res = dmc.tick(Direction.DOWN);

        // Check that two spiders have spawned
        assertEquals(2, getEntities(res, "spider").size());
    }
}
