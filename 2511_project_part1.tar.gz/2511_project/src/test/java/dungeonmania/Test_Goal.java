package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static dungeonmania.TestUtils.getGoals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;

public class Test_Goal {
    @Test
    @DisplayName("Test collect treasure and go to exit goals")
    public void testTreasureAndExitGoal() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_goalTest_andOrGoals", "c_goalTest_andOrGoals");
        
        assertTrue(getGoals(res).contains(":exit"));
        assertTrue(getGoals(res).contains(":treasure"));
        assertTrue(getGoals(res).contains(":boulders"));

        // pick up 1 treasure
        res = dmc.tick(Direction.RIGHT);
        assertTrue(getGoals(res).contains(":exit"));
        assertFalse(getGoals(res).contains(":boulders"));
        assertFalse(getGoals(res).contains(":treasure"));

        // move to the exit
        res = dmc.tick(Direction.RIGHT);
        assertEquals("", getGoals(res));
    }

    @Test
    @DisplayName("Test move all boulders on floor switches and collect all treasure exit goals")
    public void testBoulderAndTreasureGoal() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_goalTest_boulderAndTreasure", "c_goalTest_treasureGoal");
        
        assertTrue(getGoals(res).contains(":treasure"));
        assertTrue(getGoals(res).contains(":boulders"));

        // pick up 1 treasure
        res = dmc.tick(Direction.RIGHT);
        // pick up 1 sun_stone
        res = dmc.tick(Direction.RIGHT);

        assertFalse(getGoals(res).contains(":treasure"));
        assertTrue(getGoals(res).contains(":boulders"));

        // move the first boulder to the first switch
        res = dmc.tick(Direction.RIGHT);
        // move the sec boulder to the sec switch
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);

        assertFalse(getGoals(res).contains(":boulders"));
        assertEquals("", getGoals(res));
    }

    @Test
    @DisplayName("Test Destroying a certain number of enemies and spawners AND getting to an exit")
    public void testEnemySpanwerAndExitGoal() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_goalTest_EnemySpawnerExit", "c_goalTest_treasureGoal");
        
        assertTrue(getGoals(res).contains(":exit"));
        assertTrue(getGoals(res).contains(":enemies"));

        // battle with a mercenary
        res = dmc.tick(Direction.RIGHT);
        // destory a zombie toast spawner
        res = dmc.tick(Direction.RIGHT);

        assertFalse(getGoals(res).contains(":enemies"));
        assertTrue(getGoals(res).contains(":exit"));

        // go to exit
        res = dmc.tick(Direction.RIGHT);
       
        assertFalse(getGoals(res).contains(":enemies"));
        assertFalse(getGoals(res).contains(":exit"));

        assertEquals("", getGoals(res));
    }

    @Test
    @DisplayName("Test Destroying a certain number of enemies and spawners OR (getting to an exit AND collect treasure)")
    public void testSpawnerGoal() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_goalTest_EnemySpawner", "c_goalTest_treasureGoal");
        
        assertTrue(getGoals(res).contains(":exit"));
        assertTrue(getGoals(res).contains(":enemies"));
        assertTrue(getGoals(res).contains(":treasure"));

        // battle with a mercenary
        res = dmc.tick(Direction.RIGHT);
        // destory a zombie toast spawner
        res = dmc.tick(Direction.RIGHT);

        assertFalse(getGoals(res).contains(":enemies"));
        assertFalse(getGoals(res).contains(":exit"));
        assertFalse(getGoals(res).contains(":treasure"));

        assertEquals("", getGoals(res));
    }
    
}
