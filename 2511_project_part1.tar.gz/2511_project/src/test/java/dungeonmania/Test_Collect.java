package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static dungeonmania.TestUtils.getInventory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;


public class Test_Collect {
    @Test
    @DisplayName("Test the player can collect a treasure")
    public void testCollectTreasure() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectTreasure", "c_movementTest_testMovement");

        // move player towards right where a treasure exists
        dungeon = dmc.tick(Direction.RIGHT);
        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "treasure").size());
    }

    @Test
    @DisplayName("Test the player can collect a key")
    public void testCollectKey() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectKey", "c_movementTest_testMovement");

        // move player towards right where a key exists
        dungeon = dmc.tick(Direction.RIGHT);

        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "key").size());
    }

    @Test
    @DisplayName("Test the player can collect one key at one time")
    public void testCollectOneKey() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectOneKey", "c_movementTest_testMovement");

        // move player towards right where a key exists
        dungeon = dmc.tick(Direction.RIGHT);
        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "key").size());

        // move player towards right where another key exists
        dungeon = dmc.tick(Direction.RIGHT);

        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "key").size());
    }

    @Test
    @DisplayName("Test the key disappears after being used")
    public void testCollectKeyDisappear() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectKeyDisappear", "c_movementTest_testMovement");

        // move player towards right where a key exists
        dungeon = dmc.tick(Direction.RIGHT);
        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "key").size());

        // move player towards right where the corrsponding door exists
        dungeon = dmc.tick(Direction.RIGHT);

        // assert that the player's inventory amount is still 1
        assertEquals(0, getInventory(dungeon, "key").size());
    }

    @Test
    @DisplayName("Test the player can collect a invincibility potion")
    public void testCollectInvincibilityPotion() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectInvincibilityPotion", "c_movementTest_testMovement");

        // move player towards right where a invincibility_potion exists
        dungeon = dmc.tick(Direction.RIGHT);

        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "invincibility_potion").size());
    }

    @Test
    @DisplayName("Test the player can collect a invisibility potion")
    public void testCollectInvisibilityPotion() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectInvisibilityPotion", "c_movementTest_testMovement");

        // move player towards right where a invisibility_potion exists
        dungeon = dmc.tick(Direction.RIGHT);

        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "invisibility_potion").size());
    }

    @Test
    @DisplayName("Test the player can collect a wood")
    public void testCollectWood() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectWood", "c_movementTest_testMovement");

        // move player towards right where a wood exists
        dungeon = dmc.tick(Direction.RIGHT);
        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "wood").size());
    }

    @Test
    @DisplayName("Test the player can collect a arrow")
    public void testCollectArrow() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectArrow", "c_movementTest_testMovement");

        // move player towards right where a arrow exists
        dungeon = dmc.tick(Direction.RIGHT);

        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "arrow").size());
    }

    @Test
    @DisplayName("Test the player can collect a bomb")
    public void testCollectBomb() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectBomb", "c_movementTest_testMovement");

        // move player towards right where a bomb exists
        dungeon = dmc.tick(Direction.RIGHT);

        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "bomb").size());
    }

    @Test
    @DisplayName("Test the player can remove a bomb")
    public void testRemoveBomb() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_RemoveTest_testRemoveBomb", "c_movementTest_testMovement");

        // move player towards right where a bomb exists
        dungeon = dmc.tick(Direction.RIGHT);

        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "bomb").size());

        // move player to a random position to place the bomb
        dungeon = dmc.tick(Direction.DOWN);
        String bombId = getInventory(dungeon, "bomb").get(0).getId();
        dungeon = assertDoesNotThrow(() -> dmc.tick(bombId));

        // assert that the player's inventory amount is 0
        assertEquals(0, getInventory(dungeon, "bomb").size());
    }

    @Test
    @DisplayName("Test the player can collect a sword")
    public void testCollectSword() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectSword", "c_movementTest_testMovement");

        // move player towards right where a sword exists
        dungeon = dmc.tick(Direction.RIGHT);

        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "sword").size());
    }

    @Test
    @DisplayName("Test the player can collect a sun stone")
    public void testCollectSunstone() {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_collectTest_testCollectSunstone", "c_movementTest_testMovement");

        // move player towards right where a arrow exists
        dungeon = dmc.tick(Direction.RIGHT);

        // assert that the player's inventory amount is 1
        assertEquals(1, getInventory(dungeon, "sun_stone").size());
    }
}
