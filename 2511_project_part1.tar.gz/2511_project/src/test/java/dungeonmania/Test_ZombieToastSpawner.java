package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static dungeonmania.TestUtils.getEntities;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;

public class Test_ZombieToastSpawner {
    @Test
    @DisplayName("Player is not cardinally adjacent to the spawner")
    public void testCannotDestroySpawnerBcNotcardinallyAdjacent() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_DestroySpawnerBcNotcardinallyAdjacent", "c_movementTest_testMovement");

        String spawnerId = getEntities(res, "zombie_toast_spawner").get(0).getId();
        // collect a bow
        dmc.tick(Direction.RIGHT);

        assertThrows(InvalidActionException.class, () -> {
            dmc.interact(spawnerId);
        });
    }

    @Test
    @DisplayName("Player does not have a weapon")
    public void testDestroyZombieToastSpawnerNoWeapon() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_DestroyZombieToastSpawnerNoWeapon", "c_movementTest_testMovement");

        String spawnerId = getEntities(res, "zombie_toast_spawner").get(0).getId();

        assertThrows(InvalidActionException.class, () -> {
            dmc.interact(spawnerId);
        });
    }

    @Test
    @DisplayName("Destory a zombie toast spawner successfully")
    public void testDestroySpawner() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_destroySpawner", "c_movementTest_testMovement");
        String spawnerId = getEntities(res, "zombie_toast_spawner").get(0).getId();

        // collect 1 treasure
        res = dmc.tick(Direction.RIGHT);

        assertDoesNotThrow(() -> {dmc.interact(spawnerId);});
    }
    
}
