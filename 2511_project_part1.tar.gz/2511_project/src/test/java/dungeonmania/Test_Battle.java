package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;

import static dungeonmania.TestUtils.getEntities;
import static dungeonmania.TestUtils.getInventory;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.response.models.BattleResponse;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.response.models.RoundResponse;
import dungeonmania.util.Direction;

public class Test_Battle {
    @Test
    @DisplayName("Test spider battle with sword") 
    public void testSpiderBattleSwordWin() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_battleTests_spiderSword", "c_movementTest_testMovement");

        // Collect the sword below 
        DungeonResponse resOne = dmc.tick(Direction.DOWN);
        assertEquals(1, getInventory(resOne, "sword").size());

        // Will move onto same square as spider and battle
        DungeonResponse resTwo = dmc.tick(Direction.DOWN);
        BattleResponse battleRes = resTwo.getBattles().get(0);
        List<RoundResponse> rounds = battleRes.getRounds();
        // Assert the battle ended after one round and that the spider was killed
        assertEquals(3, rounds.size());
        assertEquals(0, getEntities(resTwo, "spider").size());

        // Assert that the sword is effective in first round and deteriorated
        // in second round
        assertEquals(-2.4, rounds.get(0).getDeltaEnemyHealth());
        assertEquals(-2, rounds.get(1).getDeltaEnemyHealth());
        
    } 

    @Test
    @DisplayName("Test zombie battle with bow and shield") 
    public void testZombieBowShieldSwordBattle() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_battleTest_zombieBowShieldSword", "c_battleTests_zombieBattle");

        // Collect 3 woods
        DungeonResponse res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        assertEquals(3, getInventory(res, "wood").size());

        // Collect 3 arrows
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.DOWN);
        assertEquals(3, getInventory(res, "arrow").size());

        // Collect 1 treasure
        res = dmc.tick(Direction.LEFT);
        assertEquals(1, getInventory(res, "treasure").size());

        // Build bow and shield
        assertDoesNotThrow(() -> {dmc.build("bow");});
        assertDoesNotThrow(() -> {dmc.build("shield");});

        // Collect sword and check bow and shield are in inventory
        res = dmc.tick(Direction.LEFT);
        assertEquals(1, getInventory(res, "bow").size());
        assertEquals(1, getInventory(res, "shield").size());

        // Battle a zombie by standing next to a zombie toast spawner (all
        // other cardinally adjacent squares are walls)
        res = dmc.tick(Direction.LEFT);

        // Check the battle ended after 3 rounds
        BattleResponse battleRes = res.getBattles().get(0);
        List<RoundResponse> rounds = battleRes.getRounds();
        assertEquals(3, rounds.size());

        // Check that the sword and bow are only effective in the first 2 rounds
        assertEquals(-4.8, rounds.get(0).getDeltaEnemyHealth());
        assertEquals(-4.8, rounds.get(1).getDeltaEnemyHealth());
        assertEquals(-2, rounds.get(2).getDeltaEnemyHealth());
        
        // Check that the shield is only effective in the first 2 rounds
        assertEquals(-0.4, rounds.get(0).getDeltaCharacterHealth());
        assertEquals(-0.4, rounds.get(1).getDeltaCharacterHealth());
        assertEquals(-0.5, rounds.get(2).getDeltaCharacterHealth());

        // Check the zombie was defeated
        assertEquals(0, getEntities(res, "zombie_toast").size());
    }

    @Test
    @DisplayName("Test hydra health increase 0 chance") 
    public void testHydraBattleNeverIncreaseHealth() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_battleTest_hydra", "c_battleTests_hydraOne");

        DungeonResponse res = dmc.tick(Direction.RIGHT);

        BattleResponse battleRes = res.getBattles().get(0);
        List<RoundResponse> rounds = battleRes.getRounds();

        int numDecrease = 0;
        int numIncrease = 0;
        for (int i = 0; i < rounds.size(); i++) {
            if (rounds.get(i).getDeltaEnemyHealth() > 0) {
                numIncrease += 1;
            } else {
                numDecrease += 1;
            }
        }

        // Assert health never increases (51 rounds in total)
        assertEquals(0, numIncrease);
        assertEquals(51, numDecrease);
    }

    @Test
    @DisplayName("Test hydra health increase 1 chance") 
    public void testHydraBattleAlwaysIncreaseHealth() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_battleTest_hydra", "c_battleTests_hydraTwo");

        DungeonResponse res = dmc.tick(Direction.RIGHT);

        BattleResponse battleRes = res.getBattles().get(0);
        List<RoundResponse> rounds = battleRes.getRounds();

        int numDecrease = 0;
        int numIncrease = 0;
        for (int i = 0; i < rounds.size(); i++) {
            if (rounds.get(i).getDeltaEnemyHealth() > 0) {
                numIncrease += 1;
            } else {
                numDecrease += 1;
            }
        }

        // Assert health never increases (101 rounds in total)
        assertEquals(101, numIncrease);
        assertEquals(0, numDecrease);
    }


    // @Test
    // @DisplayName("Test hydra health increase 0.5 chance") 
    // public void testHydraBattleOne() {
    //     DungeonManiaController dmc = new DungeonManiaController();
    //     dmc.newGame("d_battleTest_hydra", "c_battleTests_hydraOne");

    //     // Set the seed for this test
    //     dmc.setSeed(hydraId, 0);

    //     DungeonResponse res = dmc.tick(Direction.RIGHT);

    //     BattleResponse battleRes = res.getBattles().get(0);
    //     List<RoundResponse> rounds = battleRes.getRounds();

    //     // Assert that the health of the hydra increases for half of the attacks
    //     int numDecrease = 0;
    //     int numIncrease = 0;
    //     for (int i = 0; i < rounds.size(); i++) {
    //         if (rounds.get(i).getDeltaEnemyHealth() > 0) {
    //             numIncrease += 1;
    //         } else {
    //             numDecrease += 1;
    //         }
    //     }

    //     // Assert approximately half of the attacks cause increase while 
    //     // approximately half causes health decrease
    //     assertTrue(40 <= numIncrease && numIncrease <= 60);
    //     assertTrue(40 <= numDecrease && numDecrease <= 60);

    // }

    // @Test
    // @DisplayName("Test hydra health increase 0.90 chance") 
    // public void testHydraBattleTwo() {
    //     DungeonManiaController dmc = new DungeonManiaController();
    //     dmc.newGame("d_battleTest_hydra", "c_battleTests_hydraTwo");

    //     DungeonResponse res = dmc.tick(Direction.RIGHT);

    //     BattleResponse battleRes = res.getBattles().get(0);
    //     List<RoundResponse> rounds = battleRes.getRounds();

    //     // Assert that the health of the hydra increases for half of the attacks
    //     int numDecrease = 0;
    //     int numIncrease = 0;
    //     for (int i = 0; i < rounds.size(); i++) {
    //         if (rounds.get(i).getDeltaEnemyHealth() > 0) {
    //             numIncrease += 1;
    //         } else {
    //             numDecrease += 1;
    //         }
    //     }

    //     // Assert approximately half of the attacks cause increase while 
    //     // approximately half causes health decrease
    //     assertTrue(85 <= numIncrease && numIncrease <= 95);
    //     assertTrue(5 <= numDecrease && numDecrease <= 15);
    // }
}
