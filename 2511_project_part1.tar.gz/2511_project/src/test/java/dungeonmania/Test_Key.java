package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static dungeonmania.TestUtils.getPlayer;
import static dungeonmania.TestUtils.getEntities;
import static dungeonmania.TestUtils.getInventory;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.response.models.EntityResponse;
import dungeonmania.util.Direction;
import dungeonmania.util.Position;

public class Test_Key {
    

    @Test
    @DisplayName("Test if key works correctly")
    public void testKeyUse() throws IllegalArgumentException, InvalidActionException {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_bombTest_testBasicKey", "c_movementTest_testMovement");
        EntityResponse initPlayer = getPlayer(dungeon).get();
        assertEquals(1, getEntities(dungeon, "key").size());
        
        // move player right where the closed door exists
        DungeonResponse actualDungeonRes = dmc.tick(Direction.DOWN);
        EntityResponse actualPlayer = getPlayer(actualDungeonRes).get();

        // create the expected result
        EntityResponse expectedPlayer = new EntityResponse(initPlayer.getId(), initPlayer.getType(), new Position(2, 2), false);

        // assert after movement
        assertEquals(expectedPlayer, actualPlayer);

        // move the player up where the key exists
        actualDungeonRes = dmc.tick(Direction.UP);
        // Check that the key had been picked up
        assertEquals(0, getEntities(actualDungeonRes, "key").size());
        assertEquals(1, getInventory(actualDungeonRes, "key").size());

        // move player down where a door exists, with a treasure behind it
        actualDungeonRes = dmc.tick(Direction.DOWN);
        // door should be unlocked
        actualDungeonRes = dmc.tick(Direction.DOWN);
        assertEquals(0, getInventory(actualDungeonRes, "key").size());
        // treasure should be collected
        actualDungeonRes = dmc.tick(Direction.DOWN);
        // Check that the treasure had been picked up
        assertEquals(0, getEntities(actualDungeonRes, "treasure").size());
        assertEquals(1, getInventory(actualDungeonRes, "treasure").size());

        actualPlayer = getPlayer(actualDungeonRes).get();

        // create the expected result
        expectedPlayer = new EntityResponse(initPlayer.getId(), initPlayer.getType(), new Position(2, 4), false);

        // assert after movement
        assertEquals(expectedPlayer, actualPlayer);

    }
}

