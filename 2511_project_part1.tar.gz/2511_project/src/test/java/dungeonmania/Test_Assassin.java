package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static dungeonmania.TestUtils.getEntities;
import static dungeonmania.TestUtils.getInventory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;
import dungeonmania.util.Position;
import dungeonmania.response.models.EntityResponse;
import static dungeonmania.TestUtils.getPlayer;

public class Test_Assassin {

    @Test
    @DisplayName("Test assassin move when player is invisible and within assassin_recon_radius")
    public void testAssaMoveWhenPlayerInvisible() throws InvalidActionException {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_assaTest_playerinvisible", "c_assaTest_movements");

        Position OriginalPosition = getEntities(res, "assassin").get(0).getPosition();
        
        // Pick up the potion, at the same time assassin moves to player
        res = dmc.tick(Direction.RIGHT);
        assertEquals(1, getInventory(res, "invisibility_potion").size());

        Position CurrPosition = getEntities(res, "assassin").get(0).getPosition();
        assertNotEquals(OriginalPosition, CurrPosition);

        // Use the potion, at the same time mercenary do not move
        res = dmc.tick("entity0");
        assertEquals(0, getInventory(res, "invisibility_potion").size());

        Position expectedPosition = getEntities(res, "assassin").get(0).getPosition();
        assertNotEquals(CurrPosition, expectedPosition);
        assertNotEquals(OriginalPosition, expectedPosition);

    }

    @Test
    @DisplayName("Test assassin stays when player is invisible and not within assassin_recon_radius")
    public void testAssaStay() throws InvalidActionException {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_assaTest_playerinvisible", "c_assaTest_smallRecon");

        Position OriginalPosition = getEntities(res, "assassin").get(0).getPosition();
        
        // Pick up the potion, at the same time assassin moves to player
        res = dmc.tick(Direction.RIGHT);
        assertEquals(1, getInventory(res, "invisibility_potion").size());

        Position CurrPosition = getEntities(res, "assassin").get(0).getPosition();
        assertNotEquals(OriginalPosition, CurrPosition);

        // Use the potion, at the same time mercenary do not move
        res = dmc.tick("entity0");
        assertEquals(0, getInventory(res, "invisibility_potion").size());

        Position expectedPosition = getEntities(res, "assassin").get(0).getPosition();
        assertEquals(CurrPosition, expectedPosition);

    }

    
}
