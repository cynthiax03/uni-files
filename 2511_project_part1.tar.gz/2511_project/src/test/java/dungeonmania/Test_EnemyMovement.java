package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static dungeonmania.TestUtils.getEntities;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;
import dungeonmania.util.Position;

public class Test_EnemyMovement {
    @Test 
    @DisplayName("Test spider movement is correct")
    public void testSpiderMovement() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_spiderTest_spiderMovement", "c_movementTest_testMovement");

        // Get the spider's position
        Position positionOne = getEntities(res, "spider").get(0).getPosition();

        // tick 1, check spider moves one square up 
        res = dmc.tick(Direction.DOWN);
        Position positionTwo = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionTwo, positionOne.translateBy(Direction.UP));

        // tick 2, check spider moves right one square
        res = dmc.tick(Direction.DOWN);
        Position positionThree = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionThree, positionTwo.translateBy(Direction.RIGHT));

        // tick 3, check spider moves down one square, onto a wall
        res = dmc.tick(Direction.DOWN);
        Position positionFour = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionFour, positionThree.translateBy(Direction.DOWN));

        // tick 4, check spider moves down one square
        res = dmc.tick(Direction.DOWN);
        Position positionFive = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionFive, positionFour.translateBy(Direction.DOWN));

        // tick 5, check spider moves left one square, onto a wall
        res = dmc.tick(Direction.DOWN);
        Position positionSix = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionSix, positionFive.translateBy(Direction.LEFT));

        // tick 6, check spider moves left one square
        res = dmc.tick(Direction.DOWN);
        Position positionSeven = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionSeven, positionSix.translateBy(Direction.LEFT));

        // tick 7, check spider moves up one square, onto a wall
        res = dmc.tick(Direction.DOWN);
        Position positionEight = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionEight, positionSeven.translateBy(Direction.UP));

        // tick 8, check spider moves up one square
        res = dmc.tick(Direction.DOWN);
        Position positionNine = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionNine, positionEight.translateBy(Direction.UP));

        // tick 9, check spider moves right one square
        res = dmc.tick(Direction.DOWN);
        Position positionTen = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionTen, positionNine.translateBy(Direction.RIGHT));

        // One circle complete, assert it can continue
        // tick 10, check spider moves right one square
        res = dmc.tick(Direction.DOWN);
        Position positionEleven = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionEleven, positionTen.translateBy(Direction.RIGHT));

    }

    @Test 
    @DisplayName("Test spider cannot move onto a boulder and reverses position")
    public void testSpiderBoulderMovement() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_spiderTest_spiderBoulderMovement", "c_movementTest_testMovement");
        
        // tick 1, spider moves up one square
        DungeonResponse res = dmc.tick(Direction.DOWN);
        Position positionOne = getEntities(res, "spider").get(0).getPosition();

        // tick 2, spider reverse as next position is a boulder
        res = dmc.tick(Direction.DOWN);
        Position positionTwo = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionTwo, positionOne.translateBy(Direction.LEFT));

        // tick 3 assert spider is going in reverse direction
        res = dmc.tick(Direction.DOWN);
        Position positionThree = getEntities(res, "spider").get(0).getPosition();
        assertEquals(positionThree, positionTwo.translateBy(Direction.DOWN));
    }
}
