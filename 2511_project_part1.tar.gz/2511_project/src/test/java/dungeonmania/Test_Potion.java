package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static dungeonmania.TestUtils.getPlayer;
import static dungeonmania.TestUtils.getEntities;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.BattleResponse;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.response.models.EntityResponse;
import dungeonmania.response.models.RoundResponse;
import dungeonmania.util.Direction;

public class Test_Potion {
    
    @Test
    @DisplayName("Test if invincible potion works")
    public void testInvinciblePotion() throws IllegalArgumentException, InvalidActionException {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse initDungonRes = dmc.newGame("d_potionTest_testInvinciblePotion", "c_potionTest_testPotion");
        EntityResponse initPlayer = getPlayer(initDungonRes).get();

        // move player towards right where invincibility potion exists
        dmc.tick(Direction.RIGHT);

        // Given the potion had been obtained, use the invincibility potion
        DungeonResponse updatedDungeon = dmc.tick("entity1");

        assertEquals(1, getEntities(updatedDungeon, "zombie_toast").size());
        // move player towards right where zombie is spawned
        updatedDungeon = dmc.tick(Direction.RIGHT);
        
        // Get the battle
        BattleResponse battleRes = updatedDungeon.getBattles().get(0);
        List<RoundResponse> rounds = battleRes.getRounds();

        // move player towards left to update the game
        updatedDungeon = dmc.tick(Direction.LEFT);

        // Assert the battle ended after one round and one zombie was killed and another spawned
        assertEquals(1, rounds.size());
        assertEquals(1, getEntities(updatedDungeon, "zombie_toast").size());
    }

    @Test
    @DisplayName("Test if invisible potion works")
    public void testInvisiblePotion() throws IllegalArgumentException, InvalidActionException {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse initDungonRes = dmc.newGame("d_potionTest_testInvisiblePotion", "c_potionTest_testPotion");
        EntityResponse initPlayer = getPlayer(initDungonRes).get();

        // move player towards right where invisibility potion exists
        dmc.tick(Direction.RIGHT);

        // Given the potion had been obtained, use the invisibility potion
        dmc.tick("entity1");

        // move player towards right where zombie is spawned
        DungeonResponse updatedDungeon = dmc.tick(Direction.RIGHT);
        assertEquals(1, getEntities(updatedDungeon, "zombie_toast").size());

        // Check no battles were created
        List<BattleResponse> battleRes = updatedDungeon.getBattles();
        assertEquals(0, battleRes.size());
    }

}
