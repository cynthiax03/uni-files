package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static dungeonmania.TestUtils.getPlayer;
import static dungeonmania.TestUtils.getEntities;
import static dungeonmania.TestUtils.getInventory;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.response.models.EntityResponse;
import dungeonmania.util.Direction;
import dungeonmania.util.Position;

public class Test_Bomb {
    

    @Test
    @DisplayName("Test if bomb works correctly")
    public void testBombuse() throws IllegalArgumentException, InvalidActionException {

        // The player is on top of the zombie
        // If the player is invincible, they will get into a battle
        // and they should win immediately


        // For invisibility, move player onto a zombie toast spawner
        // set spawn to 1 so a zombie will spawn at 1st tick, place wall
        // next to spawner, tick right so player does not move but game still 
        // ticks, assert no battle is created

        // For invincibility, move player onto a zombie toast spawner, set spawn
        // to 1, tick by moving against a wall, assert that a battle with one
        // round is created

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_bombTest_testBasicBomb", "c_bombTest_testBombDefault");
        EntityResponse initPlayer = getPlayer(dungeon).get();
        assertEquals(1, getEntities(dungeon, "bomb").size());
        
        // move player down where the bomb exists
        DungeonResponse actualDungeonRes = dmc.tick(Direction.DOWN);
        assertEquals(0, getEntities(actualDungeonRes, "bomb").size());
        // Check that the bomb had been picked up
        assertEquals(1, getInventory(actualDungeonRes, "bomb").size());

        // move player right where a boulder exists, with a floor switch behind it
        actualDungeonRes = dmc.tick(Direction.RIGHT);
        EntityResponse actualPlayer = getPlayer(actualDungeonRes).get();

        // create the expected result
        EntityResponse expectedPlayer = new EntityResponse(initPlayer.getId(), initPlayer.getType(), new Position(2, 2), false);

        // assert after movement
        assertEquals(expectedPlayer, actualPlayer);

        // Given the bomb had been obtained, use the bomb at current player position
        DungeonResponse updatedDungeon = dmc.tick("entity1");

        // move player right where the boulder no longer exists
        actualDungeonRes = dmc.tick(Direction.RIGHT);
        actualPlayer = getPlayer(actualDungeonRes).get();

        expectedPlayer = new EntityResponse(initPlayer.getId(), initPlayer.getType(), new Position(3, 2), false);
        // assert after movement
        assertEquals(expectedPlayer, actualPlayer);
    }

    @Test
    @DisplayName("Test if bomb works range")
    public void testBombUseRange() throws IllegalArgumentException, InvalidActionException {

        // The player is on top of the zombie
        // If the player is invincible, they will get into a battle
        // and they should win immediately


        // For invisibility, move player onto a zombie toast spawner
        // set spawn to 1 so a zombie will spawn at 1st tick, place wall
        // next to spawner, tick right so player does not move but game still 
        // ticks, assert no battle is created

        // For invincibility, move player onto a zombie toast spawner, set spawn
        // to 1, tick by moving against a wall, assert that a battle with one
        // round is created

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_bombTest_testBombRange", "c_bombTest_testBombRadius");
        EntityResponse initPlayer = getPlayer(dungeon).get();
        assertEquals(1, getEntities(dungeon, "bomb").size());
        
        // move player down where the bomb exists
        DungeonResponse actualDungeonRes = dmc.tick(Direction.DOWN);
        assertEquals(0, getEntities(actualDungeonRes, "bomb").size());
        // Check that the bomb had been picked up
        assertEquals(1, getInventory(actualDungeonRes, "bomb").size());

        actualDungeonRes = dmc.tick(Direction.DOWN);
        actualDungeonRes = dmc.tick(Direction.RIGHT);
        actualDungeonRes = dmc.tick(Direction.RIGHT);

        EntityResponse actualPlayer = getPlayer(actualDungeonRes).get();

        // create the expected result
        EntityResponse expectedPlayer = new EntityResponse(initPlayer.getId(), initPlayer.getType(), new Position(3, 3), false);

        // assert after movement
        assertEquals(expectedPlayer, actualPlayer);

        // Given the bomb had been obtained, use the bomb at current player position
        DungeonResponse updatedDungeon = dmc.tick("entity1");

        assertEquals(0, getEntities(actualDungeonRes, "bomb").size());
    }

    @Test
    @DisplayName("Test if bomb explodes if the switch is triggered")
    public void testBombExplodeAfter() throws IllegalArgumentException, InvalidActionException {

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse dungeon = dmc.newGame("d_bombTest_testBombSwitchAfter", "c_bombTest_testBombDefault");
        EntityResponse initPlayer = getPlayer(dungeon).get();
        assertEquals(1, getEntities(dungeon, "bomb").size());
        
        // move player down where the bomb exists
        DungeonResponse actualDungeonRes = dmc.tick(Direction.DOWN);
        assertEquals(0, getEntities(actualDungeonRes, "bomb").size());
        // Check that the bomb had been picked up
        assertEquals(1, getInventory(actualDungeonRes, "bomb").size());

        actualDungeonRes = dmc.tick(Direction.RIGHT);
        // Given the bomb had been obtained, use the bomb at current player position
        DungeonResponse updatedDungeon = dmc.tick("entity1");

        actualDungeonRes = dmc.tick(Direction.DOWN);
        actualDungeonRes = dmc.tick(Direction.DOWN);
        actualDungeonRes = dmc.tick(Direction.RIGHT);
        actualDungeonRes = dmc.tick(Direction.UP);

        assertEquals(0, getEntities(actualDungeonRes, "bomb").size());
        assertEquals(0, getEntities(actualDungeonRes, "boulder").size());
        assertEquals(0, getEntities(actualDungeonRes, "switch").size());


        EntityResponse actualPlayer = getPlayer(actualDungeonRes).get();

        // create the expected result
        EntityResponse expectedPlayer = new EntityResponse(initPlayer.getId(), initPlayer.getType(), new Position(3, 3), false);

        // assert after movement
        assertEquals(expectedPlayer, actualPlayer);

    }
}
