package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static dungeonmania.TestUtils.getInventory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;

public class Test_Build {
    @Test
    @DisplayName("Build a bow with no sufficient items")
    public void testBowBuildingFail() {
            DungeonManiaController dmc = new DungeonManiaController();
            DungeonResponse res = dmc.newGame("d_buildTest_buildBow", "c_movementTest_testMovement");
    
            // collect a wood
            res = dmc.tick(Direction.RIGHT);
            // collect 2 arrows
            res = dmc.tick(Direction.RIGHT);
            res = dmc.tick(Direction.RIGHT);

            assertThrows(InvalidActionException.class, () -> {
                dmc.build("bow");
            });
            assertEquals(0, getInventory(res, "bow").size());
            
    }

    @Test
    @DisplayName("Build a bow successfully")
    public void testBowBuilding() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_buildTest_buildBow", "c_movementTest_testMovement");

        // collect a wood
        dmc.tick(Direction.RIGHT);
        // collect 3 arrows
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.RIGHT);

        assertDoesNotThrow(() -> {dmc.build("bow");});

        DungeonResponse res = dmc.tick(Direction.RIGHT);
 
        // Check that bow has been built
        assertEquals(1, getInventory(res, "bow").size());
    }

    @Test
    @DisplayName("Build a shield successfully using key")
    public void testShieldBuildingByKey() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_buildTest_buildShieldByKey", "c_movementTest_testMovement");

        // collect 2 wood
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.RIGHT);
        // collect 1 key
        dmc.tick(Direction.RIGHT);

        assertDoesNotThrow(() -> {dmc.build("shield");});

        DungeonResponse dungonRes = dmc.tick(Direction.RIGHT);
 
        // Check that a shield has been made
        assertEquals(1, getInventory(dungonRes, "shield").size());
    }

    @Test
    @DisplayName("Build a shield successfully using treasure")
    public void testShieldBuildingByTreasure() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_buildTest_buildShieldByTreasure", "c_movementTest_testMovement");

        // collect 2 wood
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.RIGHT);
        // collect 1 treasure
        dmc.tick(Direction.RIGHT);

        assertDoesNotThrow(() -> {dmc.build("shield");});
        
        DungeonResponse res = dmc.tick(Direction.RIGHT);
 
        // Check that a shield was created
        assertEquals(1, getInventory(res, "shield").size());
    }

    @Test
    @DisplayName("Build a shield with no sufficient keys")
    public void testShieldBuildingFailFromKey() {
    
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_buildTest_buildShieldByKey", "c_movementTest_testMovement");

        // collect 2 wood
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);

        assertThrows(InvalidActionException.class, () -> {
            dmc.build("shield");
        });
        assertEquals(0, getInventory(res, "shield").size());

    }

    @Test
    @DisplayName("Build a shield with no sufficient treasure")
    public void testShieldBuildingFailFromTreasure() {
        
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_buildTest_buildShieldByTreasure", "c_movementTest_testMovement");
        

        // collect 2 wood
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);

        assertThrows(InvalidActionException.class, () -> {
            dmc.build("shield");
        });
        assertEquals(0, getInventory(res, "shield").size());
    }

    @Test
    @DisplayName("Build an entity that is not one of bow, shield, sceptre, or midnight_armour")
    public void testBuildingFail() {
        
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_buildTest_buildBow", "c_movementTest_testMovement");

        // collect a wood
        dmc.tick(Direction.RIGHT);
        // collect 2 arrows
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.RIGHT);


        assertThrows(IllegalArgumentException.class, () -> {
            dmc.build("key");
        });
    
    }

    @Test
    @DisplayName("Build a sceptre with no sufficient treasure")
    public void testSceptreBuildingFailFromTreasure() {
        
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_buildTest_buildSceptreWithNoTreasure", "c_movementTest_testMovement");
        

        // collect 1 wood
        res = dmc.tick(Direction.RIGHT);
        // collect 2 arrows
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        // collect 1 sun stone
        res = dmc.tick(Direction.RIGHT);

        assertThrows(InvalidActionException.class, () -> {
            dmc.build("sceptre");
        });
        assertEquals(0, getInventory(res, "sceptre").size());
    }

    @Test
    @DisplayName("Build a sceptre with no sufficient sun stone")
    public void testSceptreBuildingFailFromSunstone() {
        
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_buildTest_buildSceptreWithNoSunstone", "c_movementTest_testMovement");
        

        // collect 1 wood
        res = dmc.tick(Direction.RIGHT);
        // collect 2 arrows
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        // collect 1 key
        res = dmc.tick(Direction.RIGHT);

        assertThrows(InvalidActionException.class, () -> {
            dmc.build("sceptre");
        });
        assertEquals(0, getInventory(res, "sceptre").size());
    }

    @Test
    @DisplayName("Build a armour with no sufficient sword")
    public void testArmourBuildingFailFromSword() {
        
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_buildTest_buildArmour_withNoSword", "c_movementTest_testMovement");
        
        // collect 1 arrow
        res = dmc.tick(Direction.RIGHT);

        assertThrows(InvalidActionException.class, () -> {
            dmc.build("midnight_armour");
        });
        assertEquals(0, getInventory(res, "midnight_armour").size());
    }

    @Test
    @DisplayName("Build a armour with no sufficient sun stone")
    public void testArmourBuildingFailFromSunStone() {
        
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_buildTest_buildArmour_withNoSunstone", "c_movementTest_testMovement");
        
        // collect 1 sun stone
        res = dmc.tick(Direction.RIGHT);

        assertThrows(InvalidActionException.class, () -> {
            dmc.build("midnight_armour");
        });
        assertEquals(0, getInventory(res, "midnight_armour").size());
    }

    @Test
    @DisplayName("Build a armour with a zombie in the dungeon")
    public void testArmourBuildingFailFromZombie() {
        
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_buildTest_buildArmourWithZombie", "c_movementTest_testMovement");
       
        // collect 1 sword
        res = dmc.tick(Direction.RIGHT);
        // collect 1 sun stone
        res = dmc.tick(Direction.RIGHT);

        assertThrows(InvalidActionException.class, () -> {
            dmc.build("midnight_armour");
        });
        assertEquals(0, getInventory(res, "midnight_armour").size());
    }
    

    @Test
    @DisplayName("Build a sceptre successfully with a key")
    public void testSceptreBuildingFromKey() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_buildTest_buildSceptre", "c_movementTest_testMovement");

        // collect 2 arrows
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.RIGHT);
        // collect 1 key
        dmc.tick(Direction.RIGHT);
        // collect 1 sun stone
        dmc.tick(Direction.DOWN);


        assertDoesNotThrow(() -> {dmc.build("sceptre");});

        DungeonResponse res = dmc.tick(Direction.RIGHT);
 
        // Check that bow has been built
        assertEquals(1, getInventory(res, "sceptre").size());
    }

    @Test
    @DisplayName("Build a sceptre successfully with a treasure")
    public void testSceptreBuildingFromTreasure() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_buildTest_buildSceptre", "c_movementTest_testMovement");

        // collect 2 arrows
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        // collect 1 treasure
        res = dmc.tick(Direction.DOWN);
        // collect 1 sun stone
        res = dmc.tick(Direction.RIGHT);


        assertDoesNotThrow(() -> {dmc.build("sceptre");});

        res = dmc.tick(Direction.RIGHT);
 
        // Check that bow has been built
        assertEquals(1, getInventory(res, "sceptre").size());
        assertEquals(0, getInventory(res, "sun_stone").size());
    }

    @Test
    @DisplayName("Build a sceptre successfully sunstone replacing treasure")
    public void testSceptreBuildingFromSunstoneReplacement() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_buildTest_buildSceptre", "c_movementTest_testMovement");

        // collect 2 arrows
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        // collect 1 sun stone replacement
        res = dmc.tick(Direction.RIGHT);
        // collect 1 sun stone
        res = dmc.tick(Direction.DOWN);

        assertDoesNotThrow(() -> {dmc.build("sceptre");});

        res = dmc.tick(Direction.RIGHT);

        // Check that bow has been built
        assertEquals(1, getInventory(res, "sceptre").size());
        // when the sun stone is a replacement of key, it's retained
        assertEquals(1, getInventory(res, "sun_stone").size());

    }
    
    @Test
    @DisplayName("Build a midnight armour successfully with a treasure")
    public void testMidngihtArmourBuilding() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_buildTest_buildArmour", "c_movementTest_testMovement");

        // collect 1 sword
        DungeonResponse res = dmc.tick(Direction.RIGHT);
        // collect 1 sun stone
        res = dmc.tick(Direction.RIGHT);


        assertDoesNotThrow(() -> {dmc.build("midnight_armour");});

        res = dmc.tick(Direction.RIGHT);
 
        // Check that bow has been built
        assertEquals(1, getInventory(res, "midnight_armour").size());
    }

    @Test
    @DisplayName("Test shield can be built with sunstone and wood")
    public void testShieldBuildingWithSunstone() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_buildTest_shieldWithSunstone", "c_movementTest_testMovement");

        // Collect 2 woods
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.UP);

        // Collect a sunstone
        dmc.tick(Direction.RIGHT);

        // Build a shield
        assertDoesNotThrow(() -> {dmc.build("shield");});

        // Assert there is a shield in the player's inventory and that sunstone
        // is still in inventory
        DungeonResponse res = dmc.tick(Direction.RIGHT);
        assertEquals(1, getInventory(res, "shield").size());
        assertEquals(1, getInventory(res, "sun_stone").size());
    }
}
