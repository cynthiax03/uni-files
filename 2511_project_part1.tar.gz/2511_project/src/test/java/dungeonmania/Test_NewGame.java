package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static dungeonmania.TestUtils.getPlayer;
import static dungeonmania.TestUtils.getEntities;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.response.models.EntityResponse;
import dungeonmania.util.Position;

public class Test_NewGame {
    @Test
    @DisplayName("Test newGame dungeonResponse")
    public void testNewGameResponse() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse initDungeonRes = dmc.newGame("d_movementTest_testMovementDown", "c_movementTest_testMovementDown");
        EntityResponse player = getPlayer(initDungeonRes).get();
        EntityResponse exit = getEntities(initDungeonRes, "exit").get(0);

        EntityResponse expectedPlayer = new EntityResponse("entity1", "player", new Position(1, 1), false);
        EntityResponse expectedExit = new EntityResponse("entity0", "exit", new Position(1, 3), false);
        assertEquals(player, expectedPlayer);
        assertEquals(exit, expectedExit);
    }

    @Test 
    @DisplayName("Test newGame exceptions")
    public void testNewGameExceptions() {
        DungeonManiaController dmc = new DungeonManiaController();
        assertThrows(IllegalArgumentException.class, () -> {
            dmc.newGame("invalid", "random");
        });
    }
}
