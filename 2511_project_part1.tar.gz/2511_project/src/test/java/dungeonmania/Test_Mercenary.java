package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static dungeonmania.TestUtils.getEntities;
import static dungeonmania.TestUtils.getInventory;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;
import dungeonmania.util.Position;
import dungeonmania.response.models.EntityResponse;
import static dungeonmania.TestUtils.getPlayer;

public class Test_Mercenary {
    @Test
    @DisplayName("Test mercenaries movement")
    public void testMercMovements() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_mercTest_movements", "c_mercTest_movements");
        dmc.tick(Direction.LEFT);
        dmc.tick(Direction.UP);
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.DOWN);
        dmc.tick(Direction.RIGHT);

        // Mercenary should be at the same position at this tick (so battle
        // should be created and mercenary should die)
        DungeonResponse res = dmc.tick(Direction.DOWN);
        assertEquals(0, getEntities(res, "mercenary").size());
    }

    @Test
    @DisplayName("Mercenary is not within specified bribing radius (radius is 1)")
    public void testMercenaryBribeRadius() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_MercenaryNotInRadius", "c_movementTest_testMovement");

        String mercenaryId = getEntities(res, "mercenary").get(0).getId();
        // collect a treasure 
        res = dmc.tick(Direction.RIGHT);

        Position player_p = getEntities(res, "player").get(0).getPosition();
        assertEquals(player_p.getX(), 2);
        assertEquals(player_p.getY(), 1);

        Position mercenary_p = getEntities(res, "mercenary").get(0).getPosition();
        assertEquals(mercenary_p.getX(), 2);
        assertEquals(mercenary_p.getY(), 5);
        
        assertThrows(InvalidActionException.class, () -> {
            dmc.interact(mercenaryId);
        });
    }

    
    @Test
    @DisplayName("Mercenary is within specified bribing radius (radius is 2)")
    public void testMercenaryBribeRadius2_0() {
        DungeonManiaController dmc = new DungeonManiaController();
        // the new bribe radius is 2
        DungeonResponse res = dmc.newGame("d_interactTest_MercenaryInRadius", "c_interactTest_mercenaryInRange");

        String mercenaryId = getEntities(res, "mercenary").get(0).getId();
        // collect a treasure
        res = dmc.tick(Direction.RIGHT);

        assertDoesNotThrow(() -> {dmc.interact(mercenaryId);});
    }

    @Test
    @DisplayName("Mercenary is not within specified bribing radius (radius is 3)")
    public void testMercenaryBribeRadius3_0() {

        DungeonManiaController dmc = new DungeonManiaController();
        // the new bribe radius is 3
        DungeonResponse res = dmc.newGame("d_interactTest_MercenaryInRadius", "c_interactTest_mercenaryInRange");

        String mercenaryId = getEntities(res, "mercenary").get(1).getId();
        // collect a treasure
        res = dmc.tick(Direction.RIGHT);

        assertThrows(InvalidActionException.class, () -> {
            dmc.interact(mercenaryId);
        });
    }

    @DisplayName("Test mercenary runs away when player is invincible")
    public void testMercRunAway() throws InvalidActionException {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_mercTest_playerinvincible", "c_mercTest_movements");

        EntityResponse initPlayer = getPlayer(res).get();
        Position mercOriginalPosition = getEntities(res, "mercenary").get(0).getPosition();
        
        // Pick up the potion, at the same time mercenary moves to player
        res = dmc.tick(Direction.RIGHT);
        assertEquals(1, getInventory(res, "invincibility_potion").size());

        Position mercCurrPosition = getEntities(res, "mercenary").get(0).getPosition();
        assertNotEquals(mercOriginalPosition, mercCurrPosition);
        // Use the potion, at the same time mercenary moves away from player, so should be back to 
        // the original spot

        res = dmc.tick("entity0");
        assertEquals(0, getInventory(res, "invincibility_potion").size());

        mercCurrPosition = getEntities(res, "mercenary").get(0).getPosition();
        assertEquals(mercCurrPosition, mercOriginalPosition);
    
    }

    @Test
    @DisplayName("Test mercenary remain at the current position when player is invisible")
    public void testMercDontMove() throws InvalidActionException {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_mercTest_playerinvisible", "c_mercTest_movements");

        EntityResponse initPlayer = getPlayer(res).get();
        Position mercOriginalPosition = getEntities(res, "mercenary").get(0).getPosition();
        
        // Pick up the potion, at the same time mercenary moves to player
        res = dmc.tick(Direction.RIGHT);
        assertEquals(1, getInventory(res, "invisibility_potion").size());

        Position mercCurrPosition = getEntities(res, "mercenary").get(0).getPosition();
        assertNotEquals(mercOriginalPosition, mercCurrPosition);

        // Use the potion, at the same time mercenary do not move
        res = dmc.tick("entity0");
        assertEquals(0, getInventory(res, "invisibility_potion").size());
        Position expectedPosition = getEntities(res, "mercenary").get(0).getPosition();
        mercCurrPosition = getEntities(res, "mercenary").get(0).getPosition();
        assertEquals(mercCurrPosition, expectedPosition);
    
    }
}
