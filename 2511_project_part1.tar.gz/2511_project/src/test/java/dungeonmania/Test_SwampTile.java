package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import static dungeonmania.TestUtils.getPlayer;
import static dungeonmania.TestUtils.getEntities;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.response.models.DungeonResponse;
import dungeonmania.response.models.EntityResponse;
import dungeonmania.util.Direction;
import dungeonmania.util.Position;

public class Test_SwampTile {
    @Test
    @DisplayName("Test player movement is not affected by swamp tile") 
    public void testPlayerSwampTile() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_swampTileTests_player", "c_swampTileTests");

        // Move onto the tile
        DungeonResponse res = dmc.tick(Direction.RIGHT);
        EntityResponse player = getPlayer(res).get();
        EntityResponse swamp = getEntities(res, "swamp_tile").get(0);
        assertEquals(player.getPosition(), swamp.getPosition());

        // Assert the player can move off the tile in the next movement tick
        // even though the movement factor is 3
        res = dmc.tick(Direction.RIGHT);
        player = getPlayer(res).get();
        assertNotEquals(player.getPosition(), swamp.getPosition());
        assertEquals(new Position(3, 1), player.getPosition());
    }

    @Test
    @DisplayName("Test zombie movement is slowed down by swamp tile") 
    public void testZombieSwampTile() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_swampTileTests_zombie", "c_swampTileTests");

        // Tick the game 4 times to spawn a zombie
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.RIGHT);
        dmc.tick(Direction.RIGHT);
        DungeonResponse res = dmc.tick(Direction.RIGHT);

        // Get the swamp
        EntityResponse swamp = getEntities(res, "swamp_tile").get(0);

        // Zombie should move onto a swamp tile
        EntityResponse zombie = getEntities(res, "zombie_toast").get(0);
        assertEquals(zombie.getPosition(), swamp.getPosition());

        // (tick 5) zombie still stuck
        res = dmc.tick(Direction.RIGHT);
        zombie = getEntities(res, "zombie_toast").get(0);
        assertEquals(zombie.getPosition(), swamp.getPosition());

        // (tick 6) zombie moves off swamp
        res = dmc.tick(Direction.RIGHT);
        zombie = getEntities(res, "zombie_toast").get(0);
        assertNotEquals(zombie.getPosition(), swamp.getPosition());
    }

    @Test
    @DisplayName("Test spider movement is slowed down by swamp tile") 
    public void testSpiderSwampTile() {  
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_swampTileTests_spider", "c_swampTileTests");

        // Tick the game (tick 1)
        DungeonResponse res = dmc.tick(Direction.RIGHT);

        // Get the swamp
        EntityResponse swamp = getEntities(res, "swamp_tile").get(0);

        // Spider should move onto a swamp tile
        EntityResponse spider = getEntities(res, "spider").get(0);

        // (tick 2) spider is still stuck
        res = dmc.tick(Direction.RIGHT);
        spider = getEntities(res, "spider").get(0);
        assertEquals(spider.getPosition(), swamp.getPosition());

        // (tick 3) spider is still stuck
        res = dmc.tick(Direction.RIGHT);
        spider = getEntities(res, "spider").get(0);
        assertEquals(spider.getPosition(), swamp.getPosition());

        // (tick 4) spider should move off swamp as movement factor is 2
        res = dmc.tick(Direction.RIGHT);
        spider = getEntities(res, "spider").get(0);

        assertNotEquals(spider.getPosition(), swamp.getPosition());
        assertEquals(spider.getPosition(), new Position(1, -1));

    }

    @Test
    @DisplayName("Test mercenary movement is slowed down by swamp tile") 
    public void testEnemySwampTile() {  
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_swampTileTests_mercenary", "c_swampTileTests");

        // Tick the game (tick 1)
        DungeonResponse res = dmc.tick(Direction.RIGHT);

        // Get the swamp
        EntityResponse swamp = getEntities(res, "swamp_tile").get(0);

        // Mercenary should move onto a swamp tile
        EntityResponse mercenary = getEntities(res, "mercenary").get(0);
        assertEquals(mercenary.getPosition(), swamp.getPosition());

        // (tick 2) mercenary still stuck
        res = dmc.tick(Direction.RIGHT);
        mercenary = getEntities(res, "mercenary").get(0);
        assertEquals(mercenary.getPosition(), swamp.getPosition());

        // (tick 3) mercenary still stuck
        res = dmc.tick(Direction.RIGHT);
        mercenary = getEntities(res, "mercenary").get(0);
        assertEquals(mercenary.getPosition(), swamp.getPosition());

        // (tick 4) mercenary still stuck
        res = dmc.tick(Direction.RIGHT);
        mercenary = getEntities(res, "mercenary").get(0);
        assertEquals(mercenary.getPosition(), swamp.getPosition());

        // (tick 5) mercenary moves off swamp as movement factor is 3
        res = dmc.tick(Direction.RIGHT);
        mercenary = getEntities(res, "mercenary").get(0);
        assertNotEquals(mercenary.getPosition(), swamp.getPosition());
        assertEquals(mercenary.getPosition(), new Position(4, 1));
    }

    @Test
    @DisplayName("Test mercenary does not go on swamp as there is a shorter path") 
    public void testMercenaryAvoidsSwamp() {  
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_swampTileTests_mercenaryAvoidsSwamp", "c_swampTileTests");

        EntityResponse swamp = getEntities(res, "swamp_tile").get(0);

        // Tick the game once and check that the mercenary does not move onto 
        // the swamp
        res = dmc.tick(Direction.RIGHT);
        EntityResponse mercenary = getEntities(res, "mercenary").get(0);
        assertNotEquals(mercenary.getPosition(), swamp.getPosition());

    }
}
