package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static dungeonmania.TestUtils.getEntities;
import static dungeonmania.TestUtils.getInventory;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.response.models.DungeonResponse;
import dungeonmania.response.models.EntityResponse;
import dungeonmania.util.Direction;
import dungeonmania.util.Position;

public class Test_Door {

    @Test
    @DisplayName("Test door can be opened with a sunstone")
    public void testSunstoneCanOpenDoor() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_sunstoneTest_unlockDoors", "c_DoorsKeysTest_useCorresKey");
        
        // Collect sunstone
        DungeonResponse res = dmc.tick(Direction.RIGHT);
        assertEquals(1, getInventory(res, "sun_stone").size());

        // Use it to open door 1
        res = dmc.tick(Direction.RIGHT);
        EntityResponse player = getEntities(res, "player").get(0);
        assertEquals(player.getPosition(), new Position(3, 1));

        // Assert it is still in inventory
        assertEquals(1, getInventory(res, "sun_stone").size());

        // Use it to open door 2
        res = dmc.tick(Direction.DOWN);
        player = getEntities(res, "player").get(0);
        assertEquals(player.getPosition(), new Position(3, 2));

        // Assert it is still in inventory
        assertEquals(1, getInventory(res, "sun_stone").size());
    }

     @Test
    @DisplayName("Test door can only be opened by the corresponding key")
    public void testDoorCorrespondKey() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_DoorsKeysTest_useCorresKey", "c_DoorsKeysTest_useCorresKey");

        // pick up key2
        res = dmc.tick(Direction.RIGHT);
        Position pos = getEntities(res, "player").get(0).getPosition();
        assertEquals(1, getInventory(res, "key").size());

        // try to open door1 but failed, stay at original position
        res = dmc.tick(Direction.RIGHT);
        assertEquals(1, getInventory(res, "key").size());
        assertEquals(pos, getEntities(res, "player").get(0).getPosition());

        // // pick up key1
        // res = dmc.tick(Direction.DOWN);
        // pos = getEntities(res, "player").get(0).getPosition();
        // assertEquals(2, getInventory(res, "key").size());

        // // go back to door1 and open it with key1, should success and player will move through
        // // the door
        // res = dmc.tick(Direction.UP);
        // pos = getEntities(res, "player").get(0).getPosition();

        // res = dmc.tick(Direction.RIGHT);
        // assertEquals(1, getInventory(res, "key").size());
        // assertNotEquals(pos, getEntities(res, "player").get(0).getPosition());

        // // try to open door2 with other key
        // pos = getEntities(res, "player").get(0).getPosition();
        // res = dmc.tick(Direction.DOWN);
        // assertNotEquals(pos, getEntities(res, "player").get(0).getPosition());
    }

}
