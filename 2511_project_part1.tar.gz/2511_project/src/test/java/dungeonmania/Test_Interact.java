package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.response.models.EntityResponse;
import static dungeonmania.TestUtils.getEntities;
import static dungeonmania.TestUtils.getInventory;
import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;


public class Test_Interact {
    @DisplayName("entityId is not valid")
    public void testInteractInvalidEntityId() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_interactTest_InvalidEntityId", "c_movementTest_testMovement");

        assertThrows(IllegalArgumentException.class, () -> {
            dmc.interact("11");
        });
    }

    @Test
    @DisplayName("entityId is not valid")
    public void testInteractWithNoValidMercenaryAndSpawnerId() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_InvalidEntityId", "c_movementTest_testMovement");

        String treausreId = getEntities(res, "treasure").get(0).getId();

        assertThrows(IllegalArgumentException.class, () -> {
            dmc.interact(treausreId);
        });
    }

    @Test
    @DisplayName("Player does not have enough gold and sceptre and attempts to bribe a mercenary")
    public void testBribeWithNoGold() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_NotSufficientGold", "c_movementTest_testMovement");

        String mercenaryId = getEntities(res, "mercenary").get(0).getId();

        assertThrows(InvalidActionException.class, () -> {
            dmc.interact(mercenaryId);
        });
    }
    
    @Test
    @DisplayName("Player bribes mercenary but failed because he is using sun stone")
    public void testBribeMercenaryWithSunstone() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_InteractTest_BribeWithSunston", "c_interactTest_mercenaryInRange");

        // collect 1 sun stone
        res = dmc.tick(Direction.LEFT);

        String mercenaryId = getEntities(res, "mercenary").get(0).getId();
        boolean interactable = getEntities(res, "mercenary").get(0).isInteractable();
        assertEquals(true, interactable);

        assertThrows(InvalidActionException.class, () -> {
            dmc.interact(mercenaryId);
        });
    }

    @Test
    @DisplayName("Player Bribing assassin but failed because he is using sun stone")
    public void testMindcontrollingAssassinWithSunstone() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_InteractTest_BribeWithSunston", "c_interactTest_mercenaryInRange");

        // collect 1 sun stone
        res = dmc.tick(Direction.LEFT);

        String assassinId = getEntities(res, "assassin").get(0).getId();

        assertThrows(InvalidActionException.class, () -> {
            dmc.interact(assassinId);
        });
    }

    // @Test
    // @DisplayName("Failing Mind controlling an assassin with treasure because of its high fail rate")
    // public void testMindcontrollingAssassinWithHighFailRate() {
    //     DungeonManiaController dmc = new DungeonManiaController();
    //     DungeonResponse res = dmc.newGame("d_interactTest_bribeAssassin", "c_interactTest_assassinInRangeHighFailRate");

    //     // collect 2 treasure
    //     res = dmc.tick(Direction.DOWN);
    //     res = dmc.tick(Direction.DOWN);
 
    //     assertEquals(2, getInventory(res, "treasure").size());
    //     boolean interactacble = getEntities(res, "assassin").get(0).isInteractable();
    //     String assassinId = getEntities(res, "assassin").get(0).getId();
    //     assertDoesNotThrow(() -> {dmc.interact(assassinId);});

    //     assertEquals(true, interactacble);
    // }

    // @Test
    // @DisplayName("Mind controlling an assassin with treasure because of its low fail rate")
    // public void testMindcontrollingAssassinWithLowFailRate() {
    //     DungeonManiaController dmc = new DungeonManiaController();
    //     DungeonResponse res = dmc.newGame("d_interactTest_bribeAssassin", "c_interactTest_assassinInRange");

    //     // collect 2 treasure
    //     res = dmc.tick(Direction.DOWN);
    //     res = dmc.tick(Direction.DOWN);
 
    //     assertEquals(2, getInventory(res, "treasure").size());

    //     boolean interactable = getEntities(res, "assassin").get(0).isInteractable();
    //     assertEquals(false, interactable);
    // }

    @Test
    @DisplayName("Bribe a mercenary successfully with gold and within the bribe radius")
    public void testBribeMercenaryWithGold() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_bribeMercenary", "c_interactTest_mercenaryInRange");
        String mercenaryId = getEntities(res, "mercenary").get(0).getId();

        // collect 1 treasure
        res = dmc.tick(Direction.LEFT);

        boolean interactable = getEntities(res, "mercenary").get(0).isInteractable();
        assertEquals(true, interactable);

        assertDoesNotThrow(() -> {dmc.interact(mercenaryId);});
        res = dmc.tick(Direction.LEFT);

        interactable = getEntities(res, "mercenary").get(0).isInteractable();
        assertEquals(false, interactable);
    }

    @Test
    @DisplayName("Mind control a mercenary successfully with a sceptre only")
    public void testBribeMercenaryWithSceptre() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_bribeMercenary", "c_movementTest_testMovement");
        String mercenaryId = getEntities(res, "mercenary").get(0).getId();

        // collect 1 wood
        res = dmc.tick(Direction.DOWN);
        // collect 1 key
        res = dmc.tick(Direction.DOWN);
        // collect 1 sun stone
        res = dmc.tick(Direction.DOWN);
        // build a sceptre
        assertDoesNotThrow(() -> {dmc.build("sceptre");});

        res = dmc.tick(Direction.RIGHT);
 
        assertEquals(1, getInventory(res, "sceptre").size());

        assertDoesNotThrow(() -> {dmc.interact(mercenaryId);});

        res = dmc.tick(Direction.RIGHT);
        boolean interactable = getEntities(res, "mercenary").get(0).isInteractable();
        assertEquals(false, interactable);
    }

    @Test
    @DisplayName("Mind controlling an assassin successfully with a sceptre only")
    public void testMindcontrollingAssassinWithSceptre() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_bribeAssassin", "c_interactTest_mercenaryInRange");
        String assassinId = getEntities(res, "assassin").get(0).getId();

        // collect 1 wood
        res = dmc.tick(Direction.RIGHT);
        // collect 1 key
        res = dmc.tick(Direction.RIGHT);
        // collect 1 sun stone
        res = dmc.tick(Direction.RIGHT);
        // build a sceptre
        assertDoesNotThrow(() -> {dmc.build("sceptre");});
        res = dmc.tick(Direction.LEFT);
        assertEquals(1, getInventory(res, "sceptre").size());

        assertDoesNotThrow(() -> {dmc.interact(assassinId);});

        res = dmc.tick(Direction.LEFT);
        boolean interactable = getEntities(res, "assassin").get(0).isInteractable();
        assertEquals(false, interactable);

        // Tick twice, the mind control should wear off and assassin should be
        // interactable (hostile) again
        res = dmc.tick(Direction.LEFT);
        EntityResponse assassin = getEntities(res, "assassin").get(0);
        assertEquals(true, assassin.isInteractable());

    }

    @Test
    @DisplayName("Bribing an assassin successfully with treasure only, fail rate 0")
    public void testBribeAssassinSuccess() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_bribeAssassin", "c_interactTest_assassinInRange");
        String assassinId = getEntities(res, "assassin").get(0).getId();

        // collect 2 treasure
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.DOWN);
 
        assertEquals(2, getInventory(res, "treasure").size());

        assertDoesNotThrow(() -> {dmc.interact(assassinId);});

        res = dmc.tick(Direction.RIGHT);
        boolean interactable = getEntities(res, "assassin").get(0).isInteractable();
        assertEquals(false, interactable);
    }

    @Test 
    @DisplayName("Test bribe assassin is unsuccessful and gold is lost, fail rate 1")
    public void testBribeAssassinFail() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_interactTest_bribeAssassin", "c_interactTest_assassinHighFailRate");
        String assassinId = getEntities(res, "assassin").get(0).getId();

        // collect 2 treasure
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.DOWN);
        assertEquals(2, getInventory(res, "treasure").size());

        // Attempt to bribe assassin
        assertDoesNotThrow(() -> {dmc.interact(assassinId);});

        res = dmc.tick(Direction.RIGHT);

        // The fail rate is 1, treasure should be wasted and assassin is not bribed
        assertEquals(0, getInventory(res, "treasure").size());
        boolean interactable = getEntities(res, "assassin").get(0).isInteractable();
        assertEquals(true, interactable);
    }

    
}
