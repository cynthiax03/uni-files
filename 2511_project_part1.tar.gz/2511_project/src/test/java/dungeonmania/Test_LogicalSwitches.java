package dungeonmania;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import static dungeonmania.TestUtils.getPlayer;
import static dungeonmania.TestUtils.getEntities;
import static dungeonmania.TestUtils.getInventory;

import java.util.List;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import dungeonmania.response.models.DungeonResponse;
import dungeonmania.response.models.EntityResponse;
import dungeonmania.util.Direction;

public class Test_LogicalSwitches {
    @Test
    @DisplayName("Test lightbulb is turned on by one or more boulder OR")
    public void TestLightBulbSwitchesOnWithBoulderOr() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_logicalSwitchTests_lightBulbOnOR", "c_movementTest_testMovement");

        // Light bulb should be created off 
        List<EntityResponse> lightBulbOff = getEntities(res, "light_bulb_off");
        List<EntityResponse> lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push boulder onto a switch cardinally adjacent to light bulb
        res = dmc.tick(Direction.RIGHT);

        // Check light bulb is switched on (it has logic OR - one cardinally
        // adjacent entity will switch it on)
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push boulder on another cardinally adjacent switch (two switches 
        // activated)
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.RIGHT);

        // Assert light bulb is still on
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push the boulder off one switch (1 switch activated)
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.UP);

        // Assert light bulb is still on
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push the boulder off other switch (0 switches activated)
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.RIGHT);

        // Assert the light bulb is off
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());
    }

    @Test 
    @DisplayName("Test lightbulb switched on by two or more boulders AND") 
    public void TestLightBulbSwitchesOnWithBoulderAND() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_logicalSwitchTests_lightBulbOnAND", "c_movementTest_testMovement");

        // Light bulb should be created off 
        List<EntityResponse> lightBulbOff = getEntities(res, "light_bulb_off");
        List<EntityResponse> lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push boulder onto a switch cardinally adjacent to light bulb
        res = dmc.tick(Direction.RIGHT);

        // Check light bulb is switched off (it has logic AND - two+ cardinally
        // adjacent entities will switch it on)
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push boulder on another cardinally adjacent switch (two switches 
        // activated)
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.RIGHT);

        // Assert light bulb is off
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push another boulder on a switch (3 switches activated)
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.RIGHT);

        // Assert light bulb is on
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push boulder off one switch (2 activated)
        res = dmc.tick(Direction.RIGHT);

        // Assert light bulb is off
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push the boulder off another switch (1 switch activated)
        res = dmc.tick(Direction.DOWN);

        // Assert the light bulb is off
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());
    }

    @Test 
    @DisplayName("Test lightbulb switched on by one and only one boulder XOR") 
    public void TestLightBulbSwitchesOnWithBoulderXOR() {
        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_logicalSwitchTest_lightBulbOnXOR", "c_movementTest_testMovement");

        // Light bulb should be created off 
        List<EntityResponse> lightBulbOff = getEntities(res, "light_bulb_off");
        List<EntityResponse> lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push boulder onto a switch cardinally adjacent to light bulb
        res = dmc.tick(Direction.RIGHT);

        // Check light bulb is switched on (it has logic XOR - one and only one
        // cardinally adjacent entities will switch it on)
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push boulder on another cardinally adjacent switch (two switches 
        // activated)
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.RIGHT);

        // Assert light bulb got turned off
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push boulder off one switch (1 switch activated)
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);

        // Assert light bulb is on again
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());
    }

    @Test 
    @DisplayName("Test lightbulb switched on by circuit AND") 
    public void TestLightBulbSwitchesOnWithCircuitAND() {
        // Map layout
        //   0 1 2 3
        // 1 S W W L
        // 2 B     W
        // 3 P B S W

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_logicalSwitchTests_lightBulbCircuitAND", "c_movementTest_testMovement");

        // Light bulb should be created off 
        List<EntityResponse> lightBulbOff = getEntities(res, "light_bulb_off");
        List<EntityResponse> lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push boulder on a switch
        res = dmc.tick(Direction.RIGHT);

        // Assert light bulb is off
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push boulder onto a switch cardinally adjacent to a wire
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.UP);

        // Check light bulb is switched on (it has logic AND - two+
        // cardinally adjacent entities will switch it on)
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push boulder off one switch (1 switch activated)
        res = dmc.tick(Direction.UP);

        // Assert light bulb gets turned off
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());
    }

    @Test 
    @DisplayName("Test lightbulb switched on by circuit OR") 
    public void TestLightBulbSwitchesOnWithCircuitOR() {
        // Map layout
        //   0 1 2 3
        // 1 S W W L
        // 2 B P B S

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_logicalSwitchTest_lightBulbCircuitOR", "c_movementTest_testMovement");

        // Light bulb should be created off 
        List<EntityResponse> lightBulbOff = getEntities(res, "light_bulb_off");
        List<EntityResponse> lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push boulder on a switch
        res = dmc.tick(Direction.RIGHT);

        // Assert light bulb is turned on
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push boulder onto a switch cardinally adjacent to a wire
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.UP);

        // Check light bulb is still on
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push boulder off one switch (1 switch activated)
        res = dmc.tick(Direction.UP);

        // Check light bulb is still on
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push boulder off other switch
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        
        // Assert light bulb gets turned off
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());
    }

    @Test 
    @DisplayName("Test lightbulb switched on by circuit XOR") 
    public void TestLightBulbSwitchesOnWithCircuitXOR() {
        // Map layout
        //   0 1 2 3
        // 1 S W W L
        // 2 B     W
        // 3 P B S W

        DungeonManiaController dmc = new DungeonManiaController();
        DungeonResponse res = dmc.newGame("d_logicalSwitchTest_lightBulbCircuitXOR", "c_movementTest_testMovement");

        // Light bulb should be created off 
        List<EntityResponse> lightBulbOff = getEntities(res, "light_bulb_off");
        List<EntityResponse> lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push boulder on a switch
        res = dmc.tick(Direction.RIGHT);

        // Assert light bulb is turned on
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push boulder onto a switch cardinally adjacent to a wire
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.UP);

        // Check light bulb is now off
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(1, lightBulbOff.size());
        assertEquals(0, lightBulbOn.size());

        // Push boulder off one switch (1 switch activated)
        res = dmc.tick(Direction.UP);

        // Check light bulb is now on
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());

        // Push boulder off other switch
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        
        // Assert light bulb gets turned off
        lightBulbOff = getEntities(res, "light_bulb_off");
        lightBulbOn = getEntities(res, "light_bulb_on");
        assertEquals(0, lightBulbOff.size());
        assertEquals(1, lightBulbOn.size());
    }

    @Test 
    @DisplayName("Test switch door can be opened with key") 
    public void TestSwitchDoorOpenedWithKey() {
        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_logicalSwitchTest_switchDoorKeyUnlock", "c_movementTest_testMovement");

        // Check the switch door is not open
        DungeonResponse res = dmc.tick(Direction.RIGHT);
        EntityResponse player = getPlayer(res).get();
        EntityResponse switchDoor = getEntities(res, "switch_door").get(0);
        assertNotEquals(player.getPosition(), switchDoor.getPosition());

        // Collect key
        res = dmc.tick(Direction.DOWN);
        assertEquals(1, getInventory(res, "key").size());

        // Open switch door with key
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.UP);
        assertEquals(0, getInventory(res, "key").size());
        player = getPlayer(res).get();
        switchDoor = getEntities(res, "switch_door").get(0);
        assertEquals(player.getPosition(), switchDoor.getPosition());
    }

    @Test
    @DisplayName("Test switch doors can be opened with circuit and boulder OR")
    public void TestSwitchDoorOpenedWitCircuitOR() {
        // Layout
        //   1 2 3 4 5
        // 1 S W W D
        // 2 B     S B
        // 3 P

        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_logicalSwitchTest_switchDoorCircuitOR", "c_movementTest_testMovement");

        // Push boulder onto a switch which activates a circuit
        DungeonResponse res = dmc.tick(Direction.UP);

        // Check the switch door is open
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.DOWN);

        EntityResponse player = getPlayer(res).get();
        EntityResponse switchDoor = getEntities(res, "switch_door").get(0);
        assertEquals(player.getPosition(), switchDoor.getPosition());

        // Push boulder on other switch
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.LEFT);
        
        // Check door is still open
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.LEFT);

        player = getPlayer(res).get();
        switchDoor = getEntities(res, "switch_door").get(0);
        assertEquals(player.getPosition(), switchDoor.getPosition());

        // Push boulder off circuit switch
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.DOWN);

        // Check the switch door is still open
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.DOWN);

        player = getPlayer(res).get();
        switchDoor = getEntities(res, "switch_door").get(0);
        assertEquals(player.getPosition(), switchDoor.getPosition());
    }

    @Test
    @DisplayName("Test switch doors can be opened with circuit and boulder XOR")
    public void TestSwitchDoorOpenedWitCircuitXOR() {
        // Layout
        //   1 2 3 4 5
        // 1 S W W D
        // 2 B     S B
        // 3 P

        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_logicalSwitchTest_switchDoorCircuitXOR", "c_movementTest_testMovement");

        // Push boulder onto a switch which activates a circuit
        DungeonResponse res = dmc.tick(Direction.UP);

        // Check the switch door is open
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.UP);

        EntityResponse player = getPlayer(res).get();
        EntityResponse switchDoor = getEntities(res, "switch_door").get(0);
        assertEquals(player.getPosition(), switchDoor.getPosition());

        // Push boulder on other switch
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.LEFT);
        
        // Check door is closed
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.LEFT);

        player = getPlayer(res).get();
        switchDoor = getEntities(res, "switch_door").get(0);
        assertEquals(player.getPosition(), switchDoor.getPosition());

        // Push boulder off circuit switch
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.LEFT);
        res = dmc.tick(Direction.DOWN);

        // Check the switch door is open again
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.DOWN);

        player = getPlayer(res).get();
        switchDoor = getEntities(res, "switch_door").get(0);
        assertEquals(player.getPosition(), switchDoor.getPosition());
    }

    @Test
    @DisplayName("Test switch doors can be opened with circuit and boulder AND")
    public void TestSwitchDoorOpenedWitCircuitAND() {
        // Layout
        //   1 2 3 4 5
        // 1 S W W D
        // 2 B     S B
        // 3 P

        DungeonManiaController dmc = new DungeonManiaController();
        dmc.newGame("d_logicalSwitchTest_switchDoorCircuitAND", "c_movementTest_testMovement");

        // Push boulder onto a switch which activates a circuit
        DungeonResponse res = dmc.tick(Direction.UP);

        // Check the switch door is not open
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.UP);

        EntityResponse player = getPlayer(res).get();
        EntityResponse switchDoor = getEntities(res, "switch_door").get(0);
        assertNotEquals(player.getPosition(), switchDoor.getPosition());

        // Push boulder on other switch
        res = dmc.tick(Direction.DOWN);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.RIGHT);
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.LEFT);
        
        // Check door now opened
        res = dmc.tick(Direction.UP);
        res = dmc.tick(Direction.LEFT);

        player = getPlayer(res).get();
        switchDoor = getEntities(res, "switch_door").get(0);
        assertEquals(player.getPosition(), switchDoor.getPosition());
    }
}
