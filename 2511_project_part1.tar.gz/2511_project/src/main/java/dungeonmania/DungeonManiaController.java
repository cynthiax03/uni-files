package dungeonmania;

import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.util.Direction;
import dungeonmania.util.FileLoader;
import dungeonmania.util.Helper;
import dungeonmania.util.Position;
import dungeonmania.MovingEntity.Mercenary;
import dungeonmania.StaticEntity.ZombieToastSpawner;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class DungeonManiaController {
    private Map<String, Dungeon> dungeonsList = new HashMap<>();
    private Dungeon currDungeon;

    public Dungeon getCurrDungeon() {
        return currDungeon;
    }

    public String getSkin() {
        return "default";
    }

    public String getLocalisation() {
        return "en_US";
    }

    /**
     * /dungeons
     */
    public static List<String> dungeons() {
        return FileLoader.listFileNamesInResourceDirectory("dungeons");
    }

    /**
     * /configs
     */
    public static List<String> configs() {
        return FileLoader.listFileNamesInResourceDirectory("configs");
    }

    /**
     * /game/new
     */
    public DungeonResponse newGame(String dungeonName, String configName) throws IllegalArgumentException {
        if (!dungeons().contains(dungeonName) || !configs().contains(configName)) {
            throw new IllegalArgumentException("Error: dungeonName or configName does not exist");
        }
        String dungeonId = "dungeon" + String.valueOf(dungeonsList.size());
        Dungeon dungeon = new Dungeon(dungeonName, "entity" + dungeonId, configName);
        dungeon.createDungeon();
        dungeonsList.put(dungeonId, dungeon);
        this.currDungeon = dungeon;
        return dungeon.getDungeonResponse();
    }

    /**
     * /game/dungeonResponseModel
     */
    public DungeonResponse getDungeonResponseModel() {
        return currDungeon.getDungeonResponse();
    }

    /**
     * /game/tick/item
     */
    public DungeonResponse tick(String itemUsedId) throws IllegalArgumentException, InvalidActionException {

        Player player = currDungeon.getPlayer();
        // Check position to see if a battle needs to be created
        currDungeon.checkPosition(player);
        
        Inventory inventory = player.getInventory();
        Entity item = inventory.findItem(itemUsedId);

        // If item does not exist in inventory, throw error
        if (item == null) {
            throw new InvalidActionException("Error: Item does not exist in the inventory");
        }
        // If item is not a bomb/potion, throw error
        if (!(item.getType().equals("bomb")) && 
            !(item.getType().equals("invincibility_potion")) && 
            !(item.getType().equals("invisibility_potion"))) {
            throw new IllegalArgumentException("Error: Cannot use item");
        }

        // Given the itemUsedId, use the item
        currDungeon.itemUse(item, currDungeon, inventory);
        
        // Move enemies and iterate tick
        currDungeon.iterateTicks();
        currDungeon.tickEnemies();

        player.updatePotion();
        // Check position to see if a battle needs to be created after enemy
        // movement
        currDungeon.checkPosition(player);
        
        return currDungeon.getDungeonResponse();
    }

    /**
     * /game/tick/movement
     */
    public DungeonResponse tick(Direction movementDirection) {
        Helper helper = new Helper();
        helper.clearWireVisitHistory(currDungeon.getEntities());
        // Find the player
        Player activePlayer = currDungeon.getPlayer();
        activePlayer.setPreviousPosition(activePlayer.getPosition());
        // Move the player if it can be moved, if it can be moved, check its
        // new position
        if (activePlayer.move(movementDirection, currDungeon.getEntities())) {
            // Check the players new position to see if anything needs to be 
            // collected, any battles need to be started, or the player has
            // moved onto an exit
            currDungeon.checkPosition(activePlayer);
        }
        currDungeon.iterateTicks();
        currDungeon.tickEnemies();

        // Check position to see if a battle needs to be created after enemy
        // movement
        currDungeon.checkPosition(activePlayer);
        
        // Update all potion effects and bombs
        activePlayer.updatePotion();
        currDungeon.updateBomb(currDungeon);

        return currDungeon.getDungeonResponse();
    }

    /**
     * /game/build
     * buildable is one of bow, shield, sceptre, or midnight_armour.
     */
    public DungeonResponse build(String buildable) throws IllegalArgumentException, InvalidActionException {
        
        Player player = currDungeon.getPlayer();
        Inventory inventory = player.getInventory();
        List<String> buildables = inventory.getBuildables();

        //  If buildable is not one of bow, shield, sceptre, or midnight_armour, throw IllegalArgumentException
        if (!buildable.equals("bow") && !buildable.equals("shield")
            && !buildable.equals("sceptre") && !buildable.equals("midnight_armour")) {
            throw new IllegalArgumentException("buildable is not one of bow, shield, sceptre, or midnight_armour.");
        }
        // If the player does not have sufficient items to craft the buildable, throw InvalidActionException
        if (buildable.equals("bow") && !buildables.contains("bow")) {
            throw new InvalidActionException("not sufficient items to build a bow.");
        }
        if (buildable.equals("shield") && !buildables.contains("shield")) {
            throw new InvalidActionException("not sufficient items to build a shield.");
        }
        if (buildable.equals("sceptre") && !buildables.contains("sceptre")) {
            throw new InvalidActionException("not sufficient items to build a sceptre.");
        }
        // or unbuildable for midnight_armour because there are zombies currently in the dungeon, throw InvalidActionException
        if (buildable.equals("midnight_armour")) {
            if (!buildables.contains("midnight_armour") || currDungeon.hasEntity("zombie_toast")) {
                throw new InvalidActionException("not sufficient items to build midnight armour.");
            }
        }

        player.build(buildable, currDungeon.getEntityFactory(), currDungeon.getConfigs());
        return currDungeon.getDungeonResponse();
    }

    /**
     * /game/interact
     */
    // Interacts with a mercenary (where the Player bribes the mercenary, mercenary includes assassin)  
    // or a zombie spawner, where the Player destroys the spawner
    public DungeonResponse interact(String entityId) throws IllegalArgumentException, InvalidActionException {
        Player player = currDungeon.getPlayer();
        Map<String, Entity> entities = currDungeon.getEntities();
        Inventory inventory = player.getInventory();
        // e is the entity
        Entity e = entities.get(entityId);

        // throw IllegalArgumentException if entityId is not a valid mercenary or zombie spawner ID
        if (e == null) {
            throw new IllegalArgumentException ("EntityId is not a valid ID.");
        }

        if (!e.getInteractable()) {
            throw new IllegalArgumentException ("EntityId is not an interactable mercenary or zombie spawner or assassin.");
        }

        if (e.getType().equals("mercenary") || e.getType().equals("assassin")) {

            // throw InvalidActionException if the player is not within specified bribing radius to the mercenary and he doesnt have sceptre, if they are bribing
            if (!player.mercenaryInRange((Mercenary) e) && !inventory.hasEntity("sceptre")) {
                throw new InvalidActionException("Player is not within specified bribing radius.");
            }

            // throw InvalidActionException if the player does not have enough gold and does not have a sceptre and attempts to bribe/mind-control a mercenary
            if (!player.canBribe((Mercenary) e) && !inventory.hasEntity("sceptre")) {
                throw new InvalidActionException("Player does not have enough gold and attempts to bribe a mercenary.");
            }

            // the mercenery becomes bribed and the player loses some gold if the player bribes the mercenary
            player.bribeMercenary((Mercenary) e);
        }
        // throw InvalidActionException if the player is not cardinally adjacent to the spawner, if they are destroying a spawner.
        List<Position> adjacentToSpawner = e.getPosition().cardinallyAdjacent();
        if (e.getType().equals("zombie_toast_spawner")) {

            if (!adjacentToSpawner.contains(player.getPosition())) {
                throw new InvalidActionException("Player is not cardinally adjacent to the spawner.");
            }

            // If the player does not have a weapon and attempts to destroy a spawner
            if (!player.hasWeapon()) {
                throw new InvalidActionException("Player does not have a weapon and attempts to destroy a spawner.");
            }

            // the spawner is destroied and the player loses a weapon if interacting with a zombie spawner
            player.destorySpawner(currDungeon, (ZombieToastSpawner) e);
            player.loseWeaponAfterInteracting();
        }
       
        return currDungeon.getDungeonResponse();
    }

        /**
     * /game/save
     */
    public DungeonResponse saveGame(String name) throws IllegalArgumentException {

        File directory2 = new File("build/games/");
        if (! directory2.exists()){
            directory2.mkdir();
        }

        try {
            Gson gameGson = new GsonBuilder().setPrettyPrinting().create();
            Writer writer = new FileWriter("build/games/" + name + ".json");
            System.out.println("Writing to " + "build/games/" + name + ".json");
            gameGson.toJson(currDungeon, writer);
            writer.close();
        } catch (IOException e) {
            throw new IllegalArgumentException("Error: Cannot save game");
        }

        try {
            Gson gameGson = new GsonBuilder().setPrettyPrinting().create();
            Writer writer = new FileWriter("src/main/resources/games/" + name + ".json");
            gameGson.toJson(currDungeon, writer);
            writer.close();
        } catch (IOException e) {
            throw new IllegalArgumentException("Error: Cannot save game");
        }
        
        return currDungeon.getDungeonResponse();
    }

    /**
     * /game/load
     */
    public DungeonResponse loadGame(String name) throws IllegalArgumentException {

        try {
            JSONObject savedFile = new JSONObject(FileLoader.loadResourceFile("/games/" + name + ".json"));
            Dungeon dungeon = new Dungeon(savedFile);
            dungeon.loadDungeon(savedFile);
            currDungeon = dungeon;
        
        } catch (IOException e) {
            System.out.println(e.getClass());
            throw new IllegalArgumentException("Game could not be loaded");
        }
        return currDungeon.getDungeonResponse();
    }

    /**
     * /games/all
     */
    public List<String> allGames() {

        List<String> allGames = new ArrayList<>();
        
        File folder = new File("build/games/");
        File[] listOfFiles = folder.listFiles();
        
        for (int i = 0; i < listOfFiles.length; i++) {
            if (listOfFiles[i].isFile()) {
                String fileName = listOfFiles[i].getName();
                fileName = fileName.substring(0, fileName.lastIndexOf('.'));
                allGames.add(fileName);
            }
        }    

        return allGames;
    }

    public DungeonResponse generateDungeon(int xStart, int yStart, int xEnd, int yEnd, String configName) {

        // // if (!configs().contains(configName)) {
        // //     throw new IllegalArgumentException("Error: configName does not exist");
        // // }
        // String dungeonId = "dungeon" + String.valueOf(dungeonsList.size());
        // Dungeon dungeon = new Dungeon("entity" + dungeonId, configName, xStart, yStart, xEnd, yEnd);
        // dungeon.createDungeon();
        // dungeonsList.put(dungeonId, dungeon);
        // this.currDungeon = dungeon;
        // return dungeon.getDungeonResponse();

        return null;
    }
    




    /**
    * Returns the path of a new file to be created that is relative to resources/.
    * Will add a `/` prefix to path if it's not specified.
    * 
    * @param directory Relative to resources/ will add an implicit `/` prefix if
    *                  not given.
    * @param newFile   file name
    * @return the full path as a string
    * @throws IOException bad directory
    */
    public static String getPathForNewFile(String directory, String newFile) throws IOException {

        if (!directory.startsWith("/")) {
            directory = "/" + directory;
        }
        try {
            // throwing error here
            Path root = Paths.get(FileLoader.class.getResource(directory).toURI());
            return root.toString() + "/" + newFile;
        } catch (URISyntaxException e) {
            throw new FileNotFoundException(directory);
        }

    }
}
