package dungeonmania;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Random;

import dungeonmania.util.FileLoader;
import dungeonmania.util.Position;
import dungeonmania.util.Direction;
import dungeonmania.util.Helper;
import dungeonmania.Goal.SimpleGoal;
import dungeonmania.Goal.AndGoal;
import dungeonmania.Goal.OrGoal;
import dungeonmania.Goal.ExpressionNode;
import dungeonmania.CollectibleEntity.Bomb;
import dungeonmania.CollectibleEntity.CollectibleEntity;
import dungeonmania.CollectibleEntity.SunStone;
import dungeonmania.CollectibleEntity.Treasure;
import dungeonmania.MovingEntity.Mercenary;
import dungeonmania.MovingEntity.MovingEntity;
import dungeonmania.MovingEntity.Spider;
import dungeonmania.MovingEntity.Zombie;
import dungeonmania.StaticEntity.ZombieToastSpawner;
import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.DungeonResponse;
import dungeonmania.response.models.EntityResponse;
import dungeonmania.response.models.ItemResponse;
import dungeonmania.response.models.RoundResponse;
import dungeonmania.response.models.BattleResponse;

public class Dungeon {
    private String dungeonName;
    private String dungeonId;
    private JSONObject configs;
    private JSONObject map;
    private Player player;
    private Map<String, Entity> entities = new HashMap<>();
    private List<BattleResponse> battles = new ArrayList<>();
    private ExpressionNode goalCondition;
    private Map<String, SimpleGoal> goals = new HashMap<>();
    private int numTicks = 0;
    private int totalEntitiesCreated = 0;
    private int killCount = 0;
    private int numTreasure = 0;
    private EntityFactory entityFactory = new EntityFactory();

    public Dungeon(String dungeonName, String dungeonId, String configName) {
        this.dungeonName = dungeonName;
        this.dungeonId = dungeonId;
        
        try {
            this.map = new JSONObject(FileLoader.loadResourceFile("dungeons/" + dungeonName + ".json"));
            this.configs = new JSONObject(FileLoader.loadResourceFile("configs/" + configName + ".json"));
        } catch (IOException e) {
            throw new IllegalArgumentException("Error: dungeonName or configName does not exist");
        }
    }

    public Dungeon(JSONObject savedFile) {

        this.dungeonName = savedFile.getString("dungeonName");
        this.dungeonId = savedFile.getString("dungeonId");
        this.configs = savedFile.getJSONObject("configs").getJSONObject("map");
        // private JSONObject map;
        // private Player player;
        // private Map<String, Entity> entities = new HashMap<>();
        // private List<BattleResponse> battles = new ArrayList<>();
        this.goalCondition = new SimpleGoal("exit", 0);
        // private Map<String, SimpleGoal> goals = new HashMap<>();
        this.numTicks = savedFile.getInt("numTicks");
        this.totalEntitiesCreated = savedFile.getInt("totalEntitiesCreated");
        this.killCount = savedFile.getInt("killCount");
        this.numTreasure = savedFile.getInt("numTreasure");
        // private EntityFactory entityFactory = new EntityFactory();

    }

    public Dungeon(String dungeonId, String configName, int xS, int xE, int yS, int yE) {
        this.dungeonName = "1";
        this.dungeonId = dungeonId;
        
        // try {
        //     this.map = new JSONObject(FileLoader.loadResourceFile("dungeons/" + dungeonName + ".json"));
        //     this.configs = new JSONObject(FileLoader.loadResourceFile("configs/" + configName + ".json"));
        // } catch (IOException e) {
        //     throw new IllegalArgumentException("Error: dungeonName or configName does not exist");
        // }

        JSONArray entityArray = map.getJSONArray("entities");

        for (int i = xS; i < xE; i++) {

            for (int j = yS; j < yE; j++) {

                
            }
        }
    }


    public JSONObject getConfigs() {
        return this.configs;
    }

    public JSONObject getMap() {
        return this.map;
    }

    // Generates a simple goal
    public SimpleGoal simpleGoalGenerator(String goal) {
        int numGoal = 0;
        switch(goal) {
            case "enemy":
                numGoal = configs.getInt("enemy_goal");
            case "treasure":
                numGoal = configs.getInt("treasure_goal");
        }
        SimpleGoal newGoal = new SimpleGoal(goal, numGoal);
        goals.put(goal, newGoal);
        return newGoal;
    }

    public ExpressionNode complexGoalGenerator(JSONObject ob) {
        if (ob.has("subgoals")) {
            ExpressionNode left = complexGoalGenerator(ob.getJSONArray("subgoals").getJSONObject(0));
            ExpressionNode right = complexGoalGenerator(ob.getJSONArray("subgoals").getJSONObject(1));
            
            switch(ob.getString("goal")) {

                case "AND":
                    return new AndGoal(left, right);

                case "OR":
                    return new OrGoal(left, right);

            }       
        } 
        return simpleGoalGenerator(ob.getString("goal"));
        
    }

    public void createDungeon() {
        // Extract entities and goal-conditions from the JSON file
        JSONArray entityArray = map.getJSONArray("entities");
        JSONObject goalObject = map.getJSONObject("goal-condition");

        generateInitialEntities(entityArray);

        if (goalObject.has("subgoals")) {
            goalCondition = complexGoalGenerator(goalObject);
        } else {
            String goalName = goalObject.getString("goal");
            goalCondition = simpleGoalGenerator(goalName);
        }

    }

    public SimpleGoal getGoal(String goal) {
        if (goalCondition.goalString().contains(goal)) {
            return goals.get(goal);
        }
        return null;
    }

    // Generates entity on dungeon map
    public void generateInitialEntities(JSONArray entityArray) {
        
        for (int i = 0; i < entityArray.length(); i++) {
            JSONObject entityData = entityArray.getJSONObject(i);
            Entity entity = entityFactory.getEntity(entityData, configs);
            addEntity(entity);

            if (entity.getType().equals("player")) {
                this.player = (Player) entity;
            }
        } 
    }

    public void addEntity(Entity entity) {
        entities.put(entity.getId(), entity);
    }

    public void removeEntity(Entity entity) {
        entities.remove(entity.getId());
    }

    public List<Entity> getEntitiesList() {
        List<Entity> entityList = new ArrayList<>();
        for (Entity entity : entities.values()) {
            entityList.add(entity);
        }
        return entityList;
    }

    public DungeonResponse getDungeonResponse() {
        // Get entity responses
        List<EntityResponse> entityResponses = new ArrayList<>();

        for (Entity entity : entities.values()) {
            entityResponses.add(entity.getEntityResponse());
        }

        // Get inventory item responses
        Inventory playerInventory = player.getInventory();
        List<ItemResponse> inventory = playerInventory.getItemResponses();

        // Get buildables
        List<String> buildables = playerInventory.getBuildables();
        String goals = goalCondition.goalString();
        
        return new DungeonResponse(dungeonId, dungeonName, entityResponses, inventory, battles, buildables, goals);
    }
    
    // Function that checks whether the entity's new position occupied
    public Boolean checkOccuppied(Entity entity, Position newPosition, Direction direction) {
        // Loop through all existing entities
        for (Entity existingEntity : entities.values()) {
            // If the entity is the existing entity, skip
            if (entity.equals(existingEntity)) {
                continue;
            }
            // Get the existing entity's position
            Position existPos = existingEntity.getPosition();
            // If the new position overlaps with existing position
            if (newPosition.equals(existPos)) {
                return true;
            } 
        }
        return false;
    }

    /** 
     * Checks the player's position to see if anything can be collected, 
     * a battle needs to be created, or the player has moved onto an exit
    */
    public void checkPosition(Player player) {
        // Get list of entities at the player's new position
        Helper helper = new Helper();
        List<Entity> entitiesAtPosition = helper.getEntitiesAtPosition(player.getPosition(), entities);
        List<Entity> allies = player.getAllies();
        
        for (Entity entity : entitiesAtPosition) {
            String entityType = entity.getType();
            if (entityType.equals("exit")) {
                if (getGoal("exit") != null) {
                    getGoal("exit").reach();
                }
            } else if (entity instanceof CollectibleEntity) {
                player.collect(entity, entities);
                if (entity instanceof Treasure || entity instanceof SunStone) {
                    numTreasure++;
                    if (getGoal("treasure") != null) {
                        if (numTreasure >= getGoal("treasure").getNumCount()) {
                            getGoal("treasure").reach();
                        }
                    }
                }
            } else if (entity instanceof MovingEntity && !allies.contains(entity) && (!player.isInvisible())) {
                battle(player, (MovingEntity) entity);
            } 

            if (getGoal("boulders") != null) {
                if (helper.switchAllActivated(entities)) {
                    getGoal("boulders").reach();
                } else {
                    getGoal("boulders").unreach();
                }
            }    

            // If not on the exit square, the goal exit's [reach] should become false
            if (!entityType.equals("exit")) {
                if (getGoal("exit") != null) {
                    getGoal("exit").unreach();
                }
            } 
        }
    }

    public Player getPlayer() {
        return player;
    }

    public Map<String, Entity> getEntities() {
        return entities;
    }

    public List<Entity> getEntitiesAtPosition(Position pos) {
        List<Entity> returnEntities = new ArrayList<>();
        for (Entity entity : entities.values()) {
            Position entityPosition = entity.getPosition();
            if (entityPosition.equals(pos)) {  
                returnEntities.add(entity);
            }
        }
        return returnEntities;
    }

    /**
     * Returns a list of entities of a given type
     */
    public List<Entity> getEntitiesByType(String type) {
        List<Entity> returnEntities = new ArrayList<>();
        for (Entity entity : entities.values()) {
            String entityType = entity.getType();
            if (entityType.equals(type)) {  
                returnEntities.add(entity);
            }
        }
        return returnEntities;
    }

     /**
     * Check if the dungeon has a certain type of entities
     */
    public boolean hasEntity(String entityType) {
        for (Entity entity : entities.values()) {
            if (entity.getType().equals(entityType)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Spawns new enemies if needed and moves current enemies
     */
    public void tickEnemies() {
        // Move current enemies
        for (Entity entity : entities.values()) {
            String entityType = entity.getType();
            
            if (entityType.equals("spider")) {
                ((Spider) entity).move(entities);

            } else if (entityType.equals("zombie_toast")) {
                ((Zombie) entity).move(entities);

            } else if (entity instanceof Mercenary) {
                ((Mercenary) entity).move(entities);
                ((Mercenary) entity).mindControlDuration();
            }
        }

        // Spawn enemies 
        int zombieSpawnRate = configs.getInt("zombie_spawn_rate");
        int spiderSpawnRate = configs.getInt("spider_spawn_rate");

        if (zombieSpawnRate != 0 && (numTicks % zombieSpawnRate == 0) && numTicks != 0) {
            spawnZombies();
        }

        if (spiderSpawnRate != 0 && (numTicks % spiderSpawnRate == 0) && numTicks != 0) {
            spawnSpider();
        }
    }

    /**
     * Spawns a spider at a random location
     */
    public void spawnSpider() {
        // Generate a random position on the map
        Random random = new Random();
        int x = random.nextInt(30);
        int y = random.nextInt(30);

        Entity entity = entityFactory.getNewEntity(x, y, "spider", configs);
        addEntity(entity);
    }

    /**
     * Spawns a zombie at each zombie toast spawner in the dungeon
     */
    public void spawnZombies() {

        // Get a list of zombie spawners
        List<Entity> zombieToastSpawners = getEntitiesByType("zombie_toast_spawner");

        // Spawn a zombie at each spawner
        for (Entity spawner : zombieToastSpawners) {
            ((ZombieToastSpawner) spawner).spawnZombies(this, entityFactory, configs);
        }
    }

    /**
     * Iterates the number of ticks for this dungeon
     */
    public void iterateTicks() {
        this.numTicks += 1;   
    }
    
    /** 
     * Given the itemId, use the item from the inventory
     * @throws InvalidActionException
    */
    public void itemUse(Entity item, Dungeon dungeon, Inventory inventory) throws InvalidActionException, IllegalArgumentException {

        // If item does not exist in inventory, throw error
        if (item == null) {
            throw new InvalidActionException("Error: Item does not exist in the inventory");
        }
        // If item is not a bomb/potion, throw error
        if (!(item.getType().equals("bomb")) && 
            !(item.getType().equals("invincibility_potion")) && 
            !(item.getType().equals("invisibility_potion"))) {
            throw new IllegalArgumentException("Error: Cannot use item");
        }
        // If the item was a bomb, place it
        if (item instanceof Bomb) {
            Bomb bomb = (Bomb) item;
            // Put bomb on the players position on the map
            player.placeBomb(bomb, entities, dungeon);
            // Attempt to detonate the bomb
            bomb.canDetonate(entities, dungeon);

        // If the item is invincible/invisible potion
        } else {
            // Use the potion 
            player.usePotion(item);
        }
        // Once the item is used, remove it
        inventory.removeItem(item.getId());

        // persist here
    }

    /**
     * Battles an enemy and adds a battle response to battles
     */
    public void battle(Player player, MovingEntity enemy) {
        double initialPlayerHealth = player.getHealth();
        double initialEnemyHealth = ((MovingEntity)enemy).getHealth();
        String enemyId = enemy.getId();
        List<ItemResponse> weaponsUsed = new ArrayList<>();
        List<RoundResponse> rounds = new ArrayList<>();

        // If player is invincible, they automatically win after one round
        if (player.isInvincible()) {
            rounds.add(new RoundResponse(0, 0, weaponsUsed));
            player.killEnemy(enemy, this);
            battles.add(new BattleResponse(enemyId, rounds, initialPlayerHealth, initialEnemyHealth));
            return;
        }

        // Battle in rounds until either the enemy dies or the player dies
        while (true) {
            // Get the weapons that will be used in this round
            weaponsUsed = player.getInventory().getWeaponResponses();
            
            // Attack each other and get delta health
            double deltaPlayerHealth = enemy.attackPlayer(player);
            double deltaEnemyHealth = player.attackEnemy(enemy);

            // Add round response to round response list
            rounds.add(new RoundResponse(deltaPlayerHealth, deltaEnemyHealth, weaponsUsed));

            // If player or enemy has died, remove it from entity map
            if (player.getHealth() <= 0) {
                enemy.killPlayer(player, this);
                break;

            } else if (enemy.getHealth() <= 0) {
                player.killEnemy(enemy, this);
                break;
            }         
        }
        battles.add(new BattleResponse(enemy.getId(), rounds, initialPlayerHealth, initialEnemyHealth));
    }

    /**
     * Iterates kill count and checks goals
     */
    public void iterateKillCount() {
        this.killCount += 1;
        if (getGoal("enemies") != null) {
            if (getGoal("enemies").getNumCount() <= killCount) {
                getGoal("enemies").reach();
            }
        }
    }

    public void updateBomb(Dungeon dungeon) {
        // Loop through all entities on the map
        for (Entity entity : entities.values()) {

            // If the entity is a bomb, check if it can be detonated
            if (entity instanceof Bomb) {
                Bomb bomb = (Bomb) entity;
                // Check if the bomb can be detonated, and if it can, detonate
                bomb.canDetonate(entities, dungeon);
                break;
            }
        }
    }

    public EntityFactory getEntityFactory() {
        return this.entityFactory;
    }


    public int getNumTicks() {
        return numTicks;
    }

    public void loadDungeon(JSONObject savedFile) {

        int totCreated = savedFile.getJSONObject("entityFactory").getInt("totalEntitiesCreated");

        // Get 
        JSONObject goals = savedFile.getJSONObject("goalCondition");
        this.goalCondition = new ExpressionNode() {

            @Override
            public boolean isReached() {
                // TODO Auto-generated method stub
                return true;
            }

            @Override
            public String goalString() {
                // TODO Auto-generated method stub
                return ":exit";
            }
            
        };
        // implement goal stuff

        JSONArray battles = savedFile.getJSONArray("battles");

        JSONObject savedInfo = savedFile.getJSONObject("entities");
        Iterator<String> entityIds = savedInfo.keys();

        
        while(entityIds.hasNext()) {
            String entityId = entityIds.next();

            JSONObject entityJSON = savedInfo.getJSONObject(entityId);
            Entity entityCreated = entityFactory.getSavedEntity(entityJSON, totCreated, configs);   
            
            if (entityCreated.getType().equals("player")) {
                this.player = (Player) entityCreated;
            }

            addEntity(entityCreated);
            // 
        }

        // JSONObject savedInventory = savedFile.getJSONObject("entities");
        // Iterator<String> entityIds = savedInfo.keys();
    }


}
