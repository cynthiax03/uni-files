package dungeonmania.util;

import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import dungeonmania.Entity;
import dungeonmania.StaticEntity.StaticEntity;
import dungeonmania.StaticEntity.Wire;
import dungeonmania.StaticEntity.Door;
import dungeonmania.StaticEntity.SwampTile;
import dungeonmania.StaticEntity.FloorSwitch;
import dungeonmania.StaticEntity.LogicalEntity;

public class Helper {
    /**
     * Gets all the entities at a given position
     */
    public List<Entity> getEntitiesAtPosition(Position pos, Map<String, Entity> entities) {
        List<Entity> returnEntities = new ArrayList<>();
        for (Entity entity : entities.values()) {
            Position entityPosition = entity.getPosition();
            if (entityPosition.equals(pos)) {  
                returnEntities.add(entity);
            } 
        }
        return returnEntities;
    }

    public List<String> getEntityTypesAtPosition(Position pos, Map<String, Entity> entities) {
        List<String> returnEntities = new ArrayList<>();
        for (Entity entity : entities.values()) {
            Position entityPosition = entity.getPosition();
            if (entityPosition.equals(pos)) {  
                returnEntities.add(entity.getType());
            }
        }
        return returnEntities;
    }

    /**
     * Checks if a wall is at a given position
     */
    public boolean isWall(List<Entity> entitiesAtPosition) {
        for (Entity entity : entitiesAtPosition) {
            String entityType = entity.getType();
            if (entityType.equals("wall")) {
                return true;
            }
        }
        return false;
    }

    /**
     * Checks if a position contains any static entities
     */
    public boolean noStaticEntities(List<Entity> entitiesAtPosition) {
        for (Entity entity : entitiesAtPosition) {
            if (entity instanceof StaticEntity) {
                return false;
            }
        }
        return true;
    }

    /**
     * Finds the floorswitch and determines if the bomb can be activated given 
     * the location
     * @return
     */
    public boolean switchExistAndActivated(Position pos, Map<String, Entity> entities) {

        for (Entity existingEntity : entities.values()) {
            if (pos.equals(existingEntity.getPosition())) {
                if (existingEntity instanceof FloorSwitch) {
                    if (((FloorSwitch) existingEntity).isTriggered()) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    public boolean switchAllActivated(Map<String, Entity> entities) {
        boolean allActivated = true;
        
        for (Entity entity : entities.values()) {
            if (entity instanceof FloorSwitch) {
                if (!((FloorSwitch) entity).isTriggered()) {
                    allActivated = false;
                }
            }
        }

        return allActivated;

    }

    public void clearWireVisitHistory(Map<String, Entity> entities) {
        for (Entity entity : entities.values()) {
            if (entity instanceof Wire) {
                ((Wire) entity).clearVisited();
            }
        }
    }


    public boolean canMove(List<Entity> entitiesAtPosition) {
        for (Entity entity: entitiesAtPosition) {
            String entityType = entity.getType();

            if (entityType.equals("boulder") ||
                entityType.equals("portal") ||
                entityType.equals("wall") ||
                (entityType.equals("door") && !(((Door) entity).isOpen())))
            {
                return false;
            }
        }
        return true;
    }

    public double distanceCalculator(Position p, Position q) {
        return (Math.abs(p.getX()-q.getX()) + Math.abs(p.getY()-q.getY()));
    }

    public double fCostCalculator(Map<Position, Double> gCost, Map<Position, Double> hCost, Position position) {
        return gCost.get(position) + hCost.get(position);
    }

    public Position lowestFScorePosition(Map<Position, Double>fCost, List<Position> openSet) {

        double lowest = 0.0;
        Position lowestFPosition = null;
        for (Position position : openSet) {
            if (fCost.get(position) < lowest || lowestFPosition == null) {
                lowest = fCost.get(position);
                lowestFPosition = position;
            }
        }
        return lowestFPosition;
    }

    // Finds the shortest path from start to the end(player's position),
    // returns the next position for the shortest path or null if no path 
    // can be found 
    public Position pathfinder(Position start, Position end, Map<String, Entity> entities) {

        if (start.equals(end)) {
            return start;
        }

        // The positions that are waiting to be visited
        List<Position> openSet = new ArrayList<>();

        // The positions that are already visited
        List<Position> closedSet = new ArrayList<>();

        // The distance of the position from the starting position 
        Map<Position, Double> gCost = new HashMap<Position,Double>();

        // THe distance of the postion from the ending position
        Map<Position, Double> hCost = new HashMap<Position,Double>();

        // The sum of gCost and hCost of the position
        Map<Position, Double> fCost = new HashMap<Position,Double>();

        // Keeps track of where the node came from
        Map<Position, Position> previousPosition = new HashMap<>();


        // Initialisation
        openSet.add(start);
        gCost.put(start, 0.0);
        hCost.put(start, distanceCalculator(start, end));
        fCost.put(start, fCostCalculator(gCost, hCost, start));

        Position current = start;
        // Keep looping when there are nodes still waiting to be visited
        while (!openSet.isEmpty()) {

            // current = position with lowest fscore value
            current = lowestFScorePosition(fCost, openSet);

            // Mark the visiting node as visited
            openSet.remove(current);
            closedSet.add(current);

            // Visiting the ending point, break the loop as the path is found
            if (current.equals(end)) {
                break;
            }

            // Otherwise, continue
            // add the unvisited neighbours to the visiting plan
            List<Position> possibleNeighbours = current.cardinallyAdjacent();
            List<Position> removed = new ArrayList<>();
            List<Entity> entitiesAtPosition;
            // Then we check if those areas are reachable
            for (Position position : possibleNeighbours) {
                entitiesAtPosition = getEntitiesAtPosition(position, entities);
    
                if(!canMove(entitiesAtPosition)) {
                    removed.add(position);
                }
            }

            // Remove the ones that are not reachable 
            possibleNeighbours.removeAll(removed);

            // Calculate the gCosts and fcosts and hcosts for each nodes that we are planning to visit
            for (Position neighbour : possibleNeighbours) {

                if (!closedSet.contains(neighbour)) {
                    double tentativeG = gCost.get(current) + 1;

                    // If neighbour contains swamp, add by movement factor                    
                    entitiesAtPosition = getEntitiesAtPosition(neighbour, entities);
                    for (Entity entity : entitiesAtPosition) {
                        if (entity instanceof SwampTile) {
                            tentativeG = gCost.get(current) + ((SwampTile) entity).getMovementFactor();
                            break;
                        }
                    } 

                    // If it's in the openSet already, check if this is a better way
                    // If so, put the better cost in
                    if (openSet.contains(neighbour)) {
                        if (tentativeG < gCost.get(neighbour)) {
                            gCost.put(neighbour, tentativeG);
                        }
                        // Else add it to the open set
                    } else {
                        gCost.put(neighbour, tentativeG);
                        openSet.add(neighbour);
                    }
                    
                    hCost.put(neighbour, distanceCalculator(neighbour, end));
                    fCost.put(neighbour, hCost.get(neighbour) + gCost.get(neighbour));
                    previousPosition.put(neighbour, current);
                }
            }
        }

        List<Position> path = new ArrayList<>(); 
        Position temp = current;
        while (previousPosition.containsKey(temp)) {
            path.add(previousPosition.get(temp));
            temp = previousPosition.get(temp);
        }

        if (path.size() < 2) {
            
            return current;
        }
        return path.get(path.size()-2);
        
    }

    public int calculateRadiusDistance(Position p, Position q) {
        return Math.max(Math.abs(p.getX() - q.getX()), Math.abs(p.getY() - q.getY()));
    }

    // Returns a list of wires on the cardinally adjacent positions
    public List<Wire> getCardinallyAdjacentWires(Position pos, Map<String, Entity> entities) {
        List<Wire> ret = new ArrayList<>();

        // Get the cardinally adjacent positions first
        List<Position> cardinallyAdjPos = pos.cardinallyAdjacent();


        // For each position check the entities on it
        for (Position position : cardinallyAdjPos) {
            List<Entity> entitiesOnPos = getEntitiesAtPosition(position, entities);
            for (Entity entity: entitiesOnPos) {

                // If the entity is wire, add it to the return list
                if (entity instanceof Wire) {
                    ret.add((Wire) entity);
                }
            }
        }

        return ret;
    }

    // Returns a list of floor switches on the cardinally adjacent positions
    public List<FloorSwitch> getCardinallyAdjacentSwitches(Position pos, Map<String, Entity> entities) {
        List<FloorSwitch> ret = new ArrayList<>();

        // Get the cardinally adjacent positions first
        List<Position> cardinallyAdjPos = pos.cardinallyAdjacent();


        // For each position check the entities on it
        for (Position position : cardinallyAdjPos) {
            List<Entity> entitiesOnPos = getEntitiesAtPosition(position, entities);
            for (Entity entity: entitiesOnPos) {

                // If the entity is a logical entity, add it to the return list
                if (entity instanceof FloorSwitch) {
                    ret.add((FloorSwitch) entity);
                }
            }
        }

        return ret;
    }

    // Returns a list of logical entities on the cardinally adjacent positions
    public List<LogicalEntity> getCardinallyAdjacentLogics(Position pos, Map<String, Entity> entities) {
        List<LogicalEntity> ret = new ArrayList<>();

        // Get the cardinally adjacent positions first
        List<Position> cardinallyAdjPos = pos.cardinallyAdjacent();


        // For each position check the entities on it
        for (Position position : cardinallyAdjPos) {
            List<Entity> entitiesOnPos = getEntitiesAtPosition(position, entities);
            for (Entity entity: entitiesOnPos) {

                // If the entity is a logical entity, add it to the return list
                if (entity instanceof LogicalEntity) {
                    ret.add((LogicalEntity) entity);
                }
            }
        }

        return ret;
    }

    // /**
    //  * Checks for cardinally adjacent switches
    //  */
    // public boolean canBeDetonated(List<Position> perimeter, Map<String, Entity> entities) {

    //     Position position1 = perimeter.get(1);
    //     Position position2 = perimeter.get(3);
    //     Position position3 = perimeter.get(5);
    //     Position position4 = perimeter.get(7);
        
    //     // If any of cardinally adjacent switches are primed, bomb can be deonated
    //     if (switchExistAndActivated(position1, entities) || 
    //         switchExistAndActivated(position2, entities) || 
    //         switchExistAndActivated(position3, entities) || 
    //         switchExistAndActivated(position4, entities)) {
    //             return true;
    //     }
    //     return false;
    // }
}
