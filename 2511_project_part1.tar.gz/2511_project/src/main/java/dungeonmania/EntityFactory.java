package dungeonmania;

import org.json.JSONArray;
import org.json.JSONObject;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import dungeonmania.CollectibleEntity.Arrow;
import dungeonmania.CollectibleEntity.Bomb;
import dungeonmania.CollectibleEntity.InvinciblePotion;
import dungeonmania.CollectibleEntity.InvisiblePotion;
import dungeonmania.CollectibleEntity.Key;
import dungeonmania.CollectibleEntity.SunStone;
import dungeonmania.CollectibleEntity.Sword;
import dungeonmania.CollectibleEntity.TimeTurner;
import dungeonmania.CollectibleEntity.Treasure;
import dungeonmania.CollectibleEntity.Wood;
import dungeonmania.StaticEntity.Boulder;
import dungeonmania.StaticEntity.NormalDoor;
import dungeonmania.StaticEntity.Exit;
import dungeonmania.StaticEntity.NormalFloorSwitch;
import dungeonmania.StaticEntity.LightBulb;
import dungeonmania.StaticEntity.LogicalFloorSwitch;
import dungeonmania.StaticEntity.FloorSwitch;
import dungeonmania.StaticEntity.Portal;
import dungeonmania.StaticEntity.SwampTile;
import dungeonmania.StaticEntity.SwitchDoor;
import dungeonmania.StaticEntity.Door;
import dungeonmania.StaticEntity.TimeTravellingPortal;
import dungeonmania.StaticEntity.Wall;
import dungeonmania.StaticEntity.Wire;
import dungeonmania.StaticEntity.ZombieToastSpawner;
import dungeonmania.util.Direction;
import dungeonmania.util.Position;
import dungeonmania.MovingEntity.Mercenary;
import dungeonmania.MovingEntity.Spider;
import dungeonmania.MovingEntity.Zombie;
import dungeonmania.MovingEntity.Hydra;
import dungeonmania.MovingEntity.Assassin;
import dungeonmania.BuildableEntity.Bow;
import dungeonmania.BuildableEntity.Shield;
import dungeonmania.BuildableEntity.Sceptre;
import dungeonmania.BuildableEntity.MidnightArmour;



public class EntityFactory {
    private int totalEntitiesCreated = 0;

    public Entity getEntity(JSONObject entityData, JSONObject configs) {
        int x = entityData.getInt("x");
        int y = entityData.getInt("y");
        String type = entityData.getString("type");
        String id = "entity" + totalEntitiesCreated;
        Entity entity = null;

        switch (type) {
            case "player":
                int health = configs.getInt("player_health");
                int attack = configs.getInt("player_attack");
                entity = new Player(x, y, type, id, health, attack);
                break;

            // Collectible entities
            case "arrow":
                entity = new Arrow(x, y, type, id);
                break;

            case "bomb":
                int bombRadius = configs.getInt("bomb_radius");
                if (entityData.has("logic")) {
                    entity = new Bomb(x, y, type, id, bombRadius, true);
                } else {
                    entity = new Bomb(x, y, type, id, bombRadius, false);
                }
                break;

            case "invincibility_potion":
                int invincibilityDuration = configs.getInt("invincibility_potion_duration");
                entity = new InvinciblePotion(x, y, type, id, invincibilityDuration);
                break;

            case "invisibility_potion":
                int invisibilityDuration = configs.getInt("invisibility_potion_duration");
                entity = new InvisiblePotion(x, y, type, id, invisibilityDuration);
                break;

            case "key":
                int keyId = entityData.getInt("key");
                entity = new Key(x, y, type, id, keyId);
                break;

            case "sword":
                int swordDamage = configs.getInt("sword_attack");
                int swordDurability = configs.getInt("sword_durability");
                entity = new Sword(x, y, type, id, swordDamage, swordDurability);
                break;

            case "treasure":
                entity = new Treasure(x, y, type, id);
                break;

            case "wood":
                entity = new Wood(x, y, type, id);
                break;
            
            case "sun_stone":
                entity = new SunStone(x, y, type, id);
                break;

            case "time_turner":
                entity = new TimeTurner(x, y, type, id);
                break;

            // Static entities
            case "boulder":
                entity = new Boulder(x, y, type, id);
                break;
            
            case "door":
                entity = new NormalDoor(x, y, type, id, entityData.getInt("key"));
                break;
            
            case "exit":
                entity = new Exit (x, y, type, id);
                break;

            case "switch":
                if (entityData.has("logic")) {
                    entity = new LogicalFloorSwitch(x, y, type, id, entityData.getString("logic"));
                    break;
                }
                entity = new NormalFloorSwitch(x, y, type, id);
                break;

            case "portal":
                String colour = entityData.getString("colour");
                entity = new Portal(x, y, type, id, colour);
                break;

            case "wall":
                entity = new Wall(x, y, type, id);
                break;
            
            case "zombie_toast_spawner":
                entity = new ZombieToastSpawner(x, y, type, id);
                break;

                case "swamp_tile":
                int movementFactor = entityData.getInt("movement_factor");
                entity = new SwampTile(x, y, type, id, movementFactor);
                break;

            case "time_travelling_portal":
                entity = new TimeTravellingPortal(x, y, type, id);
                break;

            case "wire":
                entity = new Wire(x, y, type, id);
                break;

            case "light_bulb":
                entity = new LightBulb(x, y, type, id, entityData.getString("logic"));
                break;

            case "switch_door":
                entity = new SwitchDoor(x, y, type, id, entityData.getInt("key"), entityData.getString("logic"));
                break;
            
            // Moving entities
            case "mercenary":
                int mercenaryHealth = configs.getInt("mercenary_health");
                int mercenaryAttack = configs.getInt("mercenary_attack");
                entity = new Mercenary(x, y, type, id, mercenaryHealth, mercenaryAttack, configs);
                break;

            case "spider":
                int spiderHealth = configs.getInt("spider_health");
                int spiderAttack = configs.getInt("spider_attack");
                entity = new Spider(x, y, type, id, spiderHealth, spiderAttack);
                break;
            
            case "zombie_toast":
                int zombieHealth = configs.getInt("zombie_health");
                int zombieAttack = configs.getInt("zombie_attack");
                entity = new Zombie(x, y, type, id, zombieHealth, zombieAttack);
                break;

            case "assassin":
                int assassinHealth = configs.getInt("assassin_health");
                int assassinAttack = configs.getInt("assassin_attack");
                entity = new Assassin(x, y, type, id, assassinHealth, assassinAttack, configs);
                break;

            case "hydra":
                int hydraHealth = configs.getInt("hydra_health");
                int hydraAttack = configs.getInt("hydra_attack");
                entity = new Hydra(x, y, type, id, hydraHealth, hydraAttack, configs);
                break;
        }

        iterateTotalEntitiesCreated();
        return entity;
    }

    public Entity getSavedEntity(JSONObject entityData, int totalEntitiesCreated, JSONObject configs) {
       
        this.totalEntitiesCreated = totalEntitiesCreated;

        Entity entity = null;
        String id = entityData.getString("id");
        String type = entityData.getString("type");
        JSONObject position = entityData.getJSONObject("position");

        int x = position.getInt("x");
        int y = position.getInt("y");

        boolean interactable = entityData.getBoolean("interactable");

        switch (type) {
            case "player":
                
                // Get health and attack values
                int health = entityData.getInt("health");
                int attack = entityData.getInt("attack");
                // Create new player object
                entity = new Player(x, y, type, id, health, attack);
                
                // Get player's inventory
                Inventory inv = ((Player) entity).getInventory();
                // Get saved inventory from data
                JSONObject inventory = entityData.getJSONObject("inventory");
                JSONObject savedItems = inventory.getJSONObject("items");
                // Loop through all items in inventory
                Iterator<String> entityIds1 = savedItems.keys();
                while(entityIds1.hasNext()) {
                    String entityId = entityIds1.next();
                    // Create the inventory items and add it to player
                    JSONObject entityJSON = savedItems.getJSONObject(entityId);
                    Entity itemCreated = getSavedEntity(entityJSON, totalEntitiesCreated, configs);   
                    inv.addItem(itemCreated);
                }

                // Get all buildables from saved file
                JSONArray buildable = inventory.getJSONArray("buildables");
                List<String> savedBuildable = inv.getBuildables();
                for(int i=0; i< buildable.length(); i++){
                    savedBuildable.add(buildable.getString(i));
                }
                // Load buildables into new player
                ((Inventory) inv).setBuildables(savedBuildable);

                // Key stuff
                boolean key = inventory.getBoolean("hasKey");
                ((Inventory) inv).setHasKey(key);

                // Potion effects loaded
                boolean invincible = entityData.getBoolean("isInvincible");
                boolean invisible = entityData.getBoolean("isInvisible");


                // Get player's allies
                List<Entity> allies = ((Player) entity).getAllies();
                // Get saved allies from data
                JSONArray savedAllies = entityData.getJSONArray("allies");
                // Loop through all mercenary objects in array
                for (int i = 0; i < savedAllies.length(); i++) {
                    JSONObject mercenary = savedAllies.getJSONObject(i);
                    Iterator<String> keys = mercenary.keys();
                    while (keys.hasNext()) {
                        // Create mercenary and add it to allies
                        String entityId = keys.next();
                        JSONObject entityJSON = mercenary.getJSONObject(entityId);
                        Entity entityCreated = getSavedEntity(entityJSON, totalEntitiesCreated, configs); 
                        allies.add(entityCreated);
                    }
                }
                // Load allies into new player
                ((Player) entity).setAllies(allies);


                // Get player's potionQ
                List<Entity> potionQue  = ((Player) entity).getPotionQue();
                // Get saved potions from data
                JSONArray potionQ = entityData.getJSONArray("potionQue");
                // Loop through all mercenary objects in array
                for (int i = 0; i < potionQ.length(); i++) {
                    JSONObject potion = potionQ.getJSONObject(i);
                    Iterator<String> keys = potion.keys();
                    while (keys.hasNext()) {
                        // Create mercenary and add it to allies
                        String entityId = keys.next();
                        JSONObject entityJSON = potion.getJSONObject(entityId);
                        Entity entityCreated = getSavedEntity(entityJSON, totalEntitiesCreated, configs); 
                        potionQue.add(entityCreated);
                    }
                }
                // Load potions into new player
                ((Player) entity).setPotionQue(potionQue);



                entity.setInteractable(interactable);
                ((Player) entity).setInvincible(invincible);
                ((Player) entity).setInvisible(invisible);

                // JSONArray potionQ = entityData.getJSONArray("potionQue");

                break;

            // Collectible entities
            case "arrow":
                entity = new Arrow(x, y, type, id);
                entity.setInteractable(interactable);
                break;

            case "bomb":
                int bombRadius = entityData.getInt("radius");
                boolean activated = entityData.getBoolean("activated");
                if (entityData.has("logic")) {
                    entity = new Bomb(x, y, type, id, bombRadius, true);
                } else {
                    entity = new Bomb(x, y, type, id, bombRadius, false);
                }

                ((Bomb) entity).setActivated(activated);
                entity.setInteractable(interactable);
                break;

            case "invincibility_potion":
                int invincibilityDuration = entityData.getInt("duration");
                entity = new InvinciblePotion(x, y, type, id, invincibilityDuration);
                entity.setInteractable(interactable);
                break;

            case "invisibility_potion":
                int invisibilityDuration = entityData.getInt("duration");
                entity = new InvisiblePotion(x, y, type, id, invisibilityDuration);
                entity.setInteractable(interactable);
                break;

            case "key":
                int keyId = entityData.getInt("keyId");
                entity = new Key(x, y, type, id, keyId);
                entity.setInteractable(interactable);
                break;

            case "sword":
                int swordDamage = entityData.getInt("damage");
                int swordDurability = entityData.getInt("durability");
                entity = new Sword(x, y, type, id, swordDamage, swordDurability);

                int numUses = entityData.getInt("numUses");
                ((Sword) entity).setNumUses(numUses);
                entity.setInteractable(interactable);
                break;

            case "treasure":
                entity = new Treasure(x, y, type, id);
                entity.setInteractable(interactable);
                break;

            case "wood":
                entity = new Wood(x, y, type, id);
                entity.setInteractable(interactable);
                break;
            
            case "sun_stone":
                entity = new SunStone(x, y, type, id);
                entity.setInteractable(interactable);
                break;

            case "time_turner":
                entity = new TimeTurner(x, y, type, id);
                entity.setInteractable(interactable);
                break;

            // Static entities
            case "boulder":
                entity = new Boulder(x, y, type, id);
                entity.setInteractable(interactable);
                break;
            
            case "door":
                entity = new NormalDoor(x, y, type, id, entityData.getInt("keyId"));

                boolean open = entityData.getBoolean("open");
                ((Door) entity).setOpen(open);
                entity.setInteractable(interactable);
                break;
            
            case "exit":
                entity = new Exit (x, y, type, id);
                entity.setInteractable(interactable);
                break;

            case "switch":
                if (entityData.has("logic")) {
                    entity = new LogicalFloorSwitch(x, y, type, id, entityData.getString("logic"));
                } else {
                    entity = new NormalFloorSwitch(x, y, type, id);
                }
                
                boolean triggered = entityData.getBoolean("triggered");
                ((FloorSwitch) entity).setTriggered(triggered);
                entity.setInteractable(interactable);
                break;

            case "portal":
                String colour = entityData.getString("colour");
                entity = new Portal(x, y, type, id, colour);
                entity.setInteractable(interactable);
                break;

            case "wall":
                entity = new Wall(x, y, type, id);
                entity.setInteractable(interactable);
                break;
            
            case "zombie_toast_spawner":
                entity = new ZombieToastSpawner(x, y, type, id);
                entity.setInteractable(interactable);
                break;

            case "swamp_tile":
                int movementFactor = entityData.getInt("movementFactor");
                entity = new SwampTile(x, y, type, id, movementFactor);
                entity.setInteractable(interactable);
                break;

            case "time_travelling_portal":
                entity = new TimeTravellingPortal(x, y, type, id);
                entity.setInteractable(interactable);
                break;

            case "wire":
                entity = new Wire(x, y, type, id);
                entity.setInteractable(interactable);
                break;

            case "light_bulb":
                entity = new LightBulb(x, y, type, id, entityData.getString("logic"));
                entity.setInteractable(interactable);
                break;

            case "switch_door":
                entity = new SwitchDoor(x, y, type, id, entityData.getInt("key"), entityData.getString("logic"));
                entity.setInteractable(interactable);
                break;
            
            // Moving entities
            case "mercenary":
                int mercenaryHealth = entityData.getInt("health");
                int mercenaryAttack = entityData.getInt("attack");
                entity = new Mercenary(x, y, type, id, mercenaryHealth, mercenaryAttack, configs);
                
                ((Mercenary) entity).setStuckDuration(entityData.getInt("stuckDuration"));

                boolean bribed = entityData.getBoolean("isBribed");
                ((Mercenary) entity).setIsBribed(bribed);
                ((Mercenary) entity).setAllyAttack(entityData.getInt("allyAttack"));
                ((Mercenary) entity).setAllyDefence(entityData.getInt("allyDefence"));   
                ((Mercenary) entity).setBribeRadius(entityData.getInt("bribeRadius"));   
                ((Mercenary) entity).setBribeAmount(entityData.getInt("bribeAmount"));  
                ((Mercenary) entity).setDuration(entityData.getInt("duration"));  
                ((Mercenary) entity).setIsMindControlled(entityData.getBoolean("isMind_controlled"));  

                entity.setInteractable(interactable);
                break;
            
            case "zombie_toast":
                int zombieHealth = entityData.getInt("health");
                int zombieAttack = entityData.getInt("attack");
                entity = new Zombie(x, y, type, id, zombieHealth, zombieAttack);

                ((Zombie) entity).setStuckDuration(entityData.getInt("stuckDuration"));

                String jsonString = entityData.getJSONObject("directions").toString();
                List<Direction> direction = new Gson().fromJson(jsonString, new TypeToken<List<Direction>>() {}.getType());

                ((Zombie) entity).setDirections(direction);
                entity.setInteractable(interactable);
                break;

            case "assassin":
                int assassinHealth = entityData.getInt("health");
                int assassinAttack = entityData.getInt("attack");
                entity = new Assassin(x, y, type, id, assassinHealth, assassinAttack, configs);

                ((Assassin) entity).setStuckDuration(entityData.getInt("stuckDuration"));

                ((Assassin) entity).setBribeFailRate(entityData.getInt("bribeFailRate"));
                ((Assassin) entity).setAssassinReconRadius(entityData.getInt("setAssassinReconRadius"));
                ((Assassin) entity).setIsMindControlled(entityData.getBoolean("isMind_controlled"));  

                
                entity.setInteractable(interactable);
                break;

            case "hydra":
                int hydraHealth = entityData.getInt("health");
                int hydraAttack = entityData.getInt("attack");
                entity = new Hydra(x, y, type, id, hydraHealth, hydraAttack, configs);

                ((Hydra) entity).setStuckDuration(entityData.getInt("stuckDuration"));

                entity.setInteractable(interactable);
                break;

                // Enemies that can be spawned
            case "spider":
                int spiderHealth = entityData.getInt("health");
                int spiderAttack = entityData.getInt("attack");
                entity = new Spider(x, y, type, id, spiderHealth, spiderAttack);

                ((Spider) entity).setStuckDuration(entityData.getInt("stuckDuration"));

                JSONObject spawnPosition = entityData.getJSONObject("spawnPosition");
                Position pos = new Position(spawnPosition.getInt("x"), spawnPosition.getInt("y"));
                ((Spider) entity).setSpawnPosition(pos);
                
                boolean clockwise = entityData.getBoolean("clockwise");     
                ((Spider) entity).setClockwise(clockwise);

                JSONArray circlePos = entityData.getJSONArray("circlePositions");
                List<Position> circlePositions = new Gson().fromJson(circlePos.toString(), new TypeToken<List<Position>>() {}.getType());
                ((Spider) entity).setCirclePositions(circlePositions);

                entity.setInteractable(interactable);
                break;

            // Entities that can be built
            case "bow":
                int bowDurability = entityData.getInt("durability");
                entity = new Bow(-1, -1, "bow", id, bowDurability);

                entity.setInteractable(interactable);
                break;

            case "shield":
                int shieldDefence = entityData.getInt("defence");
                int shieldDurability = entityData.getInt("durability");
                entity = new Shield(-1, -1, "shield", id, shieldDefence, shieldDurability);

                entity.setInteractable(interactable);
                break;

            case "sceptre":
                int sceptreDurability = entityData.getInt("durability");
                entity = new Sceptre(-1, -1, "sceptre", id, sceptreDurability, configs);

                entity.setInteractable(interactable);
                break;
            
            case "midnight_armour":
                int midnightArmourDurability = entityData.getInt("durability");
                entity = new MidnightArmour(-1, -1, "midnight_armour", id, midnightArmourDurability);

                entity.setInteractable(interactable);
                break;
        }
        return entity;
    }


    /**
     * Entities that can be created after the dungeon is created
     */
    public Entity getNewEntity(int x, int y, String type, JSONObject configs) {
        String id = "entity" + totalEntitiesCreated;
        
        Entity entity = null;

        switch (type) {
            // Enemies that can be spawned
            case "spider":
                int spiderHealth = configs.getInt("spider_health");
                int spiderAttack = configs.getInt("spider_attack");
                entity = new Spider(x, y, type, id, spiderHealth, spiderAttack);
                break;
            
            case "zombie_toast":
                int zombieHealth = configs.getInt("zombie_health");
                int zombieAttack = configs.getInt("zombie_attack");
                entity = new Zombie(x, y, type, id, zombieHealth, zombieAttack);
                break;

            // Entities that can be built
            case "bow":
                int bowDurability = configs.getInt("bow_durability");
                entity = new Bow(-1, -1, "bow", id, bowDurability);
                break;

            case "shield":
                int shieldDefence = configs.getInt("shield_defence");
                int shieldDurability = configs.getInt("shield_durability");
                entity = new Shield(-1, -1, "shield", id, shieldDefence, shieldDurability);
                break;

            case "sceptre":
                int sceptreDurability = 0;
                entity = new Sceptre(-1, -1, "sceptre", id, sceptreDurability, configs);
                break;
            
            case "midnight_armour":
                int midnightArmourDurability = configs.getInt("midnight_armour_durability");
                entity = new MidnightArmour(-1, -1, "midnight_armour", id, midnightArmourDurability);
                break;
        }
        iterateTotalEntitiesCreated();
        return entity;
    }

    public void iterateTotalEntitiesCreated() {
        this.totalEntitiesCreated += 1;
    }

}
