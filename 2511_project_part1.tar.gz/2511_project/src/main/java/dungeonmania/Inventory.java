package dungeonmania;

import dungeonmania.CollectibleEntity.Sword;
import dungeonmania.BuildableEntity.BuildableEntity;
import dungeonmania.exceptions.InvalidActionException;
import dungeonmania.response.models.ItemResponse;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

import com.google.gson.Gson;

public class Inventory {
    private Map<String, Entity> items = new HashMap<>();
    private List<String> buildables = new ArrayList<>();
    private boolean hasKey = false;

    /**
     * Returns a map of all items in the player's inventory
     */
    public Map<String, Entity> getItems() {
        return items;
    }

    /**
     * Checks if there is an entity in the player's inventory
     */
    public boolean hasItem(String entityType) {
        Map<String, Entity> items = getItems();
        for (Entity entity : items.values()) {
            if (entity.getType().equals(entityType)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns a list of all the item responses in the inventory
     */
    public List<ItemResponse> getItemResponses() {
        List<ItemResponse> itemResponses = new ArrayList<>();
        for (Entity entity : items.values()) {
            itemResponses.add(getItemResponse(entity));
        }
        return itemResponses;
    }

    /**
     * Returns the ItemResponse of a given item
     */
    public ItemResponse getItemResponse(Entity entity) {
        String entityId = entity.getId();
        String entityType = entity.getType();
        return new ItemResponse(entityId, entityType);
    }

    /**
     * Returns the list of buildables in inventory
     */
    public List<String> getBuildables() {
        return buildables;
    }


    public void setBuildables(List<String> buildables) {
        this.buildables = buildables;
    }

    public void setHasKey(boolean hasKey) {
        this.hasKey = hasKey;
    }

    /**
     * Adds an item to inventory and updates buildables
     */
    public void addItem(Entity item) {
        String itemType = item.getType();
        if (itemType.equals("key")) {
            this.hasKey = true;
        }
        items.put(item.getId(), item);
        updateBuildables();
    }

    /**
     * Updates the buildables string
     */
    public void updateBuildables() {
        int woodCount = 0;
        int arrowCount = 0;
        int treasureCount = 0;
        int keyCount = 0;
        int sunstoneCount = 0;
        int swordCount = 0;

        // Loop through entities and count the number of wood, arrows, treasure
        // and keys
        for (Entity entity : items.values()) {
            String type = entity.getType();

            if (type.equals("wood")) {
                woodCount++;
            } else if (type.equals("arrow")) {
                arrowCount++;
            } else if (type.equals("treasure")) {
                treasureCount++;
            } else if (type.equals("key")) {
                keyCount++;
            } else if (type.equals("sun_stone")) {
                sunstoneCount++;
            } else if (type.equals("sword")) {
                swordCount++;
            }
        }

        // Empty the buildables list
        buildables.clear();

        // Update buildable list
        if (woodCount >= 1 && arrowCount >= 3) {
            buildables.add("bow");
        }
        
        if (woodCount >= 2 && (treasureCount >= 1 || keyCount == 1 || sunstoneCount >= 1)) {
            buildables.add("shield");
        }

        if ((woodCount >= 1 || arrowCount >= 2) && sunstoneCount >= 1 && (keyCount >= 1 || treasureCount >= 1 || sunstoneCount >= 2)) {
            buildables.add("sceptre");
        }

        if (swordCount >= 1 && sunstoneCount >= 1) {
            buildables.add("midnight_armour");
        }
    }

    /**
     * Checks if there is a key in the player's inventory
     */
    public boolean hasKey() {
        return hasKey;
    }

    /**
     * Checks if there is an entity in the player's inventory
     */
    public boolean hasEntity(String entityType) {
        for (Entity entity : items.values()) {
            if (entity.getType().equals(entityType)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Removes a key from the inventory
     */
    public void removeKey() {
        this.hasKey = false;

        for (Entity entity : items.values()) {
            String entityType = entity.getType();
            if (entityType.equals("key")) {
                items.remove(entity.getId());
            }
        }
    }
    
    /**
     * 
     * @param itemId
     * @return
     * @throws InvalidActionException
     */
    public Entity findItem(String itemId) throws InvalidActionException {
        // Get the item given the itemId
        Entity foundItem = items.get(itemId);
        // If the item was not found
        if (foundItem == null) {
            throw new InvalidActionException("Error: Item not found");
        } else {
            return foundItem;
        }
    }

    /**
     * Removes an item from the inventory
     */
    public void removeItem(String itemId) {
        for (String item : items.keySet()) {
            if (item.equals(itemId)) {
                items.remove(item);
                break;
            }
        }
    }

    /**
     * Returns a list of item responses for the weapons in inventory
     */
    public List<ItemResponse> getWeaponResponses() {
        List<ItemResponse> weaponResponses = new ArrayList<>();
        for (Entity entity : items.values()) {
            String entityType = entity.getType();
            if (entityType.equals("bow") || entityType.equals("sword") ||
                entityType.equals("shield"))
            {
                weaponResponses.add(getItemResponse(entity));
            }
        }
        return weaponResponses;
    }
    

    /**
     * Removes multiple items from inventory
     */
    public void removeItems(String type, int amount) {
        // Create a list of items that need to be removed
        List<String> itemIds = new ArrayList<>();
        for (Entity item : items.values()) {
            if (item.getType().equals(type)) {
                itemIds.add(item.getId());
            }
            if (itemIds.size() == amount) {
                break;
            }
        }

        for (String itemId : itemIds) {
            removeItem(itemId);
        }
    }

    /**
     * Removes deteriorated items from inventory
     */
    public void removeDeteriorated() {
        List<String> deteriorated = new ArrayList<>();

        for (Entity item : items.values()) {
            if (item instanceof BuildableEntity) {
                BuildableEntity buildable = ((BuildableEntity) item);
                if (buildable.getNumUses() == buildable.getDurability()) {
                    deteriorated.add(item.getId());
                }
            
            } else if (item instanceof Sword) {
                if (((Sword) item).getNumUses() == ((Sword) item).getDurability()) {
                    deteriorated.add(item.getId());
                }
            }
        }
        for (String itemId : deteriorated) {
            removeItem(itemId);
        }
    }
    
}
