package dungeonmania;

import dungeonmania.util.Position;
import dungeonmania.response.models.EntityResponse;
import dungeonmania.response.models.ItemResponse;

public abstract class Entity {
    
    private String type;
    private String id;
    protected Position position;
    protected Position previousPosition;
    private boolean interactable = false;

    public Entity(int x, int y, String type, String id) {
        this.position = new Position(x, y, 0);
        this.type = type;
        this.id = id;
    }

    public String getType() {
        return this.type;
    }
    
    public String getId() {
        return this.id;
    }

    public Position getPosition() {
        return this.position;
    }

    public Boolean getInteractable() {
        return this.interactable;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public void setInteractable(Boolean interactable) {
        this.interactable = interactable;
    }

    public EntityResponse getEntityResponse() {
        return new EntityResponse(id, type, position, interactable);
    }

    public ItemResponse getItemResponse() {
        return new ItemResponse(id, type);
    }
    
    public void setPreviousPosition(Position p) {
        this.previousPosition = p;
    }

    public Position getPreviousPosition() {
        return this.previousPosition;
    }

    public void removeFromDungeon(Dungeon d) {
        d.removeEntity(this);
    }

    public void addToDungeon(Dungeon d) {
        d.addEntity(this);
    }

    public void setType(String type) {
        this.type = type;
    }
}
