package dungeonmania.MovingEntity;

import java.util.Map;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.Inventory;
import dungeonmania.Player;
import dungeonmania.util.Position;
import dungeonmania.util.Helper;

public class Assassin extends Mercenary {

    private double bribeFailRate;
    private int assassinReconRadius;


    public Assassin(int x, int y, String type, String id, int health, int attack, JSONObject configs) {
        super(x, y, type, id, health, attack, configs);
        this.bribeFailRate = configs.getInt("assassin_bribe_fail_rate");
        this.allyAttack = configs.getInt("ally_attack");
        this.bribeAmount = configs.getInt("assassin_bribe_amount");
        this.assassinReconRadius = configs.getInt("assassin_recon_radius");
    }

    public double getBribeFailRate() {
        return bribeFailRate;
    }

    // @Override
    // public JSONObject toJson() {
    public int getAssassinReconRadius() {
        return assassinReconRadius;
    }

    public void setBribeFailRate(double bribeFailRate) {
        this.bribeFailRate = bribeFailRate;
    }

    public void setAssassinReconRadius(int assassinReconRadius) {
        this.assassinReconRadius = assassinReconRadius;
    }

    

    //     return assassin;
    // }

    // Assassins are also capable of seeing and moving towards the Player when they are invisible, 
    // if they are within a certain radius.
    @Override
    public void move(Map<String, Entity> entities) {
        Entity player = null;
        Helper helper = new Helper();
        for (Entity entity : entities.values()) {
            String entityType = entity.getType();
            if ( entityType.equals("player")){
                player = entity;
            } 
        }

        Position playerPosition = player.getPosition();

        // If player is invincible, run away
        if (((Player)player).getIsInvincible()) {

            // Check if the four ajacent positions are movable 
            List<Position> possiblePositions = super.getPosition().cardinallyAdjacent();
            List<Position> removed = new ArrayList<>();
            for (Position position : possiblePositions) {
                if (!helper.canMove(helper.getEntitiesAtPosition(position, entities))) {
                    removed.add(position);
                }
            }
        
            possiblePositions.removeAll(removed);

            // Only leave the positions that are further away from the palyer
            double currentDistance = helper.distanceCalculator(super.getPosition(), playerPosition);
            removed.clear();
            for (Position position : possiblePositions) {
                if (helper.distanceCalculator(position, playerPosition) < currentDistance) {
                    removed.add(position);
                }
            }

            possiblePositions.removeAll(removed);

            // Move
            if (possiblePositions.size() != 0) {
                super.setPosition(possiblePositions.get(0));
            }
          
            return;
        }
        
        Position previousPosition = player.getPreviousPosition();

        // if bribed and is close to the player, simply follows the player around
        if (Position.isAdjacent(previousPosition, super.getPosition()) && isBribed) {
            super.setPosition(previousPosition);

            // if player is invisible but within a certain range or its not invisible, find a way
        } else if ((((Player)player).getIsInvisible() && canSeeInvisiblePlayer((Player)player)) || !(((Player)player).getIsInvisible())) {
            super.setPosition(helper.pathfinder(super.getPosition(), playerPosition, entities));
        
            // if player is not within a certain range and invisible
        } else if (((Player)player).getIsInvisible() && !canSeeInvisiblePlayer((Player)player)) {
            return;
        }
    }

    public boolean canSeeInvisiblePlayer(Player player) {
        Boolean canSee = false;

        Position assassinP = getPosition();
        int assassinX = assassinP.getX();
        int assassinY = assassinP.getY();

        Position playerP = player.getPosition();
        int playerX = playerP.getX();
        int playerY = playerP.getY();

        if (Math.abs(assassinX - playerX) <= getAssassinReconRadius() && Math.abs(assassinY - playerY) <= getAssassinReconRadius()) {
            canSee = true;
        }
        return canSee;
    }

    
}
