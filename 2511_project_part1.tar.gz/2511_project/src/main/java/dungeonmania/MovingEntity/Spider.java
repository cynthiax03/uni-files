package dungeonmania.MovingEntity;

import java.util.Map;
import java.util.List;

import dungeonmania.Entity;
import dungeonmania.util.Position;
import dungeonmania.util.Helper;
import dungeonmania.StaticEntity.SwampTile;

public class Spider extends MovingEntity {

    private Position spawnPosition;
    private List<Position> circlePositions;
    private boolean clockwise = true;

    public Spider (int x, int y, String type, String id, int health, int attack) {
        super(x, y, type, id, health, attack);
        this.spawnPosition = new Position(x, y);
        this.circlePositions = spawnPosition.getAdjacentPositions();
    }

    /**
     * moves the spider, reverses its direction if it hits a boulder
     */
    @Override
    public void move(Map<String, Entity> entities) {
        // If the spider is stuck in a swamp, do not move
        if (super.stuckInSwamp()) {
            return;
        }
        
        int currCirclePosition = -1;

        // If the spider is still at the spawn position, set currCircle position to 1
        if (position.equals(spawnPosition)) {
            currCirclePosition = 0;

        // Else find the curr position of the spider in the circle
        } else {
            for (int i = 0; i < circlePositions.size(); i++) {
                if (position.equals(circlePositions.get(i))) {
                    currCirclePosition = i;
                    break;
                }
            } 
        }

        // Get the new position
        Position newPosition = getNewPosition(currCirclePosition);
    
        // Get the entities at the new position
        Helper helper = new Helper();
        List<Entity> entitiesAtPosition = helper.getEntitiesAtPosition(newPosition, entities);

        for (Entity entity : entitiesAtPosition) {
            String entityType = entity.getType();
            
            // Check if the new position contains a boulder, if it does, reverse
            // the spider's direction and recalculate newPosition
            if (entityType.equals("boulder")) {
                reverseDirection();
                newPosition = getNewPosition(currCirclePosition);
                break;

            // If a spider moves onto a swamp, set stuck duration
            } else if (entityType.equals("swamp_tile")) {
                super.setStuckDuration(((SwampTile) entity).getMovementFactor());
            }
        }

        // Set the spider's new position
        super.setPosition(newPosition);
    }

    /**
     * Calculate new position of the spider
     */
    public Position getNewPosition(int currCirclePosition) {
        Position newPosition;

        if (clockwise) {
            newPosition = circlePositions.get((currCirclePosition + 1) % 8);
        } else {
            int newCirclePosition = (currCirclePosition - 1) % 8;
            if (newCirclePosition < 0) {
                newCirclePosition += 8;
            }
            newPosition = circlePositions.get(newCirclePosition);
        }
        return newPosition;
    }

    /**
     * Reverses the direction of the spider (this happens when it hits a 
     * boulder)
     */
    public void reverseDirection() {
        if (clockwise) {
            this.clockwise = false;
        } else {
            this.clockwise = true;
        }
    }

    public void setSpawnPosition(Position spawnPosition) {
        this.spawnPosition = spawnPosition;
    }

    public void setCirclePositions(List<Position> circlePositions) {
        this.circlePositions = circlePositions;
    }

    public void setClockwise(boolean clockwise) {
        this.clockwise = clockwise;
    }

}
