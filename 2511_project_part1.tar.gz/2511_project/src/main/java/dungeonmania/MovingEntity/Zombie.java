package dungeonmania.MovingEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.StaticEntity.Door;
import dungeonmania.util.Direction;
import dungeonmania.util.Position;
import dungeonmania.util.Helper;
import dungeonmania.StaticEntity.SwampTile;

public class Zombie extends MovingEntity {

    private List<Direction> directions;

    public Zombie (int x, int y, String type, String id, int health, int attack) {
        super(x, y, type, id, health, attack);
        this.directions = getDirections();
    }

    /**
     * Moves the zombie in a random direction, zombie has the same movement
     * constraints as player
     */
    @Override
    public void move(Map<String, Entity> entities) {
        // Check if zombie is currently stuck in swamp, don't move
        if (super.stuckInSwamp()) {
            return;
        }

        // Generate a random movement direction
        Random random = new Random();
        int i = random.nextInt(4);
        Direction movementDirection = directions.get(i);

        // Get new position and check if there is anything blocking
        Position newPosition = position.translateBy(movementDirection);

        Helper helper = new Helper();
        List<Entity> entitiesAtPosition = helper.getEntitiesAtPosition(newPosition, entities);
        if (canMove(entitiesAtPosition)) {
            super.setPosition(newPosition);
            super.checkSwamp(entities);
        }
    }

    /**
     * Checks a new position to see if a zombie can move into it
     */
    public boolean canMove(List<Entity> entitiesAtPosition) {
        for (Entity entity : entitiesAtPosition) {
            String entityType = entity.getType();

            if (entityType.equals("boulder") || entityType.equals("portal") ||
                entityType.equals("wall") || 
                (entityType.equals("door") && !(((Door) entity).isOpen())))
            {
                return false;

            // If moving onto a swamp for the first time
            } else if (entityType.equals("swamp_tile")) {
                super.setStuckDuration(((SwampTile) entity).getMovementFactor());
                return true;
            }
        }
        return true;
    }

    /**
     * Gets all possible directions of movement
     */
    public List<Direction> getDirections() {
        List<Direction> directions = new ArrayList<>();

        directions.add(Direction.UP);
        directions.add(Direction.DOWN);
        directions.add(Direction.LEFT);
        directions.add(Direction.RIGHT);

        return directions;
    }

    public void setDirections(List<Direction> directions) {
        this.directions = directions;
    }

    
}

