package dungeonmania.MovingEntity;

import java.util.Map;
import java.util.List;

import dungeonmania.Entity;
import dungeonmania.Player;
import dungeonmania.Dungeon;
import dungeonmania.StaticEntity.SwampTile;
import dungeonmania.util.Helper;

public abstract class MovingEntity extends Entity { 
    
    private double health;
    private int attack;
    private int stuckDuration = 0;

    public MovingEntity (int x, int y, String type, String id, int health, int attack) {
        super(x, y, type, id);
        this.health = health;
        this.attack = attack;
    }

    public double getHealth() {
        return health;
    }

    public int getAttack() {
        return attack;
    }

    public void setAttack(int attack) {
        this.attack = attack;
    }

    public void setHealth(double health) {
        this.health = health;
    }   

    /**
     * Attacks a player and returns the delta player health
     */
    public double attackPlayer(Player player) {
        return player.receiveAttack(attack);
    }

    /**
     * Takes attack damage from an enemy
     */
    public double receiveAttack(double playerAttack) {
        double initialHealth = health;
        double newHealth = health - (playerAttack / 5);
        setHealth(newHealth);

        // Return delta health rounded to 5dp
        double deltaEnemyHealth = newHealth - initialHealth;
        return ((double)Math.round(deltaEnemyHealth * 100000d) / 100000d);
    }

    /**
     * Kills a player and removes it from entity map
     */
    public void killPlayer (Player player, Dungeon dungeon) {
        dungeon.removeEntity(player);
    }

    public abstract void move(Map<String, Entity> entities);

    /**
     * Checks if an enemy can move off a swamp or they are still stuck
     */
    public boolean stuckInSwamp() {
        // If the enemy can move off the swamp on this tick or they are not stuck
        if (stuckDuration == 0) {
            return false;
        }
        this.stuckDuration -= 1;
        return true;
    }

    public void setStuckDuration(int duration) {
        this.stuckDuration = duration;
    }

    /**
     * Checks a position for swamp
     */
    public boolean checkSwamp(Map<String, Entity> entities) {
        Helper helper = new Helper();
        List<Entity> entitiesAtPosition = helper.getEntitiesAtPosition(super.getPosition(), entities);
        for (Entity entity : entitiesAtPosition) {
            if (entity instanceof SwampTile) {
                setStuckDuration(((SwampTile) entity).getMovementFactor());
                return true;
            }
        }
        return false;
    }
}
