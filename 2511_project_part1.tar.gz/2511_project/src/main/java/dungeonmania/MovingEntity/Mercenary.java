package dungeonmania.MovingEntity;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.Player;
import dungeonmania.util.Position;
import dungeonmania.util.Helper;
import dungeonmania.StaticEntity.SwampTile;


public class Mercenary extends MovingEntity {
    
    protected Boolean isBribed = false;
    protected int allyAttack;
    private int allyDefence;
    private int bribeRadius;
    private boolean canSeePlayer = false;
    protected int bribeAmount;
    private int duration = 0;
    private boolean isMindControlled = false;

    public Mercenary (int x, int y, String type, String id, int health, int attack, JSONObject configs) {
        super(x, y, type, id, health, attack);
        super.setInteractable(true);
        this.allyAttack = configs.getInt("ally_attack");
        this.allyDefence = configs.getInt("ally_defence");
        this.bribeRadius = configs.getInt("bribe_radius");
        this.bribeAmount = configs.getInt("bribe_amount");
    }

    public Boolean getIsBribed() {
        return this.isBribed;
    }

    public void setIsBribed(Boolean bribed) {
            this.isBribed = bribed;
    }   

    public int getBribeAmount() {
        return bribeAmount;
    }

    public int getBribeRadius() {
        return bribeRadius;
    }

    public int getAllyAttack() {
        return allyAttack;
    }

    public int getAllyDefence() {
        return allyDefence;
    }

    public boolean getCanSeePlayer() {
        return canSeePlayer;
    }

    public void setCanSeePlayer(boolean canSeePlayer) {
        this.canSeePlayer = canSeePlayer;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public boolean getIsMind_controlled() {
        return isMindControlled;
    }

    public void setIsMindControlled(boolean isMindControlled) {
        this.isMindControlled = isMindControlled;
    }

    public void mindControlDuration() {
        if (duration != 0) {
            setDuration(duration - 1);

        } else if (duration == 0 && !isBribed) {
            setIsMindControlled(false);
            setInteractable(true);
        }
    }
        
    public void setAllyAttack(int allyAttack) {
        this.allyAttack = allyAttack;
    }

    public void setAllyDefence(int allyDefence) {
        this.allyDefence = allyDefence;
    }

    public void setBribeRadius(int bribeRadius) {
        this.bribeRadius = bribeRadius;
    }

    public void setBribeAmount(int bribeAmount) {
        this.bribeAmount = bribeAmount;
    }

    @Override
    public void move(Map<String, Entity> entities) {
        // If the mercenary is stuck in swamp, dont move
        if (super.stuckInSwamp()) {
            return;
        }

        Entity player = null;
        Helper helper = new Helper();
        for (Entity entity : entities.values()) {
            String entityType = entity.getType();
            if ( entityType.equals("player")){
                player = entity;
            } 
        }

        Position playerPosition = player.getPosition();

        // If player is invisible and cannot see the player, don't move
        if (((Player)player).getIsInvisible() && !getCanSeePlayer()) {
            return;
        }

        // If player is invincible, run away
        if (((Player)player).getIsInvincible()) {

            // Check if the four ajacent positions are movable 
            List<Position> possiblePositions = super.getPosition().cardinallyAdjacent();
            List<Position> removed = new ArrayList<>();
            for (Position position : possiblePositions) {
                if (!helper.canMove(helper.getEntitiesAtPosition(position, entities))) {
                    removed.add(position);
                }
            }
        
            possiblePositions.removeAll(removed);

            // Only leave the positions that are further away from the palyer
            double currentDistance = helper.distanceCalculator(super.getPosition(), playerPosition);
            removed.clear();
            for (Position position : possiblePositions) {
                if (helper.distanceCalculator(position, playerPosition) < currentDistance) {
                    removed.add(position);
                }
            }

            possiblePositions.removeAll(removed);

            // Move
            if (possiblePositions.size() != 0) {
                super.setPosition(possiblePositions.get(0));
            }
          
            return;
        }
        
        Position previousPosition = player.getPreviousPosition();

        // if bribed and is close to the player, simply follows the player around
        if (Position.isAdjacent(previousPosition, super.getPosition()) && isBribed) {
            super.setPosition(previousPosition);
            // Otherwise, find a way
        } else {
            Position newPosition = helper.pathfinder(super.getPosition(), playerPosition, entities);
            List<Entity> entitiesAtPosition = helper.getEntitiesAtPosition(newPosition, entities);
            for (Entity entity : entitiesAtPosition) {
                if (entity instanceof SwampTile) {
                    super.setStuckDuration(((SwampTile) entity).getMovementFactor());
                    break;
                }
            }
            super.setPosition(newPosition);
        }
    }

}

