package dungeonmania.MovingEntity;

import org.json.JSONObject;
import java.util.Random;

public class Hydra extends Zombie {

    private double healthIncreaseRate;
    private int healthIncreaseAmount;
    // public Random random = new Random(1);
    // public static int seed = 0;

    public Hydra(int x, int y, String type, String id, int health, int attack, JSONObject configs) {
        super(x, y, type, id, health, attack);
        this.healthIncreaseRate = configs.getDouble("hydra_health_increase_rate");
        this.healthIncreaseAmount = configs.getInt("hydra_health_increase_amount");
    }

    @Override
    public double receiveAttack(double playerAttack) {
        double initialHealth = super.getHealth();
        double newHealth;
        
        Random random = new Random();
        // if (seed == 0) {
        //     random = new Random();
        // } else {
        //     random = new Random(0);
        // }
        
        if (random.nextDouble() < healthIncreaseRate) {
            newHealth = initialHealth + healthIncreaseAmount;
        } else {
            newHealth = initialHealth - (playerAttack / 5);
        }

        setHealth(newHealth);

        // Return delta health rounded to 5dp
        double deltaEnemyHealth = newHealth - initialHealth;
        return ((double)Math.round(deltaEnemyHealth * 100000d) / 100000d);
    }
    
}
