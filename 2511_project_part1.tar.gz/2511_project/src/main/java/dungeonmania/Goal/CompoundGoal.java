package dungeonmania.Goal;

import org.json.JSONObject;

public class CompoundGoal implements ExpressionNode {

    private ExpressionNode left;
    private ExpressionNode right;

    public CompoundGoal(ExpressionNode left, ExpressionNode right) {
        this.left = left;
        this.right = right;
    }

    public ExpressionNode getLeft() {
        return left;
    }

    public ExpressionNode getRight() {
        return right;
    }

    @Override
    public boolean isReached() {
        return false;
    }

    @Override
    public String goalString() {
        return "(" + left.goalString() + " " + this.getOperate() + " " + right.goalString() + ")";
    }


    public String getOperate() {
        return "Compound";
    }

}