package dungeonmania.Goal;

import org.json.JSONObject;

public interface ExpressionNode {

    public boolean isReached();
    public String goalString();
}