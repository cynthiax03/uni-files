package dungeonmania.Goal;

import org.json.JSONObject;

public class AndGoal extends CompoundGoal {

    private String operate;

    public AndGoal(ExpressionNode left, ExpressionNode right) {
        super(left,right);
        this.operate = "AND";
    }

    @Override 
    public boolean isReached() {
        return getLeft().isReached() && getRight().isReached();
    }

    @Override
    public String goalString() {
        if (isReached()) {
            return "";
        }
        return super.goalString();
    }

    @Override
    public String getOperate() {
        return "And";
    }

}