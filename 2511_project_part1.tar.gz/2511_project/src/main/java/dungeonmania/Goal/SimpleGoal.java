package dungeonmania.Goal;

public class SimpleGoal implements ExpressionNode {

    private String goal;
    private int numcount;
    private boolean reached = false;

    public SimpleGoal(String goal, int numcount) {
        this.goal = goal;
        this.numcount = numcount;
    }

    public void reach() {
        reached = true;
    }
    
    public void unreach() {
        reached = false;
    }

    @Override
    public boolean isReached() {
        return reached;
    }

    public int getNumCount() {
        return this.numcount;
    }
    
    @Override
    public String goalString() {
        if (reached) {
            return "";
        } else {
            return ":" + this.goal;
        }
    }
}