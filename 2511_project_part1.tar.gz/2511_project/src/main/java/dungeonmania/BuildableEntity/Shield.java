package dungeonmania.BuildableEntity;

import org.json.JSONObject;

import dungeonmania.Entity;

public class Shield extends BuildableEntity {
    private int defence;
    
    public Shield (int x, int y, String type, String id, int defence, int durability) {
        super(-1, -1, type, id, durability);
        this.defence = defence;
    }

    public int getDefence() {
        return defence;
    }
}
