package dungeonmania.BuildableEntity;

import java.util.Map;

import org.json.JSONObject;

import dungeonmania.Entity;
import dungeonmania.Inventory;

public class BuildableEntity extends Entity {
    
    private int durability = 0;
    private int numUses;

    public BuildableEntity(int x, int y, String type, String id, int durability) {
        super(-1, -1, type, id);
        this.durability = durability;
    }

    /**
     * Uses an item
     */
    public void use () {
        this.numUses += 1;
    }

    public int getNumUses() {
        return numUses;
    }

    public int getDurability() {
        return durability;
    }

    public void addToInventory(Inventory inventory) {
        inventory.addItem(this);
    }

    public void removeFromInventory(Inventory inventory) {
        inventory.removeItem(this.getId());
    }

}
