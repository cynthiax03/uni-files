package dungeonmania.BuildableEntity;

public class Bow extends BuildableEntity {
    
    public Bow(int x, int y, String type, String id, int durability) {
        super(-1, -1, type, id, durability);
    }
    
    
}
