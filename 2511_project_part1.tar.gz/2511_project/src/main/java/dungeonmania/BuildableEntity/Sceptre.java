package dungeonmania.BuildableEntity;

import org.json.JSONObject;

public class Sceptre extends BuildableEntity {

    private int mindControlDuration;
    

    public Sceptre(int x, int y, String type, String id, int durability, JSONObject configs) {
        super(x, y, type, id, durability);
        this.mindControlDuration = configs.getInt("mind_control_duration");
    }
    
    public int getMindControlDuration() {
        return mindControlDuration;
    }
    
}
