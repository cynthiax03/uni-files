package dungeonmania.BuildableEntity;

import org.json.JSONObject;

public class MidnightArmour extends BuildableEntity {

    private int midnightArmourAttack;
    private int midnightArmourDefence;


    public MidnightArmour(int x, int y, String type, String id, int durability) {
        super(x, y, type, id, durability);
    }

    public int getDamage() {
        return midnightArmourAttack;
    }

    public int getDefence() {
        return midnightArmourDefence;
    }
    
}
