package dungeonmania;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

import dungeonmania.util.Direction;
import dungeonmania.util.Position;
import dungeonmania.BuildableEntity.Bow;
import dungeonmania.BuildableEntity.BuildableEntity;
import dungeonmania.BuildableEntity.MidnightArmour;
import dungeonmania.BuildableEntity.Sceptre;
import dungeonmania.BuildableEntity.Shield;
import dungeonmania.CollectibleEntity.Bomb;
import dungeonmania.CollectibleEntity.InvinciblePotion;
import dungeonmania.CollectibleEntity.InvisiblePotion;
import dungeonmania.CollectibleEntity.Key;
import dungeonmania.CollectibleEntity.Sword;
import dungeonmania.MovingEntity.Mercenary;
import dungeonmania.MovingEntity.Assassin;
import dungeonmania.MovingEntity.MovingEntity;
import dungeonmania.StaticEntity.Boulder;
import dungeonmania.StaticEntity.Door;
import dungeonmania.StaticEntity.FloorSwitch;
import dungeonmania.StaticEntity.Portal;
import dungeonmania.StaticEntity.ZombieToastSpawner;
import dungeonmania.util.Helper;
import dungeonmania.response.models.ItemResponse;


public class Player extends Entity {

    private double health;
    private int attack;
    private boolean isInvincible = false;
    private boolean isInvisible = false;
    private Inventory inventory = new Inventory();
    private List<Entity> potionQue = new ArrayList<>();
    private List<Entity> allies = new ArrayList<>();

    public Player(int x, int y, String type, String id, int health, int attack) {
        super(x, y, type, id);
        this.health = health;
        this.attack = attack;
    }

    public Position getPreviousPosition() {
        return previousPosition;
    }

    public void setPreviousPosition(Position previousPosition) {
        this.previousPosition = previousPosition;
    }

    public List<Entity> getAllies() {
        return allies;
    }

    public Boolean getIsInvincible() {
        return this.isInvincible;
    }

    public Boolean getIsInvisible() {
        return this.isInvisible;
    }

    public void setInvincible(boolean isInvincible) {
        this.isInvincible = isInvincible;
    }

    public void setInvisible(boolean isInvisible) {
        this.isInvisible = isInvisible;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    public void setPotionQue(List<Entity> potionQue) {
        this.potionQue = potionQue;
    }

    public void setAllies(List<Entity> allies) {
        this.allies = allies;
    }

    /**
     * Moves a player if it can be moved, return true if moved, return false if
     * the player cannot be moved
     */
    public boolean move(Direction movementDirection, Map<String, Entity> entities) {

        Position newPosition = position.translateBy(movementDirection);

        // Get a list of all entities at the current direction
        Helper helper = new Helper();
        List<Entity> entitiesAtPosition = helper.getEntitiesAtPosition(newPosition, entities);

        // If no static entities at new position move the player
        if (helper.noStaticEntities(entitiesAtPosition)) {
            super.setPosition(newPosition);
            return true;
        }
        
        // If new position contains a wall the player cannot move
        if (helper.isWall(entitiesAtPosition)) {
            return false;
        }

        // Loop through the entities at the new position
        for (Entity entity : entitiesAtPosition) {
            String entityType = entity.getType();
            // If the new position has a door, the door is open or can get
            // unlocked, move
            if (entity instanceof Door && 
                canEnterDoor((Door) entity, getInventory())) 
            {
                super.setPosition(newPosition);
                return true;
            } 

            else if (entity instanceof Door && 
                !canEnterDoor((Door) entity, getInventory())) 
            {
                return false;
            } 

            // If the new position contains a boulder and the boulder can be 
            // pushed, move
            else if (entityType.equals("boulder") && 
                canMoveBoulder(movementDirection, (Boulder) entity, entities)) 
            {
                super.setPosition(newPosition);
                return true;
            } 

            // If the new position contains a boulder and the boulder can't be 
            // pushed, do not move
            else if (entityType.equals("boulder") && 
                !canMoveBoulder(movementDirection, (Boulder) entity, entities)) 
            {
                return false;
            } 

            // Will teleport to a square cardinally adjacent to the other 
            // portal if possible
            else if (entityType.equals("portal")) {
                if (teleport((Portal) entity, entities)) {
                    return true;
                } 
                return false;
            } 
        }
        
        // Else it is a zombie spawner, switch, swamp or an enemy
        super.setPosition(newPosition);
        return true;
    }

    /**
     * Checks whether a player can enter a door, it must either be open or the
     * player must have the key in their inventory and unlock it
     */
    public boolean canEnterDoor(Door door, Inventory inventory) {
        if (door.isOpen()) {
            return true;
        } else if (unlockDoor(door, inventory)) {
            return true;
        } else {
            return false;
        }
    }
    
    /**
     * Unlocks a door if the player has its key in its inventory and returns
     * true, returns false if player cannot unlock door
     */
    public boolean unlockDoor(Door door, Inventory inventory) {   
        // Unlock any door with sunstone and do not remove from inventory
        if (inventory.hasItem("sun_stone")) {
            return true;
        }

        // Check if inventory currently has key
        if (!inventory.hasKey()) {
            return false;
        }

        // Checks if the key in inventory is the door's corresponding key
        Map<String, Entity> items = inventory.getItems();
        for (Entity item : items.values()) {
            String itemType = item.getType();

            if (itemType.equals("key") && ((Key) item).unlockDoor(door)) {
                inventory.removeKey();
                return true;
            }
        }     
        return false;
    }

    /**
     * Checks if a boulder can be moved and moves it
     */
    public boolean canMoveBoulder(Direction movementDirection, Boulder boulder, Map<String, Entity> entities) {
        // Get newPosition of the boulder
        Position boulderPosition = boulder.getPosition();
        Position newPosition = boulderPosition.translateBy(movementDirection);

        // Check if the boulder can be moved onto the new position
        Helper helper = new Helper();
        List<Entity> entitiesAtOldPosition = helper.getEntitiesAtPosition(boulderPosition, entities);
        List<Entity> entitiesAtNewPosition = helper.getEntitiesAtPosition(newPosition, entities);

        // If there are no static entities at the new position, the boulder can
        // be moved
        if (helper.noStaticEntities(entitiesAtNewPosition)) {
            moveBoulder(boulder, newPosition, entitiesAtOldPosition, entitiesAtNewPosition, entities);
            return true;
        }

        // Cannot move if any of the following static entities are present at
        // the new position
        List<String> typesAtPosition = helper.getEntityTypesAtPosition(newPosition, entities);
        if (typesAtPosition.contains("wall") || typesAtPosition.contains("door") ||
            typesAtPosition.contains("portal") || typesAtPosition.contains("boulder") ||
            typesAtPosition.contains("zombie_toast_spawner"))
        {
            return false;
        } else {
            moveBoulder(boulder, newPosition, entitiesAtOldPosition, entitiesAtNewPosition, entities);
            return true;
        }
    }

    /**
     * Moves a boulder, untriggers a switch if it moves off one, triggers a 
     * switch if it moves onto one
     */
    public void moveBoulder(Boulder boulder, Position newPosition, 
        List<Entity> entitiesAtOldPosition, List<Entity> entitiesAtNewPosition, 
        Map<String, Entity> entities) {
        // Move boulder
        boulder.setPosition(newPosition);
        
        // Untrigger switch if there was one at the prev location
        for (Entity entity : entitiesAtOldPosition) {
            String entityType = entity.getType();
            if (entityType.equals("switch")) {
                ((FloorSwitch) entity).untrigger(entities);
            }
        }

        // Trigger switch if there is one at the new location
        for (Entity entity : entitiesAtNewPosition) {
            String entityType = entity.getType();
            if (entityType.equals("switch")) {
                ((FloorSwitch) entity).trigger(entities);
            }
        }        
    }

    /**
     * Collects an item and adds to inventory, removes from entities map
     */
    public void collect(Entity entity, Map<String, Entity> entities) {

        // If the entity is an activated bomb, do not collect
        if (entity instanceof Bomb) {
            Bomb bomb = (Bomb) entity;
            if (bomb.isActivated()) {
                return;
            }
        } 
        // If the entity is a key
        if (entity instanceof Key) {
            // Check if key already in inventory
            if (inventory.hasKey()) {
                return;
            }
        }
        // Otherwise collect
        inventory.addItem(entity);
        String entityId = entity.getId();
        entities.remove(entityId);
    }

    /**
     * Teleports a player to a square cardinally adjacent to corresponding
     * portal, does not teleport if there are no free squares
     */
    public boolean teleport(Portal portal, Map<String, Entity> entities) {
        portal.findCorrespondingPosition(entities, portal);
        Position correspondingPosition = portal.getCorrespondingPosition();
        
        // Get the positions cardinally adjacent to the corresponding portal
        // position
        List<Position> adjacent = correspondingPosition.getAdjacentPositions();
        List<Position> cardinallyAdjacent = new ArrayList<>();
        cardinallyAdjacent.add(adjacent.get(1));
        cardinallyAdjacent.add(adjacent.get(3));
        cardinallyAdjacent.add(adjacent.get(5));
        cardinallyAdjacent.add(adjacent.get(7));

        // Loop through the cardinally adjacent positions and teleport to the
        // first one that is not occuppied by a static entity and teleport
        Helper helper = new Helper();
        for (Position position : cardinallyAdjacent) {
            if (helper.noStaticEntities(helper.getEntitiesAtPosition(position, entities))) {
                super.setPosition(position);
                return true;
            }
        }  
        return false;
    }

    public Inventory getInventory() {
        return inventory;
    }
    
    public void usePotion(Entity entity) {
        
        // Check if there are any on-going potion effects
        if (!potionQue.isEmpty()) {
            // add to que
            potionQue.add(entity);
        // If its empty, add to que and effects kicks in immediately
        } else {
            potionQue.add(entity);
        }
        updatePotion();
    }

    public void updatePotion() {

        // If there are no on-going effects
        if (potionQue.isEmpty()) {
            return;
        }

        // If there are ongoing effects, get the first potion in que
        Entity potion = potionQue.get(0);

        // If the potion was invincible
        if (potion.getType().equals("invincibility_potion")) {

            InvinciblePotion elixr = (InvinciblePotion) potion;
            boolean inEffect = ((InvinciblePotion) potion).isInEffect();
            // If duration is zero, remove it from que
            int duration = elixr.getDuration();
            if (duration == 0) {
                
                potionQue.remove(0);
                this.isInvincible = false;
            } else if (!inEffect) {
                ((InvinciblePotion) potion).setInEffect(true);
                // Enable invincible
                this.isInvincible = true;
            } else {
                // Reduce duration by 1
                elixr.setDuration(duration - 1);
                this.isInvincible = true;
            }

        // Else if the potion was invisible and it was not used yet
        } else if (potion.getType().equals("invisibility_potion")) {

            InvisiblePotion elixr = (InvisiblePotion) potion;
            boolean inEffect = ((InvisiblePotion) potion).isInEffect();
            int duration = elixr.getDuration();
            if (duration == 0) {
                potionQue.remove(0);
                this.isInvisible = false;
            } else if (!inEffect) {
                ((InvisiblePotion) potion).setInEffect(true);
                this.isInvisible = true;
            } else {
                elixr.setDuration(duration - 1);
                this.isInvisible = true;
            }
        }
    }

    public boolean isInvincible() {
        return isInvincible;
    }

    public boolean isInvisible() {
        return isInvisible;
    }

    public void placeBomb(Bomb bomb, Map<String, Entity> entities, Dungeon dungeon) {
        // Bomb position is set to the players current position
        bomb.setPosition(super.getPosition());
        bomb.setPerimeter(bomb.getPosition());

        // Since the bomb had been placed, activate the bomb
        bomb.setActivated(true);
        // Added onto the map
        dungeon.addEntity((Entity) bomb);
    }


    /**
     * Kills an enemy and removes them from the entities map
     */
    public void killEnemy(Entity enemy, Dungeon dungeon) {
        dungeon.removeEntity(enemy);
        dungeon.iterateKillCount();
    }

    /**
     * Gets the total attack for the round and uses the weapons
     */
    public double getAttack() {
        List<ItemResponse> weaponsUsed = new ArrayList<>();

        int playerAttack = attack;
        int bowAttack = 1;
        int swordAttack = 0;
        int allyAttack = 0;
        int midnightArmourAttack = 0;
        Map<String, Entity> items = inventory.getItems();
        for (Entity item : items.values()) {
            String itemType = item.getType();

            if (itemType.equals("bow")) {
                bowAttack = 2 * bowAttack;
                weaponsUsed.add(inventory.getItemResponse(item));
                ((BuildableEntity) item).use();
            }

            else if (itemType.equals("sword")) {
                swordAttack += ((Sword) item).getDamage();
                weaponsUsed.add(inventory.getItemResponse(item));
                ((Sword) item).use();
            }

            else if (itemType.equals("midnight_armour")) {
                midnightArmourAttack += ((MidnightArmour)item).getDamage();
            }
        }

        List<Entity> allies = getAllies();
        for (Entity ally : allies) {
            allyAttack += ((Mercenary) ally).getAllyAttack();
        }

        inventory.removeDeteriorated();

        return bowAttack * (playerAttack + swordAttack + allyAttack + midnightArmourAttack);
    }

    /**
     * Gets the player defence for a given round and uses the weapons
     */
    public int getDefence() {
        int defence = 0;
        Map<String, Entity> items = inventory.getItems();

        for (Entity item : items.values()) {
            String itemType = item.getType();
            if (itemType.equals("shield")) {
                defence += ((Shield) item).getDefence();
                ((BuildableEntity) item).use();
            }

            // Since the midnight armour lasts forever, we don't need to reduce the durability
            else if (itemType.equals("midnight_armour")) {
                defence += ((MidnightArmour)item).getDefence();
            }
        }

        // Get ally defence
        List<Entity> allies = getAllies();
        for (Entity ally : allies) {
            defence += ((Mercenary) ally).getAllyDefence();
        }

        inventory.removeDeteriorated();
        return defence;
    }

    /**
     * Attacks an enemy, returns delta enemy health
     */
    public double attackEnemy(MovingEntity enemy) {
        double attack = getAttack();
        return enemy.receiveAttack(attack);
    }

    /**
     * Takes attack damage from an enemy
     */
    public double receiveAttack(int enemyAttack) {
        double initialPlayerHealth = health;
        double playerDefence = getDefence();
        double newPlayerHealth = initialPlayerHealth - ((enemyAttack - playerDefence) / 10);
        setHealth(newPlayerHealth);

        // Return delta health rounded to 5dp
        double deltaPlayerHealth = newPlayerHealth - initialPlayerHealth;
        return ((double)Math.round(deltaPlayerHealth * 100000d) / 100000d);
    }

    /**
     * Returns the player's current health
     */
    public double getHealth() {
        return health;
    }

    /**
     * Sets the player's health
     */
    public void setHealth(double newHealth) {
        this.health = newHealth;
    }

    /**
     * Builds an item
     */
    public void build(String buildable, EntityFactory entityFactory, JSONObject configs) {
        if (buildable.equals("bow")) {
            buildBow(entityFactory, configs);

        } else if (buildable.equals("shield")) {
            buildShield(entityFactory, configs);

        } else if (buildable.equals("sceptre")) {
            buildSceptre(entityFactory, configs);

        } else if (buildable.equals("midnight_armour")) {
            buildMidnightArmour(entityFactory, configs);
        }
    }

    /**
     * Builds a midnight_armour
     * Can be crafted with a sword and a sun stone
     */
    public void buildMidnightArmour(EntityFactory entityFactory, JSONObject configs) {

        // remove fixed items 
        inventory.removeItems("sword", 1);
        inventory.removeItems("sun_stone", 1);

        // Build shield and add to inventory
        Entity buildable = entityFactory.getNewEntity(-1, -1, "midnight_armour", configs);
        ((BuildableEntity) buildable).addToInventory(inventory);
    }

    /**
     * Builds a sceptre
     * Can be crafted with one wood or two arrows, one key or one treasure, and one sun stone.
     */
    public void buildSceptre(EntityFactory entityFactory, JSONObject configs) {

        // remove fixed items first
        inventory.removeItems("sun_stone", 1);

        // if has wood, remove it, else remove arrow
        if (inventory.hasEntity("wood")) {
            inventory.removeItems("wood", 1);

        } else {
            inventory.removeItems("arrow", 2);
        }

        // if has key, remove it, else remove treasure, else remove the replacement sun stone
        if (inventory.hasKey()) {
            inventory.removeItems("key", 1);

        } else if (inventory.hasEntity("treasure")) {
            inventory.removeItems("treasure", 1);
        } 

        // Build shield and add to inventory
        Entity buildable = entityFactory.getNewEntity(-1, -1, "sceptre", configs);
        ((BuildableEntity) buildable).addToInventory(inventory);
    }



    /**
     * Builds a bow
     */
    public void buildBow(EntityFactory entityFactory, JSONObject configs) {
        
        // Remove items from inventory
        inventory.removeItems("wood", 1);
        inventory.removeItems("arrow", 3);
        
        // Build the bow and add to inventory
        Entity buildable = entityFactory.getNewEntity(-1, -1, "bow", configs);
        ((BuildableEntity) buildable).addToInventory(inventory);
    }

    /**
     * Builds a shield
     */
    public void buildShield(EntityFactory entityFactory, JSONObject configs) {

        // remove wood first
        inventory.removeItems("wood", 2);

        // if has key, remove it, else remove treasure
        if (inventory.hasKey()) {
            inventory.removeItems("key", 1);

        } else if (inventory.hasItem("treasure")) {
            inventory.removeItems("treasure", 1);
        }
        // else it can be built with a sunstone - sunstone is not removed from inventory

        // Build shield and add to inventory
        Entity buildable = entityFactory.getNewEntity(-1, -1, "shield", configs);
        ((BuildableEntity) buildable).addToInventory(inventory);

    }

    public Boolean hasWeapon() {
        Map<String, Entity> items = inventory.getItems();
        Boolean weapon = false;

        for (Entity entity : items.values()) {

            if (entity.getType().equals("sword") || entity.getType().equals("bow")) {
                weapon = true;
            }
        }
        return weapon;
    }

    // player loses a weapon when interacting with a zombie toast spawner
    public void loseWeaponAfterInteracting() {
        Map<String, Entity> items = inventory.getItems();

        for (Entity entity : items.values()) {

            if (entity.getType().equals("sword")) {
                ((Sword) entity).removeFromInventory(inventory);
                break;

            } 
            if (entity.getType().equals("bow")) {
                ((Bow) entity).removeFromInventory(inventory);
                break;

            }
        }
    }

    public void successfullyBribed(Mercenary m) {
        // if a mercenary/assassin is bribed, player cannot interact with them again
        m.setIsBribed(true);
        m.setInteractable(false);
        // and becomes an ally in the battle
        addAlly(m);
}

    public void successfullyMindControlled(Mercenary m) {
        // if a mercenary/assassin is mind controlled, player cannot interact with 
        // them until the mind control wears off
        m.setIsMindControlled(true);
        m.setInteractable(false);
        // and becomes an ally in the battle
        addAlly(m);

        // find the first sceptre
        Map<String, Entity> items = inventory.getItems();
        Entity sceptre = null;
        for (Entity entity : items.values()) {
            if (entity.getType().equals("sceptre")) {
                sceptre = entity;
                break;
            }
        }
        // set mercenary duration to the sceptre duration
        int d = ((Sceptre) sceptre).getMindControlDuration();
        m.setDuration(d);
    }

    // player loses some gold after bribing the mercenary
    public void bribeMercenary(Mercenary m) {

        if (inventory.hasItem("sceptre")) {

            successfullyMindControlled(m);
            // if player has enough gold, bribe with treasure
        } else {

            inventory.removeItems("treasure", m.getBribeAmount());

            // if bribing a mercenary, it's guaranteed that the mercenary will be bribed
            if (m.getType().equals("mercenary")) {
                successfullyBribed(m);

                // When bribing an Assassin, there is a certain chance that the bribe will fail; 
                // the gold will be wasted and the Assassin will remain hostile.
            } else if (m.getType().equals("assassin")) {

                double randomRate = Math.random();
                if (((Assassin) m).getBribeFailRate() < randomRate) {
                    successfullyBribed(m);
                }
            }
        }
    }

    // check if a mercenary is in range
    public boolean mercenaryInRange(Mercenary m) {
        
        // mP is the mercenary position
        Position mP = m.getPosition();
        int mX = mP.getX();
        int mY = mP.getY();

        // p is player position
        Position p = getPosition();
        int x = p.getX();
        int y = p.getY();

        
        boolean inRange = false;
        if (Math.abs(x - mX) <= m.getBribeRadius() && Math.abs(y - mY) <= m.getBribeRadius()) {
            inRange = true;
        }
        return inRange;
    }

    public void destorySpawner(Dungeon d, ZombieToastSpawner zts) {
        zts.removeFromDungeon(d);
    }

    public void addAlly(Entity e) {
        allies.add(e);
    }

    // return true if the player has enough gold to bribe
    public Boolean canBribe(Mercenary mercenary) {

        int goldAmount = 0;
        boolean bribe = false;

        Map<String, Entity> items = inventory.getItems();
        for (Entity i : items.values()) {
            if (i.getType().equals("treasure")) {
                goldAmount++;
            }
        }
        if (goldAmount >= mercenary.getBribeAmount()) {
            bribe = true;
        }
        return bribe;
    }

    public List<Entity> getPotionQue() {
        return potionQue;
    }
    
}