package dungeonmania.CollectibleEntity;

import org.json.JSONObject;

import dungeonmania.StaticEntity.Door;

public class Key extends CollectibleEntity {
    private int keyId;

    public Key(int x, int y, String type, String id, int keyId) {
        super(x, y, type, id);
        this.keyId = keyId;
    }

    /**
     * Returns the keyId of the key
     */
    public int getKeyId() {
        return keyId;
    }

    /**
     * Unlocks a door if its the corresponding door
     */
    public boolean unlockDoor (Door door) {
        if (door.getKeyId() == keyId) {
            door.unlock();
            return true;
        }
        return false;
    }

}