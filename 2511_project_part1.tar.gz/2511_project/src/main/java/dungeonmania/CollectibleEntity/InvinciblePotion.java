package dungeonmania.CollectibleEntity;

public class InvinciblePotion extends CollectibleEntity {

    private int duration;
    private boolean inEffect = false;

    public InvinciblePotion(int x, int y, String type, String id, int duration) {
        super(x, y, type, id);
        this.duration = duration;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public boolean isInEffect() {
        return inEffect;
    }

    public void setInEffect(boolean inEffect) {
        this.inEffect = inEffect;
    }
    
}