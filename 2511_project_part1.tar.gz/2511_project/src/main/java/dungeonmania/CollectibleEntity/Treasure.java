package dungeonmania.CollectibleEntity;

public class Treasure extends CollectibleEntity {

    public Treasure(int x, int y, String type, String id) {
        super(x, y, type, id);
    }

}