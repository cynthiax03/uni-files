package dungeonmania.CollectibleEntity;

public class TimeTurner extends CollectibleEntity {

    public TimeTurner(int x, int y, String type, String id) {
        super(x, y, type, id);
    }
    
}
