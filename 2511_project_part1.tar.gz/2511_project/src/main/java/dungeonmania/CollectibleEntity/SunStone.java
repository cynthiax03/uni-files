package dungeonmania.CollectibleEntity;

public class SunStone extends CollectibleEntity {

    // can be used to open doors and interchangeably with treasure
    // but cant be used to bribe mercenaries or assassins
    // When used in place of a key, it is retained after use
    public SunStone(int x, int y, String type, String id) {
        super(x, y, type, id);
    }

    
}
