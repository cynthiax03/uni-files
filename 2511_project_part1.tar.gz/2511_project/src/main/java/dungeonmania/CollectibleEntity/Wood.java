package dungeonmania.CollectibleEntity;

public class Wood extends CollectibleEntity {
    
    public Wood(int x, int y, String type, String id) {
        super(x, y, type, id);
    }
}