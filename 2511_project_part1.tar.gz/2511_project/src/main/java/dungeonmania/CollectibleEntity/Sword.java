package dungeonmania.CollectibleEntity;

import org.json.JSONObject;

public class Sword extends CollectibleEntity {
    private int damage;
    private int durability;
    private int numUses;
    
    public Sword(int x, int y, String type, String id, int damage, int durability) {
        super(x, y, type, id);
        this.damage = damage;
        this.durability = durability;
    }

    public int getDamage() {
        return damage;
    }

    public int getDurability() {
        return durability;
    }

    public int getNumUses() {
        return numUses;
    }

    public void setNumUses(int numUses) {
        this.numUses = numUses;
    }

    /**
     * Uses the sword
     */
    public void use() {
        this.numUses = numUses += 1;
    }

    /**
     * Checks whether the sword is deteriorated
     */
    public boolean isDeteriorated() {
        if (numUses == durability) {
            return true;
        }
        return false;
    }

}