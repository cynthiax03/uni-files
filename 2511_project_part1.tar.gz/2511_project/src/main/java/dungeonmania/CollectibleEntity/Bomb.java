package dungeonmania.CollectibleEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dungeonmania.Dungeon;
import dungeonmania.Entity;
import dungeonmania.Player;
import dungeonmania.util.Helper;
import dungeonmania.util.Position;

public class Bomb extends CollectibleEntity {

    private int radius;
    private boolean activated = false;
    private List<Position> perimeter;
    private boolean isLogic;

    public Bomb(int x, int y, String type, String id, int radius, boolean isLogic) {
        super(x, y, type, id);
        this.radius = radius;
        this.isLogic = isLogic;
        // this.perimeter = bombPosition.getAdjacentPositions();
    }

    public int getRadius() {
        return radius;
    }

    public void setRadius(int radius) {
        this.radius = radius;
    }

    public boolean isActivated() {
        return activated;
    }

    public void setActivated(boolean activated) {
        this.activated = activated;
    }

    public void setPerimeter(Position pos) {
        this.perimeter = pos.getAdjacentPositions();
    }

    public boolean isLogic() {
        return this.isLogic;
    }

    /**
     * Checks if the given bomb can be detonated
     */
    public void canDetonate(Map<String, Entity> entities, Dungeon dungeon) {

        // Get the perimeter of the bomb
        List<Position> perimeter = this.position.getAdjacentPositions();

        // Check if there are any cardinally adjacent switches that are active
        boolean status = checkSwitchStatus(perimeter, entities);

        // If the bomb can be detonated, remove surrounding things
        if (status) {
            this.detonate(entities, dungeon);
        }
    }

    /**
     * Detonates the bomb
     * @param dungeon
     */
    public void detonate(Map<String, Entity> entities, Dungeon dungeon) {

        List<Entity> entitiesAtPosition = bombRange(entities);

        // Remove all entities
        for (Entity toBeRemoved : entitiesAtPosition) {

            if (!(toBeRemoved instanceof Player)) {
                dungeon.removeEntity(toBeRemoved);
            }
        }
        // Remove bomb from map
        dungeon.removeEntity(this);
    }

    // Find all positions on map that is to be removed
    public List<Entity> bombRange(Map<String, Entity> entities) {

        Helper helper = new Helper();

        List<Entity> entitiesAtPosition = new ArrayList<>();

        int startX = this.position.getX() - radius;
        int startY = this.position.getY() - radius;

        Position position;
        int size = (2 * radius) + 1;
        for (int i = 0; i < size; i++) {

            for (int j = 0; j < size; j++) {

                position = new Position((i + startX), (j + startY));

                entitiesAtPosition.addAll(helper.getEntitiesAtPosition(position, entities));
            }
        }

        return entitiesAtPosition;
    }
    
    /**
     * Checks for cardinally adjacent switches
     */
    public boolean checkSwitchStatus(List<Position> perimeter, Map<String, Entity> entities) {

        Helper helper = new Helper();

        Position position1 = perimeter.get(1);
        Position position2 = perimeter.get(3);
        Position position3 = perimeter.get(5);
        Position position4 = perimeter.get(7);

        // If any of cardinally adjacent switches are primed, bomb can be deonated
        if (helper.switchExistAndActivated(position1, entities) || 
            helper.switchExistAndActivated(position2, entities) || 
            helper.switchExistAndActivated(position3, entities) || 
            helper.switchExistAndActivated(position4, entities)) {
                return true;
        }
        return false;
    }

}