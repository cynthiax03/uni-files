package dungeonmania.CollectibleEntity;

public class Arrow extends CollectibleEntity {
    
    public Arrow(int x, int y, String type, String id) {
        super(x, y, type, id);
    }
}