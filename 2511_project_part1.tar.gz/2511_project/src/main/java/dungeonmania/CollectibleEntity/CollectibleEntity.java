package dungeonmania.CollectibleEntity;

import dungeonmania.Entity;
import dungeonmania.Inventory;

public class CollectibleEntity extends Entity {

    public CollectibleEntity(int x, int y, String type, String id) {
        super(x, y, type, id);
    }

    public void addToInventory(Inventory inventory) {
        inventory.addItem(this);
    }

    public void removeFromInventory(Inventory inventory) {
        inventory.removeItem(this.getId());
    }

}