package dungeonmania.StaticEntity;

import org.json.JSONObject;
import java.util.List;

import dungeonmania.util.Position;
import dungeonmania.util.Helper;
import dungeonmania.Entity;
import dungeonmania.EntityFactory;
import dungeonmania.MovingEntity.MovingEntity;
import dungeonmania.Dungeon;

public class ZombieToastSpawner extends Entity implements StaticEntity {

    public ZombieToastSpawner (int x, int y, String type, String id) {
        super(x, y, type, id);
        super.setInteractable(true);
    }   

    /**
     * Spawns zombies in a dungeon
     */
    public void spawnZombies(Dungeon dungeon, EntityFactory entityFactory, JSONObject configs) {
        // Get cardinally adjacent positions
        List<Position> cardinallyAdjacent = super.getPosition().cardinallyAdjacent();
        
        // Get the first position that is not a wall and spawn zombie there
        Helper helper = new Helper();
        List<Entity> entitiesAtPosition;

        for (Position position : cardinallyAdjacent) {
            // Get the list of entities at that position
            entitiesAtPosition = helper.getEntitiesAtPosition(position, dungeon.getEntities());
            if (!helper.isWall(entitiesAtPosition)) {
                Entity zombie = entityFactory.getNewEntity(position.getX(), position.getY(), "zombie_toast", configs);
                ((MovingEntity) zombie).checkSwamp(dungeon.getEntities());
                dungeon.addEntity(zombie);
                break;
            }
        }     
    }
}