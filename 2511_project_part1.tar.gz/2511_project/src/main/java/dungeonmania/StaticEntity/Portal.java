package dungeonmania.StaticEntity;

import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.util.Position;


public class Portal extends Entity implements StaticEntity {

    private Position correspondingPortalPosition;
    private String colour;


    public Portal (int x, int y, String type, String id, String colour) {
        super(x, y, type, id);
        this.colour = colour;
    }

    /**
     * Finds the position of the corresponding portal
     */
    public void findCorrespondingPosition(Map<String, Entity> entities, Portal portal) {
        for (Entity entity : entities.values()) {
            Position entityPosition = entity.getPosition();
            Position portalPosition = portal.getPosition();

            // If the entity is a portal, they are the same colour but have
            // different positions, they are equal
            if (entity instanceof Portal) {
                String entityColour = ((Portal) entity).getColour();
                if (entityColour.equals(portal.getColour()) && !(entityPosition.equals(portalPosition)))
                {
                    this.correspondingPortalPosition = entityPosition;
                }
            } 
        }
    }

    public Position getCorrespondingPosition() {
        return this.correspondingPortalPosition;
    }

    /**
     * Returns the colour of the portal
     */
    public String getColour() {
        return this.colour;
    }

}