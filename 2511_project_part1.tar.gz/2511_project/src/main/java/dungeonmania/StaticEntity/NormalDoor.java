package dungeonmania.StaticEntity;

import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.CollectibleEntity.Key;                      

public class NormalDoor extends Entity implements StaticEntity, Door {

    private int keyId;
    private boolean open = false;

    public NormalDoor (int x, int y, String type, String id, int keyId) {
        super(x, y, type, id);
        this.keyId = keyId;
    }

    public int getKeyId() {
        return keyId;
    }

    public boolean isOpen() {
        return open;
    }

    /**
     * Checks whether a player can unlock a door
     */
    public boolean canOpen(Door door, Map<String, Entity> items) {
        for (Entity item : items.values()) {
            if ((item instanceof Key) && (((Key) item).getKeyId()) == door.getKeyId()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Unlocks a door
     */
    public void unlock() {
        this.open = true;
    }

    @Override
    public void setOpen(boolean open) {
        this.open = open;
    }

}