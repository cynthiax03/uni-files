package dungeonmania.StaticEntity;

import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.util.Position;

public class Boulder extends Entity implements StaticEntity {
    
    public Boulder (int x, int y, String type, String id) {
        super(x, y, type, id);
    }

    /**
     * Checks if a boulder can be moved in a certain direction
     */
    public boolean canMove(Position newPosition, Map<String, Entity> entities) {
        for (Entity entity : entities.values()) {
            Position entityPosition = entity.getPosition();
            if (newPosition.equals(entityPosition) && (entity instanceof StaticEntity) 
                && (entity instanceof FloorSwitch)) return false;
        }
        return true;
    }

}

