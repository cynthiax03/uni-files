package dungeonmania.StaticEntity;

import dungeonmania.Entity;

public class Exit extends Entity implements StaticEntity {

    public Exit (int x, int y, String type, String id) {
        super(x, y, type, id);
    }

}