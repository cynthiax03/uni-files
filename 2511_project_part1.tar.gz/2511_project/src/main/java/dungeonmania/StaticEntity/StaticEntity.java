package dungeonmania.StaticEntity;


public interface StaticEntity {

   
    
}



  
