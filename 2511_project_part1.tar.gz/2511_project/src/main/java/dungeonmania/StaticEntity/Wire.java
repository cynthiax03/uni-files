package dungeonmania.StaticEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.util.Helper;

public class Wire extends Entity implements StaticEntity {

    private boolean activated = false;
    private List<Wire> visited = new ArrayList<>();
    public Wire(int x, int y, String type, String id) {
        super(x, y, type, id);
    }

    public boolean isActivated() {
        return this.activated;
    }

    public void activate(Map<String, Entity> entities) {
        this.activated = true;
        Helper helper = new Helper();

        // Activate wires that will be triggered by this wire
        List<Wire> connectedWires = helper.getCardinallyAdjacentWires(super.getPosition(), entities);
        
        for (Wire wire : connectedWires) {
            if (!this.visited.contains(wire)) {
                visited.add(wire);
                wire.activate(entities);
            }
            
        }

        // Update it's status to the other logical entities that's connected to this wire
        List<LogicalEntity> connectedLogics = helper.getCardinallyAdjacentLogics(super.getPosition(), entities);
        for (LogicalEntity logic : connectedLogics) {
            logic.activate(entities);
        }
    }

    public void unactivate(Map<String, Entity> entities) {
        this.activated = false;
        Helper helper = new Helper();

        // Unativate wires that were triggered by this wire
        List<Wire> connectedWires = helper.getCardinallyAdjacentWires(super.getPosition(), entities);
        for (Wire wire : connectedWires) {
            if (!visited.contains(wire)) {
                visited.add(wire);
                wire.unactivate(entities);
            }
        }

        // Update it's status to the other logical entities that's connected to this wire
        List<LogicalEntity> connectedLogics = helper.getCardinallyAdjacentLogics(super.getPosition(), entities);
        for (LogicalEntity logic : connectedLogics) {
            logic.activate(entities);
        }

    }
    
    public void clearVisited() {
        this.visited.clear();
    }
}
