package dungeonmania.StaticEntity;

import java.util.Map;

import dungeonmania.Entity;

public interface FloorSwitch {
    public boolean isTriggered();
    public void trigger(Map<String, Entity> entities);
    public void untrigger(Map<String, Entity> entities);
    public void setTriggered(Boolean triggered);
}
