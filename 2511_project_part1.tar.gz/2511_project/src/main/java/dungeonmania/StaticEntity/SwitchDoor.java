package dungeonmania.StaticEntity;

import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.CollectibleEntity.Key;

public class SwitchDoor extends LogicalEntity implements Door {

    private int keyId;
    private boolean open = false;


    public SwitchDoor(int x, int y, String type, String id, int keyId, String logic) {
        super(x, y, type, id, logic);
        this.keyId = keyId;
    }

    @Override
    public int getKeyId() {
        return keyId;
    }

    @Override
    public boolean isOpen() {
        return open || super.isLogicActivated();
    }

    @Override
    public boolean canOpen(Door door, Map<String, Entity> items) {
        for (Entity item : items.values()) {
            if ((item instanceof Key) && (((Key) item).getKeyId()) == door.getKeyId() && isOpen()) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void unlock() {
        this.open = true;
    }

    @Override
    public void setOpen(boolean open) {
        this.open = open;
    }
    
}
