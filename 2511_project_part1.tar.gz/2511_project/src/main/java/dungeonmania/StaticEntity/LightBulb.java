package dungeonmania.StaticEntity;

import java.util.Map;

import dungeonmania.Entity;

public class LightBulb extends LogicalEntity {

    public LightBulb(int x, int y, String type, String id, String logic) {
        super(x, y, type, id, logic);
        super.setType("light_bulb_off");
    }

    @Override 
    public void activate(Map<String, Entity> entities) {
        super.activate(entities);
    }

    @Override
    public boolean isLogicActivated() {
        return super.isLogicActivated();
    }
    
}
