package dungeonmania.StaticEntity;

import dungeonmania.Entity;

public class Wall extends Entity implements StaticEntity {

    public Wall (int x, int y, String type, String id) {
        super(x, y, type, id);
    }

}
