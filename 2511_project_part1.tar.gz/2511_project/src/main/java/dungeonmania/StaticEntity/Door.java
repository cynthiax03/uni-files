package dungeonmania.StaticEntity;

import java.util.Map;

import dungeonmania.Entity;

public interface Door {

    public int getKeyId();
    public boolean isOpen();
    public boolean canOpen(Door door, Map<String, Entity> items);
    public void unlock();
    public void setOpen(boolean open);
    
}
