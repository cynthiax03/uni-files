package dungeonmania.StaticEntity;

import java.util.List;
import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.util.Helper;

public abstract class LogicalEntity extends Entity implements StaticEntity {

    private String logic;
    private boolean activated = false;

    public LogicalEntity(int x, int y, String type, String id, String logic) {

        super(x, y, type, id);
        this.logic = logic;

    }


    // This function updates the current logical entity's activation status
    public void activate(Map<String, Entity> entities) {
        
        // Get the wires/switches status on it's cardinally adjacent positions
        Helper helper = new Helper();
        List<Wire> connectedWires = helper.getCardinallyAdjacentWires(super.getPosition(), entities);
        List<FloorSwitch> connectedSwitches = helper.getCardinallyAdjacentSwitches(super.getPosition(), entities);

        switch(logic) {
            // When logic is "AND", all cardinally adjacent wires and switches must be activated
            case "and":
                boolean canActivate = true;
                for (Wire wire : connectedWires) {
                    if (!wire.isActivated()) {
                        canActivate = false;
                    }
                }

                if (canActivate) {
                    for (FloorSwitch floorSwitch : connectedSwitches) {
                        if (!floorSwitch.isTriggered()) {
                            canActivate = false;
                        }
                    }
                }
                
                
                // If we proceed till here, means all cardinally adjacent wires/switches are activated
                this.activated = canActivate;
                break;
            
            // When logic is "OR", only one cardinally adjacent wire/switch need to be activated
            case "or":
                boolean determinator = false;
                for (Wire wire : connectedWires) {
                    determinator = determinator || wire.isActivated();
                }
                for (FloorSwitch floorSwitch : connectedSwitches) {
                    determinator = determinator || floorSwitch.isTriggered();
                }
                this.activated = determinator;
                break;
            
            // When logic is "XOR", only one cardinally adjacent wire/switch is allowed to be activated
            // to activate this logical entity
            case "xor":
                int numActivated = 0;

                for (Wire wire : connectedWires) {
                    if (wire.isActivated()) {
                        numActivated++;
                    }
                    if (numActivated > 1) {
                        this.activated = false;
                        break;
                    }
                }

                for (FloorSwitch floorSwitch : connectedSwitches) {
                    if (floorSwitch.isTriggered()) {
                        numActivated++;
                    }
                }

                if (numActivated == 1) {
                    this.activated = true;
                } else {
                    this.activated = false;
                }
                break;

            // When logic is "CO_AND", all cardinally adjacent entities must be activated
            // on the same tick
            case "co_and":
        }

        if (this.activated && this.getType().equals("light_bulb_off")) {
            super.setType("light_bulb_on");
        } else if (!this.activated && this.getType().equals("light_bulb_on")) {
            super.setType("light_bulb_off");
        }

        
    }


    public boolean isLogicActivated() {
        return activated;
    }

    

}
