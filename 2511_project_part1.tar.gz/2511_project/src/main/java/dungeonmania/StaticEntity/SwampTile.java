package dungeonmania.StaticEntity;

import dungeonmania.Entity;

public class SwampTile extends Entity implements StaticEntity {

    private int movementFactor;

    public SwampTile(int x, int y, String type, String id, int movementFactor) {
        super(x, y, type, id);
        this.movementFactor = movementFactor;
    }

    public int getMovementFactor() {
        return movementFactor;
    }
    
}
