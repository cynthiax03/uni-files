package dungeonmania.StaticEntity;

import java.util.List;
import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.util.Helper;

public class NormalFloorSwitch extends Entity implements StaticEntity, FloorSwitch {

    private boolean triggered = false;
    
    public NormalFloorSwitch (int x, int y, String type, String id) {
        super(x, y, type, id);
        this.triggered = false;
    }

    public boolean isTriggered() {
        return triggered;
    }

    public void trigger(Map<String, Entity> entities) {
        this.triggered = true;
        Helper helper = new Helper();

        // Activate wires that will be triggered by this switch
        List<Wire> connectedWires = helper.getCardinallyAdjacentWires(super.getPosition(), entities);
        for (Wire wire : connectedWires) {
            wire.activate(entities);
        }

        // Update it's status to the other logical entities that's connected to this switch
        List<LogicalEntity> connectedLogics = helper.getCardinallyAdjacentLogics(super.getPosition(), entities);
        for (LogicalEntity logic : connectedLogics) {
            logic.activate(entities);
        }

    }

    public void untrigger(Map<String, Entity> entities) {
        this.triggered = false;
        Helper helper = new Helper();
        
        // Unactivate the wires that were triggered by this switch
        List<Wire> connectedWires = helper.getCardinallyAdjacentWires(super.getPosition(), entities);
        for (Wire wire : connectedWires) {
            wire.unactivate(entities);
        }

        // Update it's status to the other logical entities that's connected to this switch
        List<LogicalEntity> connectedLogics = helper.getCardinallyAdjacentLogics(super.getPosition(), entities);
        for (LogicalEntity logic : connectedLogics) {
            logic.activate(entities);
        }

    }

    @Override
    public void setTriggered(Boolean triggered) {
        this.triggered = triggered;
    }
}