package dungeonmania.StaticEntity;

import java.util.List;
import java.util.Map;

import dungeonmania.Entity;
import dungeonmania.util.Helper;

public class LogicalFloorSwitch extends LogicalEntity implements FloorSwitch {

    private boolean triggered = false;

    public LogicalFloorSwitch(int x, int y, String type, String id, String logic) {
        super(x, y, type, id, logic);
    }

    @Override
    public boolean isTriggered() {
        return triggered;
    }

    @Override
    public void trigger(Map<String, Entity> entities) {
        super.activate(entities);
        if (super.isLogicActivated()) {
            this.triggered = true;
        }
    }

    @Override
    public void untrigger(Map<String, Entity> entities) {
        this.triggered = false;

        // Update the status of it's cardinally connected entities
        Helper helper = new Helper();

        List<Wire> connectedWires = helper.getCardinallyAdjacentWires(super.getPosition(), entities);
        for (Wire wire : connectedWires) {
            wire.unactivate(entities);
        }

        List<LogicalEntity> connectedLogics = helper.getCardinallyAdjacentLogics(super.getPosition(), entities);
        for (LogicalEntity logicalEntity : connectedLogics) {
            logicalEntity.activate(entities);
        }
    }

    @Override
    public void setTriggered(Boolean triggered) {
        this.triggered = triggered;
    }
    
}
