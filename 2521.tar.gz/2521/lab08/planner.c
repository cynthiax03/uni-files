// Algorithms to design electrical grids

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"
#include "Place.h"
#include "PQ.h"

////////////////////////////////////////////////////////////////////////
// Your task

/**
 * Designs  a minimal cost electrical grid that will deliver electricity
 * from a power plant to all the given cities. Power lines must be built
 * between cities or between a city and a power plant.  Cost is directly
 * proportional to the total length of power lines used.
 * Assumes  that  numCities  is at least 1 (numCities is the size of the
 * cities array).
 * Stores the power lines that need to be built in the given  powerLines
 * array, and returns the number of power lines stored. Assumes that the
 * powerLines array is large enough to store all required power lines.
 */

double distance(Place cityOne, Place cityTwo);

int planGrid1(Place cities[], int numCities, Place powerPlant,
              PowerLine powerLines[]) {
    // TODO: Complete this function

    // Create a graph of the cities and one powerplant
    Graph cityGraph = GraphNew(numCities + 1);

    // Loop through all the cities
    for (int i = 0; i < numCities; i++) {
        // Create an edge between ith city and every other city (not
        // including itself and cities it is already connected with)
        for (int j = i + 1; j < numCities; j++) {
            // Create an edge between the two cities
            Edge e;
            e.v = i;
            e.w = j;
            e.weight = distance(cities[i], cities[j]);
            if (e.weight > 0.0) {
                GraphInsertEdge(cityGraph, e);
            }
        }

        // Create an edge between the city and the powerPlant
        Edge powerPlantEdge;
        powerPlantEdge.v = i;
        powerPlantEdge.w = numCities;
        powerPlantEdge.weight = distance(cities[i], powerPlant);
        GraphInsertEdge(cityGraph, powerPlantEdge);
    }

    // Create an MST based on the cityGraph
    Graph MST = GraphMST(cityGraph);

    // Keep track of number of edges and number of power lines
    int edgeCounter = 0;
    int powerLineCounter = 0;

    // Loop through all cities
    for (int k = 0; k < numCities; k++) {
        for (int l = k + 1; l < numCities; l++) {
            // Check if there is an edge between the kth and ith city in the 
            // MST if there is, create a powerline between them and add to the
            // powerLine array
            if (GraphIsAdjacent(MST, k, l)) {
                PowerLine powerLine;
                powerLine.p1 = cities[k];
                powerLine.p2 = cities[l];
                powerLines[powerLineCounter] = powerLine;

                // Increase edgeCounter and powerLineCounter
                edgeCounter++;
                powerLineCounter++;
            }
        }
        
        // Check if there is an edge between the city and the powerPlant
        // if there is, add to the the powerLine array
        if (GraphIsAdjacent(MST, k, numCities)) {
            PowerLine powerLine;
            powerLine.p1 = cities[k];
            powerLine.p2 = powerPlant;
            powerLines[powerLineCounter] = powerLine;

            // Increase edgeCounter and powerLineCounter
            edgeCounter++;
            powerLineCounter++;
        }
    }

    // Free graphs
    GraphFree(MST);
    GraphFree(cityGraph);
    
    return edgeCounter;
}

// Finds the distance between two cities and returns it
double distance(Place cityOne, Place cityTwo) {
    int x1 = cityOne.x;
    int y1 = cityOne.y;
    int x2 = cityTwo.x;
    int y2 = cityTwo.y;
    return sqrt(((x1 - x2) * (x1 - x2)) + ((y1 - y2) * (y1 - y2)));
}

////////////////////////////////////////////////////////////////////////
// Optional task

/**
 * Designs  a minimal cost electrical grid that will deliver electricity
 * to all the given cities.  Power lines must be built between cities or
 * between a city and a power plant.  Cost is directly  proportional  to
 * the  total  length of power lines used.  Assume that each power plant
 * generates enough electricity to supply all cities, so not  all  power
 * plants need to be used.
 * Assumes  that  numCities and numPowerPlants are at least 1 (numCities
 * and numPowerPlants are the sizes of the cities and powerPlants arrays
 * respectively).
 * Stores the power lines that need to be built in the given  powerLines
 * array, and returns the number of power lines stored. Assumes that the
 * powerLines array is large enough to store all required power lines.
 */
int planGrid2(Place cities[], int numCities,
              Place powerPlants[], int numPowerPlants,
              PowerLine powerLines[]) {
    // TODO: Complete this function
    return 0;
}
