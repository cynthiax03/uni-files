#include <stdio.h>
#include <stdlib.h>

typedef struct node {
	int data;
	struct node *next;
} Node;
typedef Node *List;

int listLength(list l)

int main() {

}

int listLength(list l) {
    if (l == NULL) {
        return 0;
    }

    return (l->key % 2 + listLength(l->next))
}

time complexity: x/x^3, bottom is the most powerful function
log(n) + 1 = Olog(n)
what happens when n gets enormous, 