
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"

bool inCycle(Graph g, int nV, int currNode);
bool inCycle(Graph g, int nV, int currNode) {
    for (int i = 0; i < nV; i++) {
        if (GraphIsAdjacent(g, currNode, i)) {
            return true;
            // if (inCycle())
        }
    }

    return false;
}

// bool GraphHasCycle(Graph g) {
//     bool *visited = calloc(g->nV, sizeof(bool));
//     assert(visited != NULL); 
    
//     for (int v = 0; v < g->nV; v++) {
//         if (!visited[v] && doHasCycle(g, v, v, visited)) {
//             free(visited);
//             return true;
//         }
//     }

//     free(visited);
//     return false;
// }

// static bool doHasCycle(Graph g, Vertex v, Vertex prev, bool *visited) {
//     visited[v] = true;
//     for (int w = 0; w < g->nV; w++) {
//         if (g->edges[v][w] != 0.0) {
//             if (!visited[w]) {
//                 if (doHasCycle(g, w, v, visited)) {
//                     return true;
//                 }
//             } else if (w != prev) {
//                 return true;
//             }
//         }
//     }
//     return false;
// }

// Worst case time complexity of this solution: O(n^2)
void nodesNotInCycle(Graph g, int notInCycle[]) {
    int nV = GraphNumVertices(g);
    for (int i = 0; i < nV; i++) {
        notInCycle[i] = 1;
    }

    for (int node = 0; node < nV; node++) {
        if (inCycle(g, nV, node)) {
            notInCycle[node] = 0;
        }
    }


}

