
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "BSTree.h"

int findHeight(BSTree t, int height);
int findHeight(BSTree t, int height) {
    if (t->left == NULL && t->right == NULL) {
        return height;
    }
    
    if (t->left != NULL && t->right == NULL) {
        height++;
        return findHeight(t->left, height);

    } else if (t->left == NULL && t->right != NULL) {
        height++;
        return findHeight(t->right, height);

    } else {
        // Both children are not NULL
        height++;
        int L = findHeight(t->left, height);
        int R = findHeight(t->right, height);
        // if (L > R) {
        //     return L;
        // } else {
        //     return R;
        // }
        return L + R;
    } 
}

int findMax(BSTree t, int diff);
int findMax(BSTree t, int diff) {
    if (t == NULL) {
        return 1;
    }

    int L = findHeight(t->left, 0);
    int R = findHeight(t->right, 0);

    if (diff < abs(L - R)) {
        diff = abs(L - R);
        return diff;
    }

    return diff;
}

int maxDiff(BSTree t) {
    
    return findMax(t, 0);
}

