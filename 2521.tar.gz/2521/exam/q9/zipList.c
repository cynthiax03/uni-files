
#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "list.h"

void insertNode(List l, Node new);
void insertNode(List l, Node new) {
    if (l->last == NULL) {
        l->last = new;
    } else {
        l->last->next = new;
        l->last = new;
    }
    
    if (l->first == NULL) {
        l->first = new;
    }
}

// void combine(List l1, int x, List l2, int y, List combL);
// void combine(List l1, int x, List l2, int y, List combL) {
//     if (l1 == NULL && l2 == NULL) {
//         return;
//     }
//     int counter1 = 0;
//     int counter2 = 0;
//     for (Node curr = l1->first; curr != NULL; curr = curr->next) {
//         if (counter1 != x) {
//             Node new = newNode(curr->value);
//             insertNode(combL, new);
//             counter++;
//         } else {
//             // counter == x, add l2 items
//             for (Node curr = l->first; curr != NULL; curr = curr->next)

//         }
//     }
// }

int addL2(List combinedList, List l2, int y, int upTo);
int addL2(List combinedList, List l2, int y, int upTo) {
    int i = 0;
    int count = 0;
    for (Node curr = l2->first; curr != NULL; curr = curr->next)  {
        if (i >= upTo && i < (upTo + y)) {
            Node new = newNode(curr->value);
            insertNode(combinedList, new);
            count++;
        }
        i++;
    }
    return count;
}

int sizeOfList(List list);
int sizeOfList(List list) {
	int count = 0;
	for (Node curr = list->first; curr != NULL; curr = curr->next) {
		count++;
	}

	return count;
}


// Worst case time complexity of this solution: O(n^2)
List zipList(List l1, int x, List l2, int y) {
    
    List combinedList = ListNew();

    if (l1 == NULL && l2 == NULL) {
        return combinedList;
    }
    int size2 = sizeOfList(l2);
    int upTo = 0;
    int counter1 = 0;
    for (Node curr = l1->first; curr != NULL; curr = curr->next) {
        if (counter1 < x && upTo < size2) {
            Node new = newNode(curr->value);
            insertNode(combinedList, new);
            counter1++;
        } else if (counter1 == x && upTo < size2) {
            upTo += addL2(combinedList, l2, y, upTo);
            counter1 = 0;
            Node new = newNode(curr->value);
            insertNode(combinedList, new);
            counter1++;
            continue;
        }
        if (curr->next == NULL && upTo != size2) {
            addL2(combinedList, l2, size2, upTo);
            Node new = newNode(curr->value);
            insertNode(combinedList, new);

        } else if (curr->next != NULL && upTo == size2) {
            Node new = newNode(curr->value);
            insertNode(combinedList, new);

        }
    }

    return combinedList;
}

