
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#include "list.h"

int match(Node listA, Node listB, int t, int sizeB);
int match(Node listA, Node listB, int t, int sizeB) {
	Node curr = listA;

	for (int i = 0; i < sizeB; i++) {
		if ((curr == NULL && i != 3) || t < 0) {
			return 0;
		}
		if (curr->value != listB->value) {
			t--;
		} 

		curr = curr->next;
		listB = listB->next;
	} 
	return 1;
}

int sizeOfList(List list);
int sizeOfList(List list) {
	int count = 0;
	for (Node curr = list->first; curr != NULL; curr = curr->next) {
		count++;
	}

	return count;
}

// Worst case time complexity of this solution: O(...)
int numSubsequences(List listA, List listB, int tolerance) {
	int sizeB = sizeOfList(listB);
	
	int count = 0;
	for (Node curr = listA->first; curr != NULL; curr = curr->next) {
		if (match(curr, listB->first, tolerance, sizeB)) {
			count++;
		}
	}
	return count;
}

