
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Fs.h"

int findTotal(File file);
int findTotal(File file) {
	int count = 0;

	if (file->type == TEXT_FILE) {
		return count += strlen(file->text);
	}

	if (file->type == DIRECTORY) {
		for (FileList curr = file->files; curr != NULL; curr = curr->next) {
			if (file->type == DIRECTORY) {
				count += findTotal(curr->file);
			} else {
				// the file is a txt file
				count += strlen(file->text);
			}
		} 
	}
	
	return count;
}

int totalTextSize(Fs fs) {
	File root = fs->root;

	if (root->files == NULL && root->type == DIRECTORY) {
		return 0;
	}

	return findTotal(root);
}

