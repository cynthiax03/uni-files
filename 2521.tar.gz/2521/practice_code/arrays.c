#include <stdio.h>

int main(void) {
    int values[5];
    values[0] = 5;
    values[0] = [];
    printf("%d\n", values[0]);
    return 0;
}