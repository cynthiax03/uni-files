
#include <stdio.h>
#include <stdlib.h>

#include "Queue.h"

int main(void) {
	Queue q = QueueNew();

	// Write a benchmark test to demonstrate the difference between
	// ArrayQueue and CircularArrayQueue
	
	for (int i = 1; i <= 20000; i++) {
		QueueEnqueue(q, i);
	}

	for (int j = 1; j <= 19999; j++) {
		QueueDequeue(q);
	}
	
	for (int i = 20001; i <= 40000; i++) {
		QueueEnqueue(q, i);
	}

	for (int j = 20000; j <= 39999; j++) {
		QueueDequeue(q);
	}

	for (int i = 40001; i <= 60000; i++) {
		QueueEnqueue(q, i);
	}

	for (int j = 40000; j <= 59999; j++) {
		QueueDequeue(q);
	}

	for (int i = 60001; i <= 80000; i++) {
			QueueEnqueue(q, i);
	}

	QueueFree(q);
}

