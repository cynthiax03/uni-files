// Centrality Measures API implementation
// COMP2521 Assignment 2

#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "CentralityMeasures.h"
#include "Dijkstra.h"
#include "Graph.h"

///////////////////////////////////////////////////////////////////////////////
// Helper Function Declarations

double calculateCC(Graph g, int u, double N);
int findPaths(PredNode *currPred, NodeData *dijkstraArray, int s);
int findPathsThroughV(PredNode *head, NodeData *dijkstraArray, int v, int s, int t);

///////////////////////////////////////////////////////////////////////////////

double *closenessCentrality(Graph g) {
	// Get the number of vertices in the graph g
	int nV = GraphNumVertices(g);

	// Initialise the closeness centrality array we will be returning
	double *closenessArray = malloc(sizeof(double) * nV);

	// Loop through all the vertices in the graph
	for (int u = 0; u < nV; u++) {
		// Get closeness centrality for u and put result in closenessArray
		closenessArray[u] = calculateCC(g, u, (double)nV);
	}
	
	return closenessArray;
}


double *betweennessCentrality(Graph g) {
	// Get the number of vertices in the graph g
	int nV = GraphNumVertices(g);

	// Initialise the betweenness centrality array we will be returning
	double *betweennessArray = malloc(sizeof(double) * nV);

	// Set all values to be 0
	for (int i = 0; i < nV; i++) {
		betweennessArray[i] = 0.0;
	}

	// Loop through all vertices
	for (int v = 0; v < nV; v++) {
		// Loop through all sources
		for (int s = 0; s < nV; s++) {
			// As v cannot be equal to s, continue
			if (v == s) {
				continue;
			}

			// Get dijkstra array where s is the src
			NodeData *dijkstraArray = dijkstra(g, s);

			// Loop through all vertices t
			for (int t = 0; t < nV; t++) {
				// t cannot be equal to s or v and nothing can be done if there
				// are no preds so continue
				if (t == s || t == v || dijkstraArray[t].pred == NULL) {
					continue;
				}

				// Find the total number of shortest paths from s to t and find
				// the number of those paths that pass through v
				int pathsThroughV = findPathsThroughV(dijkstraArray[t].pred, dijkstraArray, v, s, t);
				int numShortestPaths = findPaths(dijkstraArray[t].pred, dijkstraArray, s);

				betweennessArray[v] += (double) pathsThroughV / numShortestPaths;
			}
			freeNodeData(dijkstraArray, nV);
		}
	}
	return betweennessArray;
}

///////////////////////////////////////////////////////////////////////////////
// Helper Functions

// Calculates the closeness centrality of a given node u with the Wasserman and
// Faust formula and returns it
double calculateCC(Graph g, int u, double N) {
	// Get the nodeData array of g with src u
	NodeData *dijkstraArray = dijkstra(g, u);
		
	// Initialise number of nodes reachable (n) and sum of all reachable
	double n = 0;
	double sumAllReachable = 0;

	// Loop through each v in the dijkstraArray
	for (int v = 0; v < N; v++) {
		// If the distance of v from u is not infinity, a path exists, iterate
		// numNodesReachable and add to sumAllReachable
		if (dijkstraArray[v].dist != INFINITY) {
			n++;
			sumAllReachable += dijkstraArray[v].dist;
		} 
	}

	freeNodeData(dijkstraArray, GraphNumVertices(g));

	// if n, N or sumAllReachable are 0, return 0
	if (n == 0 || N == 0 || sumAllReachable == 0) {
		return 0;
	} else {
		// Calculate closeness centrality and return
		return (((n - 1) / (N - 1)) * ((n - 1) / sumAllReachable));
	}
}

// Counts the number of paths from src to vertex t and returns it
int findPaths(PredNode *currPred, NodeData *dijkstraArray, int t) {
	// Once NULL is reached a path is finished / found
	if (currPred == NULL) {
		return 1;
	}
	// Loop through the pred nodes of curr
	int paths = 0;
	for (struct PredNode *curr = currPred; curr != NULL; curr = curr->next) {
		// Add each path onto paths
		paths += findPaths(dijkstraArray[curr->v].pred, dijkstraArray, t);
	}
	return paths;
}

// Counts the total number of paths from s to t that go through v (where s, t,
// v are vertices) and returns it
int findPathsThroughV(PredNode *head, NodeData *dijkstraArray, int v, int s, int t) {
	// If head is NULL, a path was not found to contain v
	if (head == NULL) {
		return 0;
	}

	// Loop through the pred list
	int paths = 0;
	for (struct PredNode *pred = head; pred != NULL; pred = pred->next) {
		// If a path containing v is found
		if (pred->v == v) {
			// Get the sum of all the subsequent paths (as a path containing v
			// may split into 2 paths later one)
			paths += findPaths(dijkstraArray[pred->v].pred, dijkstraArray, s);
			break;
		} else {
			// check the next pred for v
			paths += findPathsThroughV(dijkstraArray[pred->v].pred, dijkstraArray, v, s, t);
		}
	}
	return paths;
}