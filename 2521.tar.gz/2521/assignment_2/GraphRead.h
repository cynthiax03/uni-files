// Function to read in a graph
// COMP2521 Assignment 2

// !!! DO NOT MODIFY THIS FILE !!!

#ifndef GRAPH_READ_H
#define GRAPH_READ_H

#include "Graph.h"

Graph readGraph(char *file);

#endif

