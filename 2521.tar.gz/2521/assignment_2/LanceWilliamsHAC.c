// Lance-Williams Algorithm for Hierarchical Agglomerative Clustering
// COMP2521 Assignment 2

#include <assert.h>
#include <float.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "Graph.h"
#include "LanceWilliamsHAC.h"

#define INFINITY DBL_MAX

///////////////////////////////////////////////////////////////////////////////
// Helper function declarations

double **initialiseDistA(int nV, Graph g);
Dendrogram *initialiseDendA(int nV);
int *initialiseRedundantA(int nV);
double min (double a, double b);
double max (double a, double b);
double findDist(Graph g, int i, int j);
Dendrogram mergeDends(Dendrogram dendOne, Dendrogram dendTwo);
double singleLinkageDist(Dendrogram curr, Graph g, int i);
double completeLinkageDist(Dendrogram curr, Graph g, int i);
bool isRedundant(int nV, int *redundantA, int idx);
void updateDistA(double **distA, int nV, int method, int *redundantA, 
				 Dendrogram *dendA, Graph g, int clusterIdx, int redundantIdx);
void freeDistA(int nV, double **distA);

///////////////////////////////////////////////////////////////////////////////

/**
 * Generates  a Dendrogram using the Lance-Williams algorithm (discussed
 * in the spec) for the given graph  g  and  the  specified  method  for
 * agglomerative  clustering. The method can be either SINGLE_LINKAGE or
 * COMPLETE_LINKAGE (you only need to implement these two methods).
 * 
 * The function returns a 'Dendrogram' structure.
 */
Dendrogram LanceWilliamsHAC(Graph g, int method) {
	// Find the number of vertices in g
	int nV = GraphNumVertices(g);

	// Malloc the distArray and initialise its values (DBL_MAX if no edge 
	// exists between i and j and 1 / maxWeight if there is an edge between
	// them)
	double **distArray = initialiseDistA(nV, g);

	// Malloc the a dendrogram array and initialise each cell to point to a
	// dendrogram where its vertex corresponds to vertex i
	Dendrogram *dendArray = initialiseDendA(nV);

	// Create a redundant array that keeps track of all the redundant rows and
	// cols, intialise all values to -1
	int *redundantArray = initialiseRedundantA(nV);
	
	// Make the dendrogram by merging nV - 1 times
	for (int itr = 0; itr < nV - 1; itr++) {
		double shortestEdge = DBL_MAX;
		int idxI, idxJ = 0;

		// Find the shortestEdge in the distArray and its indexes
		for (int i = 0; i < nV; i++) {
			for (int j = 0; j < nV; j++) {
				if (distArray[i][j] < shortestEdge && i != j) {
					shortestEdge = distArray[i][j];
					idxI = i;
					idxJ = j;
				}
			}
		}

		// The min of idxI and idxJ will become the new row and col that
		// represents the cluster where the max of idxI and idxJ will become a 
		// redundant row and col
		int clusterIdx = min(idxI, idxJ);
		int redundantIdx = max(idxI, idxJ);

		// Update the dendArray[clusterIdx] where the right and left nodes are
		// the nodes being merged, the redundant cell will be set to NULL
		dendArray[clusterIdx] = mergeDends(dendArray[clusterIdx], dendArray[redundantIdx]);
		dendArray[redundantIdx] = NULL;

		// Add the redundantIdx to the redundantArray, there will be a 
		// redundantIdx each time a merge happens
		redundantArray[itr] = redundantIdx;
		
		// Update the distArray by finding the shortest dist from the cluster
		// to every other vertex
		updateDistA(distArray, nV, method, redundantArray, dendArray, 
					g, clusterIdx, redundantIdx);
	}
	
	// free all the arrays used and save the final dendrogram before the 
	// dendArray is freed
	freeDistA(nV, distArray);
	free(redundantArray);
	Dendrogram d = dendArray[0];
	free(dendArray);
	return d;
}

///////////////////////////////////////////////////////////////////////////////
// Helper functions

// Finds the max dist between two vertices i and j and returns it, if an edge
// does not exist between them, return DBL_MAX
double findDist(Graph g, int i, int j) {
	double maxWeight = DBL_MAX;
	
	// Find the outgoing and ingoing edges of vertice i
	AdjList outgoing = GraphOutIncident(g, i);
	AdjList ingoing = GraphInIncident(g, i);
	
	// Loop through all the outgoing edges
	for (struct adjListNode *outCurr = outgoing; outCurr != NULL;
			outCurr = outCurr->next) {
		// Set the maxWeight
		if (outCurr->v == j) {
			maxWeight = outCurr->weight;
		}
	}

	// Loop through all the ingoing edges
	for (struct adjListNode *inCurr = ingoing; inCurr != NULL;
			inCurr = inCurr->next) {
			// If the ingoing edge is a greater dist, update the maxWeight
		if (inCurr->v == j && inCurr->weight > maxWeight) {
			maxWeight = inCurr->weight;
		}
	}

	// If there are no direct edges between i and j, return DBL_MAX
	if (maxWeight == DBL_MAX) {
		return maxWeight;
	}
	// Return the maxWeight
	return 1 / maxWeight;
}

// Initialises a distArray, all values will be DBL_MAX unless there exists an
// edge between the i and j value. The maximum edge weight is found and the
// dist value is obtained by through the formula 1 / maxWeight
double **initialiseDistA(int nV, Graph g) {
	// The following code was taken from https://www.geeksforgeeks.org/dynamically-allocate-2d-array-c/
	// It is used to malloc a 2D array of size nV * nV
	double **distA = malloc(nV * sizeof(double));
	
for (int i = 0; i < nV; i++) {
		distA[i] = malloc(nV * sizeof(double));
	}
	
	// Loop through each array cell in distArray
	for (int i = 0; i < nV; i++) {
		for (int j = 0; j < nV; j++) {
			// initialise to the infinity value or dist if there exist an 
			// edge between them
			distA[i][j] = findDist(g, i, j);
		}
	}
	return distA;
}

// Mallocs and initialises a dend array where each cell points to a dendrogram
// of a different vertice
Dendrogram *initialiseDendA(int nV) {
	Dendrogram *dendA = malloc (sizeof(Dendrogram) * nV);

	// Loop through the array and initialise
	for (int i = 0; i < nV; i++) {
		// Create a dend
		Dendrogram dend = malloc(sizeof(*dend));
		dend->vertex = i;
		dend->right = NULL;
		dend->left = NULL;

		// Make dendArray[i] point to the dendNode
		dendA[i] = dend;
	}
	return dendA;
}

// Mallocs a redundant array which will store all the redundant cols / rows, 
// all values are initialised to -1 at first
int *initialiseRedundantA(int nV) {
	int *redundantA = malloc(sizeof(int) * nV);
	
	for (int i = 0; i < nV; i++) {
		redundantA[i] = -1;
	}
	return redundantA;
}

// Returns the min of two numbers
double min (double a, double b) {
	if (a < b) {
		return a;
	}
	return b;
}

// Returns the max of two numbers
double max (double a, double b) {
	if (a > b) {
		return a;
	}
	return b;
}

// Creates a new dendrogram d and sets its left node to be dendOne and its
// right node to dendTwo, then returns the new dendrogram d
Dendrogram mergeDends(Dendrogram dendOne, Dendrogram dendTwo) {
	Dendrogram d = malloc(sizeof(*d));
	d->vertex = -1;
	d->right = dendOne;
	d->left = dendTwo;
	return d;
}

// For the single linkage method, we calculate the minimum distance from the 
// cluster to a vertex i
double singleLinkageDist(Dendrogram curr, Graph g, int i) {
	if (curr == NULL) {
		return DBL_MAX;
	}
	
	// Set minDist to DBL_MAX
	double minDist = DBL_MAX;

	// If the dist of the curr vertex is less than minDist, change the minDist
	if (curr->vertex != -1 && findDist(g, i, curr->vertex) < minDist && curr->vertex != i) {
		minDist = findDist(g, i, curr->vertex);
	}

	// Look through the left and right children
	minDist = min(singleLinkageDist(curr->left, g, i), minDist);
	minDist = min(singleLinkageDist(curr->right, g, i), minDist);

	return minDist;
}

// For the complete linkage method, we calculate the max distance from the 
// cluster to the vertex i
double completeLinkageDist(Dendrogram curr, Graph g, int i) {
	if (curr == NULL) {
		return DBL_MAX;
	}

	// Set the maxDist to be 0.0 and get the dist of curr to i
	double maxDist = 0.0;
	double currDist = findDist(g, i, curr->vertex);

	// If the curr dist is greater than maxDist but is not DBL_MAX, update 
	// maxDist
	if (curr->vertex != -1 && currDist != DBL_MAX && currDist > maxDist) {
		maxDist = currDist;
	}

	// Look through the left and right children
	maxDist = max(completeLinkageDist(curr->left, g, i), maxDist);
	maxDist = max(completeLinkageDist(curr->right, g, i), maxDist);

	// If there was no maxDist, there is no direct links between the cluster
	// and the vertex so return DBL_MAX
	if (maxDist == 0) {
		return DBL_MAX;
	}

	// If there was a direct link, return maxDist
	return maxDist;
}

// Loops through the redundant array and checks whether a given index is
// redundant, returns true if it is and false if it isn't
bool isRedundant(int nV, int *redundantA, int idx) {
	for (int i = 0; i < nV; i++) {
		if (redundantA[i] != -1 && redundantA[i] ==idx) {
			return true;
		}
	}
	return false;
}

void updateDistA(double **distA, int nV, int method, int *redundantA, Dendrogram *dendA, Graph g, int clusterIdx, int redundantIdx) {
	for (int i = 0; i < nV; i++) {
		// if the method is single linkage, and idx i is not redundant
		if (method == SINGLE_LINKAGE && !isRedundant(nV, redundantA, i)) {
		// find the min dist between the cluster and i and update the distA
		// accordingly
		double minDist = singleLinkageDist(dendA[clusterIdx], g, i);
			distA[i][clusterIdx] = minDist;
			distA[clusterIdx][i] = minDist;
		} 
		
		// if the method is complete linkage, and idx i is not redundant
		else if (method == COMPLETE_LINKAGE && !isRedundant(nV, redundantA, i)) {
			// find the max dist between the cluster and i and update the 
			// distA accordingly
			double maxDist = completeLinkageDist(dendA[clusterIdx], g, i);
			distA[i][clusterIdx] = maxDist;
			distA[clusterIdx][i] = maxDist;
		}

		// Set all the redundant rows / cols to be DBL_MAX
		distA[i][redundantIdx] = DBL_MAX;
		distA[redundantIdx][i] = DBL_MAX;
	}
}

// Frees the distance array
void freeDistA(int nV, double **distA) {
	for (int i = 0; i < nV; i++) {
		free(distA[i]);
	}
	free(distA);
}
