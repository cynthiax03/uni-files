// Dijkstra API implementation
// COMP2521 Assignment 2

#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Dijkstra.h"
#include "Graph.h"
#include "PQ.h"

///////////////////////////////////////////////////////////////////////////////
// Helper Function Declarations

NodeData *initialiseNDArray(int nV);
PredNode *createNewPredNode (int vertex);
NodeData insertPred(NodeData vertex, PredNode *newPred);
void freePredList(PredNode *pred);

///////////////////////////////////////////////////////////////////////////////

NodeData *dijkstra(Graph g, Vertex src) {
	// Create a NodeData array of length equal to number of nodes in the graph
	// and intialise all values to INFINITY
	NodeData *nDArray = initialiseNDArray(GraphNumVertices(g));

	// Create a new priority queue
	PQ vSet = PQNew();

	// Initialise the distance of the src to be 0 and insert src into vSet
	nDArray[src].dist = 0;
	PQInsert(vSet, src, 0);

	while (!PQIsEmpty(vSet)) {
		// Get the vertex with the smallest priority (distance)
		int currVertex = PQDequeue(vSet);
		
		// Get outgoing vertices from currVertex and loop through them
		AdjList outgoing = GraphOutIncident(g, currVertex);
		for (struct adjListNode *currOutgoing = outgoing; currOutgoing != NULL;
			 currOutgoing = currOutgoing->next) {
			
			// Get path from src to currOutgoing
			int path = currOutgoing->weight + nDArray[currVertex].dist;

			// If the path is greater than the curr dist or if the currOutgoing 
			// is the src, continue 
			if (path > nDArray[currOutgoing->v].dist || currOutgoing->v == src) {
				continue;
			}

			// Create a new pred node with the currVertex
			PredNode *newPred = createNewPredNode(currVertex);

			// If the dist of the outgoing vertex from src is less than the 
			// dist in the nDArray (there is a new shortest dist)
			if (path < nDArray[currOutgoing->v].dist) {
				// Update the dist in the nDArray and free all nodes in the 
				// predlist before putting newPred as the new list
				nDArray[currOutgoing->v].dist = path;
				freePredList(nDArray[currOutgoing->v].pred);
				nDArray[currOutgoing->v].pred = newPred;
			} 
			
			// If the dist is equal
			else if (path == nDArray[currOutgoing->v].dist) {
				// Add newPred to the pred list in ascending order of vertex
				nDArray[currOutgoing->v] = insertPred(nDArray[currOutgoing->v], newPred);
			}

			// Insert the currOutgoing vertex into vSet
			PQInsert(vSet, currOutgoing->v, path);
		}	
	}

	PQFree(vSet);
	return nDArray;
}

void freeNodeData(NodeData *data, int nV) {
	// Loop through each element in the array 
	for (int vIndex = 0; vIndex != nV; vIndex++) {
		// free the pred list of the current vIndex
		freePredList(data[vIndex].pred);
	}

	// Free the array
	free(data);
}

///////////////////////////////////////////////////////////////////////////////
// Helper functions

// Mallocs a node data array then initialises all its values to INFINITY and
// returns it
NodeData *initialiseNDArray(int nV) {
	// Malloc the array
	NodeData *nDArray = malloc(sizeof(NodeData) * nV);

	// Initialise all values to INFINITY
	for (int v = 0; v < nV; v++) {
		nDArray[v].dist = INFINITY;
		nDArray[v].pred = NULL;
	}
	return nDArray;
}

// Creates a new PredNode with a given vertex and an empty pred list
PredNode *createNewPredNode (int vertex) {
	// Malloc the new pred and set its vertex to 
	PredNode *newPred = malloc(sizeof(PredNode));
	newPred->v = vertex;
	newPred->next = NULL;
	return newPred;
}

// Inserts a new pred into a NodeData list in ascending order
NodeData insertPred(NodeData vertex, PredNode *newPred) {
	// If the node needs to be inserted at the start of the list
	if (newPred->v < vertex.pred->v) {
		PredNode *tmp = vertex.pred;
		vertex.pred = newPred;
		newPred->next = tmp;
		return vertex;
	}

	// If the node needs to be inserted at the end of the list
	for (struct PredNode *curr = vertex.pred; curr != NULL; curr = curr->next) {
		// If the last vertex of the list is less than the newNode vertex, 
		// insert the newNode at the end
		if (curr->next == NULL && newPred->v > curr->v) {
			curr->next = newPred;
			return vertex;
		}
	}

	// If the node needs to be inserted somewhere in the middle of the list
	for (struct PredNode *curr = vertex.pred; curr->next != NULL; curr = curr->next) {
		// if the current node is less than the newNode and the next node is
		// greater than the newNode
		if (curr->v < newPred->v && curr->next->v > newPred->v) {
			struct PredNode *tmp = curr->next;
			curr->next = newPred;
			newPred->next = tmp;
			return vertex;
		}
	}
	return vertex;
}

// Frees the pred list contained in a NodeData node
void freePredList(PredNode *pred) {
	// If the list is already empty, there is nothing to free
	if (pred == NULL) {
		return;
	} else {
		// If the list is not empty, free each element
		struct PredNode *curr = pred;
		struct PredNode *tmp;
		while(curr != NULL) {
			tmp = curr->next;
			free(curr);
			curr = tmp;
		}	
	}
}