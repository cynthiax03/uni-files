
#include "list.h"

int numDupesInOrderedList(List l) {
	
	int numDupes = 0;

	// // If the list is empty or the list only has one element it is sorted
	// if (l->head == NULL || l->head->next == NULL) {
	// 	return 0;
	// }

	// int listSize = 0;
	// for (Node curr = l->head; curr->next != NULL; curr = curr->next) {
	// 	listSize++;
	// }

	NodeData *nDArray = getListNodeData(l); 

	// for (int i = 0; nDArray[i].addr != NULL; i++) {
	// 	int currValue = nDArray[i].value;
	// 	for (int j = i + 1; nDArray[j].addr != NULL; j++) {
	// 		if (nDArray[j].value == currValue) {
	// 			numDupes++;
	// 			i = j + 1;
	// 		}
	// 	}
	// }

	for (int i = 0; nDArray[i + 1].addr != NULL; i++) {
		if (nDArray[i].value == nDArray[i + 1].value) {
			numDupes++;
		}
	}

	// printf('%d\n', nDArray[0].value);
	free(nDArray);

	return numDupes;
}

