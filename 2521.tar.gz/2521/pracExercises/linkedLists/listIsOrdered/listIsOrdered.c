
#include "list.h"

bool listIsOrdered(List l) {

	// If the list is empty or the list only has one element it is sorted
	if (l->head == NULL || l->head->next == NULL) {
		return true;
	}

	bool ascending = true;
	bool descending = true;

	// If the list has more than one element
	for (Node curr = l->head; curr->next != NULL; curr = curr->next) {
		if (curr->value < curr->next->value) {
			ascending = false;
		} 
		else if (curr->value > curr->next->value) {
			descending = false;
		}
	}

	if (ascending == true || descending == true) {
		return true;
	} else {
		return false;
	}
	
}

