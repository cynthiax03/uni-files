
#include "list.h"

Node recurse(List l, Node prev, Node curr, Node next);
Node recurse(List l, Node prev, Node curr, Node next) {
	if (curr->next == NULL) {
		curr->next = prev;
		prev = curr;
		return curr;
	}
	next = curr->next;
	curr->next = prev;
	prev = curr;
	curr = next;
	curr = recurse(l, prev, curr, next);
	return curr;
}

void listReverse(List l) {
	if (l->head == NULL || l->head->next == NULL) {
		return;
	}

	Node prev = NULL;
	Node curr = l->head;
	Node next = l->head->next;

	l->head = recurse(l, prev, curr, next);

	// for (Node curr = l->head; curr->next != NULL; curr = curr->next) {
	// while (curr != NULL) {
	// 	printList(l);
	// 	next = curr->next;
	// 	curr->next = prev;
	// 	prev = curr;
	// 	curr = next;
	// }
}

