
#include <stdio.h>
#include <stdlib.h>

#include "BSTree.h"

BSTree insertNode(BSTree t, BSTree newNode);
BSTree insertNode(BSTree t, BSTree newNode) {
	if (t == NULL) { 
		return newNode;
	}
	
	if (t->value == newNode->value) {
		free(newNode);
		return t;
	}

	if (t->value > newNode->value) {
		t->left = insertNode(t->left, newNode);
	} else {
		t->right = insertNode(t->right, newNode);
	}

	return t;
}

BSTree BSTreeInsert(BSTree t, int val) {
	BSTree newNode = malloc(sizeof(*newNode));
	newNode->value = val;
	newNode->left = NULL;
	newNode->right = NULL;
	
	if (t == NULL) {
		return newNode;
	}

	insertNode(t, newNode);

	return t;
}

