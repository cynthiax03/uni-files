
#include <stdlib.h>

#include "tree.h"

int sumOdds(Tree t, int sum);
int sumOdds(Tree t, int sum) {
	if (t == NULL) {
		return sum;
	}

	if (t->value % 2 != 0) {
		sum += t->value;
	}

	sum = sumOdds(t->left, sum);
	sum = sumOdds(t->right, sum);

	return sum;
}

int TreeSumOdds(Tree t) {
	return sumOdds(t, 0);
}

