
#include <stdlib.h>

#include "BSTree.h"

int findDepth(BSTree t, int key, int height);
int findDepth(BSTree t, int key, int height) {
	if (t == NULL) {
		return -1;
	}
	
	if (t->value == key) {
		return height;
	}

	height++;
	if (t->left != NULL && t->right == NULL) {
		return findDepth(t->left, key, height);
	} else if (t->left == NULL && t->right != NULL) {
		return findDepth(t->right, key, height);
	} else {
		int L = findDepth(t->left, key, height);
		int R = findDepth(t->right, key, height);
		if (L != -1) {
			return L;
		} else {
			return R;
		}
	}
}

int BSTreeNodeDepth(BSTree t, int key) {
	return findDepth(t, key, 0);
}

