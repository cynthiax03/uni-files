
#include <stdlib.h>
#include <stdio.h>

#include "BSTree.h"

// typedef struct node *Node;
// struct node {
// 	int value;
// 	Node next;
// };

// void addNode(Node list, Node newNode);
// void addNode(Node list, Node newNode) {
// 	if (list == NULL) {
// 		list = newNode;
// 	}
// 	for (Node curr = list; curr != NULL; curr = curr->next) {
// 		if (curr->next == NULL) {
// 			curr->next = newNode;
// 		}
// 	}
// }

// Node makeList(BSTree t, Node list);
// Node makeList(BSTree t, Node list) {
// 	if (t->left == NULL && t->right == NULL) {
// 		Node newNode = malloc(sizeof(Node));
// 		newNode->value = t->value;
// 		newNode->next = NULL;
// 		addNode(list, newNode);
// 		return list;
// 	}

// 	if (t->left != NULL && t->right == NULL) {
// 		makeList(t->left, list);
// 		Node newNode = malloc(sizeof(Node));
// 		newNode->value = t->value;
// 		newNode->next = NULL;
// 		addNode(list, newNode);
// 	} else if (t->left == NULL && t->right != NULL) {
// 		makeList(t->right, list);
// 		Node newNode = malloc(sizeof(Node));
// 		newNode->value = t->value;
// 		newNode->next = NULL;
// 		addNode(list, newNode);
// 	} else {
// 		// If both children are not NULL
// 		makeList(t->left, list);
// 		makeList(t->right, list);
// 		Node newNode = malloc(sizeof(Node));
// 		newNode->value = t->value;
// 		newNode->next = NULL;
// 		addNode(list, newNode);
// 	}
	
// 	if (t == NULL) {
// 		return list;
// 	}

// 	if (makeList(t->left, list) != NULL) {
// 		Node newNode = malloc(sizeof(Node));
// 		newNode->value = t->value;
// 		newNode->next = NULL;
// 		addNode(list, newNode);
// 	} 
// 	if (makeList(t->right, list) != NULL) {
// 		Node newNode = malloc(sizeof(Node));
// 		newNode->value = t->value;
// 		newNode->next = NULL;
// 		addNode(list, newNode);
// 	}


// 	return list;
// }

// int getKth(BSTree t, int kth, int count);
// int getKth(BSTree t, int kth, int count) {
// 	if (t->left == NULL && t->right == NULL) {
// 		return t->value;
// 	}

// 	if (count == kth) {
// 		return t->value;
// 	}

// 	count++;
// 	if (t->left != NULL && t->right == NULL) {
// 		return getKth(t->left, kth, count);
// 	} else if (t->left == NULL && t->right != NULL) {
// 		return getKth(t->right, kth, count);
// 	} else {

// 	}
// }

int numNodes(BSTree t);
int numNodes(BSTree t) {
	if (t == NULL) {
		return 0;
	}

	return 1 + numNodes(t->left) + numNodes(t->right);
}

BSTree getKthNode(BSTree t, int k);
BSTree getKthNode(BSTree t, int k) {
	int size = numNodes(t->left);
	if (k == size) {
		return t;
	} else if (k < size) {
		return getKthNode(t->left, k);
	} else {
		return getKthNode(t->right, k - size - 1);
	}

	
	// if (t == NULL) {
	// 	return NULL;
	// }
	
	// if (count == k) {
	// 	return t;
	// }
	
	// BSTree L = getKthNode(t->left, k, count);
	// count--;
	// BSTree R = getKthNode(t->right, k, count);

	// if (L != NULL) {
	// 	return L;
	// } else {
	// 	return R;
	// }
}

int BSTreeGetKth(BSTree t, int k) {
	// return 43;
	return getKthNode(t, k)->value;
	// Node list = NULL;

	// list = makeList(t, list);

	// int kth;
	// int counter = 0;
	// for (Node curr = list; curr != NULL; curr = curr->next) {
	// 	if (counter == k) {
	// 		kth = curr->value;
	// 		break;
	// 	}
	// 	counter++;
	// }
	// printf("working 1\n");

	// Node curr = list;
	// while (curr != NULL) {
    //     Node tmp = curr->next;
    //     free(curr);
    //     curr = tmp;
    // }

	// return kth;
}

