
#include <stdlib.h>

#include "tree.h"

int findHeight(Tree t, int height);
int findHeight(Tree t, int height) {
    if (t->left == NULL && t->right == NULL) {
        return height;
    }
    
    if (t->left != NULL && t->right == NULL) {
        height++;
        return findHeight(t->left, height);

    } else if (t->left == NULL && t->right != NULL) {
        height++;
        return findHeight(t->right, height);

    } else {
        // Both children are not NULL
        height++;
        int L = findHeight(t->left, height);
        int R = findHeight(t->right, height);
        if (L > R) {
            return L;
        } else {
            return R;
        }
    } 
}

int TreeHeight(Tree t) {
    if (t == NULL) {
        return -1;
    }
    return findHeight(t, 0);
}

