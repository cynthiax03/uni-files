
#include "BSTree.h"

#include <stdlib.h>

BSTree findSmallest(BSTree t);
BSTree findSmallest(BSTree t) {
	if (t->left == NULL) {
		return t;
	}

	 return findSmallest(t->left);

}

BSTree BSTreeGetSmallest(BSTree t) {
	if (t == NULL) {
		return t;
	}
	return findSmallest(t);
}

