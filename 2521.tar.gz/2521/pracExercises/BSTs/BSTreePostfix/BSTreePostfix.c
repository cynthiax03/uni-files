
#include <stdio.h>

#include "BSTree.h"

void printInOrder(BSTree t);
void printInOrder(BSTree t) {
	if (t->left == NULL && t->right == NULL) {
		printf("%d ", t->value);
		return;
	}
	if (t->left != NULL && t->right == NULL) {
		printInOrder(t->left);
		printf("%d ", t->value);
	} else if (t->left == NULL && t->right != NULL) {
		printInOrder(t->right);
		printf("%d ", t->value);
	} else {
		// If both children are not NULL
		printInOrder(t->left);
		printInOrder(t->right);
		printf("%d ", t->value);
	}

}

void BSTreePostfix(BSTree t) {
	if (t == NULL) {
		return;
	}

	printInOrder(t);
}

