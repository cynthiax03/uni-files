// DFS maze solver

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Cell.h"
#include "helpers.h"
#include "Maze.h"
#include "Stack.h"

bool isValid(bool **visited, Cell c, Maze m);
void updateParent(Cell **parents, Cell c, Cell curr);

bool solve(Maze m) {
    // TODO: Complete this function
    //       Feel free to add helper functions
    
    // Get the start of the maze and set curr to start
    Cell start = MazeGetStart(m);
    Cell curr = start;

    // Create a visited matrix of the maze with all values set to 0
    bool **visited = createBoolMatrix(MazeHeight(m), MazeWidth(m));

    // Create a parent matrix that stores the parent of each cell
    Cell **parents = createCellMatrix(MazeHeight(m), MazeWidth(m));

    // Create new stack and push the start
    Stack s = StackNew();
    StackPush(s, curr);

    // While the finishing cell has not been visited and the stack is not 
    // empty
    while (MazeVisit(m, curr) != true && StackIsEmpty(s) != true) {
        // Pop first item (curr) and mark the cell as visited 
        curr = StackPop(s);
        visited[curr.row][curr.col] = true;

        
        // Check if the lower child is valid
        Cell lowerChild = {.row = curr.row + 1, .col = curr.col};
        if (isValid(visited, lowerChild, m)) {
            // Push left child to stack and add its parent if it doesn't already
            // have one
            StackPush(s, lowerChild);
            updateParent(parents, lowerChild, curr);
        } 
        // Check children of curr cell 
        // Check if the right child is valid
        Cell rightChild = {.row = curr.row, .col = curr.col + 1};
        if (isValid(visited, rightChild, m)) {
            // Push right child to stack and update its parent if it doesn't
            // already have a parent
            StackPush(s, rightChild);
            updateParent(parents, rightChild, curr);
        }

        // Check if the left child is valid
        Cell leftChild = {.row = curr.row, .col = curr.col - 1};
        if (isValid(visited, leftChild, m)) {
            // Push left child to stack and add its parent if it doesn't already
            // have one
            StackPush(s, leftChild);
            updateParent(parents, leftChild, curr);
        }

        // Check if the upper child is valid
        Cell upperChild = {.row = curr.row - 1, .col = curr.col};
        if (isValid(visited, upperChild, m)) {
            // Push upper child to stack and add its parent if it doesn't already
            // have one
            StackPush(s, upperChild);
            updateParent(parents, upperChild, curr);
        }  
    }

    // Check if there is a path, if there is a path MazeVisit will return true
    // as it has reached the destination from the start, if it returns false
    // this means all the cells have been visited but the destination couldn't
    // be reached
    bool found = MazeVisit(m, curr);

    // If there is a path, mark it with MazeMarkPath
    if (found) {
        // While the current cell isn't the starting cell, mark the path, going
        // to each cells parent until start is reached

        while (curr.row != start.row || curr.col != start.col) {
            MazeMarkPath(m, curr);
            curr = parents[curr.row][curr.col];
        }
        MazeMarkPath(m, curr);
        MazeMarkPath(m, start);
    }

    // Free s, visited and parents
    StackFree(s);
    freeBoolMatrix(visited);
    freeCellMatrix(parents);

    return found;
}

// Checks whether a given cell is a wall, has already been visited, or is out 
// of bounds, if it is any of those, it is invalid and the function returns 
// true, else the cell is valid and the function returns false
bool isValid(bool **visited, Cell c, Maze m) {
    // if the cell col is out of bounds
    if (c.col == MazeWidth(m) || c.col == -1) {
        return false;
    }

    // if the cell row is out of bounds
    if (c.row == MazeHeight(m) || c.row == -1) {
        return false;
    }

    // if the cell has been visited or is a wall
    if (visited[c.row][c.col] || MazeIsWall(m, c)) {
        return false;
    }

    // the cell is valid
    return true;
}

// Checks if a cell in the parents matrix already has a parent (there is a 
// quicker path), if there isn't already a parent, add the cell's parent
void updateParent(Cell **parents, Cell c, Cell curr) {
    // If there is already a parent
    if (parents[c.row][c.col].row != 0 || parents[c.row][c.col].col != 0) {
        return;
    }

    // Set new parent to be the current cell
    parents[c.row][c.col] = curr;
}
