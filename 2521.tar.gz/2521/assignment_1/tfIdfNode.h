// COMP2521 Assignment 1 - header file for tfIdfNode functions
// Xinyue Li (z5359629@ad.unsw.edu.au)
// Written March 2022

#ifndef TFIDF_SUM_H
#define TFIDF_SUM_H

#include "invertedIndex.h"

/**
 * Creates a TfIdfList node with filename and tfIdfSum. If the node is 
 * successfully created, return the node, if there is insufficient space return
 * NULL.
 */
TfIdfList tfIdfNodeCreate(char *filename, double tfIdfSum);

/**
 * Inserts a tfIdfNode in the middle of two given nodes.
 */
TfIdfList insertInMiddle(TfIdfList curr, TfIdfList n, TfIdfList next);

/**
 * Inserts a tfIdfList node into a tfIdfList. The list is ordered by descending
 * tfIdf sum values, if two nodes have the same tfIdf sum values, they will be 
 * in ascending alphabetical order.
 */
TfIdfList tfIdfNodeInsert(TfIdfList l, TfIdfList n);

/**
 * Searches through a TfIdfList for a node with the given filename, if it is 
 * found, return the node, if it is not found, return NULL.
 */
TfIdfList tfIdfNodeSearch(TfIdfList l, char *filename);

/**
 * Takes a given node that's tfIdfSum was just updated, removes it and 
 * reinserts it into the TfIdfList in the correct order
 */
void tfIdfNodeReinsert(TfIdfList l, TfIdfList node);

#endif