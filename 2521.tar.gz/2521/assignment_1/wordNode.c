// COMP2521 Assignment 1 - implementation file for wordNode functions
// Xinyue Li (z5359629@ad.unsw.edu.au)
// Written March 2022

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "wordNode.h"
#include "fileNode.h"
#include "invertedIndex.h"

// Creates a new node for the inverted index
InvertedIndexBST wordNodeCreate(char *word, char *filename, double wordCount) {
	// Create a new invertedIndex word node, if there is insufficient space,
	// end program
	InvertedIndexBST n = malloc(sizeof(*n));
	if (n == NULL) {
        fprintf(stderr, "error: out of memory\n");
        exit(EXIT_FAILURE);
    }

	// Set value for word and create new fileList with a node containing
	// filename
	n->word = malloc(strlen(word) + 1);
	strcpy(n->word, word);
	n->fileList = fileNodeCreate(filename, wordCount);
	n->left = NULL;
	n->right = NULL;
	return n;
}

// Searches tree to find if a node exists and returns if it does exist
InvertedIndexBST wordNodeSearch(InvertedIndexBST t, char *word) {
	// If t is NULL there is no nodes
	if (t == NULL) {
		return NULL;
	}

	// Compare word to the word in the current node
	int cmp = strcmp(word, t->word);

	if (cmp == 0) {
		// If the node containing the word is found, return it
		return t;
	} else if (cmp < 0) {
		// If the word is less than the current node word, search the left of the
		// tree and recurse
		return wordNodeSearch(t->left, word);
	} else {
		// If the word is more than the current node word, search the right of the
		// tree and recurse
		return wordNodeSearch(t->right, word);
	}
}

// Inserts a given node into an inverted index tree
InvertedIndexBST wordNodeInsert(InvertedIndexBST t, InvertedIndexBST n) {
	// If t has no nodes
	if (t == NULL) {
		return n;
	}

	// Compare the given node's word with the current node's word
	int cmp = strcmp(n->word, t->word);

	// If the word is less than the current word, it goes on the left of the
	// current node, recurse until it can be added
	if (cmp < 0) {
		t->left = wordNodeInsert(t->left, n);
	} else if (cmp > 0) {
		// If the word is more than the current word, it goes on the right of 
		// the current node, recurse until it can be added
		t->right = wordNodeInsert(t->right, n);
	}
	return t;
}

// Prints out InvertedIndex nodes
void wordNodePrint(FILE *fp, InvertedIndexBST t) {
	// If the tree is empty, nothing can be printed
	if (t == NULL) {
		return;
	}

	// Print the words with the lowest value first into the given file
	wordNodePrint(fp, t->left);
	fprintf(fp, "%s", t->word);

	// Loop through fileList and print out filenames and their tf values
	for (struct FileNode *curr = t->fileList; curr != NULL; curr = curr->next) {
		fprintf(fp, " %s (%.7lf)", curr->filename, curr->tf);
	}

	// Print a new line after the fileList has finished printing
	fprintf(fp, "\n");

	// Look at nodes on the right (larger values)
	wordNodePrint(fp, t->right);
}