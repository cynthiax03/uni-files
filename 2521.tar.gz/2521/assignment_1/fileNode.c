// COMP2521 Assignment 1 - implementation file for fileNode functions
// Xinyue Li (z5359629@ad.unsw.edu.au)
// Written March 2022

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "fileNode.h"
#include "invertedIndex.h"

// Creates a filelist node
FileList fileNodeCreate(char *filename, double wordCount) {
	// Create a new fileList node, if there is no space end program
	FileList f = malloc(sizeof(*f));
	if (f == NULL) {
        fprintf(stderr, "error: out of memory\n");
        exit(EXIT_FAILURE);
    }

	// Input filename and tf mallocing where needed
	f->filename = malloc(strlen(filename) + 1);
	strcpy(f->filename, filename);
	f->tf = 1 / wordCount;
	f->next = NULL;
	return f;
}

// Inserts a fileList node into the fileList 
void fileNodeInsert(InvertedIndexBST t, FileList n) {
	// If the node needs to be inserted at the start of the list (ie the 
	// filename is less than the first filename in the list)
	if (strcmp(t->fileList->filename, n->filename) > 0) {
		struct FileNode *temp = t->fileList;
		t->fileList = n;
		n->next = temp;
		return;
	}

	// If the node needs to be inserted last
	for (struct FileNode *curr = t->fileList; curr != NULL; curr = curr->next) {
		int cmpNext = strcmp(curr->filename, n->filename);
		// If the filename is greater than the last filename in the list
		if (curr->next == NULL && cmpNext < 0) {
			curr->next = n;
			return;
		}
	}

	// If the node needs to be inserted in the middle of the linked list
	for (struct FileNode *curr = t->fileList; curr->next != NULL; curr = curr->next) {
		int cmpPrev = strcmp(curr->filename, n->filename);
		int cmpNext = strcmp(curr->next->filename, n->filename);
		// If the curr filename is less than the given filename and the next
		// filename is greater, insert between these two nodes
		if (cmpPrev < 0 && cmpNext > 0) {
			struct FileNode *temp = curr->next;
			curr->next = n;
			n->next = temp;
			return; 
		}
	}
}

// Looks through a filelist to check if a certain file exists, if it does the
// file node is returned, if it does not exist return NULL
FileList fileNodeSearch(FileList f, char *filename) {
	// Iterate through the filelist
	for(struct FileNode *curr = f; curr != NULL; curr = curr->next) {
		// If the node containing th filename is found return the node
		if (strcmp(curr->filename, filename) == 0) {
			return curr;
		}
	}

	// If the file node is not found return NULL
	return NULL;
}

// updates the tf value in a file node where frequency of term t in d is 
// increased by 1
void fileNodeUpdateTf(FileList n, double wordCount) {
	// Find the frequency of the word
	double freq = n->tf * wordCount;
	// Add one to the frequency of the word
	freq++;
	// Find the new tf and replace old tf
	n->tf = freq / wordCount;
	return;
}

// Finds number of nodes in a fileList
int fileNodeCounter(FileList f) {
	int counter = 0;
	for (struct FileNode *curr = f; curr != NULL; curr = curr->next) {
		counter++;
	}
	return counter;
}