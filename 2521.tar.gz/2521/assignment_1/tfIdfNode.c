// COMP2521 Assignment 1 - implementation file for tfIdfNode functions
// Xinyue Li (z5359629@ad.unsw.edu.au)
// Written March 2022

#include <ctype.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "wordNode.h"
#include "fileNode.h"
#include "tfIdfNode.h"
#include "invertedIndex.h"

// Creates a TfIdfNode
TfIdfList tfIdfNodeCreate(char *filename, double tfIdfSum) {
	// Create a tfIdf node, if there is no memory, end program
    TfIdfList tfIdfNode = malloc(sizeof(*tfIdfNode));
	if (tfIdfNode == NULL) {
        fprintf(stderr, "error: out of memory\n");
        exit(EXIT_FAILURE);
    }
    
    // Malloc space for filename, set filename and tfIdfSUm
	tfIdfNode->filename = malloc(strlen(filename) + 1);
	strcpy(tfIdfNode->filename, filename);
	tfIdfNode->tfIdfSum = tfIdfSum;
	tfIdfNode->next = NULL;
	return tfIdfNode;
}

// Inserts a tfIdfNode in the middle of two other nodes
TfIdfList insertInMiddle(TfIdfList curr, TfIdfList n, TfIdfList next) {
	struct TfIdfNode *temp = next;
	curr->next = n;
	n->next = temp;
	return curr; 
}

// Inserts a tfIdfNode into a TfIdfList
TfIdfList tfIdfNodeInsert(TfIdfList l, TfIdfList n) {
	// If the list is empty
	if (l == NULL) {
		return n;
	}

	// If node needs to be inserted at the start of the list (the tfIdfSum is 
	// bigger than the first tfIdfSum or the sum is equal to the first sum but
	// the filename is less than the first filename)
	if ((n->tfIdfSum > l->tfIdfSum) || 
		(n->tfIdfSum == l->tfIdfSum && strcmp(n->filename, l->filename) < 0)) {
		n->next = l;
		l = n;
		return l;
	}

	// If node needs to be inserted into the middle of the list
	for (struct TfIdfNode *curr = l; curr->next != NULL; curr = curr->next) {
		// If the sum is less than curr sum but bigger than next sum
		if (n->tfIdfSum < curr->tfIdfSum && n->tfIdfSum > curr->next->tfIdfSum) {
			curr = insertInMiddle(curr, n, curr->next);
			return l; 
		}

		int cmpPrev = strcmp(curr->filename, n->filename);
		int cmpNext = strcmp(curr->next->filename, n->filename);
		// If the tfIdfSum of n, curr, and curr->next are all equal but the 
		// filename of n is greater than curr but less than curr->next
		if ((curr->tfIdfSum == n->tfIdfSum && n->tfIdfSum == curr->next->tfIdfSum) &&
			(cmpPrev < 0 && cmpNext > 0)) {
			curr = insertInMiddle(curr, n, curr->next);
			return l; 
		}

		// If the sum of curr and n are equal, curr filename is less than
		// filename and the sum of curr->next is less than sum
		if ((curr->tfIdfSum == n->tfIdfSum && cmpPrev < 0) && curr->next->tfIdfSum < n->tfIdfSum) {
			curr = insertInMiddle(curr, n, curr->next);
			return l; 
		}
	}

	// If node needs to be inserted at the end of the list
	for (struct TfIdfNode *curr = l; curr != NULL; curr = curr->next) {
		// Loop to the end of the list
		if (curr->next == NULL) {
			// If the sum of n is less than the sum of the last node or if the
			// sum of n and sum of last node are equal and the filename of the
			// last node is greater than filename
			if ((n->tfIdfSum < curr->tfIdfSum) ||
				(n->tfIdfSum == l->tfIdfSum && strcmp(n->filename, curr->filename) > 0)) {
				curr->next = n;
				return l;
			}
		}
	}
	return l;
}

// Searches a TfIdfList for a node containing filename
TfIdfList tfIdfNodeSearch(TfIdfList l, char *filename) {
	// Check if the list is NULL
	if (l == NULL) {
		return NULL;
	}
	
	// Check if there is a node with that filename
	for (struct TfIdfNode *curr = l; curr != NULL; curr = curr->next) {
		if (strcmp(curr->filename, filename) == 0) {
			return curr;
		}
	}

	// If the node doesn't exist, return NULL
	return NULL;
}

// Removes node and reinserts it as it may be out of order
void tfIdfNodeReinsert(TfIdfList l, TfIdfList node) {
	// Check if the node to be removed is the first node
	if (strcmp(l->filename, node->filename) == 0) {  
		// Check if there is another element in the list, if there isn't, return
		if (l->next == NULL) {
			return;
		} else {
			// If there is more than one element in the list, remove first 
			// element and add it into the list again
			l = node->next;
			node->next = NULL;
			tfIdfNodeInsert(l, node);
			return;
		}
	}
    
	// If the node to be removed is the last node, remove node and reinsert
	for (struct TfIdfNode *curr = l; curr->next != NULL; curr = curr->next) {
		if (curr->next->next == NULL && 
			strcmp(curr->next->filename, node->filename) == 0) {
			struct TfIdfNode *tmp = curr->next;
			curr->next = NULL;
			tfIdfNodeInsert(l, tmp);
			return;
		}
	}
	
	// If the node is in the middle of the list, remove node and reinsert
	for (struct TfIdfNode *curr = l; curr->next != NULL; curr = curr->next) {
		if (curr->next->filename == node->filename) {
			struct TfIdfNode *tmp = curr->next;
			curr->next = curr->next->next;
			tmp->next = NULL;
			tfIdfNodeInsert(l, tmp);
			return;
		}
	}
}