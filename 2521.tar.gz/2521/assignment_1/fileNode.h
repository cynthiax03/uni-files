// COMP2521 Assignemnt 1 - header file for fileNode functions
// Xinyue Li (z5359629@ad.unsw.edu.au)
// Written March 2022

#ifndef FILE_NODE_H
#define FILE_NODE_H

#include "invertedIndex.h"

/**
 * Creates a new filelist node with filename and calculates its tf value 
 * (frequency of term t in d / number of words in d). Returns the filenode
 * if it was created.
 */
 FileList fileNodeCreate(char *filename, double wordCount);


/**
 * Takes a filelist node and inserts it into a given filelist in alphabetical
 * order (ascending) determined by strcmp. Takes into account inserting at the
 * start, end and middle of the list.
 */
void fileNodeInsert(InvertedIndexBST t, FileList n);

/**
 * Looks through a fileList to check if a certain node with the filename exists
 * if the file node exists, return it, if it does not exist return NULL
 */
FileList fileNodeSearch(FileList f, char *filename);

/**
 * Takes a filelist node and updates its tf by adding one to the frequency of d
 * then dividing by number of words in d
 */
void fileNodeUpdateTf(FileList n, double wordCount);

/**
 * Takes a filelist and counts the number of nodes in it
 */
int fileNodeCounter(FileList f);

#endif

