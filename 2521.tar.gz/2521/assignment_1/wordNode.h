// COMP2521 Assignment 1 - header file for wordNode functions
// Xinyue Li (z5359629@ad.unsw.edu.au)
// Written March 2022

#ifndef WORD_NODE_H
#define WORD_NODE_H

#include "invertedIndex.h"

/**
 * Creates a new inverted index node containing the word and filelist
 * containing filename. Returns the new node if it can be created.
 */
 InvertedIndexBST wordNodeCreate(char *word, char *filename, double wordCount);

/**
 * Searches an inverted index to see if a certain node containing a word exists
 * if it does, the word node will be returned, if it does not exist in the
 * inverted index, return NULL.
 */
 InvertedIndexBST wordNodeSearch(InvertedIndexBST t, char *word);

/**
 * Inserts a given inverted index node into an inverted index in alphabetical 
 * order (ascending) determined by strcmp. Returns the new inverted index.
 */
 InvertedIndexBST wordNodeInsert(InvertedIndexBST t, InvertedIndexBST n);

/**
 * Prints InvertedIndex nodes in order as well as all the files in their 
 * fileLists including tf values into a file pointed to by fp.
 */
 void wordNodePrint(FILE *fp, InvertedIndexBST t);

#endif