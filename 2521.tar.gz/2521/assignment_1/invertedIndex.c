// COMP2521 Assignment 1

#include <assert.h>
#include <ctype.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "invertedIndex.h"
#include "fileNode.h"
#include "wordNode.h"
#include "tfIdfNode.h"

///////////////////////////////////////////////////////////////////////////////
// Helper function declarations
static bool isWordValid(char *word, int len);
static char *normaliseWord(char *word, int origLen);
static int fileWordCounter(FILE *ptr);
static InvertedIndexBST fileReader(InvertedIndexBST tree, char *filename);

///////////////////////////////////////////////////////////////////////////////
// Part 1

InvertedIndexBST generateInvertedIndex(char *collectionFilename) {
	// Create the tree but set it to NULL
	InvertedIndexBST tree = NULL;

	// Make filepointer and string that will store filenames
	FILE *fp;
   	char fileName[100];

	// Open collection file to read
	fp = fopen(collectionFilename, "r");

	// Checks if file does not exist in the directory and ends program
	if (fp == NULL) {
        fprintf(stderr, "file does not exist\n");
        exit(EXIT_FAILURE);
    }
	
	// Loops through all filenames in collectionfile
	while (fscanf (fp, "%s", fileName) != EOF) {

		// Passes filename to filereader
		tree = fileReader(tree, fileName);
		
	}

	fclose(fp);
	return tree;
}

void printInvertedIndex(InvertedIndexBST tree, char *filename) {
	
	// Create a file pointer to a file and open for writing
	FILE *fp;
	fp = fopen(filename, "w");

	// If the file does not exist, exit program
	if (fp == NULL) {
		fprintf(stderr, "File does not exist\n");
		exit(1);
	}

	// Print invertedIndex nodes in order
	wordNodePrint(fp, tree);

	fclose(fp);
}

void freeInvertedIndex(InvertedIndexBST tree) {
	// Base case
	if (tree == NULL) {
		return;
	}

	// free left then right nodes
	freeInvertedIndex(tree->left);
	freeInvertedIndex(tree->right);

	// free all nodes in fileList
	struct FileNode *curr = tree->fileList;
	while (curr != NULL) {
		struct FileNode *tmp = curr->next;
		free(curr->filename);
		free(curr);
		curr = tmp; 
	}
	
	// Free the word in the node then the node
	free(tree->word);
	free(tree);
}

///////////////////////////////////////////////////////////////////////////////
// Part 2

TfIdfList searchOne(InvertedIndexBST tree, char *searchWord, int D) {
	TfIdfList l = NULL;
	
	// Find the inverted index node for the searchWord
	InvertedIndexBST wordNode = wordNodeSearch(tree, searchWord);

	// If the word does not exist in any of the files, return NULL
	if (wordNode == NULL) {
		return NULL;
	}

	// Find number of docs that contain the term
	int nDocs = fileNodeCounter(wordNode->fileList);
	
	// Loop through fileNodes in the fileList
	double tfidf;
	for (struct FileNode *curr = wordNode->fileList; curr != NULL; curr = curr->next) {

		// Calculate tfidf
		tfidf = log10((double)D / (double)nDocs) * curr->tf;

		// Create the new tfIdfNode and insert into the list in the correct 
		// order
		TfIdfList newNode = tfIdfNodeCreate(curr->filename, tfidf);
		l = tfIdfNodeInsert(l, newNode);
	}
	return l;
}

TfIdfList searchMany(InvertedIndexBST tree, char *searchWords[], int D) {
	TfIdfList l = NULL;

	// Iterate through the string array containing searchWords
	for (int i = 0; searchWords[i] != NULL; i++) {
		// Find the inverted index node for the searchWord
		InvertedIndexBST wordNode = wordNodeSearch(tree, searchWords[i]);

		// If the word does not exist in any files, continue to the next word 
		// in the array
		if (wordNode == NULL) {
			continue;
		}
		
		// Find number of docs that contain the term
		int nDocs = fileNodeCounter(wordNode->fileList);

		// Loop through fileNodes in the fileList
		double tfidf;
		for (struct FileNode *curr = wordNode->fileList; curr != NULL; curr = curr->next) {
			// Calculate the tfidf for the current word node
			tfidf = log10((double)D / (double)nDocs) * curr->tf;

			// Find the TfIdfNode if it exists
			TfIdfList TfIdfNode = tfIdfNodeSearch(l, curr->filename);

			// If it doesn't exist
			if (TfIdfNode == NULL) {
				// Create a node, insert into the list in the correct oder
				TfIdfNode = tfIdfNodeCreate(curr->filename, tfidf);
				l = tfIdfNodeInsert(l, TfIdfNode);
			} else {
				// If it does exist, update the current node and rearrange list
				TfIdfNode->tfIdfSum += tfidf;
				tfIdfNodeReinsert(l, TfIdfNode);
			}
		}
	}
	return l;
}

void freeTfIdfList(TfIdfList list) {
	struct TfIdfNode *curr = list;
	while (curr != NULL) {
		struct TfIdfNode *tmp = curr->next;
		free(curr->filename);
		free(curr);
		curr = tmp; 
	}
}

///////////////////////////////////////////////////////////////////////////////
// Helper functions

// Checks if a given word is valid
static bool isWordValid(char *word, int len) {
	if (len == 1) {
		char letter = word[0];
		if (letter == '.' || letter == ',' || letter == ':' || letter == ';' ||
			letter == '?' || letter == '*') {
			return false;
		}
	}
	return true;
}

// Normalises a given word
static char *normaliseWord(char *word, int origLen) {
	
	// Convert each letter in the str to lowercase
	for(int i = 0; i < strlen(word); i++) {
		word[i] = tolower(word[i]);
	}

	// Find the end of the str
	char end = word[strlen(word) - 1];

	// If the word is not valid return NULL;
	if (!isWordValid(word, origLen)) {
		return NULL;
	}

	// If the end char is a punctuation mark, remove it and recurse
	if (end == '.' || end == ',' || end == ':' || end == ';' ||
		end == '?' || end == '*') {
		word[strlen(word) - 1] = '\0';
		normaliseWord(word, strlen(word));
	}
	return word;
}

// Counts the number of valid words in a file
static int fileWordCounter(FILE *ptr) {
	int counter = 0;
	char word[100];
	while (fscanf(ptr, "%s", word) == 1) {
		if(isWordValid(word, strlen(word))) {
			counter++;
		}
	}
	return counter;
}

// Reads each file for words
static InvertedIndexBST fileReader(InvertedIndexBST tree, char *filename) {
	
	// Create a filepointer and a word buffer
	FILE *subFp;
	char word[100];
	
	// Open subfile for reading
	subFp = fopen(filename, "r");
	
	// If the sub file does not exist, exit program
	if (subFp == NULL) {
		fprintf(stderr, "File does not exist\n");
		return NULL;
	}

	// Find number of words in the file
	double wordCount = fileWordCounter(subFp);
	
	// Reset file pointer to top of file
	fseek(subFp, 0, SEEK_SET);

	// Look through each word in the file 
	while (fscanf(subFp, "%s", word) == 1) {
		// If word is empty after removing punctuation it does not count as a
		// word so we continue to next iteration
		if (normaliseWord(word, strlen(word)) == NULL) {
			continue;
		}
		
		// Checks if node for word already exists
		InvertedIndexBST node = wordNodeSearch(tree, word);
		
		if (node == NULL) {
			// Create new node for the word and insert it into the tree in the
			// correct order
			node = wordNodeCreate(word, filename, wordCount);
			tree = wordNodeInsert(tree, node);
		} else {
			// If the node for the word already exists, check if the file is
			// already in the file list
			FileList fileNode = fileNodeSearch(node->fileList, filename);
			
			if (fileNode == NULL) {
				// Create a new node for the file and insert into the filelist
				fileNode  = fileNodeCreate(filename, wordCount);
				fileNodeInsert(node, fileNode);
			} else {
				// If the fileNode already exists, update the tf
				fileNodeUpdateTf(fileNode, wordCount);
			}
		}
	}

	fclose(subFp);
	return tree;
}