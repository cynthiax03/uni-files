// z5359629
// prints sign, exponent and fraction of a float 
// Extract the 3 parts of a float using bit operations only

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>

#include "floats.h"

#define EXPONENT_MASK 0x7F800000
#define FRACTION_MASK 0x007FFFFF


// separate out the 3 components of a float
float_components_t float_bits(uint32_t f) {
    // PUT YOUR CODE HERE
    
    // Create a float_components_t struct called internals
    float_components_t internals;
    internals.sign = 0;
    internals.exponent = 0;
    internals.fraction = 0;    
    
    // Find the sign 
    uint32_t value = f >> 31;
    uint32_t mask = 1;
    internals.sign = value & mask;
    
    // Find the exponent
    internals.exponent = (EXPONENT_MASK & f) >> 23;
    
    // Find the fraction
    internals.fraction = (FRACTION_MASK & f);
    
    return internals;
}

// given the 3 components of a float
// return 1 if it is NaN, 0 otherwise
int is_nan(float_components_t f) {
    // PUT YOUR CODE HERE
    
    // Find number of ones in exponent
    int exponent_compare = 0;
    if (f.exponent == 0xFF) {
        exponent_compare = 1;
    }
    
    // Find number of ones in fraction 
    int fraction_compare = 0;
    if (f.fraction != 0x000000) {
        fraction_compare = 1;
    }
    
    if (exponent_compare == 1 && fraction_compare == 1) {
        return 1;
    } else {
        return 0;
    }
}

// given the 3 components of a float
// return 1 if it is inf, 0 otherwise
int is_positive_infinity(float_components_t f) {
    // PUT YOUR CODE HERE
    
    // Test if exponent is all 1s
    int exponent_compare = 0;
    if (f.exponent == 0xFF) {
        exponent_compare = 1;
    }
    
    
    // Test if fraction is all 0s 
    int fraction_compare = 0;
    if (f.fraction == 0x000000) {
        fraction_compare = 1;
    }
    
    if (f.sign == 0 && exponent_compare == 1 && fraction_compare == 1) {
        return 1;
    } else {
        return 0;
    }
}

// given the 3 components of a float
// return 1 if it is -inf, 0 otherwise
int is_negative_infinity(float_components_t f) {
    // PUT YOUR CODE HERE
    
    // Test if exponent is all 1s
    int exponent_compare = 0;
    if (f.exponent == 0xFF) {
        exponent_compare = 1;
    }
    
    
    // Test if fraction is all 0s 
    int fraction_compare = 0;
    if (f.fraction == 0x000000) {
        fraction_compare = 1;
    }
    
    if (f.sign == 1 && exponent_compare == 1 && fraction_compare == 1) {
        return 1;
    } else {
        return 0;
    }
}

// given the 3 components of a float
// return 1 if it is 0 or -0, 0 otherwise
int is_zero(float_components_t f) {
    // PUT YOUR CODE HERE
    
    // Test if exponent is all 0s
    int exponent_compare = 0;
    if (f.exponent == 0x00) {
        exponent_compare++;
    }
    
    
    // Test if fraction is all 0s
    int fraction_compare = 0;
    if (f.fraction == 0x000000) {
        fraction_compare++;
    }
    
    if (exponent_compare == 1 && fraction_compare == 1) {
        return 1;
    } else {
        return 0;
    }
}
