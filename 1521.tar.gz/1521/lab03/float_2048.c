// z5359629
// COMP1521 2021T2
// Multiply a float by 2048 using bit operations only

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>

#include "floats.h"

#define EXPONENT_MASK 0x7F800000
#define FRACTION_MASK 0x007FFFFF
#define INF 0x7f800000
#define MINUS_INF 0xff800000
#define ZERO 0x0
#define MINUS_ZERO 0x80000000

// float_2048 is given the bits of a float f as a uint32_t
// it uses bit operations and + to calculate f * 2048
// and returns the bits of this value as a uint32_t
//
// if the result is too large to be represented as a float +inf or -inf is returned
//
// if f is +0, -0, +inf or -inf, or Nan it is returned unchanged
//
// float_2048 assumes f is not a denormal number
    


uint32_t float_2048(uint32_t f) {
    // PUT YOUR CODE HERE
    
    // Create a float_components_t struct called internals
    float_components_t internals;
    internals.sign = 0;
    internals.exponent = 0;
    internals.fraction = 0;    
    
    // Find the sign 
    uint32_t value = f >> 31;
    uint32_t mask = 1;
    internals.sign = value & mask;
    
    // Find the exponent
    internals.exponent = (EXPONENT_MASK & f) >> 23;
    
    // Find the fraction
    internals.fraction = (FRACTION_MASK & f);
    
    if (f == INF) {
        return INF;
    }
    
    if (f == MINUS_INF) {
        return MINUS_INF;
    }
    
    if (f == ZERO) {
        return ZERO;
    }
    
    if (f == MINUS_ZERO) {
        return MINUS_ZERO;
    }
    
    if (internals.exponent == 0xFF && internals.fraction != 0x000000) {
        return f;
    } 
        
    if (internals.exponent > 0xF4 && internals.fraction > 0x1) {
        if (internals.sign == 1) {
            return MINUS_INF;
        }
        if (internals.sign == 0) {
            return INF;
        }
    }
    
    // Adding 11 to the exponent is the same as multiplying by 2048
    internals.exponent += 11;
    
    uint32_t sign = internals.sign << 31;
    uint32_t exp = internals.exponent << 23;
    uint32_t value_x = (sign | exp) | internals.fraction;
    
    return value_x;
}

