#include <assert.h>
#include <stdint.h>
#include <stdlib.h>



// given a uint32_t value,
// return 1 iff the least significant (bottom) byte
// is equal to the 2nd least significant byte; and
// return 0 otherwise
int practice_q2(uint32_t value) {
    // PUT YOUR CODE HERE
    uint32_t LSB = value & 0x1
    uint32_t LSB2 = (value >> 1) & 0x1
    
    if (LSB == LSB2) {
        return 1;
    }
    return 0;
}

