#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ONE_BYTE 0x0
#define ONE_BYTE_MASK 0x80
#define TWO_BYTE_MASK 0xE0
#define TWO_BYTES 0xC0
#define THREE_BYTE_MASK 0xF0
#define THREE_BYTES 0xE0
#define FOUR_BYTE_MASK 0xF8
#define FOUR_BYTES 0xF0
#define NEXT_BYTE_MASK 0xC0
#define NEXT_BYTE 0x80

int main(int argc, char *argv[]) {
    char *filename = argv[1];
    FILE *file = fopen(filename, "r");
    int byte = fgetc(file);
    int number_of_utf8 = 0;
    while (byte != EOF) {
        // if ascii UTF-8
        if ((byte & ONE_BYTE_MASK) == ONE_BYTE) {
            number_of_utf8++;
            // read next byte
            byte = fgetc(file);
        } else if ((byte & TWO_BYTE_MASK) == TWO_BYTES) {
            // check whether it is a valid UTF8
            byte = fgetc(file);
            // if the second byte is valid
            if ((byte & NEXT_BYTE_MASK) == NEXT_BYTE) {
                number_of_utf8++;
                byte = fgetc(file);
            } else {
                // if the second byte is not valid
                printf("%s: invalid UTF-8 after %d valid UTF-8 characters\n", filename, number_of_utf8);
                fclose(file);
                return 0;
            }
            
        } else if ((byte & THREE_BYTE_MASK) == THREE_BYTES) {
            // check whether second byte is valid
            byte = fgetc(file);
            if ((byte & NEXT_BYTE_MASK) == NEXT_BYTE) {
                // check whether third byte is valid
                byte = fgetc(file);
                if ((byte & NEXT_BYTE_MASK) == NEXT_BYTE) {
                    // the UTF8 is valid
                    number_of_utf8++;
                    byte = fgetc(file);
                } else {
                    // if third byte is invalid
                    printf("%s: invalid UTF-8 after %d valid UTF-8 characters\n", filename, number_of_utf8);
                    fclose(file);
                    return 0;
                } 
            } else {
                // if second byte is invalid
                printf("%s: invalid UTF-8 after %d valid UTF-8 characters\n", filename, number_of_utf8);
                fclose(file);
                return 0;
            }
        } else if((byte & FOUR_BYTE_MASK) == FOUR_BYTES) {
            // check if second byte is valid
            byte = fgetc(file);
            // if second byte is valid
            if ((byte & NEXT_BYTE_MASK) == NEXT_BYTE) {
                // check if third byte is valid
                byte = fgetc(file);
                // if third byte is valid
                if ((byte & NEXT_BYTE_MASK) == NEXT_BYTE) {
                    // check if fourth byte is valid
                    byte = fgetc(file);
                    // if fourth byte is valid
                    if ((byte & NEXT_BYTE_MASK) == NEXT_BYTE) {
                        number_of_utf8++;
                        byte = fgetc(file);
                    } else {
                        // fourth byte is invalid
                        printf("%s: invalid UTF-8 after %d valid UTF-8 characters\n", filename, number_of_utf8);
                        fclose(file);
                        return 0; 
                    }
                } else {
                    // if third byte is invalid
                    printf("%s: invalid UTF-8 after %d valid UTF-8 characters\n", filename, number_of_utf8);
                    fclose(file);
                    return 0;
                }
            } else {
                // if second byte is invalid
                printf("%s: invalid UTF-8 after %d valid UTF-8 characters\n", filename, number_of_utf8);
                fclose(file);
                return 0;
            }
            
        }
    }
    
    printf("%s: %d UTF-8 characters\n", filename, number_of_utf8);
    fclose(file);
    return 0;
}

