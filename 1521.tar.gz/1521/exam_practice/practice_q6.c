#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char *filename = argv[1];
    FILE *file = fopen(filename, "r");
    int byte = fgetc(file);
    int ascii_counter = 0;
    while (byte != EOF) {
        if (byte >= 0 && byte <= 127) {
            ascii_counter++;
        }
        byte = fgetc(file);
    }   

    printf("%s contains %d ASCII bytes\n", filename, ascii_counter);
    fclose(file);
    return 0;
}
