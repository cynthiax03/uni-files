// COMP1521 21T2 ... final exam, question 9

#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "final_q8.h"
#include "final_q8_opcodes.h"

#define SPEC_MASK 0xFC000000
#define MASK 0x00000020
#define MASK2 0x80000000
#define ADDI 0x20000000
#define ADDIU 0x24000000
#define S_MASK 0x03E00000
#define T_MASK 0x001F0000
#define D_MASK 0x0000F800
#define IMM_MASK 0x0000FFFF
#define BASE_MASK 0x03E00000
#define SPEC_INSTR_MASK 0x0000003f
#define INSTR_MASK 0xF3000000
#define LW 0xA0000000
#define LB 0x80000000
#define ADD 0x00000020
#define ADDU 0x00000021
#define SUB 0x00000022
#define SUBU 0x00000023

#define TRUE 1
#define FALSE 0

Instruction
decode_instruction (Word insn_word)
{
	Instruction i = { .op = "[unknown]" };
	
	// if special
	if ((insn_word & SPEC_MASK) == 0) {
	    i.uses_rs = TRUE;
	    i.uses_rd = TRUE;
	    i.uses_rt = TRUE;
	    i.uses_base = FALSE;
	    i.uses_imm = FALSE;
	    i.rs = (insn_word & S_MASK) >> 21;
	    i.rt = (insn_word & T_MASK) >> 16;
	    i.rd = (insn_word & D_MASK) >> 11;
	    if ((insn_word & SPEC_INSTR_MASK) == ADD) {
	        i.op[] = "add";
	    } else if ((insn_word & SPEC_INSTR_MASK) == ADDU) {
	        i.op[] = "addu";
	    } else if ((insn_word & SPEC_INSTR_MASK) == SUB) {
	        i.op[] = "sub";
	    } else if ((insn_word & SPEC_INSTR_MASK) == SUBU) {
	        i.op[] = "subu";
	    }
	    
	} else {
	    // if not special
	    // if addi or addiu
	    if ((insn_word & SPEC_MASK) == ADDI || ((insn_word & SPEC_MASK) == ADDIU)) {
	        i.uses_rs = TRUE;
	        i.uses_rt = TRUE;
	        i.uses_imm = TRUE;
	        i.uses_rd = FALSE;
	        i.uses_base = FALSE;
	        i.rs = (insn_word & S_MASK) >> 21;
	        i.rt = (insn_word & T_MASK) >> 16;
	        i.imm = (insn_word & IMM_MASK);
	    } else {
	        // is lw or lb
	        i.uses_base = TRUE;
	        i.uses_rt = TRUE;
	        i.uses_rs = FALSE;
	        i.uses_rd = FALSE;
	        i.uses_imm = FALSE;
	        i.rt = (insn_word & T_MASK) >> 16;
	        i.base = (insn_word & BASE_MASK) >> 21;
	        
	    }
	    
	    if ((insn_word & INSTR_MASK) == LW) {
	        i.op[] = "lw";
	    } else if ((insn_word & INSTR_MASK) == LB) {
	        i.op[] = "lb";
	    } else if ((insn_word & INSTR_MASK) == ADDI) {
	        i.op[] = "addi";
	    } else if ((insn_word & INSTR_MASK) == ADDIU) {
	        i.op[] = "addiu";
	    }
	    
	}
	
	

	/// TODO: complete this function.
    
	return i;
}
