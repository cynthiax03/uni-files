// COMP1521 21T2 ... final exam, question 0

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define MASK 0x80000000

int
count_leading_zeroes (uint32_t x)
{
	int counter = 0;
	for (int i = 0; i < 32; i++) {
	    uint32_t check = (x << i) & MASK;
	    if (check == 0) {
	        counter++;
	    } else {
	        i = 32;
	    }
	}
	return counter;
}

