// COMP1521 21T2 ... final exam, question 3

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

void
cp (char *path_from, char *path_to)
{
	FILE *old = fopen(path_from, "r");
	FILE *new = fopen(path_to, "w");
	
	int byte = fgetc(old);
	while (byte != EOF) {
	    putc(byte, new);
	    byte = fgetc(old);
	}
	
	fclose(old);
	fclose(new);
}

