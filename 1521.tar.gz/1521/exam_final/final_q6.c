// COMP1521 21T2 ... final exam, question 6

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define ADDR_SIZE 8
#define ADDR_MASK 0xFF

void
convert_hexdump_to_bytes (FILE *hexdump_input, FILE *byte_output)
{
	char curr_address;
	int i = 0;
	
	// find number of lines in hexdump
	fseek(hexdump_input, 0, SEEK_END);
	long size = ftell(hexdump_input);
	fseek(hexdump_input, 0, SEEK_SET);
	
	// find 1st address
    fscanf(hexdump_input, "%c", &curr_address);
    char address;
    long smallest_loc = 0;	
	
	for (int j = 0; (j * 0x10) < size; j++) {
	    while(fseek(hexdump_input, i, SEEK_SET) == 0) {
	        // find the smallest_adress        
            fscanf(hexdump_input, "%c", &address);  
            if (atoi(address) < atoi(curr_address)) {
                curr_address = address;
                smallest_loc = ftell(hexdump_input);
            }
            i+=0x10;
	    }
	    // seek to the smallest address
	    fseek(hexdump_input, smallest_loc, SEEK_SET);
	    for (int k = 0; k < 32; k++) {
	        char data;
	        fscanf(hexdump_input, "%c", &data);
	        fprintf(byte_output, "%c", data);
	    }
	}
	
	
	
	// TODO
	// Hint: `man 3 fscanf`
	// Hint: `man 3 fseek`
	// Hint: See question text for
	//        third hint.
}
