// COMP1521 21T2 ... final exam, question 5

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#define ONE_BYTE 0x0
#define ONE_BYTE_MASK 0x80
#define TWO_BYTE_MASK 0xE0
#define TWO_BYTES 0xC0
#define THREE_BYTE_MASK 0xF0
#define THREE_BYTES 0xE0
#define FOUR_BYTE_MASK 0xF8
#define FOUR_BYTES 0xF0

void
print_utf8_count (FILE *file)
{
	unsigned long amount_1_byte = 0;
	unsigned long amount_2_byte = 0;
	unsigned long amount_3_byte = 0;
	unsigned long amount_4_byte = 0;

	int byte = fgetc(file);
	while(byte != EOF) {
	    if ((byte & ONE_BYTE_MASK) == ONE_BYTE) {
	        amount_1_byte++;
	        byte = fgetc(file);
	    } else if ((byte & TWO_BYTE_MASK) == TWO_BYTES) {
	        amount_2_byte++;
	        byte = fgetc(file);
	        byte = fgetc(file);
	    } else if ((byte & THREE_BYTE_MASK) == THREE_BYTES) {
	        amount_3_byte++;
	        byte = fgetc(file);
	        byte = fgetc(file);
	        byte = fgetc(file);
	    } else if ((byte & FOUR_BYTE_MASK) == FOUR_BYTES) {
	        amount_4_byte++;
	        byte = fgetc(file);
	        byte = fgetc(file);
	        byte = fgetc(file);
	        byte = fgetc(file);
	    }
	}

	printf("1-byte UTF-8 characters: %lu\n", amount_1_byte);
	printf("2-byte UTF-8 characters: %lu\n", amount_2_byte);
	printf("3-byte UTF-8 characters: %lu\n", amount_3_byte);
	printf("4-byte UTF-8 characters: %lu\n", amount_4_byte);
}
