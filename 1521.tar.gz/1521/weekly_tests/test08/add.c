#include <stdio.h>
#include <stdint.h>
#include <assert.h>

#include "add.h"

// return the MIPS opcode for add $d, $s, $t
uint32_t make_add(uint32_t d, uint32_t s, uint32_t t) {
    uint32_t ret = 0x00000000 | (s << 21);
    ret = ret | (t << 16);
    ret = ret | (d << 11);
    ret = ret | 0x020;
    
    return ret; // REPLACE WITH YOUR CODE

}
