#include <sys/types.h>

#include <sys/stat.h>

#include <assert.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdio.h>

int main (int argc, char *argv[]) {
    char *string = getenv(argv[1]);
    
    if(string == NULL) {
        printf("0\n");
    } else if (strcmp(string, "") == 0) {
        printf("0\n");
    } else {
        printf("1\n");
    }
    
    return 0;
}
