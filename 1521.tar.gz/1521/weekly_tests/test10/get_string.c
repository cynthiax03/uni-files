#include <stdio.h>

#include "get_string.h"

// print a line from stream using fgetc (only)
// reads  in at  most one less than size characters from stream and stores them into the
// buffer pointed to by s.  Reading stops after an EOF or a newline.  If a newline is read, it  is
// stored  into  the buffer.  A terminating null byte ('\0') is stored after the last character in the buffer.
void get_string(char *s, int size, FILE *stream) {
    for (int i = 0; i < (size - 1); i++) {
        s[i] = fgetc(stream);
        if (s[i] == '\n') {
            s[i + 1] = '\0';
            i = size;
        } else if (s[i] == '\0') {
            i = size;
        }
        
        if ((i + 1) == (size - 1)) {
            s[i + 1] = '\0';
        }
    }
   
    // case for if size = 1
    if (size == 1) {
        s[0] = '\0';
    }
    
    
    // PUT YOUR CODE HERE
    
}
