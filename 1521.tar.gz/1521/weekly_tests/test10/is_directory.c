#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    char *pathname = argv[1];
    
    // if success, print 1
    if (chdir(pathname) == 0) {
        printf("1\n");
    } else {
        printf("0\n");
    }
    
    return 0;
}
