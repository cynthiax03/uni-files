#include <stdio.h>

#include "put_string.h"

// print s to stdout with a new line appended using fputc (only)

void put_string(char *s) { 
    if (s[0] == '\0') {
        fputc('\n', stdout);
        return;
    }
    
    int size = sizeof(s);
    for (int i = 0; i < size; i++) {
        if (s[i] != '\0' && s[i] != '\n') {
            putc(s[i], stdout);
        } 
        
        if (s[i + 1] == '\0') {
            i = size;
        }
    }
    
    
    int new_line = '\n';
    fputc(new_line, stdout);
    
   // PUT YOUR CODE HERE

}
