#include "bit_rotate.h"
#include <stdio.h>

#define N_BITS 16

// return the value bits rotated left n_rotations
uint16_t bit_rotate(int n_rotations, uint16_t bits) {

uint16_t rotated_bits = bits;    
if (n_rotations > 0) {
    for (int i = 0; i < n_rotations; i++) {
        uint16_t value = (rotated_bits >> 15) & 1;
        rotated_bits = rotated_bits << 1;
        rotated_bits = rotated_bits | value;
    }
} else {
    for (int i = n_rotations; i < 0; i++) {
        uint16_t value = (rotated_bits << 15) & 0x8000;
        rotated_bits = rotated_bits >> 1;
        rotated_bits = rotated_bits | value;
    }
}
    
    
    return rotated_bits; //REPLACE ME WITH YOUR CODE
}
