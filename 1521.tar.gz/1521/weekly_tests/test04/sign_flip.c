#include "sign_flip.h"
#include <stdio.h>

// given the 32 bits of a float return it with its sign flipped
uint32_t sign_flip(uint32_t f) {
    uint32_t sign = (f >> 31) & 1;
    
    if (sign == 1) {
        uint32_t new_float = f << 1;
        new_float = new_float >> 1;
        return new_float;
    } else {
        uint32_t new_float = f | 0x80000000;
        return new_float;
    }

    
    return 42; // REPLACE ME WITH YOUR CODE
}
