#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char *filename = argv[1];
    int array[1000];
    FILE *file = fopen(filename, "r");
    int byte = fgetc(file);
    int i = 0;
    while (byte != EOF && i < 1000) {
        if (byte < 128) {
            array[i] = byte;
            i++;
        }        
        byte = fgetc(file);
    }
    array[i] = '\0';
    
    fclose(file);
    
    file = fopen(filename, "w");
    for(int j = 0; array[j] != '\0'; j++) {
        fprintf(file, "%d", array[j]);
    }
    
    fclose(file);
    
    return 0;
}
