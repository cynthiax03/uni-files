#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char *filename = argv[1];
    FILE *file = fopen(filename, "r");
    // loop to either EOF or a non ascii char
    int byte = fgetc(file);
    while (byte != EOF && byte <= 127) {
        byte = fgetc(file);
    }
           
    if (byte == EOF) {
        printf("%s is all ASCII\n", filename);
    } if (byte > 127) {
        printf("%s: byte %ld is non-ASCII\n", filename, (ftell(file) - 1));
    } 
    
    fclose(file);
    return 0;
}
