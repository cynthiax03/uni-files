#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char *filename1 = argv[1];
    char *filename2 = argv[2];
    FILE *file1 = fopen(filename1, "r");
    FILE *file2 = fopen(filename2, "r");
    
    int byte1 = fgetc(file1);
    int byte2 = fgetc(file2);
    
    while (byte1 != EOF && byte2 != EOF && byte1 == byte2) {
        byte1 = fgetc(file1);
        byte2 = fgetc(file2);
    }
    
    
    if (byte1 == EOF && byte2 != EOF) {
        printf("EOF on %s\n", filename1);
    } else if (byte1 != EOF && byte2 == EOF) {
        printf("EOF on %s\n", filename2);
    } else if (byte1 != byte2) {
        printf("Files differ at byte %ld\n", (ftell(file1) - 1));
    } else if (byte1 == EOF && byte2 == EOF) {
        printf("Files are identical\n");
    }
    
    fclose(file1);
    fclose(file2);
    
    
    return 0;
}
