// swap pairs of bits of a 64-bit value, using bitwise operators

#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

#define N_BITS 64

// return value with pairs of bits swapped
uint64_t bit_swap(uint64_t value) {
    // PUT YOUR CODE HERE
    
    char *str = malloc((N_BITS + 1)*sizeof(char));
    str[N_BITS] = '\0';
    for (int i = 0; i < N_BITS; i++) {
        uint64_t mask = (uint64_t)1 << i;
        if ((value & mask) != 0) {           
            str[N_BITS - i - 1] = '1';
        } else {
            str[N_BITS - i - 1] = '0';
        }
    }
    
    for (int j = 0; j < N_BITS; j += 2) {
        char temp = str[j];
        char temp2 = str[j + 1];
        str[j] = temp2;
        str[j + 1] = temp;
    }
    
    uint64_t value1 = 0;
    for(int k = 0; k < N_BITS; k++) {
        if (str[k] == '1') {
            uint64_t mask = (uint64_t)1 << (N_BITS - k - 1);
            value1 = value1 | mask;
        }
    }

    return value1;
}
