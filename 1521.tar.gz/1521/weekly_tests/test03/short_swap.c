// Swap bytes of a short

#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#define N_BITS 16
#define FIRST_BIT_MASK 0xFF00
#define SECOND_BIT_MASK 0x00FF

// given uint16_t value return the value with its bytes swapped
uint16_t short_swap(uint16_t value) {
    
    
    char *str = malloc((N_BITS + 1)*sizeof(char));
    str[N_BITS] = '\0';
    for (int i = 0; i < N_BITS; i++) {
        int mask = 1 << i;
        if ((value & mask) != 0) {           
            str[N_BITS - i - 1] = '1';
        } else {
            str[N_BITS - i - 1] = '0';
        }
    }

    int value1 = 0;
    for(int i = 0; i < 8; i++) {
        if (str[i] == '1') {
            int mask = 1 << (8 - i - 1);
            value1 = value1 | mask;
        }
    } 
    

    
    int value_2 = 0;
    for(int i = 8; i < 16; i++) {
        if (str[i] == '1') {
            int mask = 1 << (16 - i - 1);
            value_2 = value_2 | mask;
            
    }
    }

    
    uint16_t temp1 = value1;
    uint16_t temp2 = value_2 << 8;
    
    
    
    uint16_t final = temp1 | temp2;
    
    
    // PUT YOUR CODE HERE

    return final;
}
