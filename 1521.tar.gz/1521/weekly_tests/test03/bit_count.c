// count bits in a uint64_t

#include <assert.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

#define N_BITS 64

// return how many 1 bits value contains
int bit_count(uint64_t value) {
    // PUT YOUR CODE HERE
    
    char *str = malloc((N_BITS + 1)*sizeof(char));
    str[N_BITS] = '\0';
    for (int i = 0; i < N_BITS; i++) {
        uint64_t mask = (uint64_t)1 << i;
        if ((value & mask) != 0) {           
            str[N_BITS - i - 1] = '1';
        } else {
            str[N_BITS - i - 1] = '0';
        }
    }
    
    
    int counter = 0;
    for (int i = 0; i < N_BITS; i++) {
        if (str[i] == '1') {
            counter++;
        }
    }

    return counter;
}
