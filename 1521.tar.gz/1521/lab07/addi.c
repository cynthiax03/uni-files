// generate the opcode for an addi instruction

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>

#include "addi.h"

#define ADDI 0x20000000
#define mask 0xFFFF

// return the MIPS opcode for addi $t,$s, i
uint32_t addi(int t, int s, int i) {    
    uint32_t ret = ADDI | (s << 21);
    ret = ret | (t << 16);
    ret = ret | (i & mask);

    return ret; // REPLACE WITH YOUR CODE

}
