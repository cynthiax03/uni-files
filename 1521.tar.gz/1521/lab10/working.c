int free_pages = 0;
    for (int i = 0; i < n_physical_pages; i++) {
        // 1) The virtual page is already in a physical page
        if (ipt[i].virtual_page == virtual_page) {            
            ipt[i].last_access_time = access_time;
            printf("Time %d: virtual page %d -> physical page %d\n",
                   access_time, virtual_page, i);
           return;
        }
        
        if (ipt[i].virtual_page == -1) {
            free_pages++;
        }
    }
    
    if (physical_pages > 0) {
        for (int j = 0; j < n_physical_pages; j++) {
            // 2) The virtual page is not in a physical page,
            //    and there is free physical page
            if (ipt[j].virtual_page == -1) {
                ipt[j].virtual_page = virtual_page;
                ipt[j].last_access_time = access_time;                
                printf("Time %d: virtual page %d loaded to physical page %d\n", access_time, virtual_page, j);
                return;
            }
            // 3) The virtual page is not in a physical page,
            //    and there is no free physical page
            else {
                int LRU = ipt[0].last_access_time;
                for (int k = 1; k < n_physical_pages; k++) {
                    if (ipt[k].last_access_time < LRU) {
                        LRU = ipt[k].last_access_time;
                    }
                } 
       
                if (LRU == ipt[j].last_access_time) {
                    int old_virtual_page = ipt[j].virtual_page;
                    ipt[j].virtual_page = virtual_page;
                    ipt[j].last_access_time = access_time;
                    printf("Time %d: virtual page %d  - virtual page %d evicted - loaded to physical page %d\n", access_time, virtual_page, old_virtual_page, j);
                    return; 
                }  
            }
        }
    }  
    
    
    
    // Set free_page cond to false
    int free_pages = 0;
    
    // Loop through all of physical pages
    for (int i = 0; i < n_physical_pages; i++) {

        // If the virtual page is free, set free_page to true
        if (ipt[i].virtual_page == -1) {
            free_pages++;
        }

        // If the virtual page is already in a physical page
        if (ipt[i].virtual_page == virtual_page) {

            // Update LRU
            ipt[i].last_access_time = access_time;

            // Print the line and return
            printf("Time %d: virtual page %d -> physical page %d\n", 
                    access_time, virtual_page, i);
            return;
        }
    }

    // If the virtual page is not in a physical page
    
    // If theres a free physical page
    if (free_pages > 0) {

        // Loop through all physical pages
        for (int j = 0; j < n_physical_pages; j++) {

            // If theres a free space
            if (ipt[j].virtual_page == -1) {
                
                // Load it into the availabe physical memory
                ipt[j].virtual_page = virtual_page;

                // Update LRU
                ipt[j].last_access_time = access_time;

                // Print the line and return
                printf("Time %d: virtual page %d loaded to physical page %d\n",
                access_time, virtual_page, j);
                return;
            }
        }

        // Otherwise, there is no free physical page
    } else {

        // Set LRU to the first LAT
        int LRU = ipt[0].last_access_time;

        // Loop through all of physical pages to find the LRU
        for (int k = 1; k < n_physical_pages; k++) {

            // If we find a smaller LRU, update LRU
            if (ipt[k].last_access_time < LRU) {
                LRU = ipt[k].last_access_time;
            }
        }

        // Loop through the physical pages
        for (int a = 0; a < n_physical_pages; a++) {
            
            // If the LRU is found
            if (LRU == ipt[a].last_access_time) {

                // Set temp as LRU to store
                int temp = ipt[a].virtual_page;
                
                // Load it into the availabe physical memory
                ipt[a].virtual_page = virtual_page;

                // Update LRU
                ipt[a].last_access_time = access_time;
                
                // Print the line and return
                printf("Time %d: virtual page %d  - virtual page %d evicted - loaded to physical page %d\n", 
                access_time, virtual_page, temp, a);
                return;
            }
        }
    }    
