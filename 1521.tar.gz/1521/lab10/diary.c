#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_PATH_SIZE 256

int main(int argc, char *argv[]) {
    // get filepath for .diary
    char *filename = "/.diary";
    char *home = getenv("HOME");
    char *filepath = malloc(sizeof(char) * MAX_PATH_SIZE);
    filepath = strcpy(filepath, home);
    filepath = strcat(filepath, filename);
    
    // open the diary file for appending
    FILE *diary = fopen(filepath, "a");
    
    // print the args in, do not print first arg as it is the program name
    for (int i = 1; i < argc; i++) {
        // print each arg into the diary file separated by a space
        fprintf(diary, "%s ", argv[i]);
    }
    
    // "\n" after the line
    fprintf(diary, "\n");
    
    // close the file 
    fclose(diary);
    
    free(filepath);
    return 0;
}
