#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>

#define N_BITS 16

int bcd(int bcd_value);

int main(int argc, char *argv[]) {

    for (int arg = 1; arg < argc; arg++) {
        long l = strtol(argv[arg], NULL, 0);
        assert(l >= 0 && l <= 0x0909);
        int bcd_value = l;

        printf("%d\n", bcd(bcd_value));
    }

    return 0;
}


// given a  BCD encoded value between 0 .. 99
// return corresponding integer
int bcd(int bcd_value) {

    // PUT YOUR CODE HERE
    // Convert the integer into binary
    char *str = malloc((N_BITS + 1)*sizeof(char));
    str[N_BITS] = '\0';
    for (int i = 0; i < N_BITS; i++) {
        int mask = 1 << (N_BITS - i - 1);
        if ((bcd_value & mask) != 0) {           
            str[i] = '1';
        } else {
            str[i] = '0';
        }
    }
    char *bits = str;
    
    // Find tens value by reading first 8 bits 
    int value = 0;
    for(int i = 0; i < 8; i++) {
        if (bits[i] == '1') {
            int mask = 1 << (8 - i - 1);
            value = value | mask;
        }
    } 
    
    // Find ones value by reading last 8 bits
    int value_2 = 0;
    for(int i = 8; i < 16; i++) {
        if (bits[i] == '1') {
            int mask = 1 << (16 - i - 1);
            value_2 = value_2 | mask;
        }
    } 
    int final_value = (value * 10) + value_2; 

        free(bits);
    

    return final_value;
}

