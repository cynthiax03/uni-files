#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>

#define N_BCD_DIGITS 8
#define N_BITS 32

uint32_t packed_bcd(uint32_t packed_bcd);

int main(int argc, char *argv[]) {

    for (int arg = 1; arg < argc; arg++) {
        long l = strtol(argv[arg], NULL, 0);
        assert(l >= 0 && l <= UINT32_MAX);
        uint32_t packed_bcd_value = l;

        printf("%lu\n", (unsigned long)packed_bcd(packed_bcd_value));
    }

    return 0;
}

// given a packed BCD encoded value between 0 .. 99999999
// return the corresponding integer
uint32_t packed_bcd(uint32_t packed_bcd_value) {

    // PUT YOUR CODE HERE
    // Convert the integer into binary
    char *str = malloc((N_BITS + 1)*sizeof(char));
    
    for (int i = 0; i < N_BITS; i++) {
        int mask = (uint32_t)1 << (N_BITS - 1 - i);
        if (packed_bcd_value & mask) {           
            str[i] = '1';
        } else {
            str[i] = '0';
        }
    }
    str[N_BITS] = '\0';
    
    char *bits = str;
    
    // Find 1st value
    int value_1 = 0;
    for(int i = 0; i < 4; i++) {
        if (bits[i] == '1') {
            int mask = 1 << (4 - i - 1);
            value_1 = value_1 | mask;
        }
    } 
    
    // Find 2nd value
    int value_2 = 0;
    for(int i = 4; i < 8; i++) {
        if (bits[i] == '1') {
            int mask = 1 << (8 - i - 1);
            value_2 = value_2 | mask;
        }
    } 
    
    // Find the 3rd value
    int value_3 = 0;
    for(int i = 8; i < 12; i++) {
        if (bits[i] == '1') {
            int mask = 1 << (12 - i - 1);
            value_3 = value_3 | mask;
        }
    } 
    
    // find 4th value
    int value_4 = 0;
    for(int i = 12; i < 16; i++) {
        if (bits[i] == '1') {
            int mask = 1 << (16 - i - 1);
            value_4 = value_4 | mask;
        }
    } 
    
    // Find 5th value 
    int value_5 = 0;
    for(int i = 16; i < 20; i++) {
        if (bits[i] == '1') {
            int mask = 1 << (20 - i - 1);
            value_5 = value_5 | mask;
        }
    } 
    
    // Find 6th value 
    int value_6 = 0;
    for(int i = 20; i < 24; i++) {
        if (bits[i] == '1') {
            int mask = 1 << (24 - i - 1);
            value_6 = value_6 | mask;
        }
    }
    
    // Find 7th value 
    int value_7 = 0;
    for(int i = 24; i < 28; i++) {
        if (bits[i] == '1') {
            int mask = 1 << (28 - i - 1);
            value_7 = value_7 | mask;
        }
    } 
    
    // Find 8th value
    int value_8 = 0;
    for(int i = 28; i < 32; i++) {
        if (bits[i] == '1') {
            int mask = 1 << (32 - i - 1);
            value_8 = value_8 | mask;
        }
    } 
    
    int final_value = value_1 * 10000000 + value_2 * 1000000 
                  + value_3 * 100000 + value_4 * 10000 + value_5 * 1000
                  + value_6 * 100 + value_7 * 10 + value_8; 
    
    

    return final_value;
}
