#include <sys/stat.h>
#include <sys/wait.h>

#include <assert.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <spawn.h>
#include <ctype.h>
#include <glob.h>

#define MAX_PATH_SIZE 256

//
// Interactive prompt:
//     The default prompt displayed in `interactive' mode --- when both
//     standard input and standard output are connected to a TTY device.
//
static const char *const INTERACTIVE_PROMPT = "shuck& ";

//
// Default path:
//     If no `$PATH' variable is set in Shuck's environment, we fall
//     back to these directories as the `$PATH'.
//
static const char *const DEFAULT_PATH = "/bin:/usr/bin";

//
// Default history shown:
//     The number of history items shown by default; overridden by the
//     first argument to the `history' builtin command.
//     Remove the `unused' marker once you have implemented history.
//
static const int DEFAULT_HISTORY_SHOWN __attribute__((unused)) = 10;

//
// Input line length:
//     The length of the longest line of input we can read.
//
static const size_t MAX_LINE_CHARS = 1024;

//
// Special characters:
//     Characters that `tokenize' will return as words by themselves.
//
static const char *const SPECIAL_CHARS = "!><|";

//
// Word separators:
//     Characters that `tokenize' will use to delimit words.
//
static const char *const WORD_SEPARATORS = " \t\r\n";

static void execute_command(char **words, char **path, char **environment);
static void do_exit(char **words);
static int is_executable(char *pathname);
static char **tokenize(char *s, char *separators, char *special_chars);
static void free_tokens(char **tokens);

// Functions
// subset 1 functions
static void run_program(char **words, char **path, char **environment);
static char *make_path(char *program, char **path);
static int number_of_args(char **file);

// subset 2 functions
static void save_history (char **words);
static char *get_shuck_history_path(void);
static void history_n_command(char **words);
static int number_of_lines(void);
static void print_all_history(int n_lines);
static void print_last_n_lines_of_history(int n_lines, int n);
static void run_last_command(char **words, char **path, char **environment);
static int too_many_args (char **args);
static void run_nth_command(char **words, char **path, char **environment);

// subset 3 functions
static char **globber(char **words);
static bool check_glob_chars(char *words);

// subset 4 functions
static bool input_redirection_initial_errors (char **words);
static bool is_file(char *file);
static bool is_readable(char *file);
static void input_redirection(char **words, char **path, char **environment);
static bool is_builtin(char *command);
static bool check_output_redirection_command(char **words);
static int find_char(char **words, char *c);
static bool is_writable(char *file);
static void output_redirection(char **words, char **path, char **environment);

int main (void)
{
    // Ensure `stdout' is line-buffered for autotesting.
    setlinebuf(stdout);

    // Environment variables are pointed to by `environ', an array of
    // strings terminated by a NULL value -- something like:
    //     { "VAR1=value", "VAR2=value", NULL }
    extern char **environ;

    // Grab the `PATH' environment variable for our path.
    // If it isn't set, use the default path defined above.
    char *pathp;
    if ((pathp = getenv("PATH")) == NULL) {
        pathp = (char *) DEFAULT_PATH;
    }
    char **path = tokenize(pathp, ":", "");

    // Should this shell be interactive?
    bool interactive = isatty(STDIN_FILENO) && isatty(STDOUT_FILENO);

    // Main loop: print prompt, read line, execute command
    while (1) {
        // If `stdout' is a terminal (i.e., we're an interactive shell),
        // print a prompt before reading a line of input.
        if (interactive) {
            fputs(INTERACTIVE_PROMPT, stdout);
            fflush(stdout);
        }

        char line[MAX_LINE_CHARS];
        if (fgets(line, MAX_LINE_CHARS, stdin) == NULL)
            break;

        // Tokenise and execute the input line.
        char **command_words =
            tokenize(line, (char *) WORD_SEPARATORS, (char *) SPECIAL_CHARS);
        execute_command(command_words, path, environ);
        free_tokens(command_words);
    }

    free_tokens(path);
    return 0;
}


//
// Execute a command, and wait until it finishes.
//
//  * `words': a NULL-terminated array of words from the input command line
//  * `path': a NULL-terminated array of directories to search in;
//  * `environment': a NULL-terminated array of environment variables.
//
static void execute_command(char **words, char **path, char **environment)
{
    assert(words != NULL);
    assert(path != NULL);
    assert(environment != NULL);

    char *program = words[0];

    if (program == NULL) {
        // nothing to do
        return;
    }
    
    // subset 4: input/output redirection
    // input redirection
    // check if '<' exists anywhere in words
    if (find_char(words, "<")) {         
        // if < is in words but is not the first word, error
        if (strcmp(*words, "<") != 0) {
            fprintf(stderr, "invalid input redirection\n");
        }    
        // if < is the first word
        else {
            // if there are no initial errors
            if (input_redirection_initial_errors(words)) {                
                save_history(words);
                input_redirection(words, path, environment);   
            }
        }         
    }
    
    // output redirection;
    // check whether > exists anywhere in words
    else if (find_char(words, ">")) {
        // check if there are any initial errors
        // if there are no initial errors, redirect output
        if (check_output_redirection_command(words)) {
            save_history(words);
            output_redirection(words, path, environment);
        }
    }

    else if (strcmp(program, "exit") == 0) {
        do_exit(words);
        // `do_exit' will only return if there was an error.
        return;
    }
    
    // subset 0: cd and pwd
    // if command is pwd 
    else if (strcmp(*words, "pwd") == 0) {
        char pathname[MAX_PATH_SIZE];
        // find current directory and print
        char *curr_directory = getcwd(pathname, MAX_PATH_SIZE);
        printf("current directory is '%s'\n", curr_directory);
        save_history(words);
    } 
    
    // if command is cd
    else if (strcmp(*words, "cd") == 0) {
        // save commands to history, then check if any commands need to be 
        // globbered
        save_history(words);
        globber(words);
        // if there is more than one argument, change directories 
        char **new_directory = words;
        new_directory++;
        if (*new_directory != NULL) {
            // test if the directory exists
            // change directories to the given directory if it exists
            if (chdir(*new_directory) != 0) {
                fprintf(stderr, "cd: %s: No such file or directory\n", *new_directory);   
            }   
        } 
        // if no argument after cd command, the directory is changed to 
        // the directory in the HOME environment variable
        else if (*new_directory == NULL) {
            char *string = getenv("HOME");
            chdir(string);
        }
    } 
    
    // subset 2: making history
    // history command
    else if (strcmp(*words, "history") == 0) {
        char **arg = words;
        arg++;
        // if n is specified, print out the nth last commands 
        if (*arg != NULL) {
            history_n_command(words);
        }
        // if n is not specified, print out the last 10 commands
        if (*arg == NULL) {            
            // check if there are 10 lines in history
            int n_lines = number_of_lines();
            // if there are less than 10 lines in history, print all of history
            if (n_lines < 10) {
                print_all_history(n_lines);
            }
            // print the last 10 lines of history
            else {
                print_last_n_lines_of_history(n_lines, 10);
            }
        }
        save_history(words);  
    } 
    
    // ! command
    else if (strcmp(*words, "!") == 0) {
        // if command is just "!" run the last command
        words++;
        if (*words == NULL) {
            run_last_command(words, path, environment);
        } 
        // if there are args after !
        else {
            // check if there are too many args
            if (too_many_args(words)) {
                fprintf(stderr, "!: too many arguments\n");
            } 
            // if there is only one arg
            else {
                run_nth_command(words, path, environment);
            }
        }  
    }    
    
    // subset 1: running a program
    else {        
        // save words to history then globber
        save_history(words);
        globber(words);
        run_program(words, path, environment);
    }   
}

//
// Implement the `exit' shell built-in, which exits the shell.
//
// Synopsis: exit [exit-status]
// Examples:
//     % exit
//     % exit 1
//
static void do_exit(char **words)
{
    assert(words != NULL);
    assert(strcmp(words[0], "exit") == 0);

    int exit_status = 0;

    if (words[1] != NULL && words[2] != NULL) {
        // { "exit", "word", "word", ... }
        fprintf(stderr, "exit: too many arguments\n");

    } else if (words[1] != NULL) {
        // { "exit", something, NULL }
        char *endptr;
        exit_status = (int) strtol(words[1], &endptr, 10);
        if (*endptr != '\0') {
            fprintf(stderr, "exit: %s: numeric argument required\n", words[1]);
        }
    }

    exit(exit_status);
}

