#include <stdio.h>
#include <stdlib.h>

int main(int argc, char **argv) {
	(void) argc, (void) argv; // keep the compiler quiet, should be removed
	
	if (argc == 1) {
	    printf("Usage %s NUMBER [NUMBER ...]\n", argv[0]);
	} else {
	    int min = atoi(argv[1]);
	    int max = atoi(argv[1]);
	    int sum = 0;
	    int prod = 1;
	    int mean = 0;
	    int i = 1;
	    while (i < argc) {
	        // finds minimum value 
	        if (atoi(argv[i]) < min) {
	            min = atoi(argv[i]);
	        // finds maximum value
	        } if ( atoi(argv[i]) > max) {
	            max = atoi(argv[i]);
	        }
	        // Adds each value together for sum
	        sum = sum + atoi(argv[i]);
	        // Multiplies each value for product
	        prod = prod * atoi(argv[i]);     
	        // Finds mean
	        if (i == argc - 1 ) {
	            mean = sum / i;  
	        }
	        i++;
	    }
	    
	    printf("MIN:  %d\n", min);
	    printf("MAX:  %d\n", max); 
	    printf("SUM:  %d\n", sum);
	    printf("PROD: %d\n", prod); 
	    printf("MEAN: %d\n", mean); 
	}
	
	return 0;
}


