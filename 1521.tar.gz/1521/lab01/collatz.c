// z5359629
// COMP1521 2021T2
// Takes a single integer from comman line and prints its collatz chain
// using a recursive function

#include <stdio.h>
#include <stdlib.h>

void collatz_number(int n);

int main(int argc, char **argv) {
	if (argc == 0) {
	    printf("Usage: ./collatz NUMBER");
	} else {
	    int number = atoi(argv[1]);
	    collatz_number(number);
	}
	
//	(void) argc, (void) argv; // keep the compiler quiet, should be removed
	return EXIT_SUCCESS;
}

void collatz_number(int n) {
    // If the n is 1, the series terminates
    if (n == 1) {
        printf("%d\n", n);
    } else {
        // If n is odd
        if (n % 2 == 1) {
            printf("%d\n", n);
            collatz_number(3*n + 1);
        } // If n is even 
        else {
            printf("%d\n", n);
            collatz_number(n / 2);
        }
    }
} 

