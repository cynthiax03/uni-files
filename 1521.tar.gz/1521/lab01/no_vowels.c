#include <stdio.h>
#include <string.h>

#define max_size 1000

int main(void) {
	char character[max_size];
	int i = 0;
	while(scanf("%c", &character[i]) != EOF && i < 1000) {
	    if (character[i] == 'a'|| 
	        character[i] == 'A' ||
	        character[i] == 'e' || 
	        character[i] == 'E' ||
	        character[i] == 'i' || 
	        character[i] == 'I' ||
	        character[i] == 'o' || 
	        character[i] == 'O' ||
	        character[i] == 'u' ||
	        character[i] == 'U') {
	        } else {
	            printf("%c", character[i]);
	        }
	    i++;
	}
	return 0;
}
