// z5359629
#include <stdio.h>
#include <string.h>

#define MAX_SIZE 1024

int main(void) {
	char string[MAX_SIZE];
	
	while (fgets(string, MAX_SIZE, stdin) != NULL) {   
	    if (strlen(string) % 2 != 1) {
	        fputs(string, stdout);
	    }
	}
	
	 	
	return 0;
}
