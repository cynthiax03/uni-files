// z5359629
// COMP1521 2021T2
// Takes a number from input and prints the corresponding fibonacci number
// until EOF

#include <stdio.h>
#include <stdlib.h>

#define SERIES_MAX 46

int fibonacci(int n);

int main(void) {
    int already_computed[SERIES_MAX + 1] = { 0, 1 };
	(void) already_computed; // keep the compiler quiet, should be removed
    int number;
    while (scanf("%d", &number) != EOF) {
        printf("%d\n", fibonacci(number));
    }
    
    return EXIT_SUCCESS;
}

int fibonacci(int n) {
    if (n == 0) { 
        return n;
    } else if (n == 1 ) {
        return n;
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2);
    }
}
