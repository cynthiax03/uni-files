// z5359629

#include <stdio.h>
#include <ctype.h>

int main(void) {
    int character = getchar();
    while(character != EOF) {
        if (character >= 'A' && character <= 'Z') {
            int alphabet_pos = character - 'A';
            int new_character = 'a' + alphabet_pos;
            putchar(new_character);
        } else {
            putchar(character);
        }
        character = getchar();
    }	
	return 0;
}
