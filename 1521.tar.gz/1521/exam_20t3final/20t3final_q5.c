#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <sys/stat.h>

int main(int argc, char *argv[]) {
    int n = atoi(argv[1]);
    char *existing_file = argv[2];
    char *new_filename = argv[3];
    
    struct stat file;
    if (stat(existing_file, &file) != 0) {
        perror(existing_file);
        return 0;
    }
    
    int file_size = file.st_size;
    if (file_size <= n) {
        FILE *new_file = fopen(new_filename, "w");
        fclose(new_file);
        
    } else {
        int bytes_included = file_size - n;
        FILE *old = fopen(existing_file, "r");
        FILE *new = fopen(new_filename, "w");     
        int byte = fgetc(old);
        for (int bytes_read = 0; bytes_read < bytes_included; bytes_read++) {
            fputc(byte, new);
            byte = fgetc(old);
        }
        
        fclose(old);
        fclose(new);
         
    }
    return 0;    
}
