#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[]) {
    char *value1 = getenv(argv[1]);
    char *value2 = getenv(argv[2]);
    int value_1;
    int value_2;
    if (value1 == NULL) {
        value_1 = 42;
    } else {
        value_1 = atoi(getenv(argv[1]));
    }
    
    if (value2 == NULL) {
        value_2 = 42;
    } else {
        value_2 = atoi(getenv(argv[2]));
    }
      
    if (value_1 > value_2 || value_1 == value_2) {
        if ((value_1 - value_2) < 10) {
            printf("1\n");
        } else {
            printf("0\n");
        }
    } else if (value_2 > value_1) {
        if ((value_2 - value_1) < 10) {
            printf("1\n");
        } else {
            printf("0\n");
        }
    }
    
    return 0;
}
