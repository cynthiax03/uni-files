#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <sys/stat.h>

#define MASK 0x1

int main(int argc, char *argv[]) {
    char *filename = argv[1];
    FILE *file = fopen(filename, "r");
    int byte = fgetc(file);
    int bit_counter = 0;
    while(byte != EOF) {
        for(int i = 0; i < 16; i++) {
            if ((byte & MASK) == 1) {
                bit_counter++;
            }
            byte = byte >> 1;
        }
        byte = fgetc(file);
    }
    
    fclose(file);
    
    printf("%s has %d bits set\n", filename, bit_counter);
    return 0;
}
