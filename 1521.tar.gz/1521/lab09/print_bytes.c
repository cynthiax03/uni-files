#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if(argc != 2) {
        fprintf(stderr, "1 argument needed\n");
        return 1;
    }
    
    FILE *input_stream = fopen(argv[1], "rb");
    if (input_stream == NULL) {
        perror(argv[1]);  // prints why the open failed
        return 1;
    }
    
    int byte = fgetc(input_stream);
    int i = 0;
    while (byte != EOF) {
        if (byte == '\n' || byte <= 20 || byte >= 127) {
            printf("byte %4d: %3d 0x%02x\n", i, byte, byte);
        }
        else {
            printf("byte %4d: %3d 0x%02x '%c'\n", i, byte, byte, byte);
        }
        byte = fgetc(input_stream);
        i++;
    }
    
    fclose(input_stream); // automatically on exit
    
    return 0;
}
