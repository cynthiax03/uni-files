#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>

off_t stat_file(char *filename);

int main(int argc, char *argv[]) {    
    int i = 1;
    off_t total = 0;
    off_t size;
    while(i < argc) {
        size = stat_file(argv[i]);
//        printf("%s: %ld bytes\n", argv[i], size);
        total += size;
        i++;
    }
    
    printf("Total: %ld bytes\n", total);

    return 0;    
}

off_t stat_file(char *filename) {
    // create struct file
    struct stat file;
    
    // check if there is an error
    if (stat(filename, &file) != 0) {
        perror(filename);
        exit(1);
    }
    
    if ((file.st_mode & S_IRUSR) != 0) {
        printf("has read permissions\n");
    }
    
    
    
    printf("%s: %ld bytes\n", filename, file.st_size);
    
    // return size of file
    return file.st_size;
}
