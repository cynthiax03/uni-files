#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if(argc != 4) {
        fprintf(stderr, "3 arguments needed\n");
        return 1;
    }
    
    FILE *output_stream = fopen(argv[1], "wb");
    if (output_stream == NULL) {
        perror(argv[1]);
        return 1;
    }
    
    int i = atoi(argv[2]);
    while (i <= atoi(argv[3])) {
        fprintf(output_stream, "%d\n", i);
        i++;
    }
    
    fclose(output_stream); // automatically on exit

    return 0;
}
