#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    if(argc < 2) {
        fprintf(stderr, "at least one argument needed\n");
        return 1;
    }
    
    FILE *input_stream = fopen(argv[1], "wb");
    if (input_stream == NULL) {
        perror(argv[1]);  // prints why the open failed
        return 1;
    }
    
    int i = 2;
    int c;
    while (i < argc) {
        c = atoi(argv[i]);
        fputc(c, input_stream);
        i++;
    }
 
    fclose(input_stream); // automatically on exit
    return 0;    
}
