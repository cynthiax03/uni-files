# COMP1531 Final Exam

For this exam you are provided with this public repostory (`exam-spec`) that all students are provided that includes the questions being asked. You will then also have your own [personal exam repository](https://cgi.cse.unsw.edu.au/~cs1531/redirect/?path=COMP1531/21T3/students/_/exam) where you actually answer and submit these questions to.

If you are seeking information not provided in this file, check the [COMP1531 Exam Brief page](https://webcms3.cse.unsw.edu.au/COMP1531/21T3/resources/60736). If your question is still unanswered, follow the "Communicating with teaching staff" instructions at that link.

## Change Log

N/A

## WARNING

This applies to all students completing the COMP1531 21T3 exam.

* This exam is an individual assessment. Any attempt to communicate with other people (both other students in this course and outside persons) about the contents of this exam will be treated as academic misconduct and may result in you failing this course. This applies to everyone during the exam time. To avoid any doubt about your behaviour during the exam, cease all communication with other students for that time.
* From Thursday the 6th of May onward, you are only allowed to discuss the exam with students who have themselves also completed the exam, and it's your responsibility to check if they have.
* Your zpass should not be disclosed to any other person. If you have disclosed your zpass, you should change it immediately.
* Do not place your exam work in any location accessible to any other person. This includes services such as Dropbox and Github.
* If another student in the course makes any sort of contact with you during the exam, or you’re aware of any instances of other students breaching the conditions above, you are required to email cs1531@cse.unsw.edu.au with details of the interaction.

## Part 1. Cloning your repository

Please clone your [personal exam repository](https://cgi.cse.unsw.edu.au/~cs1531/redirect/?path=COMP1531/21T3/students/_/exam).

## Part 2. Questions - Short Answer (15%)

For each of these questions, write the answer in the relevant text file.

<br />

### Question 1 (3 marks)

In your personal exam repository, answer this question in `q1.txt`.

<b>Q. Describe the difference between Continuous Integration and Continuous Delivery. For each, provide a clear and specific example of their usage.</b>

<br />

### Question 2 (2 marks)

In your personal exam repository, answer this question in `q2.txt`.

Consider this statement:
 > We need to monitor the different ways that users use our product that is already in production. We also need to track how often the servers go down.

<b>Q. If you were told this statement, what part of the SDLC would you think this fits into? Justify your response.</b>

<br />

### Question 3 (2 marks)

In your personal exam repository, answer this question in `q3.txt`.

Consider this statement:
 > I've just completed a diagram that helps to explain the different key components of software that we will need to build. This diagram essentially describes software modules and how they interact.

<b>Q. If you were told this statement, what part of the SDLC would you think this fits into? Justify your response.</b>

<br />

### Question 4 (2 marks)

In your personal exam repository, answer this question in `q4.txt`.

Consider this requirement:
> MyUNSW is very challenging to use. Sometimes I'm just trying to log in to figure out what classes are on my timetable but then I realise that MyUNSW is offline during its daily downtime because it's 1am in Sydney. I know it's not down for long, but it's just the time I most often need it. I wish the site was always working.

<b>Q. Write a user story to capture the above requirement.</b>

<br />

### Question 5 (1 marks)

In your personal exam repository, answer this question in `q5.txt`.

A team member sent you a message on Teams that said the following about their work:
> I have built a function that parses a date (e.g. "2021-10-10") by breaking up the date into components based on the dash, then converting each of the 3 components into a number of seconds since 1st January 1970, and returning that value. I think it's a really important and necessary function, though others tell me it's not easy to understand.

<b>Q. Would you consider this an example of accidental complexity or essential complexity?</b>

<br />

### Question 6 (2 marks)

In your personal exam repository, answer this question in `q6.txt`.

UNSW has decided to create a robot soccer team known as the Bobocup Champions. This team consists of engineers who design and write software to run on small humanoid robots. There is a competition coming up in July 2022, and you're one of the team members on this team trying to build the best robots in the world.

<b>Q. Which of the following would constitute an Agile approach in trying to design and write software to become the Bobocup Champions?</b> There may be multiple answers. Write any relevant answers as `a`, `b`, `c`, `d`, or `e` in the text file.

<ol type='a'>
    <li>Ensuring that you have a 6 month plan of all the programming you want to do before you begin development.</li>
    <li>Focusing on ensuring the best testing pipelines are setup as a priority over how your team members feel about the testing processes.</li>
    <li>Producing a simple tested prototype that isn't perfect but helps you learn, rather than waiting months until it is perfect.</li>
    <li>Dedicating one engineer’s entire role to writing a manual documenting how the robots works.</li>
    <li>Having short meetings at least twice a week.</li>
</ol>

<br />

### Question 7 (3 marks)

In your personal exam repository, answer this question in `q7.txt`.

<b>Q. In the context of software safety, what does LBYL stand for? What is an example of a language that uses this principle, and what is an example of that principle being applied?</b>

## Part 3. Questions - Programming Questions (85%)

These questions involve you writing Python implementations, and in some cases writing Python tests with `pytest`.

The questions are ordered in no particular order, so don't mistake ordering for difficulty.

<br />

### Question 8 (5 marks)

In your personal exam repository, answer this question in `filter.py` and `filter_test.py`.

Write a function that takes in a string, and returns a filtered version of that string that removes all the punctuation from the string including:
 * Full stops
 * Commas
 * Quotation marks (single and double)
 * Semicolons
 * Question marks
 * Exclamation marks

The function should also return the resulting string as all lower case, with the exception of the first letter which should always be uppercase in the output.

Complete the function `filter_string` in `filter.py` that filters the string according to the instructions above.

Write tests for this function in the file `filter_test.py`.

If the string passed in contains any numbers, your function should raise a `ValueError` (the message is optional).

You can assume all strings passed in contain only ASCII characters.

To run your tests you can run `pytest filter_test.py`.

To run coverage you can run `coverage run -m pytest filter_test.py` followed by `coverage report`.

You will receive 60% of your marks from the correctness of your implementation, 15% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage.

### Question 9 (11 marks)

In your personal exam repository, answer this question in `acronym.py` and `acronym_test.py`.

Write a function that takes in a list of strings, and returns an acronym for each of the strings passed in.

For a given string X, we're defining the acronym of that string to be the string that is formed from taking the first letter of every word in that string that does not start with a vowel. If the acronym formed from a string would be 10 characters or more, then the acronym should simply default to "N/A". All acronym characters returned must be uppercase, regardless of whether they are uppercase or not in the input string. If every word in a string of words starts with a vowel (e.g. `I am an elephant`), the output acronym is an empty string.

For example:
```python
acronym_make(['I am very tired today']) == ['VTT']
acronym_make(['Why didnt I study for this exam more', 'I dont know']) == ['WDSFTM', 'DK']
```

Complete the function `acronym_make` in `acronym.py` that generates acronyms according to the instructions above.

Write tests for this function in the file `acronym_test.py`.

If the lists of strings passed in contains no elements (i.e. is an empty list), your function should raise a `ValueError` (the message is optional).

You can assume all strings passed in contain only A-Z uppercase and lowercase, as well as spaces.

To run your tests you can run `pytest acronym_test.py`.

To run coverage you can run `coverage run -m pytest acronym_test.py` followed by `coverage report`.

You will receive 60% of your marks from the correctness of your implementation, 15% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage.

<br />

### Question 10 (11 marks)

In your personal exam repository, answer this question in `mono.py` and `mono_test.py`.

Suppose you have some data consisting of several sequences of numbers, and you'd like to know whether each sequence is:
 * **monotonically increasing**, which means that the values along the sequence never decrease (they either stay the same or increase); or
 * **monotonically decreasing**, which means that the values along the sequence never increase (they either stay the same or decrease); or
 * **neither**.

Complete the function `monotonic` in `mono.py` that takes in a list of tuples, and returns a list of strings that describes, for each tuple, whether it contains [monotonically increasing, monotonically decreasing](https://en.wikipedia.org/wiki/Monotonic_function), or neither numbers.

Write tests for this function in the file `mono_test.py`.

The function should throw a `ValueError` (irrelevant what message is contained in it) if any of the following are true:
* The ints/floats provided in any of the tuple items have an absolute value greater than or equal to 100000
* Any of the tuples contain less than 2 elements.

You can assume that all items in each tuple are of an integer or float type. You can assume that if the numbers are both monotonically increasing and monotonically decreasing at the same time, then a result of `neither` is appropriate.

You will receive 60% of your marks from the correctness of your implementation, 15% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage.

To run your tests you can run `pytest mono_test.py`

To run coverage you can run `coverage run -m pytest mono_test.py` followed by `coverage report`

### Question 11 (9 marks)

In your personal exam repository, answer this question in `penguin.py` and `penguin_test.py`.

A University of Antarctica Penguin number is a 12 character string that uniquely identifies every penguin on iced land south of the equator.

A Penguin number starts with an uppercase letter, followed by 4 numbers, followed by an uppercase letter, followed by 5 numbers, followed by a final uppercase letter (e.g. `P8464Q94944Z`).

However, there are specific rules about those numbers and letters that also determine its validity.

The check for validity is as follows:
 * The first letter must be closer to the start of the alphabet than the second letter.
 * The second letter must be closer to the start of the alphabet than the third letter.
 * The sum of all the single digit numbers must be an even number.
 * The last number in the string must be even.

Complete the function `validate` in `penguin.py` that takes in a string and determines whether it is valid Penguin number or not.

Examples of valid Penguin numbers include: `P8464Q94944Z` and `A1234B12344C`. Examples of invalid Penguin numbers include: `A1234567890B`.

You can assume the input is an ASCII string.

You will receive 60% of your marks from the correctness of your implementation, 15% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage.

To run your tests you can run `pytest penguin_test.py`

To run coverage you can run `coverage run -m pytest penguin_test.py` followed by `coverage report`

### Question 12 (14 marks)

In your personal exam repository, answer this question in `frequency.py` and `frequency_test.py`.

Complete the function `frequency_get` in `frequency.py` that takes in a multi-line string of raw text and returns an output that is a multi-line string containing the sorted frequency map of words split on whitespace and the number of times they appear. If there are multiple words with the same frequency, they should appear in the same order that they appear in the input string.

Upon parsing the input string, you should remove any of the following characters `.?!,;:()[]{}-`. After you've removed these characters, break the words based on sets of characters that are separated by whitespace. Once you've done that, output a multi-line string that highlights the frequency of words based on our required format.

An example is below:
```python
inputstr = """ I like you
I really, really, like you!
Yes I really do
"""

print(frequency_get(inputstr))
```

This program would output the following string:
```python
I: 3
REALLY: 3
LIKE: 2
YOU: 2
YES: 1
DO: 1
```

The output string should have no trailing new line or whitespace. None of the lines in the output string should be indented.

You can assume the input will be a non-empty string. You can assume that you do not need to count the frequency of any whitespace characters.

You will receive 60% of your marks from the correctness of your implementation, 15% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage.

To run your tests you can run `pytest frequency_test.py`

To run coverage you can run `coverage run -m pytest frequency_test.py` followed by `coverage report`

### Question 13 (30 marks)

"Double Trouble" is a card game where a shuffled deck of cards is slowly flipped one card at a time onto a pile. At any given time you check if the last two cards on the pile have the same number. If they do, you say "Double Trouble" and pick up the entire pile of cards. Alternatively, if the last 4 cards were of the same suit, you say "Trouble Double" and go pick up the entire pile of cards. The game repeats forever until you run out of cards.

The questions below are in relation to this game.

It is recommended that you work on each of the questions below in order, but you can skip ahead if you wish. This question will be automarked, so make sure you follow any and all instructions relating to the type or structure of the data you need to accept as input or return as output.

#### 13.1. Backend (10 marks)

In `trouble.py` there is an incomplete series of functions for implementing this software. Implement these functions so that they match the documentation. This will be automarked, so ensure that your functions meet the specifications. Do NOT add additional arguments to the functions or rename them.

Partial marks are available for only implementing some of the functions.

#### 13.2. Testing (10 marks)

In `trouble_test.py` there is one simple test. In this file, write further tests to ensure that your implementation in `trouble.py` is correct.

For marking, your tests will be run against implementations other than your own, so they should make no assumptions about how the functions work beyond what is in their documentation and the documentation at the top of `trouble.py`. To get full marks, your tests should have 100% branch-coverage for your implementation.

To run your tests you can run `pytest trouble_test.py`.

To run coverage you can run `coverage run -m pytest trouble_test.py` followed by `coverage report`.

#### 13.3. Flask (10 marks)

In `server.py` implement a flask wrapper for "Double Trouble". The endpoints are described in comments in the file.

You can run your server with:
```bash
python3 server.py
```

If you need to use another port number, please update the port in `config.py` (this is the port your flask server uses).

To ensure it works as expected, use an API client to send the server requests.

When implementing the server:
 * In terms of return values, all routes should return a JSON string (jsonified python object).
 * In terms of input values, GET routes should get their arguments from `request.args` and POST/PUT/DELETE should get their arguments from `request.get_json()`.
 * We don't expect you to add any functionality to handle exceptions

Note that marks for this question are based on whether your server behaves in the same way as your backend implementation, so it is still possible to get full marks even if your backend does not meet the specifications in their entirety. Partial marks are also available for only implementing some endpoints.

<br />

### Question 14 (5 marks)

You may find this question more challenging than the other questions. Given that it is only worth 5% of the exam, it is strongly recommended you attempt it only after completing all other questions.

A **word square** is a square of *n* *n*-letter words are arranged in a grid so that they read the same from left to right and from top to bottom. The following are examples of word squares:

```
T O E     B A B Y    F R I L L   R E A C T S
O N E     A R E A    R O D E O   E X P O R T
E E L     B E E R    I D E A S   A P P E A R
          Y A R D    L E A P S   C O E R C E
                     L O S S Y   T R A C T S
                                 S T R E S S
```

In `wordsquares.py`, write a function `wordsquare(words)` that is given a list of words. You can assume that all of these words are upper case and are all of the same length (at least 3 and no more than 6). You will need to produce a single word square, one that uses the largest number of different letters of all word squares obtained from the word list. If there are multiple squares with the same number of different letters, any one will do.

If there is no solution, your function should return `'No solution'`.

For example:

```python
wordsquare(['LAST', 'OPUS', 'CATS', 'DOGS', 'POST', 'STOP', 'NEXT', 'PIGS', 'TYPO', 'COWS'])
==
['STOP',
 'TYPO',
 'OPUS',
 'POST'
]
```

There is a fast solution and a slow solution to this problem. For 1 mark, your code should be able to create word squares where the length of the input list is less than 10. For the remaining 4 marks, your code should be able to create word squares where the input list is of any length and run in under 300 seconds. There are two tests in `wordsquares_test.py` to give you an indication of how fast your solution is.

<br />

## Submission

At the end of your specified exam time, we will automatically collect the code on your `master` branch's HEAD (i.e. latest commit).

Please note: If you develop locally ensure you check that your code works on the CSE servers. Failure to do so could result in a fail mark in the exam.

## Originality of Work

The work you submit must be your own work. Submission of work partially or completely derived from any other person or jointly written with any other person is not permitted.

The penalties for such an offence may include negative marks, automatic failure of the course and possibly other academic discipline. Exam submissions will be examined both automatically and manually for such submissions.

Relevant scholarship authorities will be informed if students holding scholarships are involved in an incident of plagiarism or other misconduct.

Do not provide or show your exam work to any other person — apart from the teaching staff of COMP1531.

If you knowingly provide or show your exam work to another person for any reason, and work derived from it is submitted, you may be penalized, even if the work was submitted without your knowledge or consent.  This may apply even if your work is submitted by a third party unknown to you.

Note you will not be penalized if your work has the potential to be taken without your consent or
knowledge.
