
'''
<Brief description of what the function does>

Arguments:
    <name> (<data type>)    - <description>
    <name> (<data type>)    - <description>
    ...

Exceptions:
    InputError  - Occurs when ...
    AccessError - Occurs when ...

Return Value:
    Returns <return value> on <condition>
    Returns <return value> on <condition>
'''

# Search for the channel with the given channel_id
def is_channel_valid(channel_info, store):
    
    # Loop through all stored channels
    for channel in store['channels']:
        # If a matching channel id is found, channel is valid
        if channel['channel_id'] == channel_info['channel_id']:
            return True
    # Otherwise, channel does not exist, return false
    return False

# Search if user is a member of a channel
def is_member(auth_user_id, channel):
    
    # Loop through all channel members
    for member in channel['all_members']:
        # If a matching member with the same user id is found, they're a member
        if member['u_id'] == auth_user_id:
            return True
    # Otherwise, they're not a member of the given channel, return false
    return False

# Search for the channel with the given channel_id
def find_channel(channel_info, store):
    
    # Loop through all stored channels
    for channel in store['channels']:
        # If a matching channel id is found, channel is valid
        if channel['channel_id'] == channel_info['channel_id']:
            return channel

# Function implementation of channel messages
def channel_messages_v1(auth_user_id, channel_id, start):
    
    # Get data from datastore
    store = data_store.get()
    
    # If channel id was empty, raise inputerror
    if channel_id == None:
        raise InputError("Please enter a channel id")
    # Else if channel id was not valid, raise inputerror
    elif is_channel_valid(channel_id, store) == False:
        raise InputError("Please enter a valid channel id")

    # If start is greater than the total number of messages
    found_channel = find_channel(channel_id, store)
    messages = found_channel['messages']
    total_messages = len(messages)
    
    if start > total_messages:
        raise InputError("Start is greater than the total number of messages")
    
    # Given channel id is valid, if the user is not a member of the channel
    if is_member == False:
        raise AccessError("You are not a member of this channel")
    
    # If len(list of messages) + start > 50, this means that there are less than
    # 50 messages to load, i.e the system has loaded all messages it could
    # thus it returns -1 in end
    
    return {
        'messages': [
            {
                'message_id': 1,
                'u_id': auth_user_id,
                'message': 'Hello world',
                'time_created': 1582426789,
            }
        ],
        'start': 0,
        'end': 50,
    }
