def wondrous(start):
    '''
    Returns the wondrous sequence for a given number.
    '''

    if int(start) <= 0:
        raise ValueError("No wondrous sequence for 0")

    current = start
    sequence = []

    while current != 1:
        sequence.append(int(current))
        if (current % 2 == 0):
            current /= 2
        else:
            current = (current * 3) + 1

    # the loop will end when current == 1 and does not append to the end of the sequence
    # so append here
    sequence.append(1)

    return sequence
