from wondrous import wondrous
import pytest

def test_basic():
    assert wondrous(3) == [3, 10, 5, 16, 8, 4, 2, 1]

def test_zero():
    with pytest.raises(ValueError):
        wondrous(0)

def test_large_num():
    assert wondrous(12) == [12, 6, 3, 10, 5, 16, 8, 4, 2, 1]
    assert wondrous(15) == [15, 46, 23, 70, 35, 106, 53, 160, 80,40, 
                    20, 10, 5, 16, 8, 4, 2, 1]
    assert wondrous(7) == [7, 22, 11, 34, 17, 52, 26, 13 ,40, 20, 10,
                           5, 16, 8, 4, 2, 1]

def test_negative():
    with pytest.raises(ValueError):
        wondrous(-100)