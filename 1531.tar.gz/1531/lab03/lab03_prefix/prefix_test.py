from prefix import prefix_search
import pytest

def test_documentation():
    assert prefix_search({"ac": 1, "ba": 2, "ab": 3}, "a") == { "ac": 1, "ab": 3}

def test_exact_match():
    assert prefix_search({"category": "math", "cat": "animal"}, "cat") == {"category": "math", "cat": "animal"}

def test_no_matches():
    with pytest.raises(KeyError):
        prefix_search({"soup": "tomato", "sky": "blue", "box": "rectangle"}, "hello")

def test_uppercase():
    assert prefix_search({"Category": "cats", "cats": "black"}, "Cat") == {"Category": "cats"}

def test_space_prefix():
    assert prefix_search({" colour": "white", "candy": "chocolate"}, " c") == {" colour": "white"} 

def test_numerical_prefix():
    assert prefix_search({"1": "a", "2": "b", "11": "k"}, "1") == {"1": "a", "11": "k"}

