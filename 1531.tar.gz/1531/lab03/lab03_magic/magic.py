# A function that adds all values in a column
def col_sum(square, col):
    total = 0
    for row in square:
        total += row[col]
    return total

# A function that checks each row has n numbers
def row_size_correct(square, n):
    for row in square:
        if len(row) != n:
            return false
    return true

# A function that checks whether a certain number occurs more than once in the
# array
def repeated_number(square, number):
    occurences = 0
    for row in square:
        if number in row:
            occurences += 1
    if occurences > 1:
        return True
    else:
        return False

def magic(square):
    # Find n of array
    n = len(square)

    # Find sum of first row
    total = sum(square[0])

    # Error checking
    for row in square:
        # Check if rows all have same number of columns
        if len(row) != n:
            return "Invalid data: missing or repeated number"
        # Check for any repeated numbers
        for col in row:
            if repeated_number(square, col) == True:
                return "Invalid data: missing or repeated number"
            
    # Check if the total sum of rows or columns are different to total sum 
    # of first row
    for i in range(0, n):
        if total != sum(square[i]) or total != col_sum(square, i):
            return "Not a magic square" 

    # If no errors found, return "Magic square"
    return "Magic square"
