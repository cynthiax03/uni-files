from random import randint

if __name__ == "__main__":
    # loop until user's answer is correct and break
    while True:
        # obtain 2 randome ints
        num_1 = randint(2,12)
        num_2 = randint(2,12)

        # get user's answer
        user_ans = int(input("What is " + str(num_1) + " x " + str(num_2) + "? "))
        
        # if user's answer is correct, break loop
        if user_ans == num_1 * num_2:
            print("Correct!")
            break
        
        # if user's answer is incorrect, keep looping    
        else:
            print("Incorrect - try again.")

