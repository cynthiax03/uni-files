def roman(numerals):
    pass
