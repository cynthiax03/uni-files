from datetime import date, time, datetime

def timetable(dates, times):
    pass
