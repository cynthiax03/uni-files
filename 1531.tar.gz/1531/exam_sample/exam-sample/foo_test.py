from hypothesis import given, strategies
from foo import foo

# Note, the tests here use lists of integers, but the properties are true for
# all lists.

@given(strategies.lists(strategies.integers()))
def test_prop1(values):
    assert foo(foo(values)) == values

@given(strategies.lists(strategies.integers()), strategies.lists(strategies.integers()))
def test_prop2(values1, values2):
    assert foo(values1 + values2) == foo(values2) + foo(values1)

