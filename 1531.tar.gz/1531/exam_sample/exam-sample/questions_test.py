'''
Tests for the lecture question asking service.
'''
from questions import submit, like, dismiss, questions, clear

def test_simple():
    clear()
    q1 = submit("How long is a piece of string?")
    q2 = submit("What's your shoe size?")
    like(q1)
    assert questions() == [
        {"id": q1, "question": "How long is a piece of string?", "likes": 1},
        {"id": q2, "question": "What's your shoe size?", "likes": 0}
    ]

# Write your tests here
def test_1():
    clear()
    q1 = submit("Hi Justin")
    q2 = submit("Ur cute")
    like(q2)
    like(q2)
    q3 = submit("Just copy paste")
    dismiss(q3)
    assert questions() == [
        {"id": q2, "question": "Ur cute", "likes": 2},
        {"id": q1, "question": "Hi Justin", "likes": 0}
    ]