def foo(values):
    values.reverse()
    return values

# if __name__ == "__main__":
#     print(foo([1,2,3,4]))
