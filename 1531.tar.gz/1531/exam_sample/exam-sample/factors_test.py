from factors import factors

def factors_dryrun():
	assert factors(16) == [2, 2, 2, 2]
