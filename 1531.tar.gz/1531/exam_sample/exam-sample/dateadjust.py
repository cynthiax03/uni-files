from datetime import datetime
from datetime import timedelta

def adjust(weeks, hours, string):

    if abs(weeks) > 50 or abs(hours) > 50:
        raise ValueError

    total_hours = hours + (weeks * 7 * 24)

    given_time = datetime.strptime(string, "%H:%M on %d %B %Y")

    time = given_time + timedelta(hours=total_hours)

    hours_minutes = time.strftime("%H:%M")

    final_date = time.strftime("%d %B %Y")

    return f"{hours_minutes} on {final_date}"

if __name__=="__main__":
    print(adjust(4,4, "16:40 on 28 January 2021"))
