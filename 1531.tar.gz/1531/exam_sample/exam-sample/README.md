Please see [](https://gitlab.cse.unsw.edu.au/COMP1531/21T3/exam-sample-spec)
