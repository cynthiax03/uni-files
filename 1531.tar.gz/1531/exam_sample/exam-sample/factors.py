import math

def factors(num):
    pass
