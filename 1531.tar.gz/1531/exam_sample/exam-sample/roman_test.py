from roman import roman

def test_dryrun():
	assert roman("I") == 1

def test_five():
	assert roman("V") == 5

def test_ten():
	assert roman("X") == 10

def test_twenty():
	assert roman("XX") == 20

def test_fifty():
	assert roman("L") == 50

def test_hundred():
	assert roman("C") == 100

def test_thousand():
	assert roman("M") == 1000

def test_random():
	assert roman("XVII") == 18
	assert roman("XIX") == 19
	assert roman("XCIX") == 99
