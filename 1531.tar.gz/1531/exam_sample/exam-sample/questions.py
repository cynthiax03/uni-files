'''
The backend for the lecture question asking application.

Each question is assigned an ID number when it is submitted to the app. This ID
can then be used to like and dismiss the question. The numbers are always
positive, but otherwise follow no defined ordering or structure. Questions have
the same ID from when they are submitted till they are dismissed.

When questions are first submitted, they have 0 likes.
'''

# Put any global variables your implementation needs here
q_list = []
q_ids = 0

def submit(question):
    '''
    Submits a question to the service.

    Returns the ID of the question but yields a ValueError if question is an
    empty string or exceeds 280 characters in length.
    '''
    if len(question) < 1 or len(question) > 280:
        raise ValueError('Question must be between 1 and 280 characters')

    global q_ids
    q_id = q_ids
    q_ids += 1

    q_dict = {
        'id': q_id,
        'question': question,
        'likes': 0
    }

    global q_list
    q_list.append(q_dict)

    return q_id

def questions():
    '''
    Returns a list of all the questions.

    Each question is represented as a dictionary of {id, question, likes}.

    The list is in order of likes, with the most liked questions first. When
    questions have the same number of "likes", their order is not defined.
    '''
    # Hint: For this question, there are still marks available if the returned
    # list is in the wrong order, so do not focus on that initially.

    sorted(q_list, key=lambda d: d['likes'])
    q_list.reverse()
    return q_list

def clear():
    '''
    Removes all questions from the service.
    '''
    global q_list
    q_list = []

def get_q(id):
    for q in q_list:
        if q['id'] == id:
            return q

def does_q_id_exist(id):
    for q in q_list:
        if q['id'] == id:
            return True
    return False

def like(id):
    '''
    Adds one "like" to the question with the given id.

    It does not return anything but raises a KeyError if id is not a valid
    question ID.
    '''
    if not does_q_id_exist(id):
        raise KeyError('ID does not exist')

    q_dict = get_q(id)
    q_dict['likes'] += 1

def dismiss(id):
    '''
    Removes the question from the set of questions being stored.

    It does not return anything but raises a KeyError if id is not a valid
    question ID.
    '''
    if not does_q_id_exist(id):
        raise KeyError('question ID does not exist')

    global q_list
    index = 0
    for q in q_list:
        if q['id'] == id:
            del q_list[index]
        index += 1
