# def plus_one(number):
#     def add_one(number):
#         return number + 1

#     return add_one(number)

# if __name__ == "__main__":
#     print(plus_one(42))


# Arguments can either be keyword args or non keyword args,
# *args is a list of non-keyword args (positional args)
# **kwargs is a dict of keyword args
# non-keyword args cannot be passes after keyword args
# The z-id=None is a default arg, if no zid is given, it will default to None
# def foo(zid=None, name=None, *args, **kwargs):
#     print(zid, name)
#     print(args) # A list
#     print(kwargs) # A dictionary

# if __name__ == '__main__':
    
#     foo('z3418003', None, 'mercury', 'venus', 'hello', planet1='earth', planet2='mars', planet3='earth')

# def make_uppercase(function):
# 	def wrapper(*args, **kwargs):
# 		return function().upper()
# 	return wrapper

# @make_uppercase
# def get_first_name():
# 	return "Hayden"

# @make_uppercase
# def get_last_name():
# 	return "Smith"

# if __name__ == '__main__':
#     print(get_first_name())
#     print(get_last_name())

# import sys

# MESSAGE_LIST = []

# def authorise(function):
#     """ Alternative solution
#     def wrapper(*args, **kwargs):
#         authToken = args[0]
#         if authToken != "CrocodileLikesStrawberries":
#             raise ValueError("Invalid authentication")
#         return function(*args[1:])
#     return wrapper
#     """
#     def wrapper(auth_token, *args, **kwargs):
#         if auth_token != 'CrocodileLikesStrawberries':
#             raise Exception('Invalid token')
#         return function(*args, **kwargs)
#     return wrapper


# @authorise
# def get_message():
#     return MESSAGE_LIST

# @authorise
# def add_message(msg):
#     global MESSAGE_LIST
#     MESSAGE_LIST.append(msg)

# if __name__ == '__main__':
#     authToken = ""
#     if len(sys.argv) == 2:
#         authToken = sys.argv[1]

#     add_message(authToken, "Hello")
#     add_message(authToken, "How")
#     add_message(authToken, "Are")
#     add_message(authToken, "You?")
#     print(get_message(authToken))

# def decorator(function):
#         def wrapper(*args, **kwargs):
#             return function(*args, **kwargs).upper()
#         return wrapper

# @decorator
# def alphabet():
#     return "abcd"

# if __name__ == '__main__':
#     print(alphabet())

# List comprehension
# if __name__ == '__main__':
#     list1 = [1,2,3,4,5,6,7]
#     list2 = [k + 5 for k in list1]
#     print(list2)

# Mapping
# def addition(n):
#     return n + n
  
# # We double all numbers using map()
# if __name__ == '__main__':
#     numbers = (1, 2, 3, 4)
#     result = map(addition, numbers)
#     print(list(result))

def myfunc(a, b):
  return a + b + a

if __name__ == '__main__':
    x = map(myfunc, ('apple', 'banana', 'cherry'), ('orange', 'lemon', 'pineapple'))

    print(x)

    #convert the map into a list, for readability:
    print(list(x))





