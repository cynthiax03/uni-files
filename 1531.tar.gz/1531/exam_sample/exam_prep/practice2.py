def acro(input):
    # Extract the words
    words = name.strip().split(' ')

    # Could also use list comprehension
    # acronym_list = [word[0].upper for word in words]
    # acronym = acronym_list.join()
    # return acronym
    
    # Calculate the acronym
    acronym = ''
    for word in words:
        acronym += word[0].upper()

    return acronym

if __name__ == '__main__':
    name = input('What is the name? ')
    print(f"Its acronym is {acro(name)}.")

# Similar thing was in exam just had to remove vowels in acronym and 
# included some other error checking
    