from practice2 import acro
import pytest

def test_1():
    
    assert acro('University of New South Wales') == 'UONSW'
    assert acro('Kensington Campus') == "KC"
    assert acro('hello hello hello hello') == 'HHHH'
    assert acro('goodbye goodbye goodbye') == "GGG"
    assert acro('moodle moodle moodle') == "MMM"


# with pytest.raises(ErrorType) for error checking
