# COMP1531 Sample Exam

For this exam you are provided with this public repostory (`exam-spec`) that all students are provided that includes the questions being asked. You will then also have your own [personal exam repository](https://cgi.cse.unsw.edu.au/~cs1531/redirect/?path=COMP1531/21T3/students/_/exam-sample) where you actually answer and submit these questions to.

If you are seeking information not provided in this file, check the COMP1531 Exam Brief page on Webcms3.

## Part 1. Cloning your repository

Please clone your [personal exam repository](https://cgi.cse.unsw.edu.au/~cs1531/redirect/?path=COMP1531/21T3/students/_/exam-sample).

## Part 2. Questions - Short Answer (15%)

For each of these questions answer in the relevant text file.

### Question 1 (3 marks)

In your personal exam repository, answer this question in `q1.txt`

**Q. Describe and justify three attributes of good requirements.**

### Question 2 (3 marks)

In your personal exam repository, answer this question in `q2.txt`

**Q. Break the following elicited requirements into a list of atomic dot points. Remove or consolidate any unnecessary or distracting information**

*How could we clean this up into well described requirements? "I want a burger with lots of pickles and mayo but I need to make sure that the mayo doesn't make the burger bun really wet. Oh, and it needs t obe warm, like, made less than 5 minutes ago warm but not so hot that I burn myself. I'm also not a big fan of plastic containers so if it could be in a paper bag that would be good. Actually, make that a brown paper bag, I like the colour of that"*

### Question 3 (2 marks)

In your personal exam repository, answer this question in `q3.txt`

**Q. Describe they difference between Continuous Delivery and Continuous Deployment. For each, provide an clear and specific example of their usage.**

### Question 4 (3 marks)

In your personal exam repository, answer this question in `q4.txt`

**Q. Describe the key differences between JSON and YAML as data transfer objects. What is an advantage of JSON compared to usage of YAML? What is an advantage of YAML compared to use of JSON?**

### Question 5 (2 marks)

In your personal exam repository, answer this question in `q5.txt`

"The user shall be able to change their password if they forget it"

**Q. If you saw this statement written down on an engineering document, what part of the SDLC would you assume this statement was created in? Justify your response.**

### Question 6 (2 marks)

In your personal exam repository, answer this question in `q6.txt`

**Q. Write a user story to capture the follow raw requirement: *"I really hate how long it takes the gates at train stations to open. I tap on but it just takes forever, and then I'm not sure whether it's working or not. I tap my opal card, and then there is always a delay. I wish it didn't take so long so that I didn't question every single day whether my opal card is working or not. If it happened quicker I'd also feel like I wasn't just another university student about to get trampled by some giant man behind me"***

## Part 3. Questions - Programming Questions (85%)

These questions involve you writing python implementations, and in some cases writing python tests with `pytest`.

### Question 7 (12 marks)

In your personal exam repository, answer this question in `timetable.py`

Complete the function `timetable(dates, times)` where given a list of dates and list of times, generates and returns a list of datetimes. All possible combinations of date and time are contained within the result. The result is sorted in chronological order.

Write tests for this function using pytest, and include them in `timetable_test.py`.

You will receive 50% of your marks from the correctness of your implementation, 25% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage of your tests.

You can determine your branch coverage by running `coverage run -m pytest timetable_test.py` 

### Question 8 (12 marks)

In your personal exam repository, answer this question in `factors.py`

Complete the function `factors(num)` that factorises a number into its prime factors. The primes should be listed in ascending order.

Write tests for this function using pytest, and include them in `factors_test.py`.

You mark for this question will be `i * c` where `i` is the mark awarded for the correctness of your implementaiton and `c` is the mark awarded for the branch coverage of your tests on your own implementation. If your branch coverage is less than 50% we will 

You will receive 50% of your marks from the correctness of your implementation, 25% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage.

You can determine your branch coverage by running `coverage run -m pytest factors_test.py` 

### Question 9 (12 marks)

In your personal exam repository, answer this question in `roman.py`

Complete the function `roman(numerals)`. Given a string, this function returns their value as an integer. You may assume the Roman numerals are in the "standard" form, i.e. any digits involving 4 and 9 will always appear in the subtractive form.

Write tests for this function using pytest, and include them in `roman_test.py`.

You will receive 50% of your marks from the correctness of your implementation, 25% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage.

You can determine your branch coverage by running `coverage run -m pytest roman_test.py` 

### Question 10 (12 marks)

In your personal exam repository, answer this question in `dateadjust.py` and `dateadjust_test.py`

Complete the function `adjust` in `dateadjust.py` that takes in 3 values:
 * A positive or negative integer that describes a number of "weeks". A positive number implies that we want to go forward into the future by that number of weeks. A negative number describes going into the past by that number of weeks.
 * A positive or negative integer that describes a number of "hours". A positive number implies that we want to go forward into the future by that number of hours. A negative number describes going into the past by that number of hours.
 * A string that contains a date in a format consistent with "04:40 on 1 February 2020", "16:01 on 22 February 2020", or "12:33 on 2 March 1998" etc)

The function takes in these values, and "adds" the number of weeks and hours to the time/date passed in.

For example,
```adjust(4, 4, '16:40 on 28 January 2021')``` would return the string ```'20:40 on 25 February 2021'```, because the original date (`16:40, 28 January 2021`) has been increased by 4 weeks and 4 hours into the future (a total of 676 hours into the future).

Write tests for this function in the file `dateadjust_test.py`.

The function should throw a `ValueError` (irrelevant what message is contained in it) if:
 * The `weeks` or `hours` value passed in has an absolute value greater than 50

You can assume that when increasing or decreasing the date & time, that you can round the increase or decrease to the nearest minute. You can assume that the date and time will be in the correct format, and that having ` on ` between the time and date is a consistent pattern you can rely on.

We recommend you make heavy use of the python `datetime` library and utilise its library functions (hint: check out `strptime()`) Attempting to use custom logic will likely result in a wastage of time or an incorrect program produced. Regular expressions (for those who know what they are) are also _not necessary_ for a solution to this question.

You will receive 50% of your marks from the correctness of your implementation, 25% from the ability of your tests to identify correct and incorrect implementations, and 25% of your marks from your branch coverage.

To run your tests you can run `pytest dateadjust_test.py`

To run coverage you can run `coverage run -m pytest dateadjust_test.py` followed by `coverage report`

### Question 11 (7 marks)

In your personal exam repository, answer this question in `foo.py`.

The function `foo(values)` takes in a list `values` and returns a new list. In `foo_test.py` there are two property-based tests for this. Using the properties described in the tests, infer the behaviour of the function and implement it in `foo.py`. There is no need to make any changes to `foo_test.py`.

You will receive 100% of your marks from the correctness of your implementation.

To run your tests you can run `pytest foo_test.py`

### Question 12 (30 marks)

For this task you will be implementing the backend for a web application that lets students ask questions of the lecturer during lectures. In addition to the posting and displaying of questions, the web app also supports "liking" questions, so that the most liked questions can be displayed first; and dismissing questions, so that the lecturer can remove questions once they have been answered.

It is recommended that you work on each of the questions below in order, but you can skip ahead if you wish. This question will be automarked, so make sure you follow any and all instructions relating to the type or structure of the data you need to accept as input or return as output.

#### 12.1. Backend (10 marks)

In `questions.py` there is an incomplete series of functions for implementing this question asking service. Implement these functions so that they match the documentation. This will be automarked, so ensure that your functions meet the specifications. Do NOT add additional arguments to the functions or rename them.

Partial marks are available for only implementing some of the functions.

#### 12.2. Testing (10 marks)

In `questions_test.py` there is one simple test. In this file, write further tests to ensure that your implementation in `questions.py` is correct.

For marking, your tests will be run against implementations other than your own, so they should make no assumptions about how the functions work beyond what is in their documentation and the documentation at the top of `questions.py`. To get full marks, your tests should have 100% branch-coverage for your implementation.

To run your tests you can run `pytest questions_test.py`

To run coverage you can run `coverage run -m pytest questions_test.py` followed by `coverage report`

#### 12.3. Flask (10 marks)

In `server.py` implement a flask wrapper for the question asking service. The endpoints are described in comments in the file.

You can run your server with:
```bash
python3 server.py
```

To ensure it works as expected, use an API client to send the server requests.

Note that marks for this question are based on whether your server behaves in the same way as your backend implementation, so it is still possible to get full marks even if your backend does not meet the specifications in their entirety. Partial marks are also available for only implementing some endpoints.

















































## Submission

At the end of your specified exam time, we will automatically collect the code on your `master` branch's HEAD (i.e. latest commit).

Please note: If you develop locally ensure you check that your code works on the CSE servers. Failure to do so could result in a fail mark in the exam.

## Originality of Work

The work you submit must be your own work. Submission of work partially or completely derived from any other person or jointly written with any other person is not permitted.

The penalties for such an offence may include negative marks, automatic failure of the course and possibly other academic discipline. Assignment submissions will be examined both automatically and manually for such submissions.

Relevant scholarship authorities will be informed if students holding scholarships are involved in an incident of plagiarism or other misconduct.

Do not provide or show your exam work to any other person — apart from the teaching staff of COMP1531.

If you knowingly provide or show your assignment work to another person for any reason, and work derived from it is submitted, you may be penalized, even if the work was submitted without your knowledge or consent.  This may apply even if your work is submitted by a third party unknown to you.

Note you will not be penalized if your work has the potential to be taken without your consent or
knowledge.
