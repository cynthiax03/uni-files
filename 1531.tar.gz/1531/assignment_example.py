# '''
# example_list = ["a", "b", "c", "d", "e", "f"]
# copy = example_list
# print(example_list)
# del copy[0]
# del copy[1]
# print(example_list)
# '''

# # import re 
# # bad_string = "ABC%^&*%*&"
# # bad_string = re.sub(r'[^a-zA-Z0-9]', '', bad_string)
# # bad_string = bad_string.lower()
# # print(bad_string)

# import time
# import datetime
# d = datetime.datetime.now()

# unixtime = int(time.mktime(d.timetuple()))

# print(unixtime)

# data =             {
#             'messages': [
#                 {
#                     'message_id': 1,
#                     'u_id': 4,
#                     'message': "Welcome to COMP1531",
#                     'time_created': 200
#                 },
#                 {
#                     'message_id': 2,
#                     'u_id': 3,
#                     'message': "The first lecture will be on Wednesday 10am",
#                     'time_created': 800
#                 },
#                 {
#                     'message_id': 3,
#                     'u_id': 2,
#                     'message': "Lecture slides can be found on webcms3",
#                     'time_created': 900
#                 },
#                 {
#                     'message_id': 4,
#                     'u_id': 1,
#                     'message': "If you've got questions, post them on the ed forum",
#                     'time_created': 100
#                 }],
#             'start': 0,
#             'end': -1
#         }

# print(data['messages'][2]['message_id'])

# dict1 = {'hello': 'world', 1: 2}

# if 'hello' in dict1:
#     print(dict1)

# for pair in dict1:
#     if 'hello' == pair:
#         print(pair)
#         del dict1[pair]
#         break

# list1 = [{'hello': 'world'}, {1:2}]
# print(list1)
# message1 = list1[0]
# for element in list1:
#     if element == message1:
#         list1.remove(element)
#         break

# print(list1)

# if 1 == 1:
#     print('one')
# elif 2==2:
#     print('two')

# import jwt
# import uuid

# SECRET = "helloworld"

# def generate_new_session_id():
    
#     '''
#     Generates a new sequential session ID
#     Args:
#         None
#     Returns:
#         number: The next session ID
#     '''
    
#     # Generate a random uuid
#     generated_session_id = str(uuid.uuid1())
#     return generated_session_id


# def generate_jwt(username, session_id=None):
    
#     '''
#     Generates a JWT using the global SECRET
#     Args:
#         username ([string]): The username
#         session_id ([string], optional): The session id, if none is provided will
#                                          generate a new one. Defaults to None.
#     Returns:
#         string: A JWT encoded string
#     '''
    
#     if session_id is None:
#         session_id = generate_new_session_id()
    
#     # Note: HS256 is the signing algo, which signs the entire jwt to check wheter 
#     # its valid
#     # SECRET is required to decode the jwt, ensuring third parties cant generate jwt 
#     # for this project
#     return jwt.encode({'username': username, 'session_id': session_id}, 
#                       SECRET, algorithm='HS256')

# def decode_jwt(encoded_jwt):
    
#     '''
#     Decodes a JWT string into an object of the data
#     Args:
#         encoded_jwt ([string]): The encoded JWT as a string
#     Returns:
#         Object: An object storing the body of the JWT encoded string
#     '''
    
#     # returns the body of decoded jwt
#     return jwt.decode(encoded_jwt, SECRET, algorithms=['HS256'])

# session_id = generate_new_session_id()

# encoded = generate_jwt("hello", session_id)

# print(encoded)

# print(decode_jwt(encoded))

# dict1 = {'m_id': 0}

# if 1 != 1 and dict1['u_id'] == 0:
#     print(working) 

# import pickle

# DATA_STRUCTURE = {
#     'names': [
#         {
#             'first' : 'Bob',
#             'last' : 'Carr'
#         },
#         {
#             'first' : 'Julia',
#             'last' : 'Gillard'
#         },
#         {
#             'first' : 'Ken',
#             'last' : 'Henry'
#         },
#     ]
# }

# with open('export.p', 'wb') as FILE:
#     pickle.dump(DATA_STRUCTURE, FILE)

# DATA = pickle.load(open("export.p", "rb"))
# print(DATA)

import re

my_string ="@justin @cynthia hello@gmdisl noob@@@h@t!!!!"
handle = re.split('[@]', my_string)
print(handle)
new_list = []
for thing in handle:
    new_list.append(re.split('[^a-zA-Z0-9]', thing)[0])

print(new_list)

new_new_list = []
for thing in new_list:
    if thing != "":
        new_new_list.append(thing)

print(new_new_list)


# print(re.split('[^a-zA-Z]', "@a*b*c*d"))

# my_string ="@justin @cynthia hello@gmdisl @@@h@t!!!!"
# handle = re.split('[^a-zA-Z0-9@]', my_string)
# print(handle)
# for word in handle:
#     if "@" not in word:
#         handle.remove(word)
# index = 0

# new_list = []
# for word in handle:
#     word = word.split("@")
#     new_list.extend(word)

# print(new_list)

# new_new_list = []
# for thing in new_list:
#     if thing != "":
#         new_new_list.append(thing)

# print(new_new_list)

# my_string = my_string.split("@",1)[1]
# print(my_string) 
# handles = re.split('[^a-zA-Z]', my_string)
# print(handles[0])

# handles_list = []
# for char in my_string:
#     print(my_string)
#     if char == "@":
#         string = my_string.split("@", 1)[1]
#         handle = re.split('[^a-zA-Z0-9@]', string)
#         handle = handle[0] 
#         if handle != "":
#             handles_list.append(handle)
#     my_string = my_string.replace(char, "")

#@justin @cynthia
#@justin!@cynthia
#@justin blah

# print(handles_list)

