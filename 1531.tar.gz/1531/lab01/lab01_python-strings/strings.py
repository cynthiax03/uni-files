'''
TODO Complete this file by following the instructions in the lab exercise.
'''

if __name__ == "__main__":
    strings = ['This', 'list', 'is', 'now', 'all', 'together']
    
    # declare the string
    # string = ""

    # spaces = 0
    
    # for loop that iterates through the strings list
    # for item in strings:
        # if spaces < 5:
            # string += item
            # string += " "
            # spaces += 1
        
        # so there isn't a space at the end of the string
        # else:
            # string += item

    # print(string) 

    # shortcut for the above code
    print(' '.join(strings))


