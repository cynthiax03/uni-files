'''
TODO Complete this file by following the instructions in the lab exercise.
'''

if __name__ == "__main__":
    integers = [1, 2, 3, 4, 5]

    sum_1 = 0

    # add 6 to the end of the list
    integers.append(6)

    # loop through the list adding together each number
    for i in integers:
        sum_1 += i

    # print the final sum
    print(sum_1)

    # should do the same thing as above
    print(sum(integers))
