if __name__ == "__main__":
    name = input("Name: ")
    print("So you call yourself " + name + " huh?")
