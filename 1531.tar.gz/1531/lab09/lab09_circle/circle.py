import math

class Circle:
    
    def __init__(self, r):
        
        # If r is negative, raise a Value Error
        if r < 0: 
            raise ValueError

        self.r = r 

    # Instance methods
    def circumference(self):
        
        return 2 * self.r * math.pi

    def area(self):

        return math.pi * self.r ** 2
