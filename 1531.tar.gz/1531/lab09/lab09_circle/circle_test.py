from re import L
from circle import Circle
import pytest

def test_small():
    c = Circle(3)
    assert(round(c.circumference(), 1) == 18.8)
    assert(round(c.area(), 1) == 28.3)

def test_big():
    c = Circle(439)
    assert(round(c.circumference(), 1) == 2758.3)
    assert(round(c.area(), 1) == 605450.9)

    c = Circle(3940)
    assert(round(c.circumference(), 1) == 24755.8)
    assert(round(c.area(), 1) == 48768827.7)

def test_1():
    c = Circle(1)
    assert(round(c.circumference(), 1) == 6.3)
    assert(round(c.area(), 1) == 3.1)

def test_0():
    c = Circle(0)
    assert(round(c.circumference(), 1) == 0)
    assert(round(c.area(), 1) == 0)

def test_negative():
    with pytest.raises(ValueError):
        Circle(-5)
        Circle(-1000)
        Circle(-2343434343)

