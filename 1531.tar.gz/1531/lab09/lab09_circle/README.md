## Lab04 - Exercise - Circle (1 point)

Complete the class `Circle` in `circle.py` that:
 * has one attribute r (for radius) and two instance methods:
   * circumference (which returns the circumference of the circle)
   * area (which returns the area of the circle).

A basic test has been written in `circle_test.py`. Write more tests in this file.

Ensure your tests have 100% coverage. Ensure your code is pylint compliant.
