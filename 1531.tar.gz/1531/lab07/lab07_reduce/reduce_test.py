from reduce import reduce

def test_reduce_sum_ints_1():
    assert reduce(lambda x, y: x + y, [1,2,3,4,5]) == 15

def test_reduce_sum_ints_2():
    assert reduce(lambda x, y: x + y, [23, 432, 555, 2]) == 1012

def test_reduce_multiplication_ints_1():
    assert reduce(lambda x, y: x * y, [1, 2, 3, 4, 5]) == 120

def test_reduce_multiplication_ints_2():
    assert reduce(lambda x, y: x * y, [3, 5, 45, 3]) == 2025

def test_reduce_subtraction():
    assert reduce(lambda x, y: x - y, [20, 9, 3, 2]) == 6

def test_reduce_division():
    assert reduce(lambda x, y: x / y, [45, 9, 5]) == 1

def test_reduce_sum_alphabets():
    assert reduce(lambda x, y: x + y, 'abcdefg') == 'abcdefg'

def test_reduce_empty_list():
    assert reduce(lambda x, y: x + y, []) == None

def test_reduce_one_element_alphabet():
    assert reduce(lambda x, y: x + y, 'a') == 'a'

def test_reduce_one_element_int():
    assert reduce(lambda x, y: x + y, [5]) == 5