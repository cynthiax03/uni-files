def reduce(f, xs):
    
    # If list is empty return None
    if len(xs) == 0:
        return None

    # If list has only one element, return the first element
    elif len(xs) == 1:
        return xs[0]

    # If list is >= 2, f is called on first 2 elements and the return is used 
    # with the next value from the list to call f again, this repeats until 
    # the list xs is empty
    else:
        ret = f(xs[0], xs[1])
        for i in range(2, len(xs)):
            ret = f(ret, xs[i])

        return ret

# if __name__ == '__main__':
#     print(reduce(lambda x, y: x + y, [1,2,3,4,5]))
#     print(reduce(lambda x, y: x * y, [1,2,3,4,5]))