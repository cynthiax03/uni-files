import numpy

def drykiss(my_list):
    
    # Calculate product of first 4 elements
    product1 = numpy.prod(my_list[0:4])

    # Calculate product of last 4 elements
    product2 = numpy.prod(my_list[1:5])

    return (min(my_list), product1, product2)

if __name__ == '__main__':

    # Get inputs and results
    result = drykiss([
                        int(input("Enter a: ")), 
                        int(input("Enter b: ")), 
                        int(input("Enter c: ")),
                        int(input("Enter d: ")),
                        int(input("Enter e: "))
                    ])

    print(f"Minimum: {str(result[0])}\n \
            Product of first 4 numbers:  {result[1]}\n \
            Product of last 4 numbers  {result[2]}")
