from fibonacci import fib

def test_fibonacci_zero():
    assert fib(0) == [0]

def test_fibonacci_one():
    assert fib(1) == [0, 1]

def test_fibonacci_two():
    assert fib(2) == [0, 1, 1]

def test_fibonacci_ten():
    assert fib(10) == [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]

def test_fibonacci_twelve():
    assert fib(12) == [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]