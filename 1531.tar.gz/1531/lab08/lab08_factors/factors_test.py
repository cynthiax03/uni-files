from factors import factors, is_prime
from hypothesis import given, strategies, settings, Verbosity
import pytest
from functools import reduce

def test_one_factor():
    assert factors(19) == [19] 
    assert factors(17) == [17]
    assert factors(2) == [2]

def test_is_prime():
    assert is_prime(2) == True

def test_many_factors():
    assert factors(16) == [2, 2, 2, 2]
    assert factors(12) == [2, 2, 3]
    assert factors(32) == [2, 2, 2, 2, 2]
    assert factors(48) == [2, 2, 2, 2, 3]
    assert factors(49) == [7, 7]
    assert factors(15) == [3, 5]

def test_edge_cases():
    with pytest.raises(ValueError):
        factors(1)
    with pytest.raises(ValueError):
        factors(0)
    with pytest.raises(ValueError):
        factors(-3849)

@given(strategies.integers(min_value=2, max_value=999))
@settings(verbosity=Verbosity.verbose)
def test_property_based_testing(n):
    # Check that all factors multiplied together gives the original number
    assert reduce(lambda x,y: x*y, factors(n)) == n

    # Test that all factors returned are prime
    for factor in factors(n):
        assert is_prime(factor) == True 
