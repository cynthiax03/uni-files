def divisors(n):
    divisors_list = []
    for i in range(1, n + 1):
        if n % i == 0:
            divisors_list.append(i)
    return divisors_list

# You may find this helpful
def is_prime(n):
    return n != 1 and divisors(n) == [1, n]

def factors(n):
    '''
    A function that generates the prime factors of n. For example
    >>> factors(12)
    [2,2,3]

    Params:
      n (int): The operand

    Returns:
      List (int): All the prime factors of n in ascending order.

    Raises:
      ValueError: When n is <= 1.
    '''

    if n <= 1:
	    raise ValueError("n must be greater than 1")

    i = 2
    factors_list = []

    # https://stackoverflow.com/questions/15347174/python-finding-prime-factors
    # while n is divisible by a number smaller than sqrt(n)
    while i * i <= n:
        
        # If n not divisible by i, check next i
        if n % i:
            i += 1
        
        # Else n is divisible by i, append
        else:
            n = int(n / i)
            factors_list.append(i)
    
    # Only append numbers greater than 1
    if n > 1:
        factors_list.append(n)

    return factors_list

# if __name__ == '__main__':
#     print(factors(32))
#     print(divisors(7))
#     print(is_prime(7))
	
