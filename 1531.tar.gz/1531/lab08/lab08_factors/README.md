## Lab08 - Exercise - Factors (2 points)

In `factors.py`, complete the definition of `factors()` according to its documentation.

Consider what property, or properties, would form a **complete** definition of this function and write them as property-based tests in `factors_test.py`.
