from inverse import inverse
from hypothesis import given, strategies, settings, Verbosity

def swap_values(dict):
    new_dict = {}
    for key in dict:
        value = dict[key]
        if value in new_dict:
            new_dict[value].append(key)
        else:
            new_dict[value] = [key]
    return new_dict

def test_inverse_simple():
    assert inverse({1: 'A', 2: 'B', 3: 'A'}) == {'A': [1, 3], 'B': [2]}
    assert inverse({1: 'A', 2: 'B', 3: 'A', 4: 'B'}) == {'A': [1, 3], 'B': [2, 4]}

# Property based testing
@given(strategies.dictionaries(keys=strategies.integers(),
                               values=strategies.integers(), 
                               min_size=1))
@settings(verbosity=Verbosity.verbose)
def test_property_based_testing(dict):
    assert inverse(dict) == swap_values(dict)

