## Lab08 - Exercise - Inverse (1 point)

In `inverse.py`, complete the definition of the function according to its documentation. Consider what property, or properties, would form a complete definition of this function and write them as property-based tests in `inverse_test.py`.
