import sys

MESSAGE_LIST = []

def authorise(function):
    """
    You need a function here authorise which contains another function called wrapper.
    This wrapper function authenticates the token against CrocodileLikesStrawberries and if valid calls the function given as input,
    authorise then needs to return wrapper.
    """
    def wrapper(auth_token, *args, **kwargs):
        if auth_token != "CrocodileLikesStrawberries":
            raise Exception("Invalid token")
        return function(*args, **kwargs)
    return wrapper

@authorise
def get_messages():
    return MESSAGE_LIST

@authorise
def add_messages(msg):
    global MESSAGE_LIST
    MESSAGE_LIST.append(msg)

if __name__ == '__main__':
    auttoken = ""
    if len(sys.argv) == 2:
        authtoken = sys.argv[1]

    add_messages(auttoken, "Hello")
    add_messages(authtoken, "How")
    add_messages(authtoken, "Are")
    add_messages(authtoken, "You?")
    print(get_messages(authtoken))
