Please note: If you are looking at this repo before the exam start, you will need to wait until exam start to see the spec link below.

Please see the exam spec [here](https://gitlab.cse.unsw.edu.au/COMP1531/21T3/exam-spec).
