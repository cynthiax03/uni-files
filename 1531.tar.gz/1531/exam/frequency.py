def frequency_get(multilinestr):
    multilinestr = multilinestr.replace('!', "")
    multilinestr = multilinestr.replace('?', "")
    multilinestr = multilinestr.replace(';', "")
    multilinestr = multilinestr.replace('.', "")
    multilinestr = multilinestr.replace(',', "")
    multilinestr = multilinestr.replace("[", "")
    multilinestr = multilinestr.replace("]", "")
    multilinestr = multilinestr.replace("{", "")
    multilinestr = multilinestr.replace("}", "")
    multilinestr = multilinestr.replace("(", "")
    multilinestr = multilinestr.replace(")", "")
    multilinestr = multilinestr.replace("-", "")
    
    ret_str = ""
    
    str_list = multilinestr.split()
    str_list.sort()
    dict1 = {}
    for str in str_list:
        if str in dict1:
            dict1[str] += 1
        else:
            dict1[str] = 1

    dict2 = dict(sorted(dict1.items(), key=lambda item: item[1]))

    for k in reversed(list(dict2.keys())):
        ret_str += f"{k.upper()}: {dict1[k]}\n"

    return ret_str
