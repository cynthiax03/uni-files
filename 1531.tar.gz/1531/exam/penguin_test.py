from penguin import validate

def test_1():
    assert validate('P8464Q94944Z')

def test_2():
    assert validate('A1234B12344C')

def test_3():
    assert not validate('A1234567890B')
    assert not validate("1AAAA4AAAAA5")
    assert not validate("A1234B12345C")
    assert not validate("A1234B12355C")
    assert not validate("B1234B12344C")
    assert not validate("B1234C12344C")
    assert not validate("b1234B12344C")
    assert not validate("B1234b12344C")
    assert not validate("B1234B12344c")
    assert not validate('p8464Q94944Z')
    assert not validate('P8464q94944Z')
    assert not validate('P8464Q94944z')

