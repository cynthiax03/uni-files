def mono_check(seq):
    for num in seq:
        if abs(num) > 100000:
            raise ValueError

    if all(elem == seq[0] for elem in seq):
        return "neither"

    sorted_list = list(seq)
    sorted_list.sort()

    if sorted_list == list(seq):
        return "monotonically increasing"

    reverse_list = sorted_list
    reverse_list.reverse()
    
    if reverse_list == list(seq):
        return "monotonically decreasing"

    return "neither"


def monotonic(lists):
    ret_list = []
    for seq in lists:
        if len(seq) < 2:
            raise ValueError
        ret_list.append(mono_check(seq))

    return ret_list



