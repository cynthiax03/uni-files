from re import L
from mono import monotonic
import pytest

n = "neither" 
mi = "monotonically increasing"
md = "monotonically decreasing"

def test_1():
    data = [(1,3,2),(1,2)]
    out = ['neither', 'monotonically increasing']
    assert monotonic(data) == out

def test_neither():
    data = [(1,1,1,1), (1,2,1,1,2,1), (2,2,2,2)] 
    assert monotonic(data) == [n, n, n]

def test_increasing():
    data = [(1,2,3,4,5), (1,1,2,3,4), (99,9999,99999)]
    assert monotonic(data) == [mi, mi,mi]

def test_decreasing():
    data = [(99,98,97,97), (10000,93,93,-200)]
    assert monotonic(data) == [md, md]

def test_out_of_range():
    data1 = [(-10,-1000000)]
    data2 = [(10, 100000000)]
    with pytest.raises(ValueError):
        monotonic(data1)

    with pytest.raises(ValueError):
        monotonic(data2)

def test_not_enough():
    data = [(9,8), (1,)]
    with pytest.raises(ValueError):
        monotonic(data)
        
    

