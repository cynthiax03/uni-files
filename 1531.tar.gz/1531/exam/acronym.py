
def acronym(string):
    a_string = string.split()
    b_string = [word[0] for word in a_string]
    if len(b_string) >= 10:
        return "N/A"
    b_string = "".join(b_string)
    b_string = b_string.upper()
    c_string = ""
    for char in b_string:
        if char not in "AEIOU":
            c_string += char

    return c_string

def acronym_make(inputs):
    if len(inputs) < 1:
        raise ValueError
    ret_list = []
    for string in inputs:
        ret_list.append(acronym(string))

    return ret_list

    
