from acronym import acronym_make
import pytest

def test_1():
    assert acronym_make(['I am very tired today']) == ['VTT']

def test_2():
    assert acronym_make(['A E I O U', 'all in', 'our umbrella']) == ["","",""]
    assert acronym_make(['i like you', 'ver much']) == ['LY', "VM"]

def test_over_ten():
    assert acronym_make(['I AM very very very very very very very very very very tired']) == ['N/A']

def test_error():
    with pytest.raises(ValueError):
        assert acronym_make([]) 

