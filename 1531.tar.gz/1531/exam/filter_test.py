from filter import filter_string
import pytest

def test_1():
    assert(filter_string("Hello, my name is Mr O'Toole.") == "Hello my name is mr otoole")

def test_case_correct():
    assert(filter_string("HI, I AM ;?,.BATMAN!!!!")) == "Hi i am batman"

def test_numbers():
    with pytest.raises(ValueError):
        filter_string("12345")
