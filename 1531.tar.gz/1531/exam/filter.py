def filter_string(inp):
    for c in inp:
        if c.isdigit():
            raise ValueError
    inp = inp.lower()
    inp = inp.replace('!', "")
    inp = inp.replace('?', "")
    inp = inp.replace(';', "")
    inp = inp.replace('.', "")
    inp = inp.replace(',', "")
    inp = inp.replace("'", "")
    inp = inp.capitalize()
    return inp
