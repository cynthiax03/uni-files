def validate(penguin_number):
    
    if not penguin_number[0].isalpha():
        return False
    if not penguin_number[0].isupper():
        return False
    
    index = 1
    while index < 5:
        if not penguin_number[index].isdigit():
            return False
        index += 1
     
    if not penguin_number[5].isalpha():
        return False
    if not penguin_number[5].isupper():
        return False
    
    index = 6
    while index < 11:
        if not penguin_number[index].isdigit():
            return False
        index+=1

    if not penguin_number[11].isalpha():
        return False
    if not penguin_number[11].isupper():
        return False
    
    alpha_string = ""
    sum = 0
    for char in penguin_number:
        if char.isalpha():
            alpha_string += char 
        elif char.isdigit():
            sum += int(char)

    if (sum % 2) != 0:
        return False
    
    first = ord(alpha_string[0])
    sec = ord(alpha_string[1])
    third = ord(alpha_string[2])

    if sec <= first:
        return False 

    if third <= sec:
        return False
    
    if (int(penguin_number[10]) % 2) != 0:
        return False

    return True

