'''
Tests for reverse_words()
'''

import pytest

from reverse import reverse_words

def test_example():
    assert reverse_words(["Hello World", "I am here"]) == ['World Hello', 'here am I']

# test 1
def test_numbers():
    assert reverse_words(["1 2", "3 4"]) == ['2 1', "4 3"]

# test 2
def test_letters():
    assert reverse_words(["a b c", "d e f"]) == ["c b a", "f e d"]

# test 3
def test_one_element():
    assert reverse_words(["one"]) == ["one"]

# test 4
def test_numbers_and_words():
    assert reverse_words(["1 hello 2 world", "3 blue 4 sky"]) == ["world 2 hello 1", "sky 4 blue 3"]

# test 5
def test_symbols():
    assert reverse_words(["& * /", "% #"]) == ["/ * &", "# %"]
