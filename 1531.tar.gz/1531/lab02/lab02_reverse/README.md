## Lab02 - Exercise - Reverse (1 point)

Open `reverse.py` and look at the documentation. Then write at least 5 tests using pytest, and include them in `test_reverse.py`. You should be able to run these tests by just running `pytest` (they will fail).

Open `reverse.py` and complete the function `reverse_words()` so that your tests pass.

The pipeline for this repo currently fails. Once you have written your tests, and implemented `reverse_words()` the pipeline should pass.
