def reverse_words(string_list):
    '''
    Given a list of strings, return a new list where the order of the words is
    reversed
    '''

    # declare a new string
    new_strings = []

    # loop through the items in string_list
    for item in string_list:
        # split up items by space
        words = item.split(" ")
        # reverse the words in each item
        words.reverse()
        # join the words up again with a space in between and append to new_string
        new_strings.append(" ".join(words))

    return new_strings

if __name__ == "__main__":
    print(reverse_words(["Hello World", "I am here"]))
    # it should print ['World Hello', 'here am I']
