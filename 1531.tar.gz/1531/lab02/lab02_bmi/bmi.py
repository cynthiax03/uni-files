if __name__ == "__main__":
    # get weight and height input
    weight = input("What is your weight in kg? ")
    height = input("What is your height in m? ")

    # calculate bmi then round to 1dp
    bmi = int(weight) / (float(height) * float(height))
    bmi = round(bmi, 1)

    # print final bmi
    print("Your BMI is " + str(bmi))

