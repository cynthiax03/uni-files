def count_char(message):
    '''
    Counts the number of occurrences of each character in a string. The result should be a d where the key is the character and the dictionary is its count.

    For example,
    >>> count_char("HelloOo!")
    {'H': 1, 'e': 1, 'l': 2, 'o': 2, 'O': 1, '!': 1}
    '''
    # create an empty d
    d = {}
    for element in message:
        # if this is not the first occurence of the char
        if element in d:
            d[element] += 1
        # if this is the first occurence of the char 
        else:
            d[element] = 1
    return d

if __name__ == "__main__":
    print(count_char("HelloHellou"))
