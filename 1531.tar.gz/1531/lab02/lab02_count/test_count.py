from count import count_char

def test_empty():
    assert count_char("") == {}

def test_simple():
    assert count_char("abc") == {"a": 1, "b": 1, "c": 1}

def test_double():
    assert count_char("aa") == {"a": 2}

# further tests
def test_symbols():
    assert count_char("!!*#") == {"!": 2, "*": 1, "#": 1}

def test_upper_and_lower():
    assert count_char("AaAaA") == {"A": 3, "a": 2}

def test_numbers():
    assert count_char("1223334444") == {"1": 1, "2": 2, "3": 3, "4": 4}

def test_spaces():
    assert count_char("1 1 1 1") == {"1": 4, " ": 3}

def test_mix():
    assert count_char("YYooo 5**") == {"Y": 2, "o": 3, " ": 1, "5": 1, "*": 2}
