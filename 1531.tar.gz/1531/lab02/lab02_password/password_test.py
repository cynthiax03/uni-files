'''
Tests for check_password()
'''
from password import check_password

def test_123456():
    assert check_password("123456") == "Horrible password"

def test_iloveyou():
    assert check_password("iloveyou") == "Horrible password"

def test_password():
    assert check_password("password") == "Horrible password"

def test_strong1():
    assert check_password("IloveRoCK67!") == "Strong password"

def test_strong2():
    assert check_password("***___***HeLl0")

def test_moderate1():
    assert check_password("Hello1234") == "Moderate password"

def test_moderate2():
    assert check_password("cccc44444") == "Moderate password"

def test_poor():
    assert check_password("sheep") == "Poor password"

