def check_password(password):
    '''
    Takes in a password, and returns a string based on the strength of that password.

    The returned value should be:
    * "Strong password", if at least 12 characters, contains at least one number, at least one uppercase letter, at least one lowercase letter.
    * "Moderate password", if at least 8 characters, contains at least one number.
    * "Poor password", for anything else
    * "Horrible password", if the user enters "password", "iloveyou", or "123456"
    '''
    # determine if the password is a "Horrible password"
    if password == "password" or password == "iloveyou" or password == "123456":
        return "Horrible password"
    
    # password is either Strong, Moderate or Poor
    # create counters for lowercase, uppercase and numbers
    lower_counter = 0
    upper_counter = 0
    number_counter = 0

    # loop through the chars in password counting lowercase, uppercase and number chars
    for element in password:
        if ord(element) >= 97 and ord(element) <= 122:
            lower_counter += 1
        elif ord(element) >= 65 and ord(element) <= 90:
            upper_counter += 1
        elif ord(element) >= 48 and ord(element) <= 57:
            number_counter += 1
    
    if len(password) >= 12:
        if lower_counter > 0 and upper_counter > 0 and number_counter > 0:
            return "Strong password"
        elif number_counter > 0:
            return "Moderate password"
        else:
            return "Poor password"
    elif len(password) >= 8:
        if number_counter > 0:
            return "Moderate password"
        else:
            return "Poor password"  
    else:
        return "Poor password"



if __name__ == '__main__':
    print(check_password("ihearttrimesters"))
    # What does this do?
    print(check_password("sheep"))
