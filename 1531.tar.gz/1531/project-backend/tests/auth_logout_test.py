import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")
    

# Test if user token is invalid
def test_logout_invalid_token(clear_data):
    
    logout_response = th.auth_logout(th.invalid_token1())

    assert logout_response.status_code == AccessError.code
    
# Test if user can logout after logging out. 
# Also tests that they can log out after registering
def test_logout_after_logout(clear_data):
    
    register_response = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token = register_response["token"]

    logout_response1 = th.auth_logout(token)
    assert logout_response1.status_code == Success.code

    logout_response2 = th.auth_logout(token)

    assert logout_response2.status_code == AccessError.code


# Test if user can register, logout and log back in
def test_logout_after_registerd_then_login(clear_data):
    # Register
    register_response = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token1 = register_response["token"]

    # Logout
    logout_response1 = th.auth_logout(token1)
    assert logout_response1.status_code == Success.code

    # Login
    login_response = th.auth_login("justin@gmail.com", "password").json()
    token2 = login_response["token"]

    # Can use function
    list_response = th.channels_list(token2)
    assert list_response.status_code == Success.code

    
# Test if multiple users can login and log out
def test_logout_multiple_users(clear_data):
    # Register 3 users
    register_response1 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token1 = register_response1["token"]

    register_response2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token2 = register_response2["token"]

    register_response3 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    token3 = register_response3["token"]

    # Log user 1 and 2 out
    th.auth_logout(token1).json()
    th.auth_logout(token2).json()

    # Check if they can use other functions when logged out
    list_response1 = th.channels_list(token1)
    list_response2 = th.channels_list(token2)
    list_response3 = th.channels_list(token3)

    assert list_response1.status_code == AccessError.code
    assert list_response2.status_code == AccessError.code
    assert list_response3.status_code == Success.code

    

    