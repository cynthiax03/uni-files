import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')


# Test where the token is invalid
def test_channel_invite_invalid_token(clear_data):
    invite_response = th.channel_invite(th.invalid_token1(), 1, 1)
    assert invite_response.status_code == AccessError.code


# Test if InputError is raised if channel_id is not valid
def test_channel_invite_invalid_channel(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    u_id = user2["auth_user_id"]

    # User 1 creates channel
    channel = th.channels_create(token, "comedy", True).json()
    channel_id = channel["channel_id"]

    # Attempt to invite
    invite_response = th.channel_invite(token, channel_id + 1, u_id)
    assert invite_response.status_code == InputError.code


# Test if InputError is raised if u_id is already a member in the channel
def test_channel_invite_already_in(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    u_id = user2["auth_user_id"]

    # User 1 creates channel
    channel = th.channels_create(token, "comedy", True).json()
    channel_id = channel["channel_id"]

    # Invite
    th.channel_invite(token, channel_id, u_id)

    # Invite again
    invite_response = th.channel_invite(token, channel_id, u_id)
    assert invite_response.status_code == InputError.code


# Test if AccessError is raised if channel_id is valid but auth user not member
def test_channel_invite_auth_not_member(clear_data):
    # Register user 1
    user1 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token2 = user2["token"]

    # Register user 3
    user3 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    u_id = user3["auth_user_id"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedycentral", False).json()
    channel_id = channel["channel_id"]

    # User 2 invites user 3
    invite_response = th.channel_invite(token2, channel_id, u_id)
    assert invite_response.status_code == AccessError.code


# Test if channel_invite returns empty dictionary on valid channel_id, auth_user_id
# and u_id
def test_channel_invite_valid(clear_data): 
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    u_id = user2["auth_user_id"]

    # User 1 creates channel
    channel = th.channels_create(token, "comedy", False).json()
    channel_id = channel["channel_id"]

    # Invite
    invite_response = th.channel_invite(token, channel_id, u_id)
    assert invite_response.status_code == Success.code
    assert invite_response.json() == {}


# Test whether channel_invite stores the correct user information
def test_channel_invite_correctly(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    u_id1 = user1["auth_user_id"]
    token = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    u_id2 = user2["auth_user_id"]

    # User 1 creates channel
    channel = th.channels_create(token, "comedy", False).json()
    channel_id = channel["channel_id"]

    # Invite
    th.channel_invite(token, channel_id, u_id2)

    # Check for details
    details = th.channel_details(token, channel_id).json()
    assert details == {
        'name': 'comedy',
        'is_public': False,
        'owner_members': [
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ],
        'all_members': [
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id2,
                'email': 'allan@gmail.com',
                'name_first': 'allan',
                'name_last': 'zhang',
                'handle_str': 'allanzhang',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }


# Test channel_invite works for multiple users
def test_channel_invite_multiple(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    u_id1 = user1["auth_user_id"]
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    u_id2 = user2["auth_user_id"]
    token2 = user2["token"]

    # Register user 3
    user3 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    u_id3 = user3["auth_user_id"]

    # User 1 creates channel
    channel1 = th.channels_create(token1, "comedy.0", False).json()
    channel_id1 = channel1["channel_id"]

    # User 1 creates channel
    channel2 = th.channels_create(token2, "comedy.1", False).json()
    channel_id2 = channel2["channel_id"]

    # Invite user 2 to channel 1
    th.channel_invite(token1, channel_id1, u_id2)
    # Invite user 1 to channel
    th.channel_invite(token2, channel_id2, u_id1)
    # Invite user 3 to both
    th.channel_invite(token1, channel_id1, u_id3)
    th.channel_invite(token2, channel_id2, u_id3)

    # Check for details in channel 1
    details1 = th.channel_details(token1, channel_id1).json()
    assert details1 == {
        'name': 'comedy.0',
        'is_public': False,
        'owner_members': [
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ],
        'all_members': [
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id2,
                'email': 'allan@gmail.com',
                'name_first': 'allan',
                'name_last': 'zhang',
                'handle_str': 'allanzhang',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id3,
                'email': "max@gmail.com",
                'name_first': "max",
                'name_last': "dal",
                'handle_str': "maxdal",
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }

    # Check for details in channel 1
    details2 = th.channel_details(token2, channel_id2).json()
    assert details2 == {
        'name': 'comedy.1',
        'is_public': False,
        'owner_members': [
            {
                'u_id': u_id2,
                'email': 'allan@gmail.com',
                'name_first': 'allan',
                'name_last': 'zhang',
                'handle_str': 'allanzhang',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ],
        'all_members': [
            {
                'u_id': u_id2,
                'email': 'allan@gmail.com',
                'name_first': 'allan',
                'name_last': 'zhang',
                'handle_str': 'allanzhang',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id3,
                'email': "max@gmail.com",
                'name_first': "max",
                'name_last': "dal",
                'handle_str': "maxdal",
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }


# Test if InputError is raised if user invited had been removed
def test_channel_invite_removed_user(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    u_id = user2["auth_user_id"]

    # User 1 creates channel
    channel = th.channels_create(token, "comedy.0", False).json()
    channel_id = channel["channel_id"]

    # Remove user 2
    th.admin_remove(token, u_id)

    # Attempt to invite user 2
    invite_response = th.channel_invite(token, channel_id, u_id)
    assert invite_response.status_code == InputError.code
