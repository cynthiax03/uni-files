import pytest
import requests
from datetime import datetime, timedelta
import time 
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')

# Test if user token is invalid
def test_message_sendlater_dm_invalid_token(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 3)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    dm = th.dm_create(token, []).json()
    dm_id = dm["dm_id"]

    send_response = th.message_sendlaterdm(th.invalid_token1(), dm_id, "hi", time_sent)
    assert send_response.status_code == AccessError.code


# Test if input error is raised if dm_id doesn't refer to a valid dm
def test_invalid_dm_id(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 3)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    send_response = th.message_sendlaterdm(token, 400, "hi", time_sent)
    assert send_response.status_code == InputError.code


# Test if the length of the message is over 1000 characters and an input error is raised
def test_message_length_1000(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 3)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    dm = th.dm_create(token, []).json()
    dm_id = dm["dm_id"]

    message = "87Hon45kXI9hY8fgZ2QaWDRpiAXwfrkSnsdiTEzyf5lDrl8FFgl2yJn2N6OxbBMxXrfgcYMpuzBMkY6hnPkw1iIYlGFGqrsGgrUvON7D59CmAL7W4JWz4TWm8brwt0neKwapugRtfiPgo61MGK7pt5ruSoDSn3VdWDlp7j2JPc5HbhN4fl9E7PTMVzBj4oDDAkBtvpXLLzvUje1rf19NHOAnMDFetQV07fbSm1wYYIczTa2BWw6JldiMwj4Ss0N2JdrdckzEIWv3ZxofZhLJDAaiasMm9kP5m28eLdnKLMCg4XPP9rDSaKHQMPPdf0oNAp1CHWRVEHkF8P4J7zcJOxPepcJ7HI43vobuJYQwP4DG0t9ugco8r5E5QkyBCweU5qLg7gJDrpTohuEvszAvTtRAyFGBy04BVK3PZsUnK5GfILjxtxPZBZwEdmTtAd7tyoTS7ow7KjVT6aSqESMmFcaMtaK0Fr1csaHDVEKBvssEkkKkUOsT9YaS3CWSwVUVXZuEELB6tvkhBzmvjF4uYotxVaiVhFE5lR2SyNHMBuwP3sM6sPtMVWlQQNep3kL3OSi5l7CTRR8Ipcn2jtNbu260YAZ2SAw9YJdb0xzu9B02cYmPbfhzi87gYNe0DAocrmPo8WMLQheZLrbqRhSnxkGU3a1Xf8fZBW80T5RJvZHl0ZaxbKOsBeAK890gUgVtponFFSSB1Pmm4rlUB1hT9ghF6yGv5g5wjFGocN0CcPZuAzss1dKWh5NNEthB9kvzRM8nZMBClde9nJtY3k01ud63Sl7dZ23u7B0x8gFbXzefnStXIgNeUmFfsDqn5Z8bIXFS8qHJYrsg8PnE6ALV52YnEPtdomYo43z4S97j29OFAdkohFJI0oFaOAnuWjsax2zAq4QDYauQu7EqlwUwJMZ0ppbZ15eL9eLZpDnIMoWL3hqq2nbVxrE2ZQIc3N2Gfzr3mttAtpiukISX4GfrJXMsOQFNOaGy6bmRD447Rk"

    send_response = th.message_sendlaterdm(token, dm_id, message, time_sent)
    assert send_response.status_code == InputError.code


# Test if an Access Error is raised when the dm_id is valid but the member is not a dm member
def test_not_dm_member(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 3)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    dm = th.dm_create(token, []).json()
    dm_id = dm["dm_id"] 

    user2 = th.auth_register("chopin@gmail.com", "password1", "frederic", "chopin").json()
    token2 = user2["token"]

    send_response = th.message_sendlaterdm(token2, dm_id, "hi", time_sent)
    assert send_response.status_code == AccessError.code


# Test if the time_sent is in the past and an Input Error is raised
def test_time_sent_in_past(clear_data):
    time_in_future = datetime.now() - timedelta(seconds = 1)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    dm = th.dm_create(token, []).json()
    dm_id = dm["dm_id"] 

    send_response = th.message_sendlaterdm(token, dm_id, "hi", time_sent)
    assert send_response.status_code == InputError.code

    
# Test if the message has been sent correctly by adjusting the sleep timer to the correct time length
def test_sendlaterdm_correct_time(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 1)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    user2 = th.auth_register("chopin@gmail.com", "password1", "frederic", "chopin").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    dm = th.dm_create(token, [u_id2]).json()
    dm_id = dm["dm_id"]

    send_response = th.message_sendlaterdm(token2, dm_id, "hi", time_sent)
    assert send_response.status_code == Success.code

    time.sleep(1.5)

    messages = th.dm_messages(token2, dm_id, 0).json()

    assert messages['messages'][0]['message_id'] == 1

    assert messages['messages'][0]['u_id'] == u_id2

    assert messages['messages'][0]['message'] == 'hi'


# Test if the message has not been sent yet by adjusting the sleep timer to the incorrect time length
def test_sendlaterdm_incorrect_time(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 2)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    user2 = th.auth_register("chopin@gmail.com", "password1", "frederic", "chopin").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    dm = th.dm_create(token, [u_id2]).json()
    dm_id = dm["dm_id"]

    send_response = th.message_sendlaterdm(token2, dm_id, "hi", time_sent)
    assert send_response.status_code == Success.code

    messages = th.dm_messages(token2, dm_id, 0).json()
    assert messages['messages'] == []


# Check that if messages sent with sendlater and message_send in the same time
# frame do not have the same message_id
def test_message_sendlater_duplicate_message_ids(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 2)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    dm = th.dm_create(token, []).json()
    dm_id = dm["dm_id"]

    channel = th.channels_create(token, "Channel1", True).json()
    channel_id = channel["channel_id"]

    # Set 1 message to be sent in the channel later
    msg1 = th.message_sendlater(token, channel_id, "1", time_sent).json()

    # Set 2 messages to be sent in the dm later
    msg2 = th.message_sendlaterdm(token, dm_id, "2", time_sent).json()
    msg3 = th.message_sendlaterdm(token, dm_id, "3", time_sent).json()

    # Send a message with message/senddm/v1
    msg4 = th.message_senddm(token, dm_id, "4").json()
    
    # Send a message into channel
    msg5 = th.message_send(token, channel_id, "5").json()


     # Check that none of the message_ids are identical
    assert msg1['message_id'] != msg2['message_id'] != msg3['message_id'] != msg4['message_id'] != msg5['message_id'] 

