import pytest
import requests
import json
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")


# Test if inputerror is raised if no email is given
def test_register_v2_email_none(clear_data):
    register_response = th.auth_register("", "password", "justin", "son")

    assert register_response.status_code == InputError.code


# Test if inputerror is raised if invalid email is given
def test_register_v2_email_invalid(clear_data):
    register_response = th.auth_register("invalid.email.student.unsw.edu.au", "password", "justin", "son")

    assert register_response.status_code == InputError.code


# Test if inputerror is raised if the email is a duplicate
def test_register_v2_email_duplicate(clear_data):
    th.auth_register("justin@gmail.com", "password", "justin", "son")

    # Register with the same email
    register_response = th.auth_register("justin@gmail.com", "password", "justin", "son")

    assert register_response.status_code == InputError.code


# Test if inputerror is raised if the password was not entered
def test_register_v2_password_none(clear_data):
    register_response = th.auth_register("justin@gmail.com", "", "justin", "son")

    assert register_response.status_code == InputError.code


# Test if inputerror is raised if the password is less than 6 characters
def test_register_v2_password_length_invalid(clear_data):
    register_response = th.auth_register("justin@gmail.com", "12345", "justin", "son")

    assert register_response.status_code == InputError.code


# Test if inputerror is raised when first name length is less than 1 character
# (i.e empty)
def test_register_v2_first_name_too_short(clear_data):
    register_response = th.auth_register("justin@gmail.com", "password", "", "son")

    assert register_response.status_code == InputError.code


# Test if inputerror is raised if the length of first name is more than 50 characters
def test_register_v2_first_name_too_long(clear_data):
    register_response = th.auth_register("justin@gmail.com", "12345", "Henricheyvindrfaustakarissaklavdiyasumatiainamilkaalyson", "son")

    assert register_response.status_code == InputError.code


# Test if inputerror is raised when last name length is less than 1 character
# (i.e empty)
def test_register_v2_last_name_too_short(clear_data):
    register_response = th.auth_register("justin@gmail.com", "password", "justin", "")

    assert register_response.status_code == InputError.code


# Test if inputerror is raised if the length of last name is more than 50 characters
def test_register_v2_last_name_too_long(clear_data):
    register_response = th.auth_register("justin@gmail.com", "password", "Henry", "Wolfe­schlegel­stein­hausen­berger­dorffavielteoinyenepersephone")

    assert register_response.status_code == InputError.code


# Test if InputError is raised when name_first and name_last both do not include
# any alphanumeric chars
def test_no_alphanumeric(clear_data):
    register_response = th.auth_register("justin@gmail.com", "password", "$%#&@*@(*&", "#$%@^@%$&*")

    assert register_response.status_code == InputError.code


# Test if the concatenated handle is correct and is cut off at 20 chars
def test_register_v2_concatenated_handle_valid(clear_data):
    # Register
    register_response = th.auth_register("justin@gmail.com", "password", "justinisthebestong", "sansensinsonsun").json()
    token = register_response["token"]
    u_id = register_response["auth_user_id"]

    # Get handle
    user_response = th.user_profile(token, u_id).json()
    handle = user_response["user"]["handle_str"]

    # Check for handle
    assert len(handle) == 20
    assert handle == "justinisthebestongsa"


# Test if new handle is appended with the right number, given the names are the same
def test_register_concatenated_handle_append(clear_data):
    # Register 3 users
    register_response1 = th.auth_register("justin@gmail.com", "password", "justinisthebestong", "sansensinsonsun").json()
    token1 = register_response1["token"]
    u_id1 = register_response1["auth_user_id"]

    register_response2 = th.auth_register("justin1@gmail.com", "password", "justinisthebestong", "sansensinsonsun").json()
    token2 = register_response2["token"]
    u_id2 = register_response2["auth_user_id"]

    register_response3 = th.auth_register("justin2@gmail.com", "password", "justinisthebestong", "sansensinsonsun").json()
    token3 = register_response3["token"]
    u_id3 = register_response3["auth_user_id"]

    # Get handles
    user_response1 = th.user_profile(token1, u_id1).json()
    handle1 = user_response1["user"]["handle_str"]

    user_response2 = th.user_profile(token2, u_id2).json()
    handle2 = user_response2["user"]["handle_str"]

    user_response3 = th.user_profile(token3, u_id3).json()
    handle3 = user_response3["user"]["handle_str"]

    # Check handles are correct
    assert handle2 == handle1 + '0'
    assert handle3 == handle1 + '1'


# Test if the auth register function works
def test_register_works(clear_data):
    # Get registered u_id
    register_response = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    register_id = register_response["auth_user_id"]

    # Get login u_id
    login_response = th.auth_login("justin@gmail.com", "password").json()
    login_id = login_response["auth_user_id"]

    # Make sure it's the same
    assert register_id == login_id
