import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")

# Test whether an Access error is raised if the token is invalid
def test_invalid_token(clear_data):
    list_response = th.channels_list(th.invalid_token1())
    assert list_response.status_code == AccessError.code


# Test is there is no channels created
def test_channels_list_v2_no_channels(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    list_response = th.channels_list(token).json()
    assert list_response == {"channels": []}


# Testing when user 1 created a channel but user 2 try to call the list function
# but is not in any channels
def test_channels_list_v2_list_user_in_no_channel(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    token2 = user2["token"]

    th.channels_create(token1, "comedy", True)

    list_response = th.channels_list(token2).json()
    assert list_response == {"channels": []}


# Testing the first channel the user themselves created
def test_channels_list_v2_list_one_channel(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    channel = th.channels_create(token, "comedy", False).json()
    channel_id = channel["channel_id"]

    list_response = th.channels_list(token).json()
    assert list_response == {"channels": [{"channel_id": channel_id, 
                                           "name": "comedy"}]}  
                                                   

# Testing when mulitple users are in more than one channel through invite and
# join function
def test_channels_list_v2_list_multiple_channels(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    u_id2 = user2["auth_user_id"]
    token2 = user2["token"]

    # Register user 3
    user3 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token3 = user3["token"]

    # Create channels
    channel1 = th.channels_create(token1, "1", True).json()
    channel_id1 = channel1["channel_id"]

    channel2 = th.channels_create(token2, "2", True).json()
    channel_id2 = channel2["channel_id"]

    channel3 = th.channels_create(token3, "3", False).json()
    channel_id3 = channel3["channel_id"]

    # User 3 joins channel 1 and 2
    th.channel_join(token3, channel_id1)
    th.channel_join(token3, channel_id2)

    # User 2 invited to channel 3
    th.channel_invite(token3, channel_id3, u_id2)

    # User 1 joins channel 3
    th.channel_join(token1, channel_id3)

    # User 2 joins channel 1
    th.channel_join(token2, channel_id1)

    # Get channel list for all users
    list_response1 = th.channels_list(token1).json()
    list_response2 = th.channels_list(token2).json()
    list_response3 = th.channels_list(token3).json()

    # Check for correct lists
    assert list_response1 == {"channels": [{"channel_id": channel_id1, 
                                            "name": "1"},
                                           {"channel_id": channel_id3, 
                                            "name": "3"}]} 

    assert list_response2 == {"channels": [{"channel_id": channel_id1, 
                                            "name": "1"},
                                           {"channel_id": channel_id2, 
                                            "name": "2"},
                                           {"channel_id": channel_id3, 
                                            "name": "3"}]} 

    assert list_response3 == {"channels": [{"channel_id": channel_id1, 
                                            "name": "1"},
                                           {"channel_id": channel_id2, 
                                            "name": "2"},
                                           {"channel_id": channel_id3, 
                                            "name": "3"}]}                                        
