import pytest
import requests
from datetime import datetime, timedelta
import time 
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')

# Test if user token is invalid
def test_message_send_later_invalid_token(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 3)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    channel = th.channels_create(token, "Channel1", True).json()
    channel_id = channel["channel_id"]

    send_response = th.message_sendlater(th.invalid_token1(), channel_id, "hi", time_sent)
    assert send_response.status_code == AccessError.code

# Test if Input error is raised if channel_id does not refer to a valid channel
def test_invalid_channel(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 3)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    send_response = th.message_sendlater(token, 400, "hi", time_sent)
    assert send_response.status_code == InputError.code


# Test if the length of the message if over 1000 characters and raise an input error
def test_1000_characters_message(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 3)
    time_sent = int(time.mktime(time_in_future.timetuple()))

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user["token"]

    channel = th.channels_create(token, "Channel1", True).json()
    channel_id = channel["channel_id"]

    message = "87Hon45kXI9hY8fgZ2QaWDRpiAXwfrkSnsdiTEzyf5lDrl8FFgl2yJn2N6OxbBMxXrfgcYMpuzBMkY6hnPkw1iIYlGFGqrsGgrUvON7D59CmAL7W4JWz4TWm8brwt0neKwapugRtfiPgo61MGK7pt5ruSoDSn3VdWDlp7j2JPc5HbhN4fl9E7PTMVzBj4oDDAkBtvpXLLzvUje1rf19NHOAnMDFetQV07fbSm1wYYIczTa2BWw6JldiMwj4Ss0N2JdrdckzEIWv3ZxofZhLJDAaiasMm9kP5m28eLdnKLMCg4XPP9rDSaKHQMPPdf0oNAp1CHWRVEHkF8P4J7zcJOxPepcJ7HI43vobuJYQwP4DG0t9ugco8r5E5QkyBCweU5qLg7gJDrpTohuEvszAvTtRAyFGBy04BVK3PZsUnK5GfILjxtxPZBZwEdmTtAd7tyoTS7ow7KjVT6aSqESMmFcaMtaK0Fr1csaHDVEKBvssEkkKkUOsT9YaS3CWSwVUVXZuEELB6tvkhBzmvjF4uYotxVaiVhFE5lR2SyNHMBuwP3sM6sPtMVWlQQNep3kL3OSi5l7CTRR8Ipcn2jtNbu260YAZ2SAw9YJdb0xzu9B02cYmPbfhzi87gYNe0DAocrmPo8WMLQheZLrbqRhSnxkGU3a1Xf8fZBW80T5RJvZHl0ZaxbKOsBeAK890gUgVtponFFSSB1Pmm4rlUB1hT9ghF6yGv5g5wjFGocN0CcPZuAzss1dKWh5NNEthB9kvzRM8nZMBClde9nJtY3k01ud63Sl7dZ23u7B0x8gFbXzefnStXIgNeUmFfsDqn5Z8bIXFS8qHJYrsg8PnE6ALV52YnEPtdomYo43z4S97j29OFAdkohFJI0oFaOAnuWjsax2zAq4QDYauQu7EqlwUwJMZ0ppbZ15eL9eLZpDnIMoWL3hqq2nbVxrE2ZQIc3N2Gfzr3mttAtpiukISX4GfrJXMsOQFNOaGy6bmRD447Rk"

    send_response = th.message_sendlater(token, channel_id, message, time_sent)
    assert send_response.status_code == InputError.code


# Raises an Acess error when the channel is valid but the user isn't a member of it
def test_not_channel_member(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 3)
    time_sent = int(time.mktime(time_in_future.timetuple()))
    
    user1 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token1 = user1["token"]

    channel = th.channels_create(token1, "Channel1", True).json()
    channel_id = channel["channel_id"]

    user2 = th.auth_register("chopin@gmail.com", "password1", "frederic", "chopin").json()
    token2 = user2["token"]

    send_response = th.message_sendlater(token2, channel_id, "hi", time_sent)
    assert send_response.status_code == AccessError.code


# Test if an Input error is raised if the message is attempted to be sent in the past
def test_sending_message_in_the_past(clear_data):
    time_in_future = datetime.now() - timedelta(seconds = 3)
    time_sent = int(time.mktime(time_in_future.timetuple()))
    
    user1 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token1 = user1["token"]

    channel = th.channels_create(token1, "Channel1", True).json()
    channel_id = channel["channel_id"]

    send_response = th.message_sendlater(token1, channel_id, "hi", time_sent)
    assert send_response.status_code == InputError.code


# Test message send later send correctly
def test_sendlater_correct_time(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 1)
    time_sent = int(time.mktime(time_in_future.timetuple()))
    
    user1 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token1 = user1["token"]

    channel = th.channels_create(token1, "Channel1", True).json()
    channel_id = channel["channel_id"]

    send_response = th.message_sendlater(token1, channel_id, "hi", time_sent)
    assert send_response.status_code == Success.code

    time.sleep(1.5)
    message = th.channel_messages(token1, channel_id, 0).json()

    assert message['messages'][0]['message_id'] == 1

    assert message['messages'][0]['u_id'] == 1

    assert message['messages'][0]['message'] == 'hi'


# Test if the message has not been sent yet by adjusting the sleep timer to the incorrect time length
def test_sendlater_incorrect_time(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 2)
    time_sent = int(time.mktime(time_in_future.timetuple()))
    
    user1 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token1 = user1["token"]

    channel = th.channels_create(token1, "Channel1", True).json()
    channel_id = channel["channel_id"]

    send_response = th.message_sendlater(token1, channel_id, "hi", time_sent)
    assert send_response.status_code == Success.code

    message = th.channel_messages(token1, channel_id, 0).json()
    assert message['messages'] == []


# Check that if messages sent with sendlater and message_send in the same time
# frame do not have the same message_id
def test_message_sendlater_duplicate_message_ids(clear_data):
    time_in_future = datetime.now() + timedelta(seconds = 2)
    time_sent = int(time.mktime(time_in_future.timetuple()))
    
    user1 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token1 = user1["token"]

    channel = th.channels_create(token1, "Channel1", True).json()
    channel_id = channel["channel_id"]

    msg1 = th.message_sendlater(token1, channel_id, "hi", time_sent).json()
    msg2 = th.message_sendlater(token1, channel_id, "bye", time_sent).json()

    msg3 = th.message_send(token1, channel_id, "what").json()

    assert msg1['message_id'] != msg2['message_id'] != msg3['message_id']
