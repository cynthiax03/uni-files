import pytest
import requests 
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')

# Testing if the user is logged out of all sessions
def test_auth_password_reset_logout_all_sessions(clear_data):

    register_response = th.auth_register("son020120@gmail.com", "validpassword", "Justin", "Son").json()
    register_token = register_response["token"]

    login_response1 = th.auth_login("son020120@gmail.com", "validpassword").json()
    login_token1 = login_response1["token"]

    login_response2 = th.auth_login("son020120@gmail.com", "validpassword").json()
    login_token2 = login_response2["token"]

    th.auth_passwordreset_request("son020120@gmail.com")

    channel_response1 = th.channels_create(register_token, "Water", False)
    channel_response2 = th.channels_create(login_token1, "Hydro", False)
    channel_response3 = th.channels_create(login_token2, "River", False)

    assert channel_response1.status_code == AccessError.code
    assert channel_response2.status_code == AccessError.code
    assert channel_response3.status_code == AccessError.code
