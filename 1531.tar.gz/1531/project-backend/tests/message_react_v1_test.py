import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")

# Testing if the user token is invalid
def test_message_react_v1_token_invalid(clear_data):

    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token1 = user['token']

    channel1 = th.channels_create(token1, "Channel 1", True).json()
    channel_id = channel1["channel_id"]

    message = th.message_send(token1, channel_id, "The first lecture will be on Wednesday 10am").json()
    message_id = message["message_id"]
    # Input invalid token into the function
    react_response = th.message_react(th.invalid_token1(), message_id, 1)

    # Checking the Access Error code
    assert react_response.status_code == AccessError.code
    
# Testing if the message_id is not valid
def test_message_react_v1_message_id_invalid(clear_data):
    
    user1 = th.auth_register("Allan@gmail.com", "pwpwpwpw", "Allan", "Zhang").json()
    token1 = user1['token']

    channel1 = th.channels_create(token1, "Channel 10000", False).json()
    channel_id = channel1["channel_id"]

    th.message_send(token1, channel_id, "TYoyoyoyoyoyoyo").json()

    # Input invalid message_id
    react_response = th.message_react(token1, 1234, 1) 

    # Checking for the Input Error code
    assert react_response.status_code == InputError.code

# Testing if the user has not joined the DM
def test_message_react_v1_dm_not_joined(clear_data):

    user1 = th.auth_register("justins@gmail.com", "password", "Justin", "Son").json()
    token1 = user1['token']

    user2 = th.auth_register("cynthia@gmail.com", "10101010101", "Cynthia", "Li").json()
    u_id2 = user2["auth_user_id"]

    user3 = th.auth_register("Max@gmail.com", "pasword1", "Max", "Dalgeish").json()
    token3 = user3["token"]

    dm = th.dm_create(token1, [u_id2]).json()
    dm_id = dm["dm_id"]

    message = th.message_senddm(token1, dm_id, "BlahBlaBlah").json()
    message_id = message["message_id"]

    # Input user 3's token who is not in the dm
    react_response = th.message_react(token3, message_id, 1)

    # Checking Input Error code
    assert react_response.status_code == InputError.code

# Testing if the user has not joined the channel
def test_message_react_v1_channel_not_joined(clear_data):

    user1 = th.auth_register("hello@gmail.com", "password", "Calamari", "Ring").json()
    token1 = user1['token']

    user2 = th.auth_register("world@gmail.com", "12341234", "Basket", "Ball").json()
    token2 = user2['token']

    channel1 = th.channels_create(token1, "CAMEL", True).json()
    channel_id = channel1["channel_id"]

    message = th.message_send(token1, channel_id, "hellohellohellohello").json()
    message_id = message["message_id"]

    # Input user 2's token who is not in the channel
    react_response = th.message_react(token2, message_id, 1)

    # Checking Input Error code
    assert react_response.status_code == InputError.code

# Testing if the react_id is invalid
def test_message_react_v1_react_id_invalid(clear_data):
    user1 = th.auth_register("hello@gmail.com", "password", "Calamari", "Ring").json()
    token1 = user1['token']

    user2 = th.auth_register("world@gmail.com", "12341234", "Basket", "Ball").json()
    token2 = user2['token']
    u_id2 = user2["auth_user_id"]

    dm = th.dm_create(token1, [u_id2]).json()
    dm_id = dm["dm_id"]

    message = th.message_senddm(token1, dm_id, "hellohellohellohello").json()
    message_id = message["message_id"]

    # Input invalid react id value
    react_response = th.message_react(token2, message_id, 10000)

    # Checking Input Error code
    assert react_response.status_code == InputError.code


# Testing correct reacting in channel messages
def test_message_react_v1_channel_message_first_react(clear_data):

    user1 = th.auth_register("derrick@gmail.com", "999999999", "Derrick", "D").json()
    token1 = user1['token']
    u_id1 = user1["auth_user_id"]

    channel1 = th.channels_create(token1, "COMP1531", True).json()
    channel_id = channel1["channel_id"]

    message = th.message_send(token1, channel_id, "hellohellohellohello").json()
    message_id = message["message_id"]

    th.message_react(token1, message_id, 1)

    channel_messages_response1 = th.channel_messages(token1, channel_id, 0).json()

    # Testing if the react is saved correctly
    assert channel_messages_response1['messages'][0]['reacts'] == [
                                                        {   'react_id': 1,
                                                            'u_ids': [u_id1],
                                                            'is_this_user_reacted': True
                                                        }]

# Testing correct reacting in DM messages
def test_message_react_v1_dm_message_first_react(clear_data):
    user1 = th.auth_register("hello@gmail.com", "password", "Calamari", "Ring").json()
    token1 = user1['token']
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("world@gmail.com", "12341234", "Basket", "Ball").json()
    u_id2 = user2["auth_user_id"]

    dm = th.dm_create(token1, [u_id2]).json()
    dm_id = dm["dm_id"]

    message = th.message_senddm(token1, dm_id, "hellohellohellohello").json()
    message_id = message["message_id"]

    th.message_react(token1, message_id, 1)

    dm_message_response1 = th.dm_messages(token1, dm_id, 0).json()

    assert dm_message_response1['messages'][0]['reacts'] == [
        {
            'react_id': 1,
            'u_ids': [u_id1],
            'is_this_user_reacted': True
        }
    ]


# Testing when the message is already reacted by the user
def test_message_react_v1_already_reacted(clear_data):
    user1 = th.auth_register("derrick@gmail.com", "999999999", "Derrick", "D").json()
    token1 = user1['token']

    channel1 = th.channels_create(token1, "COMP1531", True).json()
    channel_id = channel1["channel_id"]

    message = th.message_send(token1, channel_id, "hellohellohellohello").json()
    message_id = message["message_id"]

    react_response1 = th.message_react(token1, message_id, 1)
    react_response2 = th.message_react(token1, message_id, 1)

    assert react_response1.status_code == Success.code
    assert react_response2.status_code == InputError.code


# Tests that a second react is saved correctly
def test_message_react_channel_second_react(clear_data):

    # Register 2 users
    user1 = th.auth_register("abcd@gmail.com", "abcdefghi", "abc", "def").json()
    token1 = user1['token']
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("12345@gmail.com", "12345678", "numbers", "12345").json()
    token2 = user2['token']
    u_id2 = user2["auth_user_id"]
    
    th.channels_create(token2, "Old channel", False)

    # User1 creates a new channel and invites user2
    channel = th.channels_create(token1, "New channel", False).json()
    channel_id = channel["channel_id"]

    th.channel_invite(token1, channel_id, u_id2)

    # Each user sends a message in the channel
    msg1 = th.message_send(token1, channel_id, "Icecream").json()
    message_id1 = msg1["message_id"]

    msg2 = th.message_send(token2, channel_id, "is gross").json()
    message_id2 = msg2["message_id"]

    # User1 2 reacts to message1, then user2 reacts to message2
    th.message_react(token2, message_id2, 1)
    th.message_react(token2, message_id1, 1)

    # User 1 reacts to msg1
    th.message_react(token1, message_id1, 1)

    # Get channel messages
    channel_messages = th.channel_messages(token1, channel_id, 0).json()

    # Check that reacts is correct for msg1
    assert channel_messages['messages'][1]['reacts'] == [ 
                            {   'react_id': 1,
                                'u_ids': [u_id2, u_id1],
                                'is_this_user_reacted': True
                            }
                        ]
            
    # Check that reacts is correct for msg2
    assert channel_messages['messages'][0]['reacts'] == [ 
                            {   'react_id': 1,
                                'u_ids': [u_id2],
                                'is_this_user_reacted': False
                            }
                        ]


# Tests that a second react is saved correctly
def test_message_react_dm_second_react(clear_data):
    # Register 2 users
    user1 = th.auth_register("abcd@gmail.com", "abcdefghi", "abc", "def").json()
    token1 = user1['token']
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("12345@gmail.com", "12345678", "numbers", "12345").json()
    token2 = user2['token']
    u_id2 = user2["auth_user_id"]

    th.dm_create(token1, [u_id2])

    dm2 = th.dm_create(token2, [u_id1]).json()
    dm_id2 = dm2["dm_id"]

    msg1 = th.message_senddm(token1, dm2['dm_id'], "jk").json()
    msg2 = th.message_senddm(token2, dm2['dm_id'], "icecream good").json()

    msg_id1 = msg1["message_id"]
    msg_id2 = msg2["message_id"]

    # User1 2 reacts to message1, then user2 reacts to message2
    th.message_react(token2, msg_id2, 1)
    th.message_react(token2, msg_id1, 1)

    # User 1 reacts to msg1
    th.message_react(token1, msg_id1, 1)

    # Get messages
    dm_messages = th.dm_messages(token1, dm_id2, 0).json()

    # Check that msg2 reacts is correct
    assert dm_messages['messages'][0]['reacts'] == [ 
                                        {   'react_id': 1,
                                            'u_ids': [u_id2],
                                            'is_this_user_reacted': False
                                        }
                                    ]    

    # Check that msg1 reacts is correct
    assert dm_messages['messages'][1]['reacts'] == [ 
                                        {   'react_id': 1,
                                            'u_ids': [u_id2, u_id1],
                                            'is_this_user_reacted': True
                                        }
                                    ]
