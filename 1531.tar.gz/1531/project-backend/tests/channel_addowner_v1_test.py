import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')

# Test where the token is invalid
def test_addowner_invalid_token(clear_data):
    addowner_response = th.channel_add_owner(th.invalid_token1(), 1, 1)
    
    assert addowner_response.status_code == AccessError.code

# Test when a user isn't an owner of a channel
def test_addowner_not_channel_owner(clear_data):
    # Register user 1
    user1 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token1 = user1["token"]

    # Create channel
    channel = th.channels_create(token1, "MAX", True).json()
    channel_id = channel["channel_id"]

    # Create user 2 and 3
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token2 = user2["token"]

    user3 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    u_id = user3["auth_user_id"]

    th.channel_join(token2, channel_id)

    # User 2 can't add user 3, not an owner
    addowner_response = th.channel_add_owner(token2, channel_id, u_id)

    assert addowner_response.status_code == AccessError.code


#Test when a channel_id doesn't refer to any channel
def test_addowner_channelid_invalid(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    user2 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    u_id = user2["auth_user_id"]

    # Can't add owner, no channel exists
    addowner_response = th.channel_add_owner(token, 1, u_id)

    assert addowner_response.status_code == InputError.code


# User id does not refer to a valid user and an input error is raised
def test_addowner_invalid_user_id(clear_data):
    # Register user 1
    user1 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token = user1["token"]

    # Create channel
    channel = th.channels_create(token, "MAX", True).json()
    channel_id = channel["channel_id"]

    # Invalid user id
    addowner_response = th.channel_add_owner(token, channel_id, 400)

    assert addowner_response.status_code == InputError.code


# Test where the user inputting token is not a member of the channel
def test_addowner_token_not_channel_member(clear_data):
    # Register user 1
    user1 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token1 = user1["token"]

    # Create channel
    channel = th.channels_create(token1, "MAX", True).json()
    channel_id = channel["channel_id"]

    # Create user 2 and 3
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token2 = user2["token"]
    u_id = user2["auth_user_id"]

    user3 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token3 = user3["token"]

    th.channel_join(token2, channel_id)

    # User 3 attempts to add user 2 to owner, but user 3 not in channel
    addowner_response = th.channel_add_owner(token3, channel_id, u_id)

    assert addowner_response.status_code == AccessError.code


# User ID refers to a user who isn't a member of the channel and returns input error
def test_addowner_not_channel_member(clear_data):
    # Register user 1
    user1 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token1 = user1["token"]

    # Create channel
    channel = th.channels_create(token1, "MAX", True).json()
    channel_id = channel["channel_id"]

    # Create user 2
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    u_id = user2["auth_user_id"]

    # Adding user who isn't a member of the channel
    addowner_response = th.channel_add_owner(token1, channel_id, u_id)

    assert addowner_response.status_code == InputError.code


# User ID refers to someone who is already an owner of the channel and returns input error
def test_addowner_already_channel_owner(clear_data):
    # Register user 1
    user1 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token1 = user1["token"]

    # Create channel
    channel = th.channels_create(token1, "MAX", True).json()
    channel_id = channel["channel_id"]

    # Create user 2
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token2 = user2["token"]
    u_id = user2["auth_user_id"]

    th.channel_join(token2, channel_id)

    # Add owner
    addowner_response1 = th.channel_add_owner(token1, channel_id, u_id)
    assert addowner_response1.status_code == Success.code

    # Try to add again
    addowner_response2 = th.channel_add_owner(token1, channel_id, u_id)
    assert addowner_response2.status_code == InputError.code


# Test if the function works properly
def test_addowner_successful_test(clear_data):
    # Register user 1
    user1 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    # Create channel
    channel = th.channels_create(token1, "MAX", True).json()
    channel_id = channel["channel_id"]

    # Create user 2
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    # Join and make owner
    th.channel_join(token2, channel_id)
    th.channel_add_owner(token1, channel_id, u_id2)

    # Check details
    details = th.channel_details(token1, channel_id).json()

    assert details == {
                        'name': 'MAX',
                        'is_public': True,
                        'owner_members': [
                            {
                                'u_id': u_id1,
                                'email': 'justin@gmail.com', 
                                'name_first': 'justin', 
                                'name_last': 'son', 
                                'handle_str': 'justinson',
                                'profile_img_url': config.url + "static/default.jpg"
                            },
                            {
                                'u_id': u_id2,
                                'email': 'rick@gmail.com',
                                'name_first': 'derrick',
                                'name_last': 'doan',
                                'handle_str': 'derrickdoan',
                                'profile_img_url': config.url + "static/default.jpg"
                            }
                                    ], 
                        'all_members':[
                        {
                                'u_id': u_id1,
                                'email': 'justin@gmail.com', 
                                'name_first': 'justin', 
                                'name_last': 'son', 
                                'handle_str': 'justinson',
                                'profile_img_url': config.url + "static/default.jpg"
                        },
                        {
                                'u_id': u_id2,
                                'email': 'rick@gmail.com',
                                'name_first': 'derrick',
                                'name_last': 'doan',
                                'handle_str': 'derrickdoan',
                                'profile_img_url': config.url + "static/default.jpg"
                            }
                            ]
                    }


# Test if a user is a global owner and can add themselves to the channel
def test_addowner_global_owner_self_add(clear_data):
    # Register user 1
    user1 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    # Create user 2
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token2 = user2["token"]

    # Create channel
    channel = th.channels_create(token2, "MAX", False).json()
    channel_id = channel["channel_id"]

    th.channel_join(token1, channel_id)

    addowner_response = th.channel_add_owner(token2, channel_id, u_id1)
    assert addowner_response.status_code == Success.code


def test_addowner_global_cant_addowner(clear_data):
    # Register user 1
    user1 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token2 = user2["token"]

    # Register user 3
    user3 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token3 = user3["token"]
    u_id3 = user3["auth_user_id"]

    # Create channel
    channel = th.channels_create(token2, "MAX", False).json()
    channel_id = channel["channel_id"]

    th.channel_join(token3, channel_id)

    # Attempting to add user 3 to channel owners while user 1 isn't a channel member
    addowner_response = th.channel_add_owner(token1, channel_id, u_id3)
    assert addowner_response.status_code == AccessError.code
