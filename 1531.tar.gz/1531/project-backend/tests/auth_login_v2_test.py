import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")

# Test if no email raises inputerror
def test_login_v2_no_email(clear_data):
    # Login the user given no email
    login_response = th.auth_login("", "password")

    assert login_response.status_code == InputError.code


# Test if invalid email raises inputerror
def test_login_v2_invalid_email(clear_data):
    # Login without registering user
    login_response = th.auth_login("justin@gmail.com", "password")

    assert login_response.status_code == InputError.code


# Test if no password raises inputerror
def test_login_no_password(clear_data):
    # Register
    th.auth_register("justin@gmail.com", "password", "justin", "son")

    # No password
    login_response = th.auth_login("justin@gmail.com", "")

    assert login_response.status_code == InputError.code


# Test if incorrect password raises inputerror
def test_login_incorrect_password(clear_data):
    # Register
    th.auth_register("justin@gmail.com", "password", "justin", "son")

    # Wrong password
    login_response = th.auth_login("justin@gmail.com", "wrongpasswordxd")

    assert login_response.status_code == InputError.code


# Test if the login function works
def test_login_works(clear_data):
    # Get registered u_id
    register_response = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    register_id = register_response["auth_user_id"]

    # Get login u_id
    login_response = th.auth_login("justin@gmail.com", "password").json()
    login_id = login_response["auth_user_id"]

    # Make sure it's the same
    assert register_id == login_id


# Check that a user can have multiple sessions
def test_login_multiple_sessions(clear_data):
    # Register user and get token
    register_response = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    register_token = register_response["token"]

    # Get login token
    login_response = th.auth_login("justin@gmail.com", "password").json()
    login_token = login_response["token"]

    # Tokens shouldn't be the same
    assert register_token != login_token

    # Check that both tokens work
    create_response1 = th.channels_create(register_token, "Music", False)
    assert create_response1.status_code == Success.code

    create_response2 = th.channels_create(login_token, "1531", False)
    assert create_response2.status_code == Success.code 

    # Logout and check that register token doesn't work
    th.auth_logout(register_token)

    create_response3 = th.channels_create(register_token, "Chicken", False)
    assert create_response3.status_code == AccessError.code

    # Check that login token still works
    create_response4 = th.channels_create(login_token, "max", False)
    assert create_response4.status_code == Success.code

