import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')

# Test where the token is invalid
def test_removeowner_invalid_token(clear_data):
    remove_response = th.channel_remove_owner(th.invalid_token1(), 1, 1)
    assert remove_response.status_code == 403

# Test when a global owner isn't a member of a channel
def test_global_owner_not_channel_member(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token2 = user2["token"]

	# Register user 3
    user3 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token3 = user3["token"]
    u_id = user3["auth_user_id"]

	# User 2 creates channel
    channel = th.channels_create(token2, "gank", True).json()
    channel_id = channel["channel_id"]

	# User 3 joins channel and becomes owner
    th.channel_join(token3, channel_id)
    th.channel_add_owner(token2, channel_id, u_id)

    # User 1 tries to remove user 3
    remove_response = th.channel_remove_owner(token1, channel_id, u_id)
    assert remove_response.status_code == 403


# Test when a user isn't a channel owner
def test_user_not_channel_owner(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]
    u_id = user1["auth_user_id"]

    # Create user 2
    user2 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token2 = user2["token"]

	# Register user 3
    user3 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token3 = user3["token"]

	# User 2 creates channel
    channel = th.channels_create(token2, "gank", True).json()
    channel_id = channel["channel_id"]

	# User 1 joins channel and becomes owner
    th.channel_join(token1, channel_id)
    th.channel_add_owner(token2, channel_id, u_id)

    # User 3 joins channel
    th.channel_join(token3, channel_id)

    # User 3 tries to remove user 2
    remove_response = th.channel_remove_owner(token3, channel_id, u_id)
    assert remove_response.status_code == 403


# Test when a channel_id doesn't refer to any channel
def test_channelid_invalid(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    u_id = user2["auth_user_id"]

    # User 1 tries to remove user 2
    remove_response = th.channel_remove_owner(token1, 1, u_id)
    assert remove_response.status_code == 400


# User id does not refer to a valid user and an input error is raised
def test_invalid_user_id(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    u_id = user2["auth_user_id"]

	# User 1 creates channel
    channel = th.channels_create(token1, "gank", True).json()
    channel_id = channel["channel_id"]

    # User 1 removes nonexistent member
    remove_response = th.channel_remove_owner(token1, channel_id, u_id + 1)
    assert remove_response.status_code == 400


# User ID refers to a user who isn't an owner of the channel and returns input error
def test_not_channel_member(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token2 = user2["token"]
    u_id = user2["auth_user_id"]

	# User 1 creates channel
    channel = th.channels_create(token1, "gank", True).json()
    channel_id = channel["channel_id"]

    th.channel_join(token2, channel_id)

    # User 1 tries removes a regular member
    remove_response = th.channel_remove_owner(token1, channel_id, u_id)
    assert remove_response.status_code == 400

# User ID refers to someone who is the only owner of a channel
def test_only_channel_owner(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]
    u_id = user1["auth_user_id"]

	# User 1 creates channel
    channel = th.channels_create(token1, "gank", True).json()
    channel_id = channel["channel_id"]

    # User 1 tries to remove himself
    remove_response = th.channel_remove_owner(token1, channel_id, u_id)
    assert remove_response.status_code == 400


# Test if the function works properly
def test_removeowner_successful_test(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    # Create user 2
    user2 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

	# User 1 creates channel
    channel = th.channels_create(token1, "gank", True).json()
    channel_id = channel["channel_id"]

    th.channel_join(token2, channel_id)
    th.channel_add_owner(token1, channel_id, u_id2)

    remove_response = th.channel_remove_owner(token1, channel_id, u_id2)
    assert remove_response.status_code == Success.code

    details = th.channel_details(token1, channel_id).json()
    assert details == {
        'name': 'gank',
        'is_public': True,
        'owner_members': [
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ],
        'all_members': [
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id2,
                'email': 'max@gmail.com',
                'name_first': 'max',
                'name_last': 'dal',
                'handle_str': 'maxdal',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }


# Test if a user is a global owner and can remove people from the owner permission
def test_global_owner(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    # Create user 2
    user2 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

	# Register user 3
    user3 = th.auth_register("justin@gmail.com", "password", "justin", "son").json()
    token3 = user3["token"]
    u_id3 = user3["auth_user_id"]

	# User 2 creates channel
    channel = th.channels_create(token2, "gank", True).json()
    channel_id = channel["channel_id"]

	# User 3 joins channel and becomes owner
    th.channel_join(token3, channel_id)
    th.channel_add_owner(token2, channel_id, u_id3)

    # User 1 joins channel
    th.channel_join(token1, channel_id)

    # User 1 removes user 2 channel owner permission
    th.channel_remove_owner(token1, channel_id, u_id2)

    # Check details
    details = th.channel_details(token1, channel_id).json()
    assert details == {
        'name': 'gank',
        'is_public': True,
        'owner_members': [
            {
                'u_id': u_id3,
                'email': 'justin@gmail.com',
                'name_first': 'justin',
                'name_last': 'son',
                'handle_str': 'justinson',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ],
        'all_members': [
            {
                'u_id': u_id2,
                'email': 'max@gmail.com',
                'name_first': 'max',
                'name_last': 'dal',
                'handle_str': 'maxdal',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id3,
                'email': 'justin@gmail.com',
                'name_first': 'justin',
                'name_last': 'son',
                'handle_str': 'justinson',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }