import pytest
import requests
import datetime
import time
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(f"{config.url}clear/v1")

# Test that AccessError is raised when invalid token is entered
def test_user_stats_invalid_token(clear_data):

    stats_response = th.user_stats(th.invalid_token1())
    
    assert stats_response.status_code == AccessError.code
    
def test_user_stats_default_channel_join_then_leave(clear_data):
    
    # Register two users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    
    # User1 creates a channel
    channel1 = th.channels_create(token1, "Totoro", True).json()
    channel_id = channel1["channel_id"]

    # User2 joins the created channel
    th.channel_join(token2, channel_id)
    
    # User2 then leaves the channel
    th.channel_leave(token2, channel_id)

    # User1 calls user/stats/v1
    user1_stats1 = th.user_stats(token1).json()
    
    # User2 calls user/stats/v1
    user2_stats1 = th.user_stats(token2).json()

    # Check that the number of channels_joined has been updated
    assert user1_stats1['user_stats']['channels_joined'][0]['num_channels_joined'] == 0
    assert user1_stats1['user_stats']['channels_joined'][1]['num_channels_joined'] == 1

    assert user2_stats1['user_stats']['channels_joined'][0]['num_channels_joined'] == 0
    assert user2_stats1['user_stats']['channels_joined'][1]['num_channels_joined'] == 1
    assert user2_stats1['user_stats']['channels_joined'][2]['num_channels_joined'] == 0


def test_user_stats_default_dm_join_then_leave(clear_data):
    
    # Register two users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    u_id = user2["auth_user_id"]

    # User1 creates a dm with user2
    dm1 = th.dm_create(token1, [u_id]).json()
    dm_id = dm1['dm_id']
    
    # User2 leaves the created dm
    th.dm_leave(token2, dm_id)
    
    # User1 calls user/stats/v1
    user1_stats1 = th.user_stats(token1).json()
    
    # User2 calls user/stats/v1
    user2_stats1 = th.user_stats(token2).json()

    # Check that the number of dms_joined has been updated
    assert user1_stats1['user_stats']['dms_joined'][0]['num_dms_joined'] == 0
    assert user1_stats1['user_stats']['dms_joined'][1]['num_dms_joined'] == 1
    
    assert user2_stats1['user_stats']['dms_joined'][0]['num_dms_joined'] == 0
    assert user2_stats1['user_stats']['dms_joined'][1]['num_dms_joined'] == 1
    assert user2_stats1['user_stats']['dms_joined'][2]['num_dms_joined'] == 0

def test_user_stats_default_dm_join_then_remove(clear_data):
    
    # Register two users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    u_id = user2["auth_user_id"]
    
    # User1 creates a dm with user2
    dm1 = th.dm_create(token1, [u_id]).json()
    dm_id = dm1['dm_id']
    
    # User1 removes the created dm
    th.dm_remove(token1, dm_id)

    # User1 calls user/stats/v1
    user1_stats1 = th.user_stats(token1).json()
    
    # User2 calls user/stats/v1
    user2_stats1 = th.user_stats(token2).json()

    # Check that the number of channels_joined has been updated
    assert user1_stats1['user_stats']['dms_joined'][0]['num_dms_joined'] == 0
    assert user1_stats1['user_stats']['dms_joined'][1]['num_dms_joined'] == 1
    assert user1_stats1['user_stats']['dms_joined'][2]['num_dms_joined'] == 0
    
    assert user2_stats1['user_stats']['dms_joined'][0]['num_dms_joined'] == 0
    assert user2_stats1['user_stats']['dms_joined'][1]['num_dms_joined'] == 1
    assert user2_stats1['user_stats']['dms_joined'][2]['num_dms_joined'] == 0


def test_user_stats_default_message_send_then_delete(clear_data):
    # Register two users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    u_id = user2["auth_user_id"]
    
    # User1 creates a channel
    channel1 = th.channels_create(token1, "Totoro", True).json()
    channel_id = channel1["channel_id"]

    # User2 joins the created channel
    th.channel_join(token2, channel_id)
    
    # User2 sends message into the channel
    sent1 = th.message_send(token2, channel_id, "HELLO").json()
    message_id1 = sent1['message_id']
    
    # User1 creates a dm with user2
    dm1 = th.dm_create(token1, [u_id]).json()
    dm_id = dm1['dm_id']

    # User2 sends message into the dm
    sent2 = th.message_senddm(token2, dm_id, "WORLD").json()
    message_id2 = sent2['message_id']
    
    # User2 removes both messages from dm and channel
    th.message_remove(token2, message_id1)
    th.message_remove(token2, message_id2)
    
    # User1 calls user/stats/v1
    user1_stats1 = th.user_stats(token1).json()
    
    # User2 calls user/stats/v1
    user2_stats1 = th.user_stats(token2).json()
    
    # Check that the number of messages_sent has been updated
    assert user1_stats1['user_stats']['messages_sent'][0]['num_messages_sent'] == 0

    assert user2_stats1['user_stats']['messages_sent'][0]['num_messages_sent'] == 0
    assert user2_stats1['user_stats']['messages_sent'][1]['num_messages_sent'] == 1
    assert user2_stats1['user_stats']['messages_sent'][2]['num_messages_sent'] == 2
    assert user2_stats1['user_stats']['messages_sent'][3]['num_messages_sent'] == 2
    assert user2_stats1['user_stats']['messages_sent'][4]['num_messages_sent'] == 2

# Test that user/stats/v1 returns correctly when involvement is 0 and all
# metrics are 0
def test_user_stats_no_involvement(clear_data):
    # Register user
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]
    
    # Call stats
    stats = th.user_stats(token1).json()

    assert stats['user_stats']['channels_joined'][0]['num_channels_joined'] == 0
    assert stats['user_stats']['dms_joined'][0]['num_dms_joined'] == 0
    assert stats['user_stats']['messages_sent'][0]['num_messages_sent'] == 0
    assert stats['user_stats']['involvement_rate'] == 0
    
# Test that time_stamp is within 2 seconds of actual time and is updated 
# each time user/stats/v1 is called
def test_user_stats_timestamp(clear_data):
    # Register user
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]
    
    # User creates 2 channels
    channel1 = th.channels_create(token1, "CaramelPopcorn", False).json()
    channel_id = channel1["channel_id"]
    th.channels_create(token1, "CornIcecream", True)

    # Call user/stats/v1
    stats1 = th.user_stats(token1).json()

    # Get current timestamp
    curr_time1 = datetime.datetime.now()
    curr_time1 = int(time.mktime(curr_time1.timetuple()))

    # Check that timestamp is within 2 seconds of current time
    assert stats1['user_stats']['channels_joined'][0]['time_stamp'] - curr_time1 < 2

    # User creates 2 dms
    dm1 = th.dm_create(token1, []).json()
    dm_id = dm1["dm_id"]
    th.dm_create(token1, [])

    # Call user/stats/v1 again
    stats2 = th.user_stats(token1).json()

    # Get current timestamp
    curr_time2 = datetime.datetime.now()
    curr_time2 = int(time.mktime(curr_time2.timetuple()))

    # Check that the timestamp for channels_joined is updated and the timestamp
    # for dms_joined is correct
    assert stats2['user_stats']['channels_joined'][0]['time_stamp'] - curr_time2 < 2
    assert stats2['user_stats']['dms_joined'][0]['time_stamp'] - curr_time2 < 2

    # Send a message in the channel and a message in the dm
    th.message_send(token1, channel_id, "blahblahblah")
    th.message_senddm(token1, dm_id, "hellohellohello")

    # Call user/stats/v1 again
    stats3 = th.user_stats(token1).json()

    # Get current timestamp
    curr_time3 = datetime.datetime.now()
    curr_time3 = int(time.mktime(curr_time3.timetuple()))

    # Check that the timestamp for channels_joined and dms_joined is updated and 
    # the timestamp for messages_sent is correct
    assert stats3['user_stats']['channels_joined'][0]['time_stamp'] - curr_time3 < 2
    assert stats3['user_stats']['dms_joined'][0]['time_stamp'] - curr_time3 < 2
    assert stats3['user_stats']['messages_sent'][0]['time_stamp'] - curr_time3 < 2

# Test that channels_joined is correct
def test_user_stats_channels_joined(clear_data):
    # Register two users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    # User1 creates 3 channels
    channel1 = th.channels_create(token1, "Totoro", True).json()
    channel_id1 = channel1["channel_id"]
    th.channels_create(token1, "CaramelPopcorn", False)
    th.channels_create(token1, "Pizza", True)

    # User1 calls user/stats/v1
    user1_stats1 = th.user_stats(token1).json()

    # Check the number of channels joined is correct
    assert user1_stats1['user_stats']['channels_joined'][3]['num_channels_joined'] == 3

    # User2 creates 2 channels
    channel4 = th.channels_create(token2, "CornIcecream", True).json()
    channel5 = th.channels_create(token2, "ChocolatePopcorn", False).json()
    channel_id4 = channel4["channel_id"]
    channel_id5 = channel5["channel_id"]

    # User2 calls user/stats/v1
    user2_stats1 = th.user_stats(token2).json()

    # Check the number of channels joined is correct
    assert user2_stats1['user_stats']['channels_joined'][2]['num_channels_joined'] == 2

    # User1 is invited to user2's channels
    th.channel_invite(token2, channel_id4, u_id1)
    th.channel_invite(token2, channel_id5, u_id1)

    # User1 calls user/stats/v1 again
    user1_stats2 = th.user_stats(token1).json()

    # Check that the number of channels_joined has been updated
    assert user1_stats2['user_stats']['channels_joined'][5]['num_channels_joined'] == 5

    # User1 invites user2 to one of its channels
    th.channel_invite(token1, channel_id1, u_id2)

    # User1 calls user/stats/v1 again
    user2_stats2 = th.user_stats(token2).json()

    # Check that the number of channels_joined has been updated
    assert user2_stats2['user_stats']['channels_joined'][3]['num_channels_joined'] == 3

# Test that dms_joined is correct
def test_user_stats_dms_joined(clear_data):
    # Register two users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    # User1 creates 3 dms with user2
    th.dm_create(token1, [u_id2])
    th.dm_create(token1, [u_id2])
    th.dm_create(token1, [u_id2])

    # User1 calls user/stats/v1
    user1_stats1 = th.user_stats(token1).json()

    # Check the number of dms joined is correct
    assert user1_stats1['user_stats']['dms_joined'][3]['num_dms_joined'] == 3

    # User2 creates 2 dms with just themself
    th.dm_create(token2, [])
    th.dm_create(token2, [])

    # User2 calls user/stats/v1
    user2_stats1 = th.user_stats(token2).json()

    # Check the number of dms joined is correct
    assert user2_stats1['user_stats']['dms_joined'][5]['num_dms_joined'] == 5

# Test that messages_sent is correct
def test_user_stats_msgs_sent(clear_data):

    # Register 3 users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    user3 = th.auth_register("ccc@gmail.com", "10000000000", "Max", "D").json()
    token3 = user3["token"]
    u_id3 = user3["auth_user_id"]

    # User1 creates a channel and invites user2 and user3
    channel1 = th.channels_create(token1, "Totoro", True).json()
    channel_id1 = channel1["channel_id"]

    th.channel_invite(token1, channel_id1, u_id2)
    th.channel_invite(token1, channel_id1, u_id3)

    # User2 creates a channel and invites user1 and user3
    channel2 = th.channels_create(token2, "BinChicken", True).json()
    channel_id2 = channel2["channel_id"]

    th.channel_invite(token2, channel_id2, u_id1)
    th.channel_invite(token2, channel_id2, u_id3)

    # User3 creates a dm with user1 and user2
    dm1 = th.dm_create(token1, [u_id1, u_id2]).json()
    dm_id1 = dm1["dm_id"]

    # User1 sends a message in channel1, channel2 and dm1
    th.message_send(token1, channel_id1, "blahblahblah")
    th.message_send(token1, channel_id1, "hellohellohello")
    th.message_senddm(token1, dm_id1, "Never gonna give you up")

    # Check the msgs_sent stats for user1 is 3
    user1_stats1 = th.user_stats(token1).json()

    assert user1_stats1['user_stats']['messages_sent'][3]['num_messages_sent'] == 3

    # Check the msgs_sent stats for user2 is 0
    user2_stats1 = th.user_stats(token2).json()

    assert user2_stats1['user_stats']['messages_sent'][0]['num_messages_sent'] == 0

    # User2 sends 2 messages in the dm
    th.message_senddm(token2, dm_id1,"Never gonna let you down")
    th.message_senddm(token2, dm_id1,"Never gonna run around and desert you")

    # Check the msgs_sent stats for user2 is 2
    user2_stats2 = th.user_stats(token2).json()

    assert user2_stats2['user_stats']['messages_sent'][2]['num_messages_sent'] == 2

    # User3 sends a message in channel2
    th.message_send(token3, channel_id2, "Fish icecream is gross")

    # Check the msgs_sent stats for user 3
    user3_stats1 = th.user_stats(token3).json()

    assert user3_stats1['user_stats']['messages_sent'][1]['num_messages_sent'] == 1

# Test that removing messages does not decrease msgs_sent
def test_user_stats_removed_messages(clear_data):

    # Register User1
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    # User1 creates a channel
    channel1 = th.channels_create(token1, "Totoro", True).json()
    channel_id1 = channel1["channel_id"]

    # User1 sends 4 messages in the channel
    message1 = th.message_send(token1, channel_id1, "a").json()
    message_id1 = message1["message_id"]
    th.message_send(token1, channel_id1, "b")
    th.message_send(token1, channel_id1, "c")
    th.message_send(token1, channel_id1, "d")

    # Message 1 is removed
    th.message_remove(token1, message_id1)

    # Check that the users' msgs_sent is still 4
    stats1 = th.user_stats(token1).json()

    assert stats1['user_stats']['messages_sent'][4]['num_messages_sent'] == 4

    # Send another 2 messages in the channel
    message5 = th.message_send(token1, channel_id1, "e").json()
    message_id5 = message5["message_id"]
    th.message_send(token1, channel_id1, "f")

    # Check the users' msgs_sent is 6
    stats2 = th.user_stats(token1).json()
    
    assert stats2['user_stats']['messages_sent'][7]['num_messages_sent'] == 6

    # Remove 5th message
    th.message_remove(token1, message_id5)

    # Check the users' msgs_sent is still 6
    stats3 = th.user_stats(token1).json()

    assert stats3['user_stats']['messages_sent'][8]['num_messages_sent'] == 6
        
# Test that involvement rate is correct
def test_user_stats_involvement(clear_data):
    # Register 3 users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]

    user3 = th.auth_register("ccc@gmail.com", "10000000000", "Max", "D").json()
    token3 = user3["token"]

    # User1 creates 5 channels and sends a message in each
    for i in range(0, 5):
        channel = th.channels_create(token1, f"channel{i}", True).json()
        channel_id = channel["channel_id"]
        th.message_send(token1, channel_id, str(i))

    # User2 creates 2 dms  and sends a message in each
    dm1 = th.dm_create(token2, []).json()
    dm2 = th.dm_create(token2, []).json()

    dm_id1 = dm1['dm_id']
    dm_id2 = dm2['dm_id']

    th.message_senddm(token2, dm_id1, "1")
    th.message_senddm(token2, dm_id2, "2")

    # Check user1's involvement stats
    user1_stats = th.user_stats(token1).json()

    assert user1_stats['user_stats']['involvement_rate'] == \
           (5 + 0 + 5) / (5 + 2 + 7)

    # Check user2's involvemente stats
    user2_stats = th.user_stats(token2).json()
    
    assert user2_stats['user_stats']['involvement_rate'] == \
           (0 + 2 + 2) / (5 + 2 + 7)

    # Check that user3's stats is 0
    user3_stats = th.user_stats(token3).json()

    assert user3_stats['user_stats']['involvement_rate'] == 0

# Test that involvement rate is capped at 1
def test_user_stats_max_involvement(clear_data):

    # Register a user
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    # Create a channel
    channel1 = th.channels_create(token1, "Totoro", True).json()
    channel_id1 = channel1["channel_id"]

    # Send 5 messages in the channel and immediately remove them
    for i in range(1, 6):
        th.message_send(token1, channel_id1, str(i))
        th.message_remove(token1, str(i))
    
    # Send a 6th message
    th.message_send(token1, channel_id1, "6")

    # Check that involvement rate is capped at 1 even though it would be 6
    stats = th.user_stats(token1).json()

    assert stats['user_stats']['involvement_rate'] == 1
    
# Test if stats is correct when standup is used
def test_user_stats_standup(clear_data):
    
    # Register a user
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    # Create a channel
    channel1 = th.channels_create(token1, "Totoro", True).json()
    channel_id1 = channel1["channel_id"]

        
    # User1 starts a standup
    th.start_standup(token1, channel_id1, 1)

    # User1 sends a message during the standup
    th.send_standup(token1, channel_id1, "BYE")
    
    time.sleep(1)

    # Get users stats
    users_stats = th.user_stats(token1).json()

    # Get current time
    curr_time = datetime.datetime.now()
    curr_time = int(time.mktime(curr_time.timetuple()))

    # Check that messages_sent is correct and that time_stamp is within a second of
    # the request being sent
    assert users_stats['user_stats']['messages_sent'][1]['num_messages_sent'] == 1
    assert users_stats['user_stats']['messages_sent'][1]['time_stamp'] - curr_time < 2
