import pytest
import requests 
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')

# Invalid token
def test_admin_remove_v1_invalid_token(clear_data):
    # Register user
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    u_id = user1["auth_user_id"]

    # Pass in invalid token
    remove_response = th.admin_remove(th.invalid_token1(), u_id)

    assert remove_response.status_code == AccessError.code


# U_id does not refer to a valid user
def test_admin_remove_v1_invalid_user(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token = user1["token"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    u_id = user2["auth_user_id"]

    # Pass in invalid u_id
    remove_response = th.admin_remove(token, u_id + 1)

    assert remove_response.status_code == InputError.code


# U_id refers to a user who is the only global owner and are removing themselves
def test_admin_remove_v1_only_global_owner(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    # Change user2 to global owner
    th.admin_change(token1, u_id2, 1)

    # User 1 removes themselves
    remove_response1 = th.admin_remove(token1, u_id1)
    assert remove_response1.status_code == Success.code

    # User 2 removes themselves but fails, only global owner
    remove_response2 = th.admin_remove(token2, u_id2)
    assert remove_response2.status_code == InputError.code


# The authorised user is not a global owner
def test_admin_remove_v1_not_global_owner(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    u_id = user1["auth_user_id"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user2["token"]

    # User 2 tries to remove user 1, but is not a global owner
    remove_response = th.admin_remove(token, u_id)
    assert remove_response.status_code == AccessError.code


# Test a user cannot be removed twice and InputError status code is returned
def test_admin_remove_cant_remove_twice(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token = user1["token"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    u_id = user2["auth_user_id"]

    # Remove user 2
    remove_response1 = th.admin_remove(token, u_id)
    assert remove_response1.status_code == Success.code

    # Try to remove user 2 again
    remove_response2 = th.admin_remove(token, u_id)
    assert remove_response2.status_code == InputError.code


# Remove user and checks if user can still be found
def test_admin_remove_v1_user_list(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    u_id2 = user2["auth_user_id"]

    # Remove user 2
    remove_response = th.admin_remove(token1, u_id2)
    assert remove_response.status_code == Success.code

    # Get all users
    user_list = th.users_all(token1).json()

    assert user_list == {'users': [{'u_id': u_id1,
                                    'email': 'rick@gmail.com',
                                    'name_first': 'derrick', 
                                    'name_last': 'doan',
                                    'handle_str': 'derrickdoan',
                                    'profile_img_url': config.url + "static/default.jpg"}]}


# Checks if removed users is no longer part of channel
# Also checks for channel messages
def test_admin_remove_v1_channel_owner(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    user3 = th.auth_register("ravel@gmail.com", "password1", "maurice", "ravel").json()
    token3 = user3["token"]
    u_id3 = user3["auth_user_id"]

    # User 2 creates channel
    channel = th.channels_create(token2, "Music", True).json()
    channel_id = channel["channel_id"]

    # User 1 and 3 join channel
    th.channel_join(token1, channel_id)
    th.channel_join(token3, channel_id)

    # Make user 1 and 3 an owner
    th.channel_add_owner(token2, channel_id, u_id1)
    th.channel_add_owner(token2, channel_id, u_id3)

    # User 2 sends a message
    th.message_send(token2, channel_id, "HD EZ CLAP")

    # Remove user 2
    remove_response = th.admin_remove(token1, u_id2)
    assert remove_response.status_code == Success.code

    # Check for channel details
    details = th.channel_details(token1, channel_id).json()

    # Make sure details is correct
    assert details == {
        'name': 'Music',
        'is_public': True,
        'owner_members': [
            {
				'u_id': u_id1,
				'email': 'rick@gmail.com',
				'handle_str': 'derrickdoan',
				'name_first': 'derrick',
				'name_last': 'doan',
                'profile_img_url': config.url + "static/default.jpg"
			 },
            {
				'u_id': u_id3,
				'email': 'ravel@gmail.com',
				'handle_str': 'mauriceravel',
				'name_first': 'maurice',
				'name_last': 'ravel',
                'profile_img_url': config.url + "static/default.jpg"
			 }
        ],
        'all_members': [
            {
				'u_id': u_id1,
				'email': 'rick@gmail.com',
				'handle_str': 'derrickdoan',
				'name_first': 'derrick',
				'name_last': 'doan',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
				'u_id': u_id3,
				'email': 'ravel@gmail.com',
				'handle_str': 'mauriceravel',
				'name_first': 'maurice',
				'name_last': 'ravel',
                'profile_img_url': config.url + "static/default.jpg"
			 }
        ]
    }
    # Check for correct message in channel
    messages = th.channel_messages(token1, channel_id, 0).json()

    assert messages['messages'][0]['message_id'] == 1
    assert messages['messages'][0]['u_id'] == u_id2
    assert messages['messages'][0]['message'] == "Removed user"


# Checks dm_details and dm_messages
def test_admin_remove_v1_dm_details(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    dm_response = th.dm_create(token2, [u_id1]).json()
    dm_id = dm_response["dm_id"]

    # User 2 sends a message
    th.message_senddm(token2, dm_id, "Rani goated fr")

    # User 1 sends a message
    th.message_senddm(token1, dm_id, "Evil programming be like: Goodbye World")

    # Remove user 2
    remove_response = th.admin_remove(token1, u_id2)
    assert remove_response.status_code == Success.code

    details = th.dm_details(token1, dm_id).json()

    assert details == {
        'name': 'derrickdoan, franzliszt',
        'members': [{'u_id': 1, 
                     'email': 'rick@gmail.com',
                     'name_first': 'derrick',
                     'name_last': 'doan',
                     'handle_str': 'derrickdoan',
                     'profile_img_url': config.url + "static/default.jpg"}
                    ]
        }

    messages = th.dm_messages(token1, dm_id, 0).json()

    assert messages['messages'][0]['message_id'] == 2
    assert messages['messages'][0]['u_id'] == u_id1
    assert messages['messages'][0]['message'] == "Evil programming be like: Goodbye World"

    assert messages['messages'][1]['message_id'] == 1
    assert messages['messages'][1]['u_id'] == u_id2
    assert messages['messages'][1]['message'] == "Removed user"


# Test whether user profile is still retrievable with users/profile
def test_admin_remove_profile_still_retrievable(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token = user1["token"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    u_id = user2["auth_user_id"]

    # Remove user 2
    remove_response = th.admin_remove(token, u_id)
    assert remove_response.status_code == Success.code

    # Get profile and check for response
    profile = th.user_profile(token, u_id).json()

    assert profile == {
                        'user': {
                            'u_id': u_id,
                            'email': "",
                            'name_first': "Removed",
                            'name_last': "user",
                            'handle_str': "",
                            'profile_img_url': ''
                        }
                }


# Test whether removed message do not affect this function
def test_admin_remove_removed_message(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token1 = user1["token"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    # User 1 creates channel
    channel = th.channels_create(token1, "CAMEL", True).json()
    channel_id = channel["channel_id"]

    # User 2 joins channel
    th.channel_join(token2, channel_id)

    # User 2 sends 2 messages
    message1 = th.message_send(token2, channel_id, "Why did they ban gambling at the zoo?").json()
    message_id = message1["message_id"]

    th.message_send(token2, channel_id, "Because there was too many cheetahs")
    
    # User 1 removes 1st message
    th.message_remove(token1, message_id)

    # Remove user 2
    remove_response = th.admin_remove(token1, u_id2)
    assert remove_response.status_code == Success.code
