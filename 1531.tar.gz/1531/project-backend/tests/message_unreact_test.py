import pytest
import requests
from src import config
from src.error import AccessError, InputError
import tests.test_helpers as th

@pytest.fixture
def clear():
    requests.delete(config.url + "clear/v1")

# Testing if the user token is invalid
def test_message_unreact_v1_token_invalid(clear):

    reg_response1 = th.auth_register("derrick@gmail.com",
                                     "123456",
                                     "Derrick",
                                     "Doan").json()

    channel_response1 = th.channels_create(reg_response1['token'],
                                           "Channel 1",
                                           True).json()

    message_response1 = th.message_send(reg_response1['token'], 
                                        channel_response1['channel_id'], 
                                        "The first lecture will be on Wednesday 10am").json()

    th.message_react(reg_response1['token'], message_response1['message_id'], 1)

    # Input invalid token into the function
    unreact_response = th.message_unreact(th.invalid_token2(),
                                          message_response1["message_id"],
                                          1) 

    # Checking the Access Error code
    assert unreact_response.status_code == AccessError.code

# Testing if the message_id is not valid
def test_message_unreact_v1_message_id_invalid(clear):
    
    reg_response1 = th.auth_register("derrick@gmail.com",
                                     "123456",
                                     "Derrick",
                                     "Doan").json()

    channel_response1 = th.channels_create(reg_response1['token'],
                                           "Channel 1",
                                           True).json()

    message_response1 = th.message_send(reg_response1['token'], 
                                        channel_response1['channel_id'], 
                                        "The first lecture will be on Wednesday 10am").json()

    th.message_react(reg_response1, message_response1, 1)

    # Input invalid message_id
    unreact_response = th.message_unreact(reg_response1['token'],
                                          1000,
                                          0) 

    # Checking the Input Error code
    assert unreact_response.status_code == InputError.code

# # Testing if the user is in the dm or not
def test_message_unreact_v1_dm_not_joined(clear):
    
    reg_response1 = th.auth_register("Allan@gmail.com", 
                                     "pwpwpwpw", 
                                     "Allan", 
                                     "Zhang").json()

    reg_response2 = th.auth_register("justins@gmail.com", 
                                     "password", 
                                     "Justin", 
                                     "Son").json()

    dm_response1 = th.dm_create(reg_response1['token'], 
                                [reg_response2["auth_user_id"]]).json()

    message_response1 = th.message_senddm(reg_response1['token'], 
                                          dm_response1['dm_id'], "Bye").json()

    th.message_react(reg_response2['token'], message_response1['message_id'], 1)

    # User 2 leaves the dm
    th.dm_leave(reg_response2['token'], dm_response1['dm_id'])

    # User 2 attemps to unreact the message
    unreact_response = th.message_unreact(reg_response2['token'],
                                          message_response1["message_id"],
                                          1) 
    
    assert unreact_response.status_code == InputError.code

# # Testing if the user is in the channel or not
def test_message_unreact_v1_channel_not_joined(clear):
     
    reg_response1 = th.auth_register("Max@gmail.com",
                                     "pasword1",
                                     "Max", 
                                     "Dalgeish").json()

    reg_response2 = th.auth_register("cynthia@gmail.com",
                                     "10101010101", 
                                     "Cynthia", 
                                     "Li").json()

    channel_response1 = th.channels_create(reg_response1['token'], 
                                           "CAMEL", 
                                           True).json()

    th.channel_join(reg_response2['token'], channel_response1['channel_id'])

    message_response1 = th.message_send(reg_response1['token'], 
                                        channel_response1['channel_id'], 
                                        "birb").json()

    th.message_react(reg_response2['token'], message_response1['message_id'], 1)

    # User 2 leaves the channel
    th.channel_leave(reg_response2['token'], channel_response1['channel_id'])

    # User 2 attempts to unreact the message in the channel
    unreact_response = th.message_unreact(reg_response2['token'],
                                          message_response1["message_id"],
                                          1) 

    # Checking the Input Error code
    assert unreact_response.status_code == InputError.code
    
# Testing if the react_id is invalid
def test_message_unreact_v1_react_id_invalid(clear):

    reg_response1 = th.auth_register("Allan@gmail.com", 
                                     "pwpwpwpw", 
                                     "Allan", 
                                     "Zhang").json()

    reg_response2 = th.auth_register("derrick@gmail.com", 
                                     "123456",
                                     "Derrick", 
                                     "Doan").json()

    channel_response1 = th.channels_create(reg_response1['token'], 
                                           "Channel 1", 
                                           True).json()

    th.channel_join(reg_response2['token'], channel_response1['channel_id'])

    message_response1 = th.message_send(reg_response1['token'], 
                                        channel_response1['channel_id'], 
                                        "Icecream").json()

    th.message_react(reg_response2['token'], message_response1['message_id'], 1)

    # User 2 attempts to unreact the message with invalid react_id
    unreact_response = th.message_unreact(reg_response2['token'],
                                          message_response1["message_id"],
                                          99) 

    # Checking for the InputError code
    assert unreact_response.status_code == InputError.code

# Testing correct unreacting in channel messages
def test_message_unreact_v1_channel_message(clear):
     
    reg_response1 = th.auth_register("gyg@gmail.com", 
                                     "quisedilla", 
                                     "G", 
                                     "YG").json()

    reg_response2 = th.auth_register("helloworld@gmail.com", 
                                     "password", 
                                     "hello",
                                     "world").json()

    channel_response1 = th.channels_create(reg_response1['token'], 
                                           "New channel", 
                                           False).json()

    th.channel_invite(reg_response1['token'], 
                      channel_response1['channel_id'], 
                      reg_response2['auth_user_id'])

    message_response1 = th.message_send(reg_response1['token'], 
                                        channel_response1['channel_id'], 
                                        "Icecream").json()
    
    # Both users react to user 1's message
    th.message_react(reg_response1['token'], message_response1['message_id'], 1)
    th.message_react(reg_response2['token'], message_response1['message_id'], 1)

    # Both users unreact to the message in the channel
    th.message_unreact(reg_response1['token'],
                       message_response1["message_id"],
                       1) 

    th.message_unreact(reg_response2['token'],
                       message_response1["message_id"],
                       1) 

    # User 1 gets the channel messages data
    channel_messages_response1 = th.channel_messages(reg_response1['token'], 
                                                     message_response1['message_id'], 
                                                     0).json()

    assert channel_messages_response1['messages'][0]['reacts'] == [
                                            {   'react_id': 1,
                                                'u_ids': [],
                                                'is_this_user_reacted': False
                                            }
                                    ]

# Testing correct unreacting in DM messages
def test_message_unreact_v1_dm_message(clear):

    reg_response1 = th.auth_register("hotmail@gmail.com", 
                                     "543210987", 
                                     "Calamari", 
                                     "Ring").json()

    reg_response2 = th.auth_register("derrick@gmail.com", 
                                     "00000000", 
                                     "Derrick", 
                                     "D").json()

    dm_response1 = th.dm_create(reg_response1['token'], 
                                [reg_response2['auth_user_id']]).json()

    message_response1 = th.message_senddm(reg_response2['token'], 
                                          dm_response1['dm_id'], 
                                          "first message ever").json()

    # Both users react to User 2's message
    th.message_react(reg_response1['token'], message_response1['message_id'], 1)
    th.message_react(reg_response2['token'], message_response1['message_id'], 1)

    # Both users unreact to the message in the channel
    th.message_unreact(reg_response1['token'],
                       message_response1["message_id"],
                       1) 

    th.message_unreact(reg_response2['token'],
                       message_response1["message_id"],
                       1) 

    # User 1 gets the dm message data
    dm_message_response1 = th.dm_messages(reg_response1['token'], 
                                          dm_response1['dm_id'], 
                                          0).json()
    
    assert dm_message_response1['messages'][0]['reacts'][0] == {'react_id': 1,
                                                                'u_ids': [],
                                                                'is_this_user_reacted': False
                                                                }
                                                            

# Testing when the message is not reacted by the user in the first place
def test_message_unreact_v1_reacted(clear):

    reg_response1 = th.auth_register("hello@gmail.com", 
                                     "password", 
                                     "Calamari", 
                                     "Ring").json()

    reg_response2 = th.auth_register("world@gmail.com", 
                                     "12341234", 
                                     "Basket", 
                                     "Ball").json()

    channel_response1 = th.channels_create(reg_response1['token'], 
                                           "CAMEL", 
                                           True).json()

    th.channel_join(reg_response1['token'], channel_response1['channel_id'])

    message_response1 = th.message_send(reg_response1['token'], 
                                        channel_response1['channel_id'], 
                                        "hellohellohellohello").json()

    # User 2 attempts to unreact the message without reacting first
    unreact_response = th.message_unreact(reg_response2['token'],
                                          message_response1["message_id"],
                                          1) 

    # Checking the Input Error code
    assert unreact_response.status_code == InputError.code