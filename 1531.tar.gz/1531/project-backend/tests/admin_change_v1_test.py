import pytest
import requests 
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')


# Invalid token
def test_admin_change_v1_invalid_token(clear_data):

    change_response = th.admin_change(th.invalid_token1(), 1, 1)
    assert change_response.status_code == AccessError.code


# U_id does not refer to a valid user
def test_admin_change_v1_invalid_user(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token = user1["token"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    u_id = user2["auth_user_id"]

    # U id not valid
    change_response = th.admin_change(token, u_id + 1, 1)
    assert change_response.status_code == InputError.code


# U_id refers to a user who is the only global owner and they are being demoted to a user
def test_admin_change_v1_only_global_owner(clear_data):
    # Register users
    user = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token = user["token"]
    u_id = user["auth_user_id"]

    # Can't self demote when only global owner
    change_response = th.admin_change(token, u_id, 2)
    assert change_response.status_code == InputError.code


# Permission_id is invalid
def test_admin_change_v1_invalid_permission_id(clear_data):
    # Register users
    user = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token = user["token"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    u_id = user2["auth_user_id"]

    # 3 not a valid permission id
    change_response = th.admin_change(token, u_id, 3)
    assert change_response.status_code == InputError.code


# The authorised user is not a global owner
def test_admin_change_v1_not_global_owner(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    u_id = user1["auth_user_id"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token = user2["token"]

    # user 2 not global owner
    change_response = th.admin_change(token, u_id, 2)
    assert change_response.status_code == AccessError.code


# Tests for correct return
def test_admin_change_v1_correct_return(clear_data):
    # Register users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token = user1["token"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    u_id = user2["auth_user_id"]

    # Check for success and correct return
    change_response1 = th.admin_change(token, u_id, 1)
    assert change_response1.status_code == Success.code

    assert change_response1.json() == {}


# Test for correct behaviour for multiple users
def test_admin_change_v1_multiple_users(clear_data):
    #  Register 3 users
    user1 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    user3 = th.auth_register("ravel@gmail.com", "password1", "maurice", "ravel").json()
    token3 = user3["token"]
    u_id3 = user3["auth_user_id"]

    # User_1 changes user_2, his best friend, to global owner
    change_response1 = th.admin_change(token1, u_id2, 1)
    assert change_response1.status_code == Success.code

    # User_2 changes his other friend user_3 to global owner
    change_response2 = th.admin_change(token2, u_id3, 1)
    assert change_response2.status_code == Success.code

    # User_1 decided the pressure as a global owner was too much, and steps down.
    # User_1 changes himself to a regular member
    change_response3 = th.admin_change(token1, u_id1, 2)
    assert change_response3.status_code == Success.code 

    # User_3 betrays user_2 and makes him a regular member
    change_response4 = th.admin_change(token3, u_id2, 2)
    assert change_response4.status_code == Success.code 

    # Register user 4 and create a private channel
    user4 = th.auth_register("bach@gmail.com", "password1", "js", "bach").json()
    token4 = user4["token"]
    u_id4 = user4["auth_user_id"]

    channel = th.channels_create(token4, "Music", False).json()
    channel_id = channel["channel_id"]

    # User 1 can't join
    join_response1 = th.channel_join(token1, channel_id)
    assert join_response1.status_code == AccessError.code

    # User 2 can't join
    join_response2 = th.channel_join(token2, channel_id)
    assert join_response2.status_code == AccessError.code

    # User 3 can join
    join_response3 = th.channel_join(token3, channel_id)
    assert join_response3.status_code == Success.code

    # Check for channel details
    details = th.channel_details(token4, channel_id).json()

    assert details == {
        'name': 'Music',
        'is_public': False,
        'owner_members': [
            {
                'u_id': u_id4,
                'email': "bach@gmail.com",
                'name_first': "js",
                'name_last': "bach",
                'handle_str': "jsbach",
                'profile_img_url': config.url + "static/default.jpg"
            }
        ],
        'all_members': [
            {
                'u_id': u_id4,
                'email': "bach@gmail.com",
                'name_first': "js",
                'name_last': "bach",
                'handle_str': "jsbach",
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id3,
                'email': "ravel@gmail.com",
                'name_first': "maurice",
                'name_last': "ravel",
                'handle_str': "mauriceravel",
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }