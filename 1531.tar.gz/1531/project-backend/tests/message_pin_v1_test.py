import pytest
import requests
from src import config
from src.error import AccessError, InputError
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")

# Test if invalid token raises an AccessError
def test_message_pin_invalid_token(clear_data):

    # Register user 1
    register_response1 = th.auth_register('justin@gmail.com',
                                          'password123',
                                          'Justin',
                                          'Son').json()
    token1 = register_response1['token']
    
    # User 1 creates a dm to themself
    dm_create_response = th.dm_create(token1, []).json()
    
    # Send a dm
    send_response = th.message_senddm(token1,
                                      dm_create_response['dm_id'],
                                      "Just do it").json()
    
    # Pin the dm message given an invalid token
    pin_response = th.message_pin(th.invalid_token1(),
                                  send_response['message_id'])

    assert pin_response.status_code == AccessError.code
    
# Test whether InputError is raised given invalid message id for channel
def test_message_pin_channel_invalid_id(clear_data):
    
    # Register a user and save response
    register_response = th.auth_register('justin@gmail.com',
                                         'password123',
                                         'Justin',
                                         'Son').json()
    token = register_response['token']

    # Create a channel and save response
    channel_response = th.channels_create(register_response['token'],
                                          'Vroom',
                                          False).json()

    # Send a message in the channel
    th.message_send(register_response['token'],
                    channel_response['channel_id'],
                    "Skrt Skrt")
    
    # Pin the message given an invalid message id in channel
    pin_response = th.message_pin(token, 0)

    assert pin_response.status_code == InputError.code

# Test whether InputError is raised given invalid message id for dm
def test_message_pin_dm_invalid_id(clear_data):

    # Register user 1
    register_response1 = th.auth_register('justin@gmail.com',
                                         'password123',
                                         'Justin',
                                         'Son').json()
    token1 = register_response1['token']
    
    # User 1 creates a dm to themself
    dm_create_response = th.dm_create(token1, []).json()
    
    # Send a dm
    th.message_senddm(token1, 
                      dm_create_response['dm_id'], 
                      "Aloha :)")

    # Pin the message given an invalid message id in dm
    pin_response = th.message_pin(token1, 0)
    
    assert pin_response.status_code == InputError.code

# Test whether InputError raised if the message is already pinned
def test_message_pin_already(clear_data):
    
    # Register a user and save response
    register_response = th.auth_register('justin@gmail.com',
                                         'password123',
                                         'Justin',
                                         'Son').json()
    token = register_response['token']

    # Create a channel and save response
    channel_response = th.channels_create(register_response['token'],
                                               'bobaicecream',
                                               False).json()

    # Send a message in the channel
    send_response = th.message_send(register_response['token'],
                                         channel_response['channel_id'],
                                         "yummy").json()
    
    # Pin the message
    th.message_pin(token, send_response['message_id'])
    
    # Pin the same message again
    pin_response = th.message_pin(token, send_response['message_id'])

    assert pin_response.status_code == InputError.code

# Test if accesserror is raised when message is pinned by a non-owner in dm
def test_message_pin_valid_but_not_owner_dm(clear_data):
    
    # Register user1 and save response
    register_response1 = th.auth_register('justin@gmail.com',
                                         'password123',
                                         'Justin',
                                         'Son').json()
    token1 = register_response1['token']
    
    # Register user2 and save response
    register_response2 = th.auth_register('cynthia@gmail.com',
                                         'password123456',
                                         'Cynthia', 
                                         'Li').json()
    token2 = register_response2['token']
    auth_register_2 = register_response2['auth_user_id']
    
    # User1 creates a dm with user2
    dm_create_response = th.dm_create(token1, [auth_register_2]).json()

    # User2 sends a dm message
    send_response = th.message_senddm(token2,
                                      dm_create_response['dm_id'],
                                      "Lets go").json()
    
    # User2 attempts to pin the message
    pin_response = th.message_pin(token2, send_response['message_id'])
    
    assert pin_response.status_code == AccessError.code
    
# Test if accesserror is raised when message is pinned by a non-owner in channel
def test_message_pin_valid_but_not_owner_channel(clear_data):
    
    # Register user1 and save response
    register_response1 = th.auth_register('justin@gmail.com',
                                         'password123',
                                         'Justin',
                                         'Son').json()
    token1 = register_response1['token']
    
    # Register user2 and save response
    register_response2 = th.auth_register('cynthia@gmail.com',
                                         'password123456',
                                         'Cynthia', 
                                         'Li').json()
    token2 = register_response2['token']
    
    # User1 creates a channel and save response
    channel_response = th.channels_create(token1, 'Yesterday', True).json()
    channel_id = channel_response['channel_id']
    
    # User 2 joins channel
    th.channel_join(token2, channel_id)

    # User2 send a message in the channel
    send_response = th.message_send(token2, channel_id, "Off the grid").json()
    
    # User2 attempts to pin the message
    pin_response = th.message_pin(token2, send_response['message_id'])

    assert pin_response.status_code == AccessError.code

# Test if inputerror is raised when user who hasnt joined any dm or channel 
# tries to pin a message
def test_message_pin_not_a_member(clear_data):
    
    # Register user1 and save response
    register_response1 = th.auth_register('justin@gmail.com',
                                         'password123',
                                         'Justin',
                                         'Son').json()
    token1 = register_response1['token']
    
    # Register user2 and save response
    register_response2 = th.auth_register('cynthia@gmail.com',
                                         'password123456',
                                         'Cynthia', 
                                         'Li').json()
    token2 = register_response2['token']
    auth_register_2 = register_response2['auth_user_id']
    
    # Register user3 and save response
    register_response3 = th.auth_register('Derrick@gmail.com',
                                         'password000',
                                         'Derrick',
                                         'Doan').json()
    token3 = register_response3['token']
    
    # User1 creates a channel
    channel_create_response = th.channels_create(token1, 
                                                 'Downtown', 
                                                 True).json()
    channel_id = channel_create_response['channel_id']
    
    # User2 joins channel
    th.channel_join(token2, channel_id)
    
    # User2 send a message in the channel
    send_channel_response = th.message_send(token2, channel_id, "Wednesday").json()
    
    # User1 creates a dm with user2
    dm_create_response = th.dm_create(token1, [auth_register_2]).json()

    # User2 sends a dm
    send_dm_response = th.message_senddm(token2, 
                                         dm_create_response['dm_id'],
                                         "KBBQ time").json()
    
    # User3 attempts to pin the channel message
    pin_response1 = th.message_pin(token3,
                                   send_channel_response['message_id'])
    
    # User3 attempts to pin the dm message
    pin_response2 = th.message_pin(token3,
                                   send_dm_response['message_id'])
    
    assert pin_response1.status_code == InputError.code
    assert pin_response2.status_code == InputError.code

# Test if message can be pinned if the member becomes an owner
def test_message_pin_promoted_as_owner(clear_data):
    
    # Register user1 and save response
    register_response1 = th.auth_register('justin@gmail.com',
                                         'password123',
                                         'Justin',
                                         'Son').json()
    token1 = register_response1['token']
    
    # Register user2 and save response
    register_response2 = th.auth_register('cynthia@gmail.com',
                                         'password123456',
                                         'Cynthia', 
                                         'Li').json()
    token2 = register_response2['token']
    auth_user_id2 = register_response2['auth_user_id']
    
    # Register user3 and save response
    register_response3 = th.auth_register('Derrick@gmail.com',
                                         'password000',
                                         'Derrick',
                                         'Doan').json()
    token3 = register_response3['token']
    auth_user_id3 = register_response3['auth_user_id']
    
    # User 1 makes user 3 global owner
    th.admin_change(token1, auth_user_id3, 1)
    
    # User1 creates a channel
    channel_create_response = th.channels_create(token1, 'Priv', True).json()
    channel_id = channel_create_response['channel_id']
    
    # User2 joins channel
    th.channel_join(token2, channel_id)
    
    # User2 sends a message in the channel
    send_response1 = th.message_send(token2, channel_id, "Yeezy").json()

    # User2 sends a message in the channel
    send_response2 = th.message_send(token2, channel_id, "Shoes").json()
    
    # User1 adds user2 to the channel owners
    th.channel_add_owner(token1, channel_id, auth_user_id2)
    
    # User3 attempts pins the message
    pin_response1 = th.message_pin(token3, send_response1['message_id'])

    # User3 joins the channel
    th.channel_join(token3, channel_id)

    # User3 pins the message as a global owner
    pin_response3 = th.message_pin(token3, send_response1['message_id'])

    # User2 attempts to pin the message
    pin_response2 = th.message_pin(token2, send_response2['message_id'])
    
    # user2 gets messages with start 0
    channel_messages_response = th.channel_messages(token2, 
                                                    channel_id, 
                                                    0).json()

    assert pin_response1.status_code == InputError.code
    assert pin_response2.status_code == 200
    assert pin_response3.status_code == 200
    assert channel_messages_response['messages'][0]['is_pinned'] == True