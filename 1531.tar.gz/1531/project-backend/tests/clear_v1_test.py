import pytest
import requests
import json
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")


# Test if the clear function deletes all data and return an empty dictionary
def test_clear_return():
    th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    clear_response = th.clear().json()
    assert clear_response == {}


# Test whether a user can re-register with the same details once clear_v1 has
# been run and the ids returned are the same
def test_clear_register_user_again(clear_data):
    old_user = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    old_auth_id = old_user['auth_user_id']

    th.clear()

    new_user = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    new_auth_id = new_user['auth_user_id']

    assert old_auth_id == new_auth_id


# Test whether a channel can be recreated with the same details once clear_v1
# has been run and returns the same channel_id
def test_clear_recreate_channel(clear_data):
    old_user = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    old_token = old_user['token']

    old_channel = th.channels_create(old_token, "Camel", True).json()
    old_channel_id = old_channel["channel_id"]

    th.clear()

    new_user = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    new_token = new_user['token']

    new_channel = th.channels_create(new_token, "Camel", True).json()
    new_channel_id = new_channel["channel_id"]

    assert new_channel_id == old_channel_id
