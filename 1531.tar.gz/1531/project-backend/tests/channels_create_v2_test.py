import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')

# Test whether an Access error is raised if the token is invalid
def test_invalid_token(clear_data):
    create_response = th.channels_create(th.invalid_token1(), "yes", True)
    assert create_response.status_code == AccessError.code


# Test if inputerror arises when the name of the channel is greater than 20
def test_channel_create_v2_name_length_over_20(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    # Create channel
    create_response = th.channels_create(token, "derrickjustincynthiamaxallan", True)
    assert create_response.status_code == InputError.code


# Test if input error arises when name is an empty string
def test_channel_create_v2_no_name(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    # Create channel
    create_response = th.channels_create(token, "", True)
    assert create_response.status_code == InputError.code


# Test if the creating of multiple channel works
def test_channel_create_v2_create_multiple(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]
    u_id = user1["auth_user_id"]

    # Create channel
    create_response1 = th.channels_create(token, "max", True)
    assert create_response1.status_code == Success.code

    channel1 = create_response1.json()
    channel_id1 = channel1["channel_id"]

    # Create channel
    create_response2 = th.channels_create(token, "cynthia", False)
    assert create_response2.status_code == Success.code

    channel2 = create_response2.json()
    channel_id2 = channel2["channel_id"]

    # Check for details
    details1 = th.channel_details(token, channel_id1).json()
    assert details1 == {
        'name': 'max',
        'is_public': True,
        'owner_members': [
            {
                'u_id': u_id,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ],
        'all_members': [
            {
                'u_id': u_id,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }

    # Check for details
    details2 = th.channel_details(token, channel_id2).json()
    assert details2 == {
        'name': 'cynthia',
        'is_public': False,
        'owner_members': [
            {
                'u_id': u_id,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ],
        'all_members': [
            {
                'u_id': u_id,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }
