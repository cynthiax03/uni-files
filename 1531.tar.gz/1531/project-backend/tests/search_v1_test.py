import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")
    

# Test if invalid token raises an AccessError
def test_search_invalid_token(clear_data):
    # Register user
    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token1 = user['token']

    # Create dm
    dm = th.dm_create(token1, []).json()
    dm_id = dm["dm_id"]

    th.message_senddm(token1, dm_id, "BlahBlaBlah").json()

    # Invalid user 
    search_response = th.search(th.invalid_token1(), "hi")

    assert search_response.status_code == AccessError.code

    
# Test whether InputError is raised on empty query string
def test_search_empty_query(clear_data):
    # Register user
    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token1 = user['token']

    # Create dm
    dm = th.dm_create(token1, []).json()
    dm_id = dm["dm_id"]

    th.message_senddm(token1, dm_id, "BlahBlaBlah").json()

    # Empty query
    search_response = th.search(token1, "")

    assert search_response.status_code == InputError.code


# Test whether InputError raised on query string with length over 1000
def test_search_query_len_over_1000(clear_data):
    # Register users
    user = th.auth_register("liszt@gmail.com", "password1", "franz", "liszt").json()
    token1 = user['token']

    # Create channel
    channel1 = th.channels_create(token1, "Channel 10000", False).json()
    channel_id = channel1["channel_id"]

    th.message_send(token1, channel_id, "TYoyoyoyoyoyoyo").json()

    # Search query too long
    search_query = "p10LiqPptwrkoRTPYs0yZP9dABPEiqebu6DCKheVXxOlrqbnksGZhyWbayt0ZKvDOxXdSJaHaO5i1Q2GSZSVwce3HlvCKHCSdqqoUzkQDMjkH0SDsucOZUscE1qRhejLnxL4xbWqQKQm4DU5Dll9WWq6Xi728ZuvzK5XUCfCOkHSak8xHsI3R2xJq5u2H9NBjRa5Y5ZDp1ghKMbB7X5CLYWZaJcKLyXPUxNO0fcV6RYPBhC2eE5zIS2gijBLOUQ3JHZrJVEvsdqE0ld3zw7AVa3uMyfLP5TwMgkgivi6cqER0O6wkeS4kNeFil3YC3Fr7dabbsIakHQfC9l8VhodkGGywc4N8iX3MTKdGVeEpI3DKYYRSHNEMq6QTxfUPzYN7ay0fQBrVMT3fWY2YFscXmJBpzdpWRHyX4g5MMKCzQhw2j4RemJZFD3JnR40Qk2bwL4STpNCmctgAeHrzRAF6TwpvgXGGBrmxbFxJQy4VsL8WIVgaXMosaAIcPzByDf8srtiem8WWmkx0itNu5AFKCcULtjoHLpzzFIMNW3caq9QlU2eMG6Zz4cqffTq0QqdoeUjioRQic2ldrlawr9PJJdxTtN9nYrziNnGAakVXztoynhltgxNPE3oEQiHoRNU33Sp5uTPyafOuIFj4sqfgZJLr7BbXbdKob9M7QxX1BOsYdKbGmTk5nZ5ydFfIXTS10nuqRAMzXB4Oov7sns702W8B3m0yZ8gMOkAIzYNgy2yCzkqrWzsYBncYpomX694YDHszoyCvU76NkiQS32nLKsOzip2i87i6Rf7FtUqwJOcgcZRUOKztvn84bnptQgRYBxeNuBHEKojdJOImhMJHHv5Kbc90RVjVHNZujQhmNQmVAVMC58g8wE5E8ibAcll6LyYI38hCBVVrMI9L1FHwkodXJf1uuGHWMQtXDcEtGDRVTMQwWOMSv3WCbCxPU1MUANFLQx9ocoNN3HpirKXzKthbrJjKB1aYsksaCEDW"
    search_response = th.search(token1, search_query)

    assert search_response.status_code == InputError.code   

# Test if dm messages are returned correctly when searched
def test_search_dm_messages(clear_data):
    # Register users
    user1 = th.auth_register("hello@gmail.com", "password", "Calamari", "Ring").json()
    token1 = user1['token']

    user2 = th.auth_register("world@gmail.com", "12341234", "Basket", "Ball").json()
    token2 = user2['token']
    u_id2 = user2["auth_user_id"]
    
    dm = th.dm_create(token1, [u_id2]).json()
    dm_id = dm["dm_id"]

    # User2 sends dm 51 times, which is a string of a number from 1 to 51
    for message in range(1, 52):
        th.message_senddm(token2, dm_id, str(message))
    
    # Check for response
    search_response = th.search(token1, "5").json()
    
    assert search_response['messages'][0]['u_id'] == u_id2
    assert search_response['messages'][0]['message'] == "5"
    assert search_response['messages'][0]['message_id'] == 5

# Test if dm messages are returned correctly when searched by a user who is not
# a part of the dm
def test_search_dm_messages_user_not_in(clear_data):
    # Create users
    user1 = th.auth_register("hello@gmail.com", "password", "Calamari", "Ring").json()
    token1 = user1['token']

    user2 = th.auth_register("world@gmail.com", "12341234", "Basket", "Ball").json()
    token2 = user2['token']
    u_id2 = user2["auth_user_id"]
    
    user3 = th.auth_register("rick@gmail.com", "12341234", "rick", "r").json()
    token3 = user3['token']

    # Create dm
    dm = th.dm_create(token1, [u_id2]).json()
    dm_id = dm["dm_id"]

    th.message_senddm(token2, dm_id, "hi")

    # Make sure user 3 can't find message
    search_response = th.search(token3, "hi").json()

    assert search_response['messages'] == []

    
# Test if channel messages are returned correctly when searched
def test_search_channel_messages(clear_data):
    # Register users
    user1 = th.auth_register("hello@gmail.com", "password", "Calamari", "Ring").json()
    token1 = user1['token']

    user2 = th.auth_register("world@gmail.com", "12341234", "Basket", "Ball").json()
    token2 = user2['token']
    u_id2 = user2["auth_user_id"]

    # Create channel
    channel1 = th.channels_create(token1, "Channel 10000", True).json()
    channel_id = channel1["channel_id"]

    # User 2 sends 51 messages
    th.channel_join(token2, channel_id)
    for message in range(1, 52):
        th.message_send(token2, channel_id, str(message)).json()

    # Check for search response
    search_response = th.search(token1, "9").json()

    assert search_response['messages'][0]['u_id'] == u_id2
    assert search_response['messages'][0]['message'] == "9"
    assert search_response['messages'][0]['message_id'] == 9


# Test if dm messages are returned correctly when searched by a user who is not
# a part of the channel
def test_search_channel_messages_user_not_in(clear_data):
    # Register 3 users
    user1 = th.auth_register("hello@gmail.com", "password", "Calamari", "Ring").json()
    token1 = user1['token']

    user2 = th.auth_register("world@gmail.com", "12341234", "Basket", "Ball").json()
    token2 = user2['token']
    
    user3 = th.auth_register("rick@gmail.com", "12341234", "rick", "r").json()
    token3 = user3['token']

    # Create channel and user 2 joins
    channel1 = th.channels_create(token1, "Channel 10000", True).json()
    channel_id = channel1["channel_id"]

    th.channel_join(token2, channel_id)

    th.message_send(token2, channel_id, "hey")

    # Check that user 3 doesn't find message, not in channel
    search_response = th.search(token3, "hey").json()

    assert search_response['messages'] == []


# Test if sending messages to both dm and channels can be searched correctly
def test_search_dm_and_channel_messages(clear_data):
    # Register users
    user1 = th.auth_register("hello@gmail.com", "password", "Calamari", "Ring").json()
    token1 = user1['token']

    user2 = th.auth_register("world@gmail.com", "12341234", "Basket", "Ball").json()
    token2 = user2['token']
    u_id2 = user2["auth_user_id"]

    # User 1 creates channel
    channel1 = th.channels_create(token1, "Channel 10000", True).json()
    channel_id = channel1["channel_id"]

    th.channel_join(token2, channel_id)
    
    # User 2 sends 51 channel messages
    for message in range(1, 52):
        th.message_send(token2, channel_id, str(message)).json()

    # Create dm
    dm = th.dm_create(token1, [u_id2]).json()
    dm_id = dm["dm_id"]

    # User 2 sends 51 dm messages
    for message in range(1, 52):
        th.message_senddm(token2, dm_id, str(message))

    # Check for response
    search_response = th.search(token1, "7").json()
    
    assert search_response['messages'][0]['u_id'] == u_id2
    assert search_response['messages'][0]['message'] == "7"
    assert search_response['messages'][0]['message_id'] == 7

    assert search_response['messages'][1]['message'] == "17"
    assert search_response['messages'][2]['message'] == "27"
    assert search_response['messages'][3]['message'] == "37"
    assert search_response['messages'][4]['message'] == "47"
    
    assert search_response['messages'][5]['u_id'] == u_id2
    assert search_response['messages'][5]['message'] == "7"
    assert search_response['messages'][5]['message_id'] == 58

    assert search_response['messages'][6]['message'] == "17"
    assert search_response['messages'][7]['message'] == "27"
    assert search_response['messages'][8]['message'] == "37"
    assert search_response['messages'][9]['message'] == "47"
