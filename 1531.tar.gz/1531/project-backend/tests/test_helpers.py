import requests
from src import config

##################### FUNCTIONS TO GENERATE INVALID TOKENS #####################
# Generate invalid token1
def invalid_token1():
    # Create user
    user = auth_register("dd@gmail.com", "password", "derrick", "doan").json()
    token = user["token"]

    # Logout so token is invalid
    auth_logout(token)

    return token

# Generate invalid token2
def invalid_token2():
    # Create user
    user = auth_register("cynthial@gmail.com", "password", "cynthia", "li").json()
    token = user["token"]

    # Logout so token is invalid
    auth_logout(token)

    return token

# Generate invalid token3
def invalid_token3():
    # Create user
    user = auth_register("allanz@gmail.com", "password", "allan", "zhang").json()
    token = user["token"]

    # Logout so token is invalid
    auth_logout(token)

    return token

# Generate invalid token4
def invalid_token4():
    # Create user
    user = auth_register("maxd@gmail.com", "password", "max", "dal").json()
    token = user["token"]

    # Logout so token is invalid
    auth_logout(token)

    return token

############################ FUNCTIONS FOR TEST REQUESTS ############################

def auth_login(email, password):
    return requests.post(config.url + "auth/login/v2", 
                         json={'email': email,
                               'password': password})

def auth_register(email, password, name_first, name_last):
    return requests.post(config.url + "auth/register/v2", 
                         json={'email': email,
                               'password': password,
                               'name_first': name_first, 
                               'name_last': name_last}) 

def auth_logout(token):
    return requests.post(config.url + "auth/logout/v1",
                         json={"token": token})

def channels_create(token, name, is_public):
    return requests.post(config.url + "channels/create/v2", 
                         json={'token': token,
                               'name': name,
                               'is_public': is_public})                       

def channels_list(token):
    return requests.get(config.url + "channels/list/v2",
                        params={'token': token})

def channels_listall(token):
    return requests.get(config.url + "channels/listall/v2",
                        params={'token': token})

def channel_details(token, channel_id):  
    return requests.get(config.url + "channel/details/v2",
                        params={'token': token,
                                'channel_id': channel_id})

def channel_join(token, channel_id):
    return requests.post(config.url + "channel/join/v2", 
                         json={'token': token,
                               'channel_id': channel_id})   

def channel_invite(token, channel_id, u_id):
    return requests.post(config.url + "channel/invite/v2", 
                         json={'token': token,
                               'channel_id': channel_id,
                               'u_id': u_id})

def channel_messages(token, channel_id, start):
    return requests.get(config.url + 'channel/messages/v2',
                        params={'token': token,
                                'channel_id': channel_id,
                                'start': start})

def channel_leave(token, channel_id):
    return requests.post(config.url + "channel/leave/v1",
                         json={'token': token,
                               'channel_id': channel_id})

def channel_add_owner(token, channel_id, u_id):
    return requests.post(config.url + 'channel/addowner/v1',
                         json={'token': token,
                               'channel_id': channel_id,
                               'u_id': u_id})

def channel_remove_owner(token, channel_id, u_id):
    return requests.post(config.url + 'channel/removeowner/v1',
                         json={'token': token,
                               'channel_id': channel_id,
                               'u_id': u_id})

def message_send(token, channel_id, message):
    return requests.post(config.url + "message/send/v1",
                         json={'token': token,
                               'channel_id': channel_id,
                               'message': message})

def message_edit(token, message_id, message):
    return requests.put(config.url + "message/edit/v1",
                         json={'token': token,
                               'message_id': message_id,
                               'message': message})

def message_remove(token, message_id):
    return requests.delete(config.url + "message/remove/v1",
                           json={'token': token,
                                 'message_id': message_id})

def dm_create(token, u_ids):
    return requests.post(config.url + "dm/create/v1", 
                         json={'token': token,
                               'u_ids': u_ids})

def dm_list(token):
    return requests.get(config.url + "dm/list/v1", 
                        params={'token': token})

def dm_remove(token, dm_id):
    return requests.delete(config.url + "dm/remove/v1",
                           json={'token': token,
                                 'dm_id': dm_id}) 

def dm_details(token, dm_id):
    return requests.get(config.url + "dm/details/v1",
                        params={'token': token,
                                'dm_id': dm_id})

def dm_leave(token, dm_id):
    return requests.post(config.url + "dm/leave/v1",
                         json={'token': token,
                               'dm_id': dm_id})

def dm_messages(token, dm_id, start):
    return requests.get(config.url + "dm/messages/v1", 
                        params={'token': token,
                                'dm_id': dm_id,
                                'start': start})

def message_senddm(token, dm_id, message):
    return requests.post(config.url + "message/senddm/v1",
                         json={'token': token,
                               'dm_id': dm_id,
                               'message': message})

def users_all(token):
    return requests.get(config.url + "users/all/v1",
                        params={'token': token})

def user_profile(token, u_id):
    return requests.get(config.url + "user/profile/v1",
                        params={'token': token,
                                'u_id': u_id})

def user_profile_setname(token, name_first, name_last):
    return requests.put(config.url + 'user/profile/setname/v1',
                        json={'token': token,
                              'name_first': name_first,
                              'name_last': name_last})

def user_profile_setemail(token, email):
    return requests.put(config.url + 'user/profile/setemail/v1',
                        json={'token': token, 
                              'email': email})

def user_profile_sethandle(token, handle_str):
    return requests.put(config.url + 'user/profile/sethandle/v1',
                        json={'token': token, 
                              'handle_str': 'handle_str'})

def admin_remove(token, u_id):
    return requests.delete(config.url + 'admin/user/remove/v1',
                           json={'token': token,
                                 'u_id': u_id})

def admin_change(token, u_id, permission_id):
    return requests.post(config.url + 'admin/userpermission/change/v1',
                         json={'token': token,
                               'u_id': u_id,
                               'permission_id': permission_id})

def clear():
    return requests.delete(config.url + "clear/v1")

def notifications_get(token):
    return requests.get(config.url + "notifications/get/v1",
                        params={'token': token})

def search(token, query_str):
    return requests.get(config.url + "search/v1",
                        params={'token': token,
                                'query_str': query_str})

def message_share(token, og_message_id, message, channel_id, dm_id):
    return requests.post(config.url + "message/share/v1",
                         json={'token': token,
                               'og_message_id': og_message_id,
                               'message': message,
                               'channel_id': channel_id,
                               'dm_id': dm_id})

def message_react(token, message_id, react_id):
    return requests.post(config.url + "message/react/v1",
                         json={'token': token,
                               'message_id': message_id,
                               'react_id': react_id})

def message_unreact(token, message_id, react_id):
    return requests.post(config.url + "message/unreact/v1",
                         json={'token': token,
                               'message_id': message_id,
                               'react_id': react_id})

def message_pin(token, message_id):
    return requests.post(config.url + "message/pin/v1",
                         json={'token': token,
                               'message_id': message_id})

def message_unpin(token, message_id):
    return requests.post(config.url + "message/unpin/v1",
                         json={'token': token,
                               'message_id': message_id})

def message_sendlater(token, channel_id, message, time_sent):
    return requests.post(config.url + "message/sendlater/v1",
                         json={'token': token,
                               'channel_id': channel_id,
                               'message': message,
                               'time_sent': time_sent})

def message_sendlaterdm(token, dm_id, message, time_sent):
    return requests.post(config.url + 'message/sendlaterdm/v1',
                         json={'token': token,
                               'dm_id': dm_id,
                               'message': message,
                               'time_sent': time_sent})

def start_standup(token, channel_id, length):
    return requests.post(config.url + "standup/start/v1",
                         json={'token': token,
                               'channel_id': channel_id,
                               'length': length})

def active_standup(token, channel_id):
    return requests.get(config.url + "standup/active/v1",
                        params={'token': token,
                                'channel_id': channel_id})

def send_standup(token, channel_id, message):    
    return requests.post(config.url + "standup/send/v1",
                         json={'token': token,
                               'channel_id': channel_id,
                               'message': message})

def auth_passwordreset_request(email):
    return requests.post(config.url + 'auth/passwordreset/request/v1',
                         json={'email': email})

def auth_passwordreset_reset(reset_code, new_password):
    return requests.post(config.url + 'auth/passwordreset/reset/v1',
                         json={'reset_code': reset_code,
                               'new_password': new_password})

def user_upload_photo(token, img_url, x_start, y_start, x_end, y_end):
    return requests.post(config.url + "user/profile/uploadphoto/v1",
                         json={'token': token,
                               'img_url': img_url,
                               'x_start': x_start,
                               'y_start': y_start,
                               'x_end': x_end,
                               'y_end': y_end})

def user_stats(token):
    return requests.get(config.url + "user/stats/v1",
                        params={'token': token})  

def users_stats(token):
    return requests.get(config.url + "users/stats/v1",
                        params={'token': token})
