import pytest
import requests 
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')

# Test if inputerror is raised if new password is less than 6 characters long
def test_auth_password_reset_length_invalid(clear_data):
    
    th.auth_register("justin@gmail.com", "password", "justin", "son")
    th.auth_passwordreset_request('justin@gmail.com')

    password_reset_response = th.auth_passwordreset_reset(123456, "12345")

    assert password_reset_response.status_code == InputError.code


# Test if inputerror is raised if the reset_code_is_invalid (not 6 ints)
def test_invalid_reset_code(clear_data):
    th.auth_register("justin@gmail.com", "password", "justin", "son")
    th.auth_passwordreset_request('justin@gmail.com')

    password_reset_response = th.auth_passwordreset_reset(1234567, "123456")

    assert password_reset_response.status_code == InputError.code

