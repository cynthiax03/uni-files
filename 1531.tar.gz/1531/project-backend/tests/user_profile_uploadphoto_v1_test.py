import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")


# Test if uploading photo with invalid token raises an AccessError
def test_user_uploadphoto_invalid_token(clear_data):
    # The user attempts to upload a photo with invalid token
    img_url = 'http://www.cse.unsw.edu.au/~richardb/index_files/RichardBuckland-200.png'
    upload_response = th.user_upload_photo(th.invalid_token1(), img_url, 0, 0, 100, 100)

    assert upload_response.status_code == AccessError.code


# Test if img url returns http status of anything other than 200
def test_user_uploadphoto_http_status(clear_data):
    user = th.auth_register("allan@gmail.com", "password1", "allan", "zhang").json()
    token1 = user['token']

    # The user attempts to upload a photo with invalid img url (https)
    img_url1 = 'https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885_960_720.jpg'
    upload_response1 = th.user_upload_photo(token1, img_url1, 0, 0, 100, 100)

    img_url2 = 'https///////.jpg'
    upload_response2 = th.user_upload_photo(token1, img_url2, 0, 0, 100, 100)

    img_url3 = 'http://www.cse.unsw.edu.au/~richardb/index_files/RichardBuckland-200.png'
    upload_response3 = th.user_upload_photo(token1, img_url3, 0, 0, 100, 100)

    assert upload_response1.status_code == InputError.code
    assert upload_response2.status_code == InputError.code
    assert upload_response3.status_code == InputError.code

    
# Test whether InputError is raised given invalid image dimensions
def test_user_uploadphoto_dimensions_invalid(clear_data):
    user = th.auth_register("allan@gmail.com", "password1", "allan", "zhang").json()
    token1 = user['token']

    img_url = 'http://cgi.cse.unsw.edu.au/~jas/home/pics/jas.jpg'

    upload_response = th.user_upload_photo(token1, img_url, -1, -1, 160, 201)

    assert upload_response.status_code == InputError.code

    
# Test whether InputError is raised given invalid image coordinates
def test_user_uploadphoto_dimensions_coordinates_invalid(clear_data):
    user = th.auth_register("allan@gmail.com", "password1", "allan", "zhang").json()
    token1 = user['token']

    img_url = 'http://cgi.cse.unsw.edu.au/~jas/home/pics/jas.jpg'

    upload_response = th.user_upload_photo(token1, img_url, 100, 100, 50, 50)

    assert upload_response.status_code == InputError.code

    
# Test if inputerror is raised given a non jpg file format
def test_user_uploadphoto_not_jpg(clear_data):
    user = th.auth_register("allan@gmail.com", "password1", "allan", "zhang").json()
    token1 = user['token']

    img_url = 'http://info.cern.ch'
    
    upload_response = th.user_upload_photo(token1, img_url, 0, 0, 100, 100)

    assert upload_response.status_code == InputError.code


# Test if image can be uploaded successfully
def test_user_uploadphoto_success(clear_data):
    user = th.auth_register("allan@gmail.com", "password1", "allan", "zhang").json()
    token = user['token']
    u_id = user['auth_user_id']

    img_url = 'http://cgi.cse.unsw.edu.au/~jas/home/pics/jas.jpg'

    upload_response = th.user_upload_photo(token, img_url, 0, 0, 120, 120)

    assert upload_response.status_code == Success.code

    user_response1 = th.user_profile(token, u_id).json()

    assert user_response1['user']['profile_img_url'] == config.url + "static/user1.jpg"


# Test when the cropping dimensions are out of range
def test_user_uploadphoto_out_of_pixels(clear_data):
    user = th.auth_register("allan@gmail.com", "password1", "allan", "zhang").json()
    token = user['token']
    u_id = user['auth_user_id']

    img_url = 'http://cgi.cse.unsw.edu.au/~jas/home/pics/jas.jpg'

    upload_response = th.user_upload_photo(token, img_url, 0, 0, 9999999999, 9999999999)

    assert upload_response.status_code == InputError.code

    user_response1 = th.user_profile(token, u_id).json()

    assert user_response1['user']['profile_img_url'] == config.url + "static/default.jpg"


# Test if profile_img_url is updated inside the channels data
def test_user_uploadphoto_channel(clear_data):
    user1 = th.auth_register("allan@gmail.com", "password1", "allan", "zhang").json()
    token1 = user1['token']
    u_id1 = user1['auth_user_id']

    user2 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token2 = user2['token']
    u_id2 = user2['auth_user_id']

    channel1 = th.channels_create(token1, "Channel 1", True).json()
    channel_id = channel1["channel_id"]

    th.channel_join(token2, channel_id)

    img_url = 'http://cgi.cse.unsw.edu.au/~jas/home/pics/jas.jpg'

    th.user_upload_photo(token1, img_url, 0, 0, 120, 120)

    details = th.channel_details(token1, channel_id).json()

    assert details == {'name': 'Channel 1', 
                       'is_public': True, 
                       'owner_members': [{'u_id': u_id1, 
                                          'email': 'allan@gmail.com', 
                                          'name_first': 'allan', 
                                          'name_last': 'zhang', 
                                          'handle_str': 'allanzhang', 
                                          'profile_img_url': config.url + 'static/user1.jpg'}], 
                       'all_members': [{'u_id': u_id1, 
                                          'email': 'allan@gmail.com', 
                                          'name_first': 'allan', 
                                          'name_last': 'zhang', 
                                          'handle_str': 'allanzhang', 
                                          'profile_img_url': config.url + 'static/user1.jpg'},
                                         {'u_id': u_id2, 
                                          'email': 'rick@gmail.com', 
                                          'name_first': 'derrick', 
                                          'name_last': 'doan', 
                                          'handle_str': 'derrickdoan', 
                                          'profile_img_url': config.url + 'static/default.jpg'}]}


# Test if profile_img_url is updated inside the dms data
def test_user_uploadphoto_dm(clear_data):
    user1 = th.auth_register("allan@gmail.com", "password1", "allan", "zhang").json()
    token1 = user1['token']
    u_id1 = user1['auth_user_id']

    user2 = th.auth_register("rick@gmail.com", "password1", "derrick", "doan").json()
    token2 = user2['token']
    u_id2 = user2['auth_user_id']

    user3 = th.auth_register("cynthia@gmail.com", "password1", "cynthia", "li").json()
    u_id3 = user3['auth_user_id']

    dm = th.dm_create(token2, [u_id1, u_id3]).json()
    dm_id = dm["dm_id"]

    img_url = 'http://cgi.cse.unsw.edu.au/~jas/home/pics/jas.jpg'

    th.user_upload_photo(token1, img_url, 0, 0, 120, 120)

    details = th.dm_details(token1, dm_id).json()

    assert details == {'name': 'allanzhang, cynthiali, derrickdoan', 
                       'members': [{'u_id': u_id2, 
                                    'email': 'rick@gmail.com', 
                                    'name_first': 'derrick', 
                                    'name_last': 'doan', 
                                    'handle_str': 'derrickdoan', 
                                    'profile_img_url': config.url + 'static/default.jpg'}, 
                                   {'u_id': u_id1, 
                                    'email': 'allan@gmail.com', 
                                    'name_first': 'allan', 
                                    'name_last': 'zhang', 
                                    'handle_str': 'allanzhang', 
                                    'profile_img_url': config.url + 'static/user1.jpg'}, 
                                   {'u_id': u_id3, 
                                    'email': 'cynthia@gmail.com', 
                                    'name_first': 'cynthia', 
                                    'name_last': 'li', 
                                    'handle_str': 'cynthiali', 
                                    'profile_img_url': config.url + 'static/default.jpg'}]}
