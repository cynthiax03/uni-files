import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')

# Test whether an Access error is raised if the token is invalid
def test_invalid_token(clear_data):
    leave_response = th.channel_leave(th.invalid_token1(), 1)
    assert leave_response.status_code == AccessError.code


# Test whether input error is raised when channel_id does not refer to a valid channel
def test_channel_id_invalid(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    # User 1 creates channel
    channel = th.channels_create(token, "comedy", True).json()
    channel_id = channel["channel_id"]

    leave_response = th.channel_leave(token, channel_id + 1)
    assert leave_response.status_code == InputError.code


# Test whether access error is raised if a channel id is valid but the user is not a member of the channel
def test_user_not_channel_member(clear_data):
    # Register user 1
    user1 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token2 = user2["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    leave_response = th.channel_leave(token2, channel_id)
    assert leave_response.status_code == AccessError.code


# Test that everything is working properly
def test_remove_user(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    u_id1 = user1["auth_user_id"]
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    u_id2 = user2["auth_user_id"]

    # Register user 3
    user3 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    u_id3 = user3["auth_user_id"]
    token3 = user3["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    # Invite users to channel 1
    th.channel_invite(token1, channel_id, u_id2)
    th.channel_invite(token1, channel_id, u_id3)

    # User 3 leaves
    leave_response = th.channel_leave(token3, channel_id)
    assert leave_response.status_code == Success.code

    # Check for details
    details = th.channel_details(token1, channel_id).json()
    assert details == {
        'name': 'comedy',
        'is_public': True,
        'owner_members': [
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ],
        'all_members': [
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id2,
                'email': 'allan@gmail.com',
                'name_first': 'allan',
                'name_last': 'zhang',
                'handle_str': 'allanzhang',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }


# Test of removing an owner from a channel
def test_owner_leave(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    u_id2 = user2["auth_user_id"]
    token2 = user2["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    # Invite users to channel 1
    th.channel_invite(token1, channel_id, u_id2)

    # User 1 leaves
    leave_response = th.channel_leave(token1, channel_id)
    assert leave_response.status_code == Success.code

    # Check for details
    details = th.channel_details(token2, channel_id).json()
    assert details == {
        'name': 'comedy',
        'is_public': True,
        'owner_members': [],
        'all_members': [
            {
                'u_id': u_id2,
                'email': 'allan@gmail.com',
                'name_first': 'allan',
                'name_last': 'zhang',
                'handle_str': 'allanzhang',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }
