import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")


# Test whether an Access error is raised if the token is invalid
def test_channel_messages_invalid_token(clear_data):
    message_response = th.channel_messages(th.invalid_token1(), 1, 0)
    assert message_response.status_code == AccessError.code


# Test if inputerror is raised if channel_id does not exist
def test_channel_messages_channel_id_doesnt_exist(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    # User 1 creates channel
    channel = th.channels_create(token, "comedy", True).json()
    channel_id = channel["channel_id"]

    message_response = th.channel_messages(token, channel_id + 1, 0)
    assert message_response.status_code == InputError.code


# Test if inputerror is raised if start is greater than the total number of messages
def test_channel_messages_channel_start_greater_than_total_messages(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    # User 1 creates channel
    channel = th.channels_create(token, "comedy", True).json()
    channel_id = channel["channel_id"]

    message_response = th.channel_messages(token, channel_id, 2)
    assert message_response.status_code == InputError.code


# Test if inputerror is raised if channel is valid but the user is not a member
# of the channel
def test_channel_messages_channel_id_valid_and_authorised_but_not_a_member(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    # Create user 2
    user2 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token2 = user2["token"]

    message_response = th.channel_messages(token2, channel_id, 2)
    assert message_response.status_code == AccessError.code


# Test if end is returned as -1 if there are no more messages to load
def test_channel_messages_no_more_messages(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token = user1["token"]

    # User 1 creates channel
    channel = th.channels_create(token, "comedy", True).json()
    channel_id = channel["channel_id"]

    message_response = th.channel_messages(token, channel_id, 0).json()
    assert message_response["end"] == -1

            
# Test if channel message is returned correctly given different start values
def test_channel_messages_returned_comprehensive(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    token2 = user2["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    # User 2 joins channel
    th.channel_join(token2, channel_id)

    # User 1 sends 51 messages
    for message in range(1, 52):
        th.message_send(token1, channel_id, str(message))

    # User 2 checks for messages
    messages_response1 = th.channel_messages(token2, channel_id, 0).json()

    # Check that messages are returned correctly
    for index in range(0, 50):
        assert messages_response1['messages'][index]['message'] == str(52 - index - 1)

    # Check start and end
    assert messages_response1["start"] == 0
    assert messages_response1["end"] == 50

    # User 1 checks for messages with start 50
    messages_response2 = th.channel_messages(token1, channel_id, 50).json()
    assert messages_response2['start'] == 50
    assert messages_response2['end'] == -1
    assert messages_response2['messages'][0]['message'] == '1'
