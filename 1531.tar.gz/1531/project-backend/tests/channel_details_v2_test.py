import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + "clear/v1")


# Test where the token is invalid
def test_channel_details_invalid_token(clear_data):
    details_response = th.channel_details(th.invalid_token1(), 1)
    
    assert details_response.status_code == AccessError.code

    
# Test whether InputError is raised when a non-existent channel id is given
def test_channel_details_invalid_channel(clear_data):
    # Register user 1
    user = th.auth_register("cynthia@gmail.com", "password", "cynthia", "li").json()
    token = user["token"]

    details_response = th.channel_details(token, 1)
    
    assert details_response.status_code == InputError.code


# Test whether user can call details when not in channel
def test_channel_details_v2_invalid_user(clear_data):
    # Register user 1
    user1 = th.auth_register("cynthia@gmail.com", "password", "cynthia", "li").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token2 = user2["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    # User 2 tries to call details
    details_response = th.channel_details(token2, channel_id)
    assert details_response.status_code == AccessError.code


# Test whether AcessError status code is returned when an invalid token and 
# invalid_channel_id are entered
def test_channel_details_v2_invalid_user_and_channel(clear_data):
    # Register user 1
    user1 = th.auth_register("cynthia@gmail.com", "password", "cynthia", "li").json()
    token1 = user1["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    # Logout
    th.auth_logout(token1)

    # Test for Access code priority
    details_response = th.channel_details(token1, channel_id + 1)
    assert details_response.status_code == AccessError.code


# Test whether a channel returns the correct name, is_public, owner_members
# and all_members
def test_channel_details_v2_return(clear_data):
    # Register user 1
    user = th.auth_register("cynthia@gmail.com", "password", "cynthia", "li").json()
    token = user["token"]
    u_id = user["auth_user_id"]

    # User 1 creates channel
    channel = th.channels_create(token, "comedycentral", False).json()
    channel_id = channel["channel_id"]

    details = th.channel_details(token, channel_id).json()

    assert details == {
        'name':'comedycentral',
        'is_public': False,
        'owner_members': [
                {
                    'u_id': u_id,
                    'email': "cynthia@gmail.com",
                    'name_first': "cynthia",
                    'name_last': "li",
                    'handle_str': "cynthiali",
                    'profile_img_url': config.url + "static/default.jpg"
                }
        ],
        'all_members':[
                {
                    'u_id': u_id,
                    'email': "cynthia@gmail.com",
                    'name_first': "cynthia",
                    'name_last': "li",
                    'handle_str': "cynthiali",
                    'profile_img_url': config.url + "static/default.jpg"
                }
        ]
    }


# Test whether a channel with many members returns the correct name, is_public,
# owner_members and all_members
def test_channel_details_v2_return_many_members(clear_data):
    # Register user 1
    user1 = th.auth_register("cynthia@gmail.com", "password", "cynthia", "li").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    # Create user 2
    user2 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    u_id2 = user2["auth_user_id"]

    # Register user 3
    user3 = th.auth_register("max@gmail.com", "password", "max", "dal").json()
    u_id3 = user3["auth_user_id"]
    
    # User 1 creates channel
    channel = th.channels_create(token1, "comedycentral", False).json()
    channel_id = channel["channel_id"]

    # Invite user 2 and 3 to channel
    th.channel_invite(token1, channel_id, u_id2)
    th.channel_invite(token1, channel_id, u_id3)

    details = th.channel_details(token1, channel_id).json()

    assert details == {
        'name':'comedycentral',
        'is_public': False,
        'owner_members': [
                {
                    'u_id': u_id1,
                    'email': "cynthia@gmail.com",
                    'name_first': "cynthia",
                    'name_last': "li",
                    'handle_str': "cynthiali",
                    'profile_img_url': config.url + "static/default.jpg"
                }
        ],
        'all_members':[
                {
                    'u_id': u_id1,
                    'email': "cynthia@gmail.com",
                    'name_first': "cynthia",
                    'name_last': "li",
                    'handle_str': "cynthiali",
                    'profile_img_url': config.url + "static/default.jpg"
                },
                {
                    'u_id': u_id2,
                    'email': "rick@gmail.com",
                    'name_first': "derrick",
                    'name_last': "doan",
                    'handle_str': "derrickdoan",
                    'profile_img_url': config.url + "static/default.jpg"
                },
                {
                    'u_id': u_id3,
                    'email': "max@gmail.com",
                    'name_first': "max",
                    'name_last': "dal",
                    'handle_str': "maxdal",
                    'profile_img_url': config.url + "static/default.jpg"
                }
        ]
    }
