import pytest
import requests
from src import config
import datetime
import time
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(f"{config.url}clear/v1")

# Test AccessError is raised if token is invalid
def test_users_stats_invalid_token(clear_data):

    stats_response = th.user_stats(th.invalid_token1())
    
    assert stats_response.status_code == AccessError.code

# Test that all metrics are 0 when first user registers
def test_users_stats_starting_metrics(clear_data):
    
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    # Get users stats
    users_stats = th.users_stats(token1).json()

    # Get current time
    curr_time = datetime.datetime.now()
    curr_time = int(time.mktime(curr_time.timetuple()))

    assert users_stats['workspace_stats']['channels_exist'][0]['num_channels_exist'] == 0
    assert users_stats['workspace_stats']['channels_exist'][0]['time_stamp'] - curr_time < 2

    assert users_stats['workspace_stats']['dms_exist'][0]['num_dms_exist'] == 0
    assert users_stats['workspace_stats']['channels_exist'][0]['time_stamp'] - curr_time < 2

    assert users_stats['workspace_stats']['messages_exist'][0]['num_messages_exist'] == 0
    assert users_stats['workspace_stats']['messages_exist'][0]['time_stamp'] - curr_time < 2

    assert users_stats['workspace_stats']['utilization_rate'] == 0

# Test channels_exist is correct and time is correct
def test_users_stats_channels_exist(clear_data):

    # Register 2 users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]

    # User1 creates 3 channels
    channel1 = th.channels_create(token1, "Totoro", True).json()
    channel_id1 = channel1["channel_id"]
    th.channels_create(token1, "CaramelPopcorn", False)
    th.channels_create(token1, "Pizza", True)

    # User1 sends a message in channel1
    th.message_send(token1, channel_id1, "blahblahblah")

    # User1 creates a dm
    th.dm_create(token2, [])

    # User2 creates 2 channels
    th.channels_create(token2, "BojackHorseman", True)
    th.channels_create(token2, "SquidGame", False)

    # Get users stats
    users_stats = th.users_stats(token1).json()
    
    # Get current time_stamp
    curr_time = datetime.datetime.now()
    curr_time = int(time.mktime(curr_time.timetuple()))

    # Check that details are correct
    assert users_stats['workspace_stats']['channels_exist'][5]['num_channels_exist'] == 5
    assert users_stats['workspace_stats']['dms_exist'][1]['num_dms_exist'] == 1
    assert users_stats['workspace_stats']['messages_exist'][1]['num_messages_exist'] == 1
    
    # Check the time_stamp is within a second of the time of the request
    assert users_stats['workspace_stats']['channels_exist'][0]['time_stamp'] - curr_time < 2

# Test dms_exist is correct
def test_users_stats_dms_exist(clear_data):

    # Register 2 users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]

    # User1 creates 4 dms with themself
    dm1 = th.dm_create(token1, []).json()
    dm_id1 = dm1["dm_id"]
    th.dm_create(token1, [])
    th.dm_create(token1, [])
    th.dm_create(token1, [])

    # User2 creates 3 dms with user1
    th.dm_create(token2, [u_id1])
    th.dm_create(token2, [u_id1])
    th.dm_create(token2, [u_id1])

    # User1 creates a channel
    channel1 = th.channels_create(token1, "SquidGame", False).json()
    channel_id1 = channel1["channel_id"]

    # User1 sends a message in dm1 and channel1
    th.message_senddm(token1, dm_id1, "Player 067 eliminated")
    th.message_send(token1, channel_id1, "hellohellohello")

    # Get users stats
    users_stats = th.users_stats(token1).json()
    
    # Get current time_stamp
    curr_time = datetime.datetime.now()
    curr_time = int(time.mktime(curr_time.timetuple()))

    # Check that details are correct
    assert users_stats['workspace_stats']['channels_exist'][1]['num_channels_exist'] == 1
    assert users_stats['workspace_stats']['dms_exist'][7]['num_dms_exist'] == 7
    assert users_stats['workspace_stats']['messages_exist'][2]['num_messages_exist'] == 2
    
    # Check that dms_exist is correct and time_stamp is within a second of the 
    # request being sent
    assert users_stats['workspace_stats']['channels_exist'][0]['time_stamp'] - curr_time < 2

# Test if dms_exist decreases if a dm is removed
def test_users_stats_dms_decrease(clear_data):
    # Register 2 users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]

    # User1 creates 3 dms with themself
    dm1 = th.dm_create(token1, []).json()
    dm_id1 = dm1["dm_id"]
    dm2 = th.dm_create(token1, []).json()
    dm_id2 = dm2["dm_id"]
    dm3 = th.dm_create(token1, []).json()
    dm_id3 = dm3["dm_id"]

    # User2 creates 2 dms with themselves
    th.dm_create(token2, [])
    th.dm_create(token2, [])

    # Get users stats
    users_stats1 = th.users_stats(token1).json()
    

    # Check that num_dms_exist is correct
    assert users_stats1['workspace_stats']['dms_exist'][5]['num_dms_exist'] == 5

    # User1 removes the first 3 dms
    th.dm_remove(token1, dm_id1)
    th.dm_remove(token1, dm_id2)
    th.dm_remove(token1, dm_id3)

    # Check that num_dms_exist decreases by 3
    users_stats2 = th.users_stats(token1).json()
    
    
    assert users_stats2['workspace_stats']['dms_exist'][8]['num_dms_exist'] == 2

    # User1 creates 2 more dms
    th.dm_create(token1, [])
    th.dm_create(token1, [])

    # Get users_stats
    users_stats3 = th.users_stats(token2).json()

    # Get current time
    curr_time = datetime.datetime.now()
    curr_time = int(time.mktime(curr_time.timetuple()))

    # Check that dms_exist is correct and that time_stamp is within a second of
    # the request being sent
    assert users_stats3['workspace_stats']['dms_exist'][10]['num_dms_exist'] == 4
    assert users_stats3['workspace_stats']['channels_exist'][0]['time_stamp'] - curr_time < 2

# Test if messages_exist is correct
def test_users_stats_messages_exist(clear_data):
    # Register 3 users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    user3 = th.auth_register("ccc@gmail.com", "10000000000", "Max", "D").json()
    token3 = user3["token"]
    u_id3 = user3["auth_user_id"]

    # User1 creates a channel and invites user2 and user3
    channel1 = th.channels_create(token1, "Arietty", True).json()
    channel_id1 = channel1["channel_id"]
    th.channel_invite(token1, channel_id1, u_id2)
    th.channel_invite(token1, channel_id1, u_id3)

    # User2 creates a channel and invites user1 and user3
    channel2 = th.channels_create(token2, "BinChicken", True).json()
    channel_id2 = channel2["channel_id"]
    th.channel_invite(token2, channel_id2, u_id1)
    th.channel_invite(token2, channel_id2, u_id3)

    # User3 creates 2 dms with themself
    dm1 = th.dm_create(token3, []).json()
    dm2 = th.dm_create(token3, []).json()

    dm_id1 = dm1["dm_id"]
    dm_id2 = dm2["dm_id"]

    # User3 sends 3 messages in channel2
    th.message_send(token3, channel_id2, "giraffe")
    th.message_send(token3, channel_id2, "rhino")
    th.message_send(token3, channel_id2, "octopus")

    # User2 sends a message in channel2
    th.message_send(token2, channel_id2, "cow")

    # User1 sends 2 messages in channel1
    th.message_send(token1, channel_id2, "sushi")
    th.message_send(token1, channel_id2, "spaghetti")

    # User3 sends 2 messages in dm1
    th.message_senddm(token3, dm_id1, "hello")
    th.message_senddm(token3, dm_id1, "world")

    # User3 sends 2 messages in dm2
    th.message_senddm(token3, dm_id2, "hello")
    th.message_senddm(token3, dm_id2, "world")

    # Get users stats
    users_stats = th.users_stats(token3).json()
    

    # Get current time
    curr_time = datetime.datetime.now()
    curr_time = int(time.mktime(curr_time.timetuple()))

    # Check that dms_exist is correct and that time_stamp is within a second of
    # the request being sent
    assert users_stats['workspace_stats']['messages_exist'][10]['num_messages_exist'] == 10
    assert users_stats['workspace_stats']['channels_exist'][0]['time_stamp'] - curr_time < 2

# Test if messages_exist decreases when a message is removed
def test_users_stats_messages_decrease(clear_data):

    # Register 2 users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]

    # User1 creates a channel
    channel1 = th.channels_create(token1, "Arietty", True).json()
    channel_id1 = channel1["channel_id"]

    # User2 creates a dm with user1
    dm1 = th.dm_create(token2, [u_id1]).json()
    dm_id1 = dm1["dm_id"]

    # User1 sends 3 messages into channel1
    msg1 = th.message_send(token1, channel_id1, "giraffe").json()
    msg2 = th.message_send(token1, channel_id1, "rhino").json()
    msg3 = th.message_send(token1, channel_id1, "octopus").json()
    msg_id1 = msg1["message_id"]
    msg_id2 = msg2["message_id"]
    msg_id3 = msg3["message_id"]

    # User2 sends 2 messages in dm1
    msg4 = th.message_senddm(token2, dm_id1, "I'm so bored").json()
    msg5 = th.message_senddm(token2, dm_id1, "://////").json()
    msg_id4 = msg4["message_id"]
    msg_id5 = msg5["message_id"]

    # Get users stats
    users_stats1 = th.users_stats(token1).json()
    

    # Check that num_messages_exist is correct
    assert users_stats1['workspace_stats']['messages_exist'][5]['num_messages_exist'] == 5

    # User1 removes first 3 messages in channel1
    th.message_remove(token1, msg_id1)
    th.message_remove(token1, msg_id2)
    th.message_remove(token1, msg_id3)

    # User2 removes 2 messages in dm1
    th.message_remove(token2, msg_id4)
    th.message_remove(token2, msg_id5)

    # Get users stats
    users_stats2 = th.users_stats(token2).json()
    

    # Check that num_messages_exist is correct
    assert users_stats2['workspace_stats']['messages_exist'][10]['num_messages_exist'] == 0

    # User1 sends 2 messages into channel1
    th.message_send(token1, channel_id1, "crab")
    th.message_send(token1, channel_id1, "snail")

    # Get users stats
    users_stats2 = th.users_stats(token2).json()
    

    # Get curr time
    curr_time = datetime.datetime.now()
    curr_time = int(time.mktime(curr_time.timetuple()))

    # Check that num_messages_exist is correct and time_stamp is within a second
    # of the time the request was sent
    assert users_stats2['workspace_stats']['messages_exist'][12]['num_messages_exist'] == 2
    assert users_stats2['workspace_stats']['messages_exist'][0]['time_stamp'] - curr_time < 2

# Test if time_stamps are correctly updated
def test_users_stats_time_stamp(clear_data):

    # Register 2 users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    
    # Get users stats
    users_stats1 = th.users_stats(token1).json()
    

    # Get current time
    curr_time1 = datetime.datetime.now()
    curr_time1 = int(time.mktime(curr_time1.timetuple()))

    # Check that all time_stamps are correct
    assert users_stats1['workspace_stats']['channels_exist'][0]['time_stamp'] - curr_time1 < 2
    assert users_stats1['workspace_stats']['dms_exist'][0]['time_stamp'] - curr_time1 < 2
    assert users_stats1['workspace_stats']['messages_exist'][0]['time_stamp'] - curr_time1 < 2


    # Get users stats again
    users_stats2 = th.users_stats(token2).json()
    

    # Get current time
    curr_time2 = datetime.datetime.now()
    curr_time2 = int(time.mktime(curr_time2.timetuple()))

    # Check that all time_stamps are updated
    assert users_stats2['workspace_stats']['channels_exist'][0]['time_stamp'] - curr_time2 < 2
    assert users_stats2['workspace_stats']['dms_exist'][0]['time_stamp'] - curr_time2 < 2
    assert users_stats2['workspace_stats']['messages_exist'][0]['time_stamp'] - curr_time2 < 2

# Test utilisation rate is correct
def tests_users_stats_ulitization_rate(clear_data):
    # Register 5 users
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    user3 = th.auth_register("ccc@gmail.com", "10000000000", "Max", "D").json()
    u_id3 = user3["auth_user_id"]

    user4 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token4 = user4["token"]

    user5 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    token5 = user5["token"]

    # Get users stats and check utilization rate is 0
    users_stats1 = th.users_stats(token2).json()
    

    assert users_stats1['workspace_stats']['utilization_rate'] == 0

    # User1 creates a dm with user2 and user3
    th.dm_create(token1, [u_id2, u_id3])

    # User5 creates a channel
    channel1 = th.channels_create(token5, "Club house", True).json()
    channel_id1 = channel1["channel_id"]

    # Get user stats and check that utilizatio_rate is 4/5
    users_stats2 = th.users_stats(token4).json()

    assert users_stats2['workspace_stats']['utilization_rate'] == 4 / 5

    # Register 2 more users
    th.auth_register("name@gmail.com", "password", "Taylor", "Swift")
    th.auth_register("object@gmail.com", "12345678", "Timothee", "Chalamet")
    # User 4 joins a channel
    th.channel_join(token4, channel_id1)

    # Check that utilization_rate is updated
    users_stats3 = th.users_stats(token4).json()

    assert users_stats3['workspace_stats']['utilization_rate'] == 5 / 7

# Test removed users are not being considered in ultilization rate calculation
def test_users_stats_removed_users(clear_data):

    # Create 4 users, user1 is a global owner
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    user3 = th.auth_register("ccc@gmail.com", "10000000000", "Max", "D").json()
    token3 = user3["token"]
    u_id3 = user3["auth_user_id"]

    th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()

    # User2 creates a dm with user1 and user3
    th.dm_create(token2, [u_id1, u_id3])

    # User1 (a global owner) removes user2
    th.admin_remove(token1, u_id2)

    # Get users stats
    users_stats = th.users_stats(token3).json()
    
    # Check that utilization rate is 2/3
    assert users_stats['workspace_stats']['utilization_rate'] == 2 / 3
    
# Test if stats is correct when register is called after it
def test_users_stats_register_after_stats(clear_data):

    # User1 is a global owner
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    th.channels_create(token1, "Club house", True).json()
    
    # Get users stats
    users_stats = th.users_stats(token1).json()
    
    assert users_stats['workspace_stats']['channels_exist'][1]['num_channels_exist'] == 1
    
    # Register user2
    user2 = th.auth_register("bbb@gmail.com", "12345678", "Derrick", "D").json()
    token2 = user2["token"]
    
    # User2 creates a channel
    th.channels_create(token2, "Pent house", True).json()

    # Get users stats
    users_stats2 = th.users_stats(token2).json()

    assert users_stats2['workspace_stats']['channels_exist'][2]['num_channels_exist'] == 2
    
    # Register user3
    user3 = th.auth_register("ccc@gmail.com", "10000000000", "Max", "D").json()
    token3 = user3["token"]

    # User3 creates a channel
    th.channels_create(token3, "Pent house", True).json()

    # Get users stats
    users_stats3 = th.users_stats(token3).json()

    assert users_stats3['workspace_stats']['channels_exist'][3]['num_channels_exist'] == 3
    
# Test if stats is correct when sendlater is used
def test_users_stats_sendlater(clear_data):
    
    # Register a user
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    # User1 creates a channel
    channel1 = th.channels_create(token1, "Club house", True).json()
    channel_id1 = channel1["channel_id"]
    
    # Calculate time in future by 3 seconds
    time_in_future = datetime.datetime.now() + datetime.timedelta(seconds = 1)

    # User1 sends a message into channel using sendlater
    th.message_sendlater(token1, channel_id1, "Hello World", int(time.mktime(time_in_future.timetuple())))
    
    time.sleep(1)

    # Get users stats
    users_stats = th.users_stats(token1).json()
    
    # Get current time
    curr_time = datetime.datetime.now()
    curr_time = int(time.mktime(curr_time.timetuple()))

    # Check that channels_exist is correct and that time_stamp is within a second of
    # the request being sent
    assert users_stats['workspace_stats']['messages_exist'][1]['num_messages_exist'] == 1
    assert users_stats['workspace_stats']['channels_exist'][0]['time_stamp'] - curr_time < 2
    
# Test if stats is correct when standup is used
def test_users_stats_standup(clear_data):
    
    # Register a user
    user1 = th.auth_register("aaa@gmail.com", "password", "Allan", "Z").json()
    token1 = user1["token"]

    # User1 creates a channel
    channel1 = th.channels_create(token1, "Club house", True).json()
    channel_id1 = channel1["channel_id"]
    
    # User1 starts a standup
    th.start_standup(token1, channel_id1, 1)

    # User1 sends a message during the standup
    th.send_standup(token1, channel_id1, "HELLO")
    
    time.sleep(1)

    # Get users stats
    users_stats = th.users_stats(token1).json()
    
    # Get current time
    curr_time = datetime.datetime.now()
    curr_time = int(time.mktime(curr_time.timetuple()))

    # Check that messages_exist is correct and that time_stamp is within a second of
    # the request being sent
    assert users_stats['workspace_stats']['messages_exist'][1]['num_messages_exist'] == 1
    assert users_stats['workspace_stats']['messages_exist'][1]['time_stamp'] - curr_time < 2
