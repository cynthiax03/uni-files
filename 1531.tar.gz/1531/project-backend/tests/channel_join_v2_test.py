import pytest
import requests
from src import config
from src.error import AccessError, InputError, Success
import tests.test_helpers as th

@pytest.fixture
def clear_data():
    requests.delete(config.url + 'clear/v1')


# Test where the token is invalid
def test_invalid_token(clear_data):
    join_response = th.channel_join(th.invalid_token1(), 1)
    assert join_response.status_code == AccessError.code


# test whether InputError is raised if channel_id does not refer to a valid channel_id
def test_channel_join_v2_invalid_channel(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    token2 = user2["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    # Attempt to join
    join_response = th.channel_join(token2, channel_id + 1)
    assert join_response.status_code == InputError.code
    

# Test whether InputError is raised if authorised user is already a member of
# the channel
def test_channel_join_v2_already_member(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    token2 = user2["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    # Join successfully
    join_response1 = th.channel_join(token2, channel_id)
    assert join_response1.status_code == Success.code

    # Attempt to join
    join_response2 = th.channel_join(token2, channel_id)
    assert join_response2.status_code == InputError.code


# Test whether AccessError is raised if channel is private and user is not a
# member or global owner
def test_channel_join_v2_private_channel(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    token2 = user2["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", False).json()
    channel_id = channel["channel_id"]

    # Attempt to join
    join_response = th.channel_join(token2, channel_id)
    assert join_response.status_code == AccessError.code
    

# Test whether global owner can join a private channel
def test_channel_join_v2_global_owner(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    token2 = user2["token"]

    # User 2 creates a private channel
    channel = th.channels_create(token2, "comedy", False).json()
    channel_id = channel["channel_id"]

    # Joins successfully
    join_response = th.channel_join(token1, channel_id)
    assert join_response.status_code == Success.code


# Test whether empty dictionary is returned on valid channel_id and valid token
def test_channel_join_v2_correct_return(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    token2 = user2["token"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    # Join successfully
    join_response = th.channel_join(token2, channel_id)
    assert join_response.status_code == Success.code
    assert join_response.json() == {}


# Test whether channel_join stores the correct user information in all_members
def test_channel_join_v2_stored_correctly(clear_data):
    # Register user 1
    user1 = th.auth_register("rick@gmail.com", "password", "derrick", "doan").json()
    token1 = user1["token"]
    u_id1 = user1["auth_user_id"]

    # Create user 2
    user2 = th.auth_register("allan@gmail.com", "password", "allan", "zhang").json()
    token2 = user2["token"]
    u_id2 = user2["auth_user_id"]

    # User 1 creates channel
    channel = th.channels_create(token1, "comedy", True).json()
    channel_id = channel["channel_id"]

    # User 2 joins
    th.channel_join(token2, channel_id)

    # Check for details
    details = th.channel_details(token1, channel_id).json()
    assert details == {
        'name': 'comedy',
        'is_public': True,
        'owner_members': [
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ],
        'all_members': [
            {
                'u_id': u_id1,
                'email': 'rick@gmail.com',
                'name_first': 'derrick',
                'name_last': 'doan',
                'handle_str': 'derrickdoan',
                'profile_img_url': config.url + "static/default.jpg"
            },
            {
                'u_id': u_id2,
                'email': 'allan@gmail.com',
                'name_first': 'allan',
                'name_last': 'zhang',
                'handle_str': 'allanzhang',
                'profile_img_url': config.url + "static/default.jpg"
            }
        ]
    }
