## Lab05 - Exercise - Team (1 point)

By yourself, answer the following questions:

1. What do you expect will end up being the biggest challenges of working in a team by the end of the term?

2. Now that we're half way through, what is one aspect of teamwork that you're hoping to learn more about?
