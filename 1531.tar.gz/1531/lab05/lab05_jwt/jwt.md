Part 1:
    The data stored inside the jwt is a {'u_id': '12345'}

Part 2:
    It isn't appropriately signed with the secret as jwt.io returns invalid
    signature, so the token has been tampered with