import pytest
import requests
import config

@pytest.fixture
def clear_list():
    requests.delete(config.url + "names/clear")

def test_add_name(clear_list):
    
    # Add a user
    add_response = requests.post(config.url + "names/add",
                                    json={'name': 'Parker'})

    assert add_response.status_code == 200
    assert add_response.json() == {}

    # Check that the user has been stored
    get_response = requests.get(config.url + "names",
                                params={})

    assert get_response.status_code == 200
    assert get_response.json() == {'names': ['Parker']}

def test_delete_name(clear_list):

    # Add a user
    add_response = requests.post(config.url + "names/add",
                                    json={'name': 'Parker'})

    assert add_response.status_code == 200
    assert add_response.json() == {}

    # Delete user
    delete_response = requests.delete(config.url + "names/remove",
                                        json={'name': 'Parker'})

    assert delete_response.status_code == 200
    assert delete_response.json() == {}

    # Check that the user has been removed
    get_response = requests.get(config.url + "names",
                                    params={})

    assert get_response.status_code == 200
    assert get_response.json() == {'names': []}

def test_names_clear(clear_list):

    # Add two names
    add_response1 = requests.post(config.url + "names/add",
                                    json={'name': 'Parker'})

    assert add_response1.status_code == 200
    assert add_response1.json() == {}

    add_response2 = requests.post(config.url + "names/add",
                                    json={'name': 'Parker'})

    assert add_response2.status_code == 200
    assert add_response2.json() == {}

    # Call names/clear
    requests.delete(config.url + "names/clear")

    # Check that all names have been removed
    get_response = requests.get(config.url + "names",
                                    params={})

    assert get_response.status_code == 200
    assert get_response.json() == {'names': []}



