from flask import request
from flask import Flask
from json import dumps

APP = Flask(__name__)

# Create an empty list
names_list = []

# adds an inputted name to name_list
@APP.route("/names/add", methods=['POST'])
def add_name():

    # Get input from the request body
    input = request.get_json()

    # Append the name to the global names_list
    global names_list
    names_list.append(input['name'])

    # Return an empty dict
    return dumps({})

# Returns all names in name_list
@APP.route("/names", methods=['GET'])
def list_names():

    # Return the names
    global names_list
    return dumps({'names': names_list})

# Removed an inputted name from name_list
@APP.route("/names/remove", methods=['DELETE'])
def remove_name():

    # Get the input from the request body
    input = request.get_json()

    # Remove the inputted name from the name_list
    global names_list 
    for name in names_list:
        if name == input['name']:
            names_list.remove(input['name'])

    return dumps({})

# Clears all names in name_list
@APP.route("/names/clear", methods=['DELETE'])
def clear_all_names():

    # Empty the global names_list
    global names_list
    names_list = []

if __name__ == '__main__':
    APP.run(port=5000)

