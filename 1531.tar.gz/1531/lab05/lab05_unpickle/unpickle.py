import pickle

def most_common():
    
    colour_list = []
    shape_list = []

    # Open the pickle file
    with open('shapecolour.p', 'rb') as FILE:
        pickle_file = pickle.load(FILE)

        # Append colours and shapes to colour_list and shape_list
        for element in pickle_file:
            colour_list.append(element['colour'])
            shape_list.append(element['shape'])

        # Find the most common colour in the list
        most_common_colour = max(set(colour_list), key=colour_list.count)

        # Find the most common shape in the list
        most_common_shape = max(set(shape_list), key=shape_list.count)

        return {
            'colour': most_common_colour,
            'shape': most_common_shape
        }

if __name__ == '__main__':
    most_common()

