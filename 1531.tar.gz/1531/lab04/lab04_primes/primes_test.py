from primes import factors

def test_one_factor():
    assert factors(19) == [19] 
    assert factors(17) == [17]
    assert factors(2) == [2]

def test_many_factors():
    assert factors(16) == [2, 2, 2, 2]
    assert factors(12) == [2, 2, 3]
    assert factors(48) == [2, 2, 2, 2, 3]
    assert factors(49) == [7, 7]
    assert factors(15) == [3, 5]

def test_edge_cases():
    assert factors(1) == []
    assert factors(0) == []
    assert factors(-3849) == []


