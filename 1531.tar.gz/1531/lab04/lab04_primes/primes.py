import math

def factors(num):
    '''
    Returns a list containing the prime factors of 'num'. The primes should be
    listed in ascending order.

    For example:
    >>> factors(16)
    [2, 2, 2, 2]
    >>> factors(21)
    [3, 7]
    '''

    factors_list = []
    # Edge cases
    if num <= 1:
        return factors_list

    for i in range(2, num):
        # Find smallest factor of num
        if (num % i) == 0:
            # If a factor is found, num is divided by its factors
            num = int(num / i)
            # Recurse function to test if i has any further factors and extend
            # the factors list to include further prime factors
            factors_list.extend(factors(i))

    # If num has no further factors, it is prime so append it to the list and sort
    if num != 1:
        factors_list.append(num)
    factors_list = sorted(factors_list)

    return factors_list



