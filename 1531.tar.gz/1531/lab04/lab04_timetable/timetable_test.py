from datetime import date, time, datetime
from timetable import timetable
import pytest

def test_timetable():
    assert timetable([date(2019,9,27), date(2019,9,30)], [time(14,10), time(10,30)]) == [datetime(2019,9,27,10,30), 
                                                                                        datetime(2019,9,27,14,10), 
                                                                                        datetime(2019,9,30,10,30), 
                                                                                        datetime(2019,9,30,14,10)]
    assert timetable([date(2021,10,6), date(2021,10,5)], [time(5,30), time(3,30)]) == [datetime(2021,10,5,3,30), 
                                                                                       datetime(2021,10,5,5,30), 
                                                                                        datetime(2021,10,6,3,30), 
                                                                                        datetime(2021,10,6,5,30)]
    assert timetable([date(2003,6,28)], [time(8,30)]) == [datetime(2003,6,28,8,30)]
