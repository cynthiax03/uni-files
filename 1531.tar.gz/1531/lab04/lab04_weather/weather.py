import datetime
import csv

# Checks if a row in the csvfile has the given date and town
def is_date_town_valid(date, town, csvreader, csvfile):
    
    # Seek to start of the file
    csvfile.seek(0)
    for row in csvreader:
        if date == row[0] and town == row[1]:
            return True
    
    # If no row corresponds to the given date and town, return False
    return False

# Finds the average max(index = 3) or min(index = 2) temperature across the 
# entire data set for a given location
def average_temp(town, csvreader, index, csvfile):
    
    # Seek to start of the file
    csvfile.seek(0)
    
    average_temp = 0
    number_of_temps = 0

    # Loop through csvfile and add all min/max temps for the given town
    for row in csvreader:
        if row[1] == town:
            # Only count the temp if the temp is not "NA"
            if row[index] != 'NA':
                average_temp += float(row[index])
                number_of_temps += 1

    # Find the average temp and retun 
    average_temp = average_temp/number_of_temps
    return average_temp

def weather(date, location):
    '''
    Weather takes in a given date and location and returns a tuple (A, B) where 
    A is the value of how far the minimum temperature is below the average 
    minimum across all time, for that given day, and B is the value of how far 
    the maximum temperature is above the average maximum across all time, for 
    that given day.

    Arguments:
        date (string)           - A date in the format "DD-MM-YYYY"
        location (string)       - The name of a location e.g. "Albury"

    Exceptions:
        N/A

    Return Value:
        Returns (None, None) on invalid date and/or location
        Returns (A, B) on valid date and location
    '''
    
    # Check if date or location is an empty string
    if date == '' or location == '':
        return (None, None)
    
    # Convert date from "DD-MM-YYYY" to "YYYY-MM-DD"
    date = date.split("-")
    date = str(datetime.date(int(date[2]), int(date[1]), int(date[0])))

    filename = "weatherAUS.csv"

    # Open csvfile to read
    with open(filename, 'r') as csvfile:
        # Create a new csv reader object
        csvreader = csv.reader(csvfile)

        # If date and town are invalid
        if is_date_town_valid(date, location, csvreader, csvfile) == False:
            return (None, None)
        
        # Find max_avg and min_avg temps for the location
        max_avg = average_temp(location, csvreader, 3, csvfile)
        min_avg = average_temp(location, csvreader, 2, csvfile)

        # Seek to start
        csvfile.seek(0)
        for row in csvreader:
            if row[0] == date and row[1] == location:
                # Extract min_temp and max_temp from row with given date and location
                min_temp = float(row[2])
                max_temp = float(row[3])
                break
        
        # Find min_diff and max_diff
        min_diff = round((min_avg - min_temp), 1)
        max_diff = round((max_temp - max_avg),1)

    # return tupile
    return (min_diff, max_diff)

'''
if __name__ == "__main__" :

    filename = "weatherAUS.csv"

    with open(filename, 'r') as csvfile:
        csvreader = csv.reader(csvfile)
        for row in csvreader:
            if str(row[0]) == '2008-12-01' and row[1] == 'Albury':
                print(row)

    print(weather('08-08-2010', 'Albury'))
    # print(weather('', ''))
'''
