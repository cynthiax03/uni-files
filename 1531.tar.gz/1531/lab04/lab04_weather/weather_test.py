from weather import weather
import csv

# Test Albury
def test_Albury():
    assert weather('08-08-2010', 'Albury') == (10.8, -10.0)
    assert weather('18-01-2012', 'Albury') == (-6.6, 8.1)

# Test invalid town/date
def test_invalid_town_date():
    assert weather('', '') == (None, None)
    assert weather ('', 'Albury') == (None, None)
    assert weather('08-09-2039', 'Kingsford') == (None, None)
    assert weather('08-08-2010', '')
    assert weather('09-02-2099', 'Albury') == (None, None)

def test_Canberra():
    filename = "weatherAUS.csv"

    with open(filename, 'r') as csvfile:
        csvreader = csv.reader(csvfile)
        max_counter = 0
        min_counter = 0
        max_avg = 0
        min_avg = 0
        for row in csvreader:
            if row[1] == 'Canberra':
                if row[3] != 'NA':
                    max_avg += float(row[3])
                    max_counter += 1
                if row[2] != 'NA':
                    min_avg += float(row[2])
                    min_counter += 1
            if row[0] == '2009-06-11' and row[1] == 'Canberra':
                min_temp = float(row[2])
                max_temp = float(row[3])
    min_avg = round(min_avg/min_counter, 1)
    max_avg = round(max_avg/max_counter, 1)

    assert weather('11-06-2009', 'Canberra') == (min_avg - min_temp, max_temp - max_avg)

