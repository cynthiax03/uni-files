/* Automatically generated; do not edit */
#ifndef _OPT_UNSW_H_
#define _OPT_UNSW_H_
#define OPT_UNSW 1
#endif /* _OPT_UNSW_H_ */
