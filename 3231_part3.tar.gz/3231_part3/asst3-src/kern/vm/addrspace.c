/*
 * Copyright (c) 2000, 2001, 2002, 2003, 2004, 2005, 2008, 2009
 *	The President and Fellows of Harvard College.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <spl.h>
#include <spinlock.h>
#include <current.h>
#include <mips/tlb.h>
#include <addrspace.h>
#include <vm.h>
#include <proc.h>
#include <synch.h>

/*
 * Note! If OPT_DUMBVM is set, as is the case until you start the VM
 * assignment, this file is not compiled or linked or in any way
 * used. The cheesy hack versions in dumbvm.c are used instead.
 *
 * UNSW: If you use ASST3 config as required, then this file forms
 * part of the VM subsystem.
 *
 * GABBY NOTES:
 * NEED SOMETHING TO KEEP TRACK OF HOW MUCH FREE MEMORY WE HAVE
 * ^ Could be a variable that we decrement everytime memory is used up for address space?
 * ^ as_create returns NULL if not enough memory
 *
 */

struct addrspace *
as_create(void)
{
	struct addrspace *as;

	// Make space for addrspace
	as = kmalloc(sizeof(struct addrspace));
	if (as == NULL)
		return NULL;

	// Record the size of the address space
	int size = 2 * (ram_getsize() / PAGE_SIZE);
	as->hpt_size = size;

	// Make space for Hash Page Table, traversed by indexing (refer to add_hte in vm.c)
	as->hpt = kmalloc(size * sizeof(struct hte *));
	if (as->hpt == NULL)
	{
		kfree(as);
		return NULL;
	} 
	// Set all entries to null
	for (int i = 0; i < size; i++)
	{
		as->hpt[i] = NULL;
	}

	as->regions = NULL;
	as->copied = 0;

	as->hpt_lock = lock_create("lock");

	return as;
}

int as_copy(struct addrspace *old, struct addrspace **ret)
{
	struct addrspace *newas;

	newas = as_create();
	if (newas == NULL)
	{
		return ENOMEM;
	}

	/*
	 * Write this.
	 */
	if (old == NULL) 
	{
		return EFAULT;
	}

	lock_acquire(old->hpt_lock);
	// Copy hpt
	newas->hpt_size = old->hpt_size;
	newas->hpt = kmalloc(old->hpt_size * sizeof(struct hte *));
	if (newas->hpt == NULL)
	{
		kfree(newas);
		return ENOMEM;
	}

	// Set all entries to null
	for (int i = 0; i < newas->hpt_size; i++)
	{
		newas->hpt[i] = NULL;
	}

	for (int i = 0; i < old->hpt_size; i++)
	{
		struct hte *old_entry = old->hpt[i];
		while (old_entry != NULL)
		{
			int error = add_hte(newas, old_entry->vpn, old_entry->pfn);
			if (error)
			{
				return error;
			}
			old_entry = old_entry->next;
		}
	}

	// Copy regions
	newas->regions = NULL;
	struct region *old_region = old->regions;
	while(old_region != NULL)
	{
		// Create region and copy info over from old_region
		struct region *new_region = kmalloc(sizeof(struct region));
		if (new_region == NULL)
			return ENOMEM;

		copy_region(old_region, new_region);
		add_region(newas, new_region);
		
		old_region = old_region->next;
	}

	// Copy lock
	newas->hpt_lock = lock_create("lock");
	newas->copied = 1;

	lock_release(old->hpt_lock);
	(void)old;

	*ret = newas;
	return 0;
}

void as_destroy(struct addrspace *as)
{
	lock_acquire(as->hpt_lock);
	// Free the all htes first
	struct hte *curr_hte = as->hpt[0];
	for (int i = 0; i < as->hpt_size; i++)
	{
		curr_hte = as->hpt[i];
		if (curr_hte != NULL) // If page entry exists
		{
			struct hte *tmp_hte;
			while (curr_hte != NULL)
			{
				tmp_hte = curr_hte;
				if (!as->copied)
					free_kpages(PADDR_TO_KVADDR(curr_hte->pfn));
				
				curr_hte = curr_hte->next;
				kfree(tmp_hte);
			}
		}
	}

	// Free the regions linked list
	struct region *curr_region = as->regions;
	struct region *tmp_region;
	while (curr_region != NULL)
	{
		tmp_region = curr_region;
		curr_region = curr_region->next;
		kfree(tmp_region);
	}

	kfree(as->hpt);
	lock_release(as->hpt_lock);
	lock_destroy(as->hpt_lock);
	as_deactivate();
	kfree(as);
}

void as_activate(void)
{
	struct addrspace *as;

	as = proc_getas();
	if (as == NULL)
	{
		/*
		 * Kernel thread without an address space; leave the
		 * prior address space in place.
		 */
		return;
	}

	/* Disable interrupts on this CPU while frobbing the TLB. */
	int spl = splhigh();

	for (int i = 0; i < NUM_TLB; i++)
	{
		tlb_write(TLBHI_INVALID(i), TLBLO_INVALID(), i);
	}

	splx(spl);
}

void as_deactivate(void)
{
	/*
	 * Write this. For many designs it won't need to actually do
	 * anything. See proc.c for an explanation of why it (might)
	 * be needed.
	 */
	
	// Flush tlb again
	int spl = splhigh();

	for (int i = 0; i < NUM_TLB; i++)
	{
		tlb_write(TLBHI_INVALID(i), TLBLO_INVALID(), i);
	}

	splx(spl);

}

/*
 * Set up a segment at virtual address VADDR of size MEMSIZE. The
 * segment in memory extends from VADDR up to (but not including)
 * VADDR+MEMSIZE.
 *
 * The READABLE, WRITEABLE, and EXECUTABLE flags are set if read,
 * write, or execute permission should be set on the segment. At the
 * moment, these are ignored. When you write the VM system, you may
 * want to implement them.
 */
int as_define_region(struct addrspace *as, vaddr_t vaddr, size_t memsize,
					 int readable, int writeable, int executable)
{
	if (as == NULL)
		return EFAULT;

	memsize += vaddr & ~(vaddr_t)PAGE_FRAME;
	vaddr_t v_start = (vaddr & PAGE_FRAME);
	memsize = (memsize + PAGE_SIZE - 1) & PAGE_FRAME;

	vaddr_t v_end = v_start + memsize;

	struct region *new_region = kmalloc(sizeof(struct region));
	if (new_region == NULL)
		return ENOMEM;

	// Set actual region space
	new_region->as_v_start = v_start;
	new_region->as_v_end = v_end;
	new_region->region_size = memsize;

	// Set Permissions
	new_region->readable = readable;
	new_region->writeable = writeable;
	new_region->orig_writeable = writeable;
	new_region->executable = executable;

	new_region->next = NULL;

	// Inserts a new region to the addrspace
	add_region(as, new_region);

	return 0;
}

int as_prepare_load(struct addrspace *as)
{
	/*
	 * Write this.
	 */

	// Make all regions writeable
	struct region *curr_region = as->regions;
	while (curr_region != NULL)
	{
		curr_region->writeable = 1;
		curr_region = curr_region->next;
	}

	(void)as;
	return 0;
}

int as_complete_load(struct addrspace *as)
{
	/*
	 * Write this.
	 */

	// Change all regions back to readonly
	struct region *curr_region = as->regions;
	while (curr_region != NULL)
	{
		curr_region->writeable = curr_region->orig_writeable;
		curr_region = curr_region->next;
	}

	(void)as;
	return 0;
}

int as_define_stack(struct addrspace *as, vaddr_t *stackptr)
{
	/* Initial user-level stack pointer */
	*stackptr = USERSTACK;
	
	// Pass off to define region
	int result = as_define_region(as, USERSTACK - 65536, 65536, 1, 1, 0);
	if (result)
		return result;

	return 0;
}

/* Helper Functions */
void add_region(struct addrspace *as, struct region *new_region)
{
	if (as->regions == NULL)
	{
		as->regions = new_region;
	}

	else
	{
		struct region *curr = as->regions;
		while (curr->next != NULL)
		{
			curr = curr->next;
		}
		curr->next = new_region;
	}
}

void copy_region(struct region *old_region, struct region *new_region)
{
	// Copy region info
	new_region->as_v_start = old_region->as_v_start;
	new_region->as_v_end = old_region->as_v_end;
	new_region->region_size = old_region->region_size;

	// Copy permissions
	new_region->readable = old_region->readable;
	new_region->writeable = old_region->writeable;
	new_region->orig_writeable = old_region->writeable;
	new_region->executable = old_region->executable;

	new_region->next = NULL;
}
