#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <thread.h>
#include <addrspace.h>
#include <vm.h>
#include <machine/tlb.h>
#include <addrspace.h>
#include <synch.h>
#include <proc.h>
#include <current.h>

/* Place your page table functions here */
// Need functions that lookup, add and delete hash table entries
int add_hte(struct addrspace *as, vaddr_t vpn, paddr_t pfn)
{
    if (as == NULL)
    {
        return ENOMEM;
    }

    vaddr_t index = hash(as, vpn);

    struct hte *new_entry = kmalloc(sizeof(struct hte));
    if (new_entry == NULL)
    {
        return ENOMEM;
    }

    new_entry->vpn = vpn;
    new_entry->pfn = pfn;
    new_entry->flags = 0;
    new_entry->next = NULL;

    lock_acquire(as->hpt_lock);
    // If there is something at the hash index in the hpt
    if (as->hpt[index] == NULL)
    {
        as->hpt[index] = new_entry;
    }
    else
    {
        // Else loop to the end of the linked list and insert the new_entry
        // there
        struct hte *curr = as->hpt[index];
        while (curr != NULL)
        {
            if (curr->next == NULL)
            {
                curr->next = new_entry;
            }
            curr = curr->next;
        }
    }
    lock_release(as->hpt_lock);

    return 0;
}

vaddr_t hash(struct addrspace *as, vaddr_t vpn)
{
    return (((uint32_t)as) ^ (vpn >> 12)) % as->hpt_size;
}

void delete_hte(vaddr_t old_vpn)
{
    // Get index
    struct addrspace *as = proc_getas();
    vaddr_t index = hash(as, old_vpn);

    lock_acquire(as->hpt_lock);

    // If there was only one entry at the index
    if (as->hpt[index]->next == NULL)
    {
        kfree(as->hpt[index]);
        as->hpt[index] = NULL;
        return;
    }
    // Else there is more than one entry at the index
    struct hte *prev = NULL;
    struct hte *curr = as->hpt[index];
    struct hte *next = as->hpt[index]->next;
    while (curr != NULL)
    {
        // If the pte to be deleted is the first in the linked list
        if (curr->vpn == old_vpn && prev == NULL)
        {
            // Assign the hpt entry head to be the next node in the linked list
            // and free old hte
            as->hpt[index] = next;
            kfree(curr);
            break;
        }
        // If the pte to be deleted is at the end of the linked list
        else if (curr->vpn == old_vpn && next == NULL)
        {
            // set the prev->next to be null and free old hte
            prev->next = NULL;
            kfree(curr);
            break;
        }
        // If the pte to be deleted is in the middle of the list
        else if (curr->vpn == old_vpn)
        {
            // Set prev->next to point to next and free old hte
            prev->next = next;
            kfree(curr);
            break;
        }

        // If curr does not match the old_hte
        prev = curr;
        curr = curr->next;

        // If curr is set to null, we've reached the end of the list and havent
        // found the corresponding entry, return (needed cos can't set next if
        // curr is null, idk if should return something else)
        if (curr == NULL)
        {
            lock_release(as->hpt_lock);
            return;
        }
        else
        {
            next = curr->next;
        }
    }
    lock_release(as->hpt_lock);
}

struct hte *lookup_hte(vaddr_t hte_vpn)
{
    struct addrspace *as = proc_getas();
    vaddr_t index = hash(as, hte_vpn);

    struct hte *curr = as->hpt[index];
    while (curr != NULL)
    {
        if (curr->vpn == hte_vpn)
        {
            return curr;
        }
        curr = curr->next;
    }

    // If we return NULL, the hte doesnt exist
    return NULL;
}

void vm_bootstrap(void)
{
    /* Initialise any global components of your VM sub-system here.
     *
     * You may or may not need to add anything here depending what's
     * provided or required by the assignment spec.
     */
}

int vm_fault(int faulttype, vaddr_t faultaddress)
{
    (void)faulttype;
    (void)faultaddress;

    if (curproc == NULL || faultaddress == 0)
        return EFAULT;

    switch (faulttype)
    {
    case VM_FAULT_READONLY:
        /* We always create pages read-write, so we can't get this */
        return EFAULT;
    case VM_FAULT_READ:
    case VM_FAULT_WRITE:
        break;
    default:
        return EINVAL;
    }

    struct addrspace *as = proc_getas();
    // If either are null, it's likely a fault early in boot
    if (as == NULL || as->hpt == NULL || as->regions == NULL)
        return EFAULT;

    // Page align faultaddress
    faultaddress &= PAGE_FRAME;

    // Get region info
    struct region *curr_region = as->regions;
    while (curr_region != NULL)
    {
        if (faultaddress >= curr_region->as_v_start && faultaddress < curr_region->as_v_end)
        {
            break;
        }
        curr_region = curr_region->next;
    }

    paddr_t elo_paddr;
    struct hte *entry = lookup_hte(faultaddress);
    // Use page number to check in HPT if it exists
    if (entry == NULL)
    {
        if (curr_region == NULL)
            return EFAULT;

        vaddr_t vpn = alloc_kpages(1);      // Virtual address (kernal space)
        paddr_t pfn = KVADDR_TO_PADDR(vpn); // Physical memory location
        elo_paddr = pfn & PAGE_FRAME;
        bzero((void *)vpn, PAGE_SIZE);
        add_hte(as, faultaddress, pfn);
    }
    else
    {
        elo_paddr = entry->pfn & PAGE_FRAME;
    }

    vaddr_t entryhi = faultaddress;

    paddr_t dirty;
    if (curr_region->writeable)
        dirty = TLBLO_DIRTY;
    else
        dirty = 0;

    paddr_t entrylo = elo_paddr | dirty | TLBLO_VALID;
    tlb_random(entryhi, entrylo);

    return 0;
}

/*
 * SMP-specific functions.  Unused in our UNSW configuration.
 */

void vm_tlbshootdown(const struct tlbshootdown *ts)
{
    (void)ts;
    panic("vm tried to do tlb shootdown?!\n");
}
