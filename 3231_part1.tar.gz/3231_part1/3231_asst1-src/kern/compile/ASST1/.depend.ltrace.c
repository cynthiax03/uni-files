ltrace.o: ../../dev/lamebus/ltrace.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/lib.h ../../include/cdefs.h \
 opt-noasserts.h includelinks/platform/bus.h includelinks/machine/vm.h \
 ../../dev/lamebus/lamebus.h ../../include/cpu.h ../../include/spinlock.h \
 ../../include/hangman.h opt-hangman.h includelinks/machine/spinlock.h \
 ../../include/threadlist.h ../../dev/lamebus/ltrace.h autoconf.h
