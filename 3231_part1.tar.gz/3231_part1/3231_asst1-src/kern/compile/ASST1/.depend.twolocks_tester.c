twolocks_tester.o: ../../asst1/twolocks_tester.c ../../asst1/twolocks.h
