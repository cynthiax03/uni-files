time_syscalls.o: ../../syscall/time_syscalls.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/clock.h opt-synchprobs.h \
 ../../include/kern/time.h ../../include/copyinout.h \
 ../../include/syscall.h ../../include/cdefs.h
