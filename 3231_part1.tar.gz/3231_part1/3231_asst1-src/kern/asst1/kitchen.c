#include "opt-synchprobs.h"
#include "kitchen.h"
#include <types.h>
#include <kern/errno.h>
#include <lib.h>
#include <test.h>
#include <thread.h>
#include <synch.h>




/*
 * ********************************************************************
 * INSERT ANY GLOBAL VARIABLES YOU REQUIRE HERE
 * ********************************************************************
 */

struct lock *l;
struct cv *not_empty;
struct cv *empty;

static int curr_serves = 0;

/*
 * initialise_kitchen: 
 *
 * This function is called during the initialisation phase of the
 * kitchen, i.e.before any threads are created.
 *
 * Initialise any global variables or create any synchronisation
 * primitives here.
 * 
 * The function returns 0 on success or non-zero on failure.
 */

int initialise_kitchen()
{
        l = lock_create("l");
        not_empty = cv_create("not_empty");
        empty = cv_create("empty");

        if (l == NULL || not_empty == NULL || empty == NULL) {
                return ENOMEM;
        }

        return 0;
}

/*
 * cleanup_kitchen:
 *
 * This function is called after the dining threads and cook thread
 * have exited the system. You should deallocated any memory allocated
 * by the initialisation phase (e.g. destroy any synchronisation
 * primitives).
 */

void cleanup_kitchen()
{
        lock_destroy(l);
        cv_destroy(not_empty);
        cv_destroy(empty);
}


/*
 * do_cooking:
 *
 * This function is called repeatedly by the cook thread to provide
 * enough soup to dining customers. It creates soup by calling
 * cook_soup_in_pot().
 *
 * It should wait until the pot is empty before calling
 * cook_soup_in_pot().
 *
 * It should wake any dining threads waiting for more soup.
 */

void do_cooking()
{
        lock_acquire(l);
        
        while (curr_serves != 0) {
                cv_wait(not_empty, l);
        }

        cook_soup_in_pot();
        curr_serves += POTSIZE_IN_SERVES;
        cv_broadcast(empty, l);
        lock_release(l);
}

/*
 * fill_bowl:
 *
 * This function is called repeatedly by dining threads to obtain soup
 * to satify their hunger. Dining threads fill their bowl by calling
 * get_serving_from_pot().
 *
 * It should wait until there is soup in the pot before calling
 * get_serving_from_pot().
 *
 * get_serving_from_pot() should be called mutually exclusively as
 * only one thread can fill their bowl at a time.
 *
 * fill_bowl should wake the cooking thread if there is no soup left
 * in the pot.
 */

void fill_bowl()
{
        lock_acquire(l);

        while (curr_serves == 0) {
                cv_wait(empty, l);
        }

        get_serving_from_pot();
        curr_serves--;
        cv_broadcast(not_empty, l);
        lock_release(l);
        
}
