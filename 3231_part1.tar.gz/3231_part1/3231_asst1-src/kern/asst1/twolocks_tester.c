#include "twolocks.h"
/* 
 * This file is used for testing. It will be replaced by the auto tester, 
 * so do not make any changes here.
 */

#define LOOPS 1000

void holds_locka(void)
{
    /* Do nothing productive here */

    int i;
    for (i = 0; i < LOOPS; i++) {

    }
}
void holds_lockb(void)
{
    /* Do nothing productive here */
    int i;
    for (i = 0; i < LOOPS; i++) {

    }  
}

void holds_locka_and_b(void)
{
    /* Do nothing productive here */
    
    int i;
    for (i = 0; i < LOOPS; i++) {

    }
}
