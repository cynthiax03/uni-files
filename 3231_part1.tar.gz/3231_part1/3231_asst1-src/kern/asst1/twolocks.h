#ifndef TWOLOCKS_H
#define TWOLOCKS_H

extern void holds_locka(void);
extern void holds_lockb(void);
extern void holds_locka_and_b(void);

#endif
