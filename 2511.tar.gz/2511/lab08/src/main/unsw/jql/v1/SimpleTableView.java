package unsw.jql.v1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SimpleTableView<E> implements TableView<E> {
    private Iterator<E> it;
    private List<E> records;

    public SimpleTableView(Iterator<E> iterator, List<E> records) {
        System.out.println("12");
        System.out.println(iterator);
        this.it = iterator;
        this.records = new ArrayList<>(records);
    }

    @Override
    public boolean hasNext() {
        System.out.println("13");
        return it.hasNext();
    }

    @Override
    public E next() {
        // Update records
        System.out.println("14");
        this.records = records.subList(1, records.size());
        System.out.println(records);
        System.out.println("HELLO");
        return it.next();
    }

    @Override
    public Table<E> toTable() {
        System.out.println("15");
        List<E> list = new ArrayList<E>();
        this.forEachRemaining(list::add);
        return new Table<E>(list);
    }

    @Override
    public Iterator<E> iterator() {
        System.out.println("16");
        // *technically* this is non standard
        // since this should reproduce a unique iterator each time
        // but for our sakes it's fine, since any operation on an
        // iterator will implicitly invalidate the inner iterators
        // invalidating its original context anyways.
        return this.it;
    }

    @Override
    public int count() {
        System.out.println("17");
        this.records = records.subList(1, records.size());
        System.out.println(records);
        System.out.println(it);
        int count = 0;
        while (it.hasNext()) {
            it.next();
            count++;
        }

        return count;
    }
}
