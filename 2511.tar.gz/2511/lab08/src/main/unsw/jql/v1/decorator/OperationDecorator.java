package unsw.jql.v1.decorator;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import unsw.jql.v1.Table;
import unsw.jql.v1.TableView;

public abstract class OperationDecorator<E> implements TableView<E> {

    private TableView<E> inner;

    public OperationDecorator(TableView<E> inner) {
        System.out.println("6");
        this.inner = inner;
    }

    @Override
    public boolean hasNext() {
        System.out.println("7");
        return inner.hasNext();
    }

    @Override
    public abstract E next();

    public E nextElement() {
        System.out.println("8");
        return inner.next();
    }

    @Override
    public Iterator<E> iterator() {
        System.out.println("9");
        return this;
    }

    @Override
    public int count() {
        System.out.println("10");
        return inner.count();
    }

    @Override
    public Table<E> toTable() {
        System.out.println("11");
        List<E> list = new ArrayList<E>();
        this.forEachRemaining(list::add);
        return new Table<E>(list);
    }
    
}