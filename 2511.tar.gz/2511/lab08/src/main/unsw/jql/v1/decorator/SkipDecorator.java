package unsw.jql.v1.decorator;

import unsw.jql.v1.TableView;

public class SkipDecorator<E> extends OperationDecorator<E> {

    private int numberOfItems;

    public SkipDecorator(TableView<E> inner, int numberOfItems) {
        super(inner);
        System.out.println("21");
        this.numberOfItems = numberOfItems;
    }

    @Override
    public boolean hasNext() {
        System.out.println("18");
        return super.count() > numberOfItems && super.hasNext();
    }

    @Override
    public E next() {
        System.out.println("19");
        while (numberOfItems > 0 && hasNext()) {
            numberOfItems--;
            super.nextElement();
        }

        return super.nextElement();
    }

    @Override
    public int count() {
        System.out.println("20");
        int innerCount = super.count();
        return (numberOfItems <= innerCount) ? (innerCount - numberOfItems) : innerCount;
    }
}