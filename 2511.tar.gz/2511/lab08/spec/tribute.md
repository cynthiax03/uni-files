## Lab 08 - Choice Blogging - Tribute

Consider the song [Tribute](https://www.youtube.com/watch?v=_lK4cX5xGiQ). What Design Principle does the song embody? Write it down inside a private blog post.
