package unsw.archaic_fs.exceptions;

public class UNSWFileNotFoundException extends java.io.FileNotFoundException {
    public UNSWFileNotFoundException(String path) {
        super("File " + path + " not found");
    }
}