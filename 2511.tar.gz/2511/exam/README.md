The exam specification can be found here:

https://gitlab.cse.unsw.edu.au/COMP2511/22T2/exam-spec

This link will become available at the exam start time.