package q13;

import java.time.LocalDateTime;

public class LiveArticleSystem {

    public String createLiveArticle(LocalDateTime timeCreated) {
        return null;
    }

    public String createPost(String articleID, String title, String content, LocalDateTime timeCreated) {
        return null;
    }

    public void updatePost(String articleID, String postID, String newContent) {
        
    }

    public void deletePost(String articleID, String postID) {

    }

    public void addComment(String articleID, String postID, String comment) {
        
    }

}