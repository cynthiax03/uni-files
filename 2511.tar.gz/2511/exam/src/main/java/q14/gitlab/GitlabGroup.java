package q14.gitlab;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.json.JSONArray;
import org.json.JSONObject;

public class GitlabGroup extends GitlabPermissionsNode {

    private Map<User, PermissionsLevel> members = new HashMap<User, PermissionsLevel>();
    private List<GitlabPermissionsNode> subgroups = new ArrayList<GitlabPermissionsNode>();

    public GitlabGroup(String name, User creator) {
        this.name = name;
        members.put(creator, PermissionsLevel.OWNER);
    }

    public List<String> getUsersOfPermissionLevel(PermissionsLevel level) {
        Set<User> membersSet = members.keySet();
        List<String> names = new ArrayList<String>();

        membersSet.stream().filter(m -> getUserPermissions(m).equals(level)).forEach(m -> names.add(m.getName()));
        // for (User member : membersSet) {
        //     if (members.get(member).equals(level)) {
        //         names.add(member.getName());
        //     }
        // }

        return names;
    }

    @Override
    public GitlabGroup createSubgroup(String name, User user) throws GitlabAuthorisationException {
        authorise(user, PermissionsLevel.MAINTAINER);

        GitlabGroup group = new GitlabGroup(name, user);
        subgroups.add(group);
        return group;
    }

    @Override
    public GitlabProject createProject(String name, User user) throws GitlabAuthorisationException {
        authorise(user, PermissionsLevel.DEVELOPER);
        
        GitlabProject project = new GitlabProject(name, user);
        subgroups.add(project);
        return project;
    }

    @Override
    public JSONObject toJSON() {
        JSONObject json = super.toJSON()

        JSONArray subgroupJSON = new JSONArray(
            subgroups.stream()
                     .map(GitlabPermissionsNode::toJSON)
                     .collect(Collectors.toList())
        );

        json.put("subgroups", subgroupJSON);

        return json;
    }
}