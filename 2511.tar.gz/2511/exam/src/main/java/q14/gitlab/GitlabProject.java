package q14.gitlab;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;

public class GitlabProject extends GitlabPermissionsNode {

    private Map<User, PermissionsLevel> members = new HashMap<User, PermissionsLevel>();

    public void setName(String name) {
        this.name = name;
    }

    public GitlabProject(String name, User owner) {
        this.name = name;
    }

    @Override
    public GitlabGroup createSubgroup(String name, User user) {
        return null;
    }

    @Override
    public GitlabProject createProject(String name, User user) throws GitlabAuthorisationException {
        return null;
    }

    public void runPipeline(Runnable runnable) {
        GitlabRunner runner = new GitlabRunner();
        runner.run(runnable);
    }

}