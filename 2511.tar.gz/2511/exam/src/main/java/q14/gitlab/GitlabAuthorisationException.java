package q14.gitlab;

public class GitlabAuthorisationException extends Exception {
    public GitlabAuthorisationException(String message) {
        super(message);
    }
}