package q14.gitlab;

import org.json.JSONObject;

public abstract class GitlabPermissionsNode {
    protected String name;
    protected Map<User, PermissionsLevel> members = new HashMap<User, PermissionsLevel>();

    public String getName() {
        return name;
    }

    public PermissionsLevel getUserPermissions(User user) {
        return members.get(user);
    }
    
    public void updateUserPermissions(User userToUpdate, PermissionsLevel permissions, User userUpdating) throws GitlabAuthorisationException {
        authorise(updatingUser, PermissionsLevel.OWNER);
        members.put(userToUpdate, permissions);
    }

    public abstract GitlabGroup createSubgroup(String name, User creator) throws GitlabAuthorisationException;
    
    public abstract GitlabProject createProject(String name, User creator) throws GitlabAuthorisationException;

    protected void authorise(User user, PermissionsLevel requiredPermissionsLevel) throws GitlabAuthorisationException {
        int perms = getUserPermissions(user).ordinal();
        int requiredPerms = requiredPermissionsLevel.ordinal();
        if (perms > requiredPerms) {
            throw new GitlabAuthorisationException("User is not authorised");
        }
    }

    public JSONObject toJSON() {
        JSONObject json = new JSONObject();
        json.put("type", "project");
        json.put("name", name);

        return json;
    }
}