## Week 01 - Core Blogging - My First Blog Post

This exercise is simply getting you familiar with WebCMS blog posts.

### Step 1: Navigate to the Blog Posts Section on WebCMS.

<img src="imgs/blog1.png" width="500" />

### Step 2: Create a New Post

<img src="imgs/blog2.png" width="500" />

### Step 3: Write the Blog Post

<img src="imgs/blog3.png" width="500" />

### Step 4: Set the Visibility

Mosts blog posts you will make in this course will need to be **private** (select the **Course Staff** option, meaning only Course Staff will be able to view the post). You can make this one viewable by everyone in the course if you like (set the visibility to **Course**).

<img src="imgs/blog4.png" width="500" />

### Step 5: Press Post!

And you're all finished! Well done! You made your first blog post.
