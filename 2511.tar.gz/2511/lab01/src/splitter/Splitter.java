package splitter;

import java.util.Scanner;

public class Splitter {

    public static void main(String[] args) {
        System.out.println("Enter a message: ");
        
        Scanner scanner = new Scanner(System.in);
        String message[] = scanner.nextLine().split(" ");
        scanner.close();

        for (String word : message) {
            System.out.println(word);
        }
    }
}
