package staff;

public class Lecturer extends StaffMember {
    private String school;
    private String academicStatus;

    public Lecturer(String name, double salary, String school, String academicStatus) {
        super(name, salary);
        setSchool(school);
        setAcademicStatus(academicStatus);
    }

    // Getters
    public String getSchool() {
        return school;
    }

    public String getAcademicStatus() {
        return academicStatus;
    }

    // Setters
    public void setSchool(String school) {
        this.school = school;
    }

    public void setAcademicStatus(String academicStatus) {
        this.academicStatus = academicStatus;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        Lecturer other = (Lecturer) obj;
        if (academicStatus == null) {
            if (other.academicStatus != null)
                return false;
        } else if (!academicStatus.equals(other.academicStatus))
            return false;
        if (school == null) {
            if (other.school != null)
                return false;
        } else if (!school.equals(other.school))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return super.toString() + " " + school + " " + academicStatus;
    }

}
