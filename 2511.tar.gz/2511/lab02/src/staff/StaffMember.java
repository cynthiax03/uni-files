package staff;

import java.time.LocalDate;

/**
 * A staff member
 * 
 * @author Robert Clifton-Everest
 *
 */
public class StaffMember {
    private String name;
    private double salary;
    private LocalDate hireDate;
    private LocalDate endDate;

    public StaffMember(String name, double salary) {
        setName(name);
        setSalary(salary);
        this.hireDate = LocalDate.now();
        this.endDate = LocalDate.now();
    }

    // Getters
    public String getName() {
        return name;
    }

    public double getSalary() {
        return salary;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public LocalDate getEndDate() {
        return endDate;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    @Override
    public String toString() {
        return getClass().getName() + " " + name + " $" + Double.toString(salary) + " " + hireDate.toString() + " "
                + endDate.toString();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        StaffMember other = (StaffMember) obj;
        if (endDate == null) {
            if (other.endDate != null)
                return false;
        } else if (!endDate.equals(other.endDate))
            return false;
        if (hireDate == null) {
            if (other.hireDate != null)
                return false;
        } else if (!hireDate.equals(other.hireDate))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        if (Double.doubleToLongBits(salary) != Double.doubleToLongBits(other.salary))
            return false;
        return true;
    }

}
