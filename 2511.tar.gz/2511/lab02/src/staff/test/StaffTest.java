package staff.test;

import staff.StaffMember;
import staff.Lecturer;

public class StaffTest {
    public static void printStaffDetails(StaffMember staffMember) {
        System.out.println(staffMember.toString());
    }

    public static void main(String[] args) {
        StaffMember staffMember = new StaffMember("Parker Qiu", 300000);
        Lecturer lecturer = new Lecturer("Ashesh Mahidadia", 300000, "CSE", "A");

        StaffTest.printStaffDetails(staffMember);
        StaffTest.printStaffDetails(lecturer);

        if (staffMember.equals(lecturer)) {
            System.out.println("Staff members are equal");
        } else {
            System.out.println("Staff members are not equal");
        }
    }
}