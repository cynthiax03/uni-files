package hotel;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.json.JSONArray;

public class StandardRoom extends Room {

    private List<Booking> bookings = new ArrayList<Booking>();

    @Override
    public JSONObject toJSON() {
        JSONObject standardRoom = super.toJSON();
        standardRoom.put("type", "standard");
        return standardRoom;
    }

    @Override
    public void printWelcomeMessage() {
        System.out.println("Welcome to your standard room. Enjoy your stay :)");
    }

}