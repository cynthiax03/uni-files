package random;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class GameTest {
    @Test
    public void testGivenSeedEqual () {
        Game game1 = new Game(500);
        Game game2 = new Game(500);

        for (int i = 0; i < 100; i++) {
            assertEquals(game1.battle(), game2.battle());
        }
    }

    @Test
    public void testGivenSeedNotEqual() {
        Game game1 = new Game(23405);
        Game game2 = new Game(9);

        List<Boolean> game1Battles= new ArrayList<>();
        List<Boolean> game2Battles = new ArrayList<>();

        for (int i = 0; i < 100; i++) {
            game1Battles.add(game1.battle());
            game2Battles.add(game2.battle());
        }
        assertNotEquals(game1Battles, game2Battles);
    }

    @Test
    public void testNoGivenSeedNotEqual() {
        Game game1 = new Game();
        
        try {
            TimeUnit.SECONDS.sleep(1); 
        } catch (InterruptedException e) {
            System.out.println("interrupted expception error");
        }    
        
        Game game2 = new Game(); 
        List<Boolean> game1Battles= new ArrayList<>();
        List<Boolean> game2Battles = new ArrayList<>();

        for (int i = 0; i < 100; i++) {
            game1Battles.add(game1.battle());
            game2Battles.add(game2.battle());
        }
        assertNotEquals(game1Battles, game2Battles);
    }

    @Test
    public void testNoGivenSeedEqual() {
        Game game1 = new Game();
        Game game2 = new Game(); 

        List<Boolean> game1Battles= new ArrayList<>();
        List<Boolean> game2Battles = new ArrayList<>();

        for (int i = 0; i < 100; i++) {
            game1Battles.add(game1.battle());
            game2Battles.add(game2.battle());
        }
        assertEquals(game1Battles, game2Battles);
    }

    @Test
    public void test () {
        Random rand1 = new Random(1);
        Random rand2 = new Random(1);
        assertEquals(rand1.nextInt(), rand2.nextInt());
        // Produces same number 431529176
        System.out.println(rand1.nextInt());
        System.out.println(rand2.nextInt());
        // Produces diff number from above but still same 1761283695
        System.out.println(rand1.nextInt());
        System.out.println(rand2.nextInt());
    }
}