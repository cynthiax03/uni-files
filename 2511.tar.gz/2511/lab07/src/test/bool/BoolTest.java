package bool;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test; 
import org.json.JSONObject;

public class BoolTest {
    @Test
    @DisplayName("Test basic and printing")
    public void testPrintAnd() {
        BooleanNode boolNode = new AndNode(new ValueNode("true"), new ValueNode("false"));
        BooleanEvaluator boolEvaluator = new BooleanEvaluator();
        assertEquals(boolEvaluator.prettyPrint(boolNode), "(AND true false)");
    }

    @Test
    @DisplayName ("Test complex expression printing")
    public void testPrintComplex() {
        BooleanNode boolNode = new OrNode(new AndNode(new NotNode(new ValueNode("false")), new ValueNode("true")), new ValueNode("false"));
        BooleanEvaluator boolEvaluator = new BooleanEvaluator();
        assertEquals(boolEvaluator.prettyPrint(boolNode), "(OR (AND (NOT false) true) false)");
    }

    @Test 
    @DisplayName ("Test basic evaluating")
    public void testBasicEvaluating() {
        BooleanNode andNode1 = new AndNode(new ValueNode("true"), new ValueNode("false"));
        BooleanNode andNode2 = new AndNode(new ValueNode("false"), new ValueNode("false"));
        BooleanNode andNode3 = new AndNode(new ValueNode("true"), new ValueNode("true"));

        BooleanNode orNode1 = new OrNode(new ValueNode("true"), new ValueNode("false"));
        BooleanNode orNode2 = new OrNode(new ValueNode("false"), new ValueNode("false"));
        BooleanNode orNode3 = new OrNode(new ValueNode("true"), new ValueNode("true"));

        BooleanNode notNode1 = new NotNode(new ValueNode("true"));
        BooleanNode notNode2 = new NotNode(new ValueNode("false"));

        BooleanEvaluator boolEvaluator = new BooleanEvaluator();

        assertEquals(boolEvaluator.evaluate(andNode1), false);
        assertEquals(boolEvaluator.evaluate(andNode2), false);
        assertEquals(boolEvaluator.evaluate(andNode3), true);

        assertEquals(boolEvaluator.evaluate(orNode1), true);
        assertEquals(boolEvaluator.evaluate(orNode2), false);
        assertEquals(boolEvaluator.evaluate(orNode3), true);

        assertEquals(boolEvaluator.evaluate(notNode1), false);
        assertEquals(boolEvaluator.evaluate(notNode2), true);
    }

    @Test
    @DisplayName("Test complex evaluating")
    public void testComplexEvaluating() {
        BooleanEvaluator boolEvaluator = new BooleanEvaluator();
        BooleanNode boolNode = new AndNode(new AndNode(new OrNode(new ValueNode("true"), new ValueNode("false")), new ValueNode("true")), new NotNode(new ValueNode("false")));
        assertEquals(boolEvaluator.evaluate(boolNode), true);
    }

    @Test
    @DisplayName("Test node factory")
    public void testNodeFactory() {
    // String dataString = { 
    //     "node": 
    //     "and", 
    //     "subnode1" : {
    //         "node": 
    //         "or", 
    //         "subnode1": {
    //             "node": "value", "value": true
    //         },
    //         "subnode2": {
    //             "node": "value", "value": false
    //         }
    //     },
    //     "subnode2": {
    //         "node": "value", "value": true
    //     }
    // }
    
    //     JSONObject data = new JSONObject();
    //     data.put("node", "and");
    //     JSONObject subNode1 = new JSONObject().put("node", "or");
    //     JSONObject subNode11 = new JSONObject().put("node", "or");

    //     data.put("subnode1", new JSONObject().put("key1", "value1"))
    //     data.put("age", "22");
    //     data.put("city", "chicago");
    //     String jsonString = new JSONObject()
    //               .put("JSON1", "Hello World!")
    //               .put("JSON2", "Hello my World!")
    //               .put("JSON3", new JSONObject().put("key1", "value1"))
    //               .toString();
        
    }
}
