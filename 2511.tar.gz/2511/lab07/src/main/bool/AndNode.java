package bool;

public class AndNode implements BooleanNode {

    private BooleanNode subNode1;
    private BooleanNode subNode2;

    public AndNode(BooleanNode subNode1, BooleanNode subNode2) {
        this.subNode1 = subNode1;
        this.subNode2 = subNode2;
    }

    @Override
    public boolean evaluate() {
        return subNode1.evaluate() && subNode2.evaluate();    
    }

    @Override
    public String print() {
        return "(AND " + subNode1.print() + " " + subNode2.print() + ")";
    }
}
