package bool;

public class NotNode implements BooleanNode {
    
    private BooleanNode subNode;

    public NotNode(BooleanNode subNode) {
        this.subNode = subNode;
    }

    @Override
    public boolean evaluate() {
        return !subNode.evaluate(); 
    }

    @Override
    public String print() {
        return "(NOT " + subNode.print() + ")";
    }
}