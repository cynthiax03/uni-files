package bool;

public class OrNode implements BooleanNode {
    
    private BooleanNode subNode1;
    private BooleanNode subNode2;

    public OrNode(BooleanNode subNode1, BooleanNode subNode2) {
        this.subNode1 = subNode1;
        this.subNode2 = subNode2;
    }

    @Override
    public boolean evaluate() {
        return subNode1.evaluate() || subNode2.evaluate();   
    }

    @Override
    public String print() {
        return "(OR " + subNode1.print() + " " + subNode2.print() + ")";
    }
}
