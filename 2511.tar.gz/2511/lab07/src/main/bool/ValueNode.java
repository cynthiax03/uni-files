package bool;

public class ValueNode implements BooleanNode {
    private String value;
    
    public ValueNode(String value) {
        this.value = value;
    }

    @Override
    public boolean evaluate() {
        return Boolean.parseBoolean(value);
    }

    @Override
    public String print() {
        return value; 
    }
}
