package bool;

public class BooleanEvaluator {

    public static boolean evaluate(BooleanNode expression) {
        return expression.evaluate();
    }

    public static String prettyPrint(BooleanNode expression) {
        return expression.print();
    }

    public static void main(String[] args) {
        BooleanNode booleanNode = new OrNode(new ValueNode("true"), new ValueNode("false"));
        prettyPrint(booleanNode);
    }
}