package bool;

import org.json.JSONObject;

public class NodeFactory {

    public static BooleanNode createBooleanNode(JSONObject data) {
        BooleanNode booleanNode = null;
        String node = data.getString("node");

        if (node.equals("and")) {
            BooleanNode left = createBooleanNode(data.getJSONObject("subNode1"));
            BooleanNode right = createBooleanNode(data.getJSONObject("subNode2"));
            return new AndNode(left, right);

        } else if (node.equals("or")) {
            BooleanNode left = createBooleanNode(data.getJSONObject("subNode1"));
            BooleanNode right = createBooleanNode(data.getJSONObject("subNode2"));
            return new OrNode(left, right);

        } else if (node.equals("not")) {
            BooleanNode subNode = createBooleanNode(data.getJSONObject("subNode"));
            return new NotNode(subNode);

        } else {
            String value = data.getString("value");
            return new ValueNode(value);
        }
    }

}