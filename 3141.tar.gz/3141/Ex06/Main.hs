module Main where

import Ex06

main = play
