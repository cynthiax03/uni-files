module Exam where

{- Feel free to import more stuff here, as long as it's all from
   `base`. In other words, importing it should not require tinkering
   with the stack.yaml or .cabal files.
 -}
import Data.Maybe(fromMaybe, fromJust)
import Data.List(intersperse,sort,nub,intersect,delete)
import Data.Char(toLower)
import Control.Monad((>=>))
import Test.QuickCheck
-- data Trie = Trie {c :: Char, t :: Trie}
data T = X Bool|Y Bool|Z
instance Arbitrary T where arbitrary = oneof [X Bool, Y Bool, Z]