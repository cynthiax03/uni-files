module QuizMarker where
import Data.Maybe(isJust, fromJust)
import Data.List(inits,nub,intercalate)
import Data.Char(isSpace,isDigit)
import Data.Foldable(find)
import Text.Read(readMaybe)
import Data.Time.Format
import Data.Time.Clock
import Test.QuickCheck
import Data.Bifunctor (second)
import Numeric (showFFloat)
import Data.Bifunctor (second)

{- A `Parser a` consumes input (of type `String`),
   and can either fail (represented by returning `Nothing`)
   or produce a value of type `a` along with a `String`
   of leftovers -- this is the unconsumed suffix
   of the original input.

   Side note:
    This combines features of both the Maybe monad and the
    State monad. So why didn't we just use those?
    Well, note that  `State String (Maybe a)`
    isn't quite what we want (because then failure
    could consume input), and neither is
    `Maybe (State String a)` (because then failure
    could not depend on what the input is).
 -}
newtype Parser a = Parser (String -> Maybe (String,a))

instance Functor Parser where
  fmap f (Parser p) = Parser $ fmap (fmap f) . p

instance Applicative Parser where
  pure x = Parser $ \s -> Just (s,x)
  Parser f <*> Parser x =
     Parser $ \s ->
        do -- this is using the Maybe monad
          (s',f') <- f s
          fmap f' <$> x s'

{- `>>=` can be used to compose two parsers
   sequentially, so that the second parser
   operates on the leftovers of the first.
   If either parser fails, the composite
   parser also fails.

   For example, the following parser:

     parseDouble >>= \x ->
     keyword "+" >>
     parseDouble >>= \y ->
     return(x+y)

   or equivalently in do notation:

     do
       x <- parseDouble
       keyword "+"
       y <- parseDouble
       return(x+y)

   should return 3.0::Double when given
   the input string "1+2"
 -}
instance Monad Parser where
  return = pure
  Parser m >>= k =
    Parser $ \s ->
      do -- this is using the Maybe monad
        (s',a) <- m s
        let Parser m' = k a
        m' s'

{- A parser that always fails
 -}
abort :: Parser a
abort = Parser $ const Nothing

{- `try m` is a parser that fails if
   m is Nothing, and otherwise succeeds
   with result `m` without consuming any
   input.
 -}
try :: Maybe a -> Parser a
try Nothing  = abort
try (Just a) = return a

{- `keyword s` is a parser
   that consumes a string s,
   and fails if unable to do so.
 -}
keyword :: String -> Parser ()
keyword kw =
  Parser(\s ->
           let (xs,ys) = splitAt (length kw) s
           in
             if xs == kw then
               Just (ys,())
             else
               Nothing)

{- `parsePred f` is a parser
   that consumes and returns the
   longest prefix of the input
   such that every character satisfies
   `p`. Never fails.
 -}
parsePred :: (Char -> Bool) -> Parser String
parsePred f =
  Parser(\s ->
           let xs = takeWhile f s
           in
             Just (drop (length xs) s, xs))

{- `least f` consumes and returns the
   shortest prefix of the input that
   satisfies f.

   Fails if no prefix of the input
   satisfies f.
 -}
least :: (String -> Bool) -> Parser String
least f =
  Parser(\s -> do
            xs <- find f $ inits s
            return(drop (length xs) s, xs))

{- `orelse p1 p2` is a parser that
   behaves like p1, unless p1 fails.
   If p1 fails, it behaves instead like p2.
 -}
orelse :: Parser a -> Parser a -> Parser a
orelse (Parser p1) (Parser p2) =
  Parser $ \s ->
    case p1 s of
      Nothing -> p2 s
      res -> res

{- `parseWhile p` will repeatedly run
   the parser p until p fails,
   and return the list of all
   results from the successful
   runs in order.

   For example, we would expect:

   runParserPartial (parseWhile (keyword "bla")) "blablably"
   == Just ("bly",[(),()])

   Note that even if `p` fails,
   `parseWhile` should not fail.
 -}
parseWhile :: Parser a -> Parser [a]
parseWhile p =
  do
    x <- p
    xs <- parseWhile p
    return (x:xs)
  `orelse` return []

{- `first ps` behaves as the first parser
   in `ps` that does not fail. If they all
   fail, `first ps` fails too.
 -}
first :: [Parser a] -> Parser a
first (x:xs) = x `orelse` first xs
first [] = abort

{- peekChar is a parser that
   returns the first character
   of input without consuming it,
   failing if input is empty.

   For example, we'd expect

     runParserPartial peekChar "bla"
     == Just ("bla",'b')
 -}
peekChar :: Parser Char
peekChar = Parser $ \s ->
  case s of 
    (x:xs) -> Just (s, x)
    [] -> Nothing

{- parseChar is a parser that
   consumes (and returns) a single
   character, failing if there
   is nothing to consume.

   For example, we'd expect

     runParserPartial parseChar "bla"
     == Just ("la",'b')
 -}
parseChar :: Parser Char
parseChar = Parser $ \s ->
  case s of 
    (x:xs) -> Just (xs, x)
    [] -> Nothing

{- A parser that consumes all leading
   whitespace (as determined by isSpace).
   Should always succeed.
 -}
whiteSpace :: Parser ()
whiteSpace = do 
  parsePred isSpace
  return ()

{- parseBool either
   consumes "true" to produce True,
   consumes "false" to produce False,
   or fails if unable.
 -}
parseBool :: Parser Bool
parseBool = (keyword "true" >> return True) `orelse` (keyword "false" >> return False)

{- parsePositiveInt is a parser that parses a
   non-empty sequence of digits (0-9)
   into a number.
 -}
parsePositiveInt :: Parser Int
parsePositiveInt = do 
  digitStr <- parsePred isDigit
  case readMaybe digitStr of
    Just 0 -> abort
    Just num -> return num
    Nothing -> abort

{- parseDouble is a parser that parses a number on the
   format:

     -<digits>.<digits>

   Where the minus sign and decimal point are optional.
   Should fail if the start of input does not match
   this format.

   The JSON file format also allows numbers with E notation.
   We do not support such numbers.
 -}
parseDouble :: Parser Double
parseDouble = do
  negative <- (keyword "-" >> return (-1)) `orelse` (return 1)
  wholeNum <- parseInt
  decimals <- (keyword "." >> parseInt) `orelse` (return 0)
  let n = fromIntegral wholeNum
  let d = fromIntegral decimals
  return (negative * (n + ((d) / (10 ^ (length (show d))))))

-- Same as parsePositiveInt but also accepts 0
parseInt :: Parser Int
parseInt = do 
  digitStr <- parsePred isDigit
  case readMaybe digitStr of
    Just num -> return num
    Nothing -> abort

{- `parseString` is a parser that consumes a quoted
   string delimited by " quotes, and returns it.

   For example, we would expect:

     runParserPartial parseString "\"ab\"r"
     == runParserPartial parseString ['"','a','b','"','r']
     == Just ("r","ab")

   To add an additional complication, it's possible
   for the input string to contain escape sequences.
   Note in particular that escaped quotes do not end
   the string.
   For example:

     runParser parseString "\"a\\\"b\""
     Just "a\"b"

   Hint: what does (readMaybe s)::Maybe String do?
         And how is that useful here?
         And how is what (readMaybe "[]")::Maybe String
         does less than optimally useful?
 -}

parseString :: Parser String
parseString = do
  -- Check the first character is a quotation mark
  first <- peekChar
  if first /= '"' then abort
  else 
    Parser $ \s -> 
      -- Get the valid string
      case findString s of 
        Just (value, length) -> Just (drop length s, value)
        Nothing -> Nothing

-- Returns the first string that satisfies readMaybe, if readMaybe fails, the
-- function recurses by removing the last char from the string and trying 
-- again
findString :: String -> Maybe (String, Int) 
findString s = do
  -- If string is empty, there is no valid string
  if length s == 0 then Nothing
  else
    case readMaybe s of
      -- If readMaybe works, return the valid value as well as the length of
      -- the string
      Just value -> return (value, length s)
      -- If readMaybe fails, recurse with the last element removed from the
      -- string
      Nothing -> findString (removeLastElement s)

-- Function that removes last char from a string
removeLastElement :: String -> String 
removeLastElement [] = []
removeLastElement [x] = []
removeLastElement (x:xs) = x : (removeLastElement xs)

{- `parseList l r p` parses a
   comma-separated list that
   is delimited on the left by l,
   on the right by r,
   and where p is a parser for single
   elements of the list type.

   For example, we would expect:

     runParser (parseList '[' ']' parseDouble) "[1, 2]"
     == Just [1.0,2.0]

   Trailing commas, or omitted commas between elements,
   should yield failure.

   You should accept any amount of whitespace
   after l, before r, and before and after comma,
   including no whitespace. So we would expect
   the same result as above for the following call:

     runParser (parseList '[' ']' parseDouble) "[ 1  ,2 ]"

   The fact that we haven't hardcoded [ and ] as the
   delimiters will be handy later.
 -}
parseList :: Char -> Char -> Parser a -> Parser [a]
parseList l r p = 
  do
    -- Parse left delimiter and consume any white space
    keyword (l:[])
    whiteSpace
    -- Check whether it is empty (ie nothing or whitespace between l and r)
    ended <- (keyword (r:[]) >> return True) `orelse` (return False)
    if ended 
      then return []
    else do
      -- If not empty consume first element and use parseRest to parse the rest
      x <- p 
      xs <- parseRest r p
      return (x:xs)

-- Function that recursively parses a list until the right delimiter
parseRest :: Char -> Parser a -> Parser [a]
parseRest r p = 
  do 
    -- remove any whitespace and check if we've reached r
    whiteSpace
    ended <- (keyword (r:[]) >> return True) `orelse` (return False)
    if ended 
      then return []
    else do
      -- if we're not at the end parse comma, and parse next element
      keyword ","
      whiteSpace
      x <- p 
      -- recursively parse what is next
      xs <- parseRest r p
      return (x:xs)

{- `runParser s p` runs the parser p
   on input s.
   This should return Nothing if:
   - the parser fails, or
   - the parser succeeds, but has not
       consumed all input.
 -}
runParser :: Parser a -> String -> Maybe a
runParser (Parser p) s =
  case p s of
    Just ([],a) -> Just a
    _           -> Nothing

{- `runParserPartial s p` runs the parser p
   on input s.

   In the event that some of the input remains
   unconsumed, it is returned alongside the result.

   You should only use this for testing ---
   input that contains spare tokens at the end
   should be considered malformed, which is
   what `runParser` handles.
 -}
runParserPartial :: Parser a -> String -> Maybe(String,a)
runParserPartial (Parser p) s = p s

{- Now for our JSON parser.
   `JSON` is a datatype for representing
   JSON objects, which are key-value pairs
   mapping names to values.
 -}
data JSON = JSON [(String,Data)] deriving (Eq,Show)

{- Values in a JSON object can be of the following types:
   - a floating-point number
   - a string
   - a list of data objects, not necessarily of the same type
   - a boolean
   - null
   - another JSON object.
 -}
data Data =
  Number Double
  | String String
  | List [Data]
  | Bool Bool
  | Null
  | JSONData JSON deriving (Eq,Show)

{- This Arbitrary instance only generates keys in the
    range a..z.
   This is for readability, and should not be construed
   as a limitation on the type of keys allowed.

   The generator is deliberately biased towards
   smaller JSON objects.
 -}
instance Arbitrary JSON where
  arbitrary = JSON <$> listOf ((,) <$> key <*> arbitrary)
    where key = listOf $ elements ['a'..'z']
  shrink (JSON d) =
    JSON <$> shrinkList (const []) d

instance Arbitrary Data where
  shrink (JSONData j) = JSONData <$> shrink j
  shrink (List l) = List <$> shrink l
  shrink d = []  
  arbitrary = frequency [
                     (3,Number   <$> arbitrary),
                     (3,String   <$> arbitrary),
                     (1,List     <$> smaller arbitrary),
                     (3,Bool     <$> arbitrary),
                     (1,JSONData <$> smaller arbitrary),
                     (1,pure Null)] where
    smaller g = sized (\n -> resize (n `div` 4) g)

{- A parser for JSON objects.

   JSON objects are {}-delimited,
   comma-separated lists of key-value
   pairs.

   A key-value pair is a "-delimited string
   and a data value, separated by a :

   Allow any amount of whitespace
   before or after the elements

     { } : ,

   Hints:
    Because JSON objects can themselves be data, this
    function needs to be mutually recursive with parseData.
 -}
parseJSON :: Parser JSON
parseJSON = do
  whiteSpace 
  x <- parseList '{' '}' parseStringData
  whiteSpace 
  return (JSON x)

parseStringData :: Parser (String, Data)
parseStringData = do
  s <- parseString 
  whiteSpace
  keyword ":"
  whiteSpace
  d <- parseData
  return (s, d)

{- A parser for JSON data values.

   Hints:
    You've already done most of the work for this in the
    previous functions, it's just a matter of composing
    them.

    Because JSON objects can themselves be data, this
    function needs to be mutually recursive with parseJSON.
 -}
parseData :: Parser Data
parseData = do
  -- Get first char
  first <- peekChar 
  -- Check what parser to use based on first char
  if isDigit first || first == '-' then Number <$> parseDouble
  else do 
    if first == '[' then List <$> (parseList '[' ']' parseData)
    else do
      if first == '{' then JSONData <$> parseJSON
      else do 
        if first == 'n' then do keyword "null" >> return Null
        else do
          if first == '"' then String <$> parseString
          else do
            if first == 't' || first == 'f' then Bool <$> parseBool
            else do 
              abort

{- Time strings are represented in the following format:

     YYYY-MM-DD HH-MM-SS

   where H is in 24h format. This is a string-to-time
   function that accepts the above format.
 -}
toTime :: String -> Maybe UTCTime
toTime = parseTimeM True defaultTimeLocale "%F %X"

{- A quiz submission consists of:

  - A session (something like 23T2)
  - Name of the quiz (something like quiz02)
  - Name of the student (something like "Jean-Baptiste Bernadotte")
  - A list of answers.
    For example, a student who answer option 4 on question 1,
    and options 1,3 on question 2,
    would have [[4],[1,3]]
  - A submission time.
 -}
data Submission =
  Submission { session :: String,
               quizName :: String,
               student :: String,
               answers :: [[Int]],
               time :: UTCTime
             } deriving (Eq,Show)

instance Arbitrary Submission where
  arbitrary =
    Submission <$>
    arbitrary <*>
    arbitrary <*>
    arbitrary <*>
    arbitraryAnswers <*>
    arbitraryTime where arbitraryAnswers = map (map getPositive) <$> arbitrary

-- Likes generating years in the far future.
arbitraryTime :: Gen UTCTime
arbitraryTime =
  do
    Large d <- arbitrary
    t <- choose (0,86400)
    return $ UTCTime (toEnum $ abs d) (secondsToDiffTime t)
          

{- These utility functions will be handy I promise -}
getString :: Data -> Maybe String
getString (String s) = return s
getString _ = Nothing

getList :: Data -> Maybe [Data]
getList (List xs) = return xs
getList _ = Nothing

getNumber :: Data -> Maybe Double
getNumber (Number n) = return n
getNumber _ = Nothing

getJSON :: Data -> Maybe JSON
getJSON (JSONData j) = return j
getJSON _ = Nothing

{- This function should convert a JSON object
   to a `Submission`.
   This should fail if:
   - Either of the keys
       session, quiz_name, student, answers,time
     are absent from the JSON object
   - Either of the above are present, but
     do not have the expected type.
     All fields except `answers` are expected to
     hold string values; `answers` should hold
     a list of lists of numbers.
   - The `time` key is present, and holds
     a string, but this string is not
     recognised as a valid time by
     `toTime`.
   - The `answers` contain numbers that are
     not whole, or not positive.

   You should *not* fail if the JSON object
   contains more keys than the above.
   Politely ignore such keys.

   If either of the above keys have duplicate
   entries in the JSON object, you're free
   to do anything you want.
   Duplicates of other keys should be ignored.
 -}
toSubmission :: JSON -> Maybe Submission
toSubmission json = do
  -- Check whether the json has all the keys
  let validKeys = getAllKeys json []
  if length validKeys /= 5 then Nothing
  else do 
    -- Get the value for each key
    let sessionData = getString (getValue "session" validKeys)
    let quizNameData = getString (getValue "quiz_name" validKeys)
    let studentData = getString (getValue "student" validKeys)
    let answersStr = getList (getValue "answers" validKeys)
    let timeStr = getString (getValue "time" validKeys)

    -- Check that the values are valid
    if (isJust sessionData) && (isJust quizNameData) && (isJust studentData) && 
      (isJust answersStr) && (isJust timeStr)
      then do
        -- Check that time is valid and answers are valid
        let timeUTC = toTime (fromJust timeStr)
        let answerList = checkAnswerList (fromJust answersStr)
        if (isJust timeUTC) && (length answerList == length (fromJust answersStr))
          then Just Submission {session = fromJust sessionData,
               quizName = fromJust quizNameData,
               student = fromJust studentData,
               answers = answerList,
               time = fromJust timeUTC}
        else Nothing
    else Nothing

-- Takes in a list of data and returns a list of list of ints
checkAnswerList :: [Data] -> [[Int]]
checkAnswerList (x:xs) = do
  -- Check curr list is a list
  case getList x of 
    Nothing -> checkAnswerList xs
    Just l -> do
      -- If it is a valid list, check that the ints inside are valid
      let nums = checkNumbers l 
      -- nums will be a list of valid nums, if nums is the same length as the
      -- list l we can add l to the list and recurse
      if length l /= length nums 
        then checkAnswerList xs
      else nums:(checkAnswerList xs)
checkAnswerList [] = []

-- Checks a list of data to check whether they are valid ints
checkNumbers :: [Data] -> [Int]
checkNumbers (x:xs) = do
  -- Check if current data is an int
  case getNumber x of 
    Nothing -> (checkNumbers xs) 
    Just n -> do
      -- If it is an int, check that it is positive and whole, if it is add it
      -- to the list and recurse
      if n > 0 && (n == fromInteger (round n)) 
        then (round n):(checkNumbers xs)
      else (checkNumbers xs)
checkNumbers [] = []

-- Gets the data from a JSON list by key
getValue :: String -> [(String, Data)] -> Data 
getValue key (x:xs) = do
  -- If key is found return the data
  if fst x == key 
    then (snd x)
    -- Or recurse
  else getValue key xs
-- If key not found return Number 0 (not a valid string or list for above)
getValue key [] = Number 0

-- Gets all the JSON for the keys needed in a submission
getAllKeys :: JSON -> [String] -> [(String, Data)]
getAllKeys (JSON (x:xs)) list = do
  -- If the length of our list is 5, we can finish the recursion
  if length (nub list) == 5 
    then []
  else do
    -- If the currect key is a submission key and not currently in the list,
    -- add it to the list
    if fst x `elem` submissionKeys && not (fst x `elem` list) 
      then (getAllKeys (JSON xs) (list ++ [(fst x)])) ++ [x]
    -- Else do not add it to the list as it is a duplicate or not a submission 
    -- key
    else getAllKeys (JSON xs) (list)
getAllKeys (JSON []) list = []

submissionKeys :: [String]
submissionKeys = ["session", "quiz_name", "student", "answers", "time"]

{- This function should convert a JSON object
   to a key-value store where the values are
   of type `Submission` instead of JSON objects.

   Should fail if the JSON object holds one or
   more values that are not valid submissions.
 -}
toSubmissions :: JSON -> Maybe [(String,Submission)]
toSubmissions (JSON list) = do
  -- Get a list of all valid submissions
  let validList = getValidSubmissions (JSON list)
  -- If the valid submission list is a different length to the JSON we got
  -- return Nothing
  if length list /= length validList 
    then Nothing 
  else Just validList

-- Gets a list of valid submissions
getValidSubmissions :: JSON -> [(String, Submission)]
getValidSubmissions (JSON (x:xs)) = do
  -- Check that the data from the json can be converted to JSON, add it to the
  -- list if it is a valid submission
  case toSubmission (fromJust (getJSON (snd x))) of 
    Nothing -> getValidSubmissions (JSON xs)
    Just sub -> (fst x, sub):(getValidSubmissions (JSON xs))
getValidSubmissions (JSON []) = []

{- There are two kinds of questions:
   - multiple-choice, represented by CheckBox
   - single-choice, represented by Radio
 -}
data QuestionType = Radio | CheckBox deriving (Eq,Show)

instance Arbitrary QuestionType where arbitrary = elements [Radio,CheckBox]

{- A question has:
   - a question number
   - a question type
   - a list of correct answers
 -}
data Question =
  Question { number  :: Int,
             qtype   :: QuestionType,
             correct :: [Int]
           } deriving (Eq,Show)

{- A quiz comprises a deadline and a list of questions.
 -}
data Quiz =
  Quiz { deadline :: UTCTime,
         questions :: [Question]
       } deriving (Eq,Show)

instance Arbitrary Question where
  arbitrary = do
    Positive n <- arbitrary
    qtype <- arbitrary
    correct <- listOf1 (getPositive <$> arbitrary)
    return $ Question n qtype correct

nubBy :: Eq b => (a -> b) -> [a] -> [a]
nubBy f [] = []
nubBy f (x:xs) = x:nubBy f (filter ((/= f x) . f) xs)

{- This generator is set up to generate quizzes with distinct
   question numbers starting from 1.

   This partially overrides the behaviour of the Question
   generator.
 -}
instance Arbitrary Quiz where
  arbitrary = Quiz <$> arbitraryTime <*> arbitraryQuestions
    where
      arbitraryQuestions = do
        qs <- arbitrary
        return $ map (\(n,q) -> Question n (qtype q) (correct q)) $ zip [1..] qs

{- `parseQuiz` is a parser that
   reads a quiz from an input representing
   a key. A key is a file such that:

   - The first line is a date, of the form
     accepted by toTime
   - The subsequent lines represent questions,
     and have the form

       n|type|correct

     Where `n` is a question number,
     `type` is either a checkbox or a radio button,
     and `correct` is a comma-separated list
     of answers with no delimiters.
     The answer must be a a list of non-empty
     positive integers denoting
     the correct alternatives.

   Malformed input should be rejected.
   Questions must start from 1, be consecutive,
   be positive integers,
   and be free of duplicates question numbers;
   reject any input that does not conform.
   Answers must be positive integers,
   and there must be at least one answer.
 -}
parseQuiz :: Parser Quiz
-- parseQuiz = error "TODO: implement parseQuiz"
parseQuiz = do 
  -- Get time string on the first line and check it is valid
  timeStr <- parsePred (/= '\n')
  case toTime timeStr of 
    Nothing -> abort
    Just time -> do 
      -- If time is valid parse the questions
      keyword "\n"
      questions <- parseQuestions 0
      return Quiz {deadline = time, questions = questions}
      -- parseWhile (parseQuestions 0) >>= 
      --   \[questions] -> return Quiz {deadline = time, questions = questions}

-- Parses questions and takes in an int representing the current number of qs
-- so we can check that the questions start from 1 and are consecutive
parseQuestions :: Int -> Parser [Question]
parseQuestions numQs = do
  -- Consume newline and check if we've reached the end of the string
  -- keyword "\n"
  ended <- (peekChar >> return False) `orelse` return True
  if ended 
    then return []
  else do 
    -- If we're not at the end of the str parse the current question, if the
    -- current question is not valid, return [], or recursively parse the rest
    question <- parseQuestion numQs `orelse` return []
    case question of 
      [] -> return []
      _ -> do
        rest <- parseQuestions (numQs + 1)
        return (question ++ rest)

-- Parses a string representing a question and takes an int that represents
-- the previous question number to ensure the current qNum is consecutive
parseQuestion :: Int -> Parser [Question]
parseQuestion prevQ = do
  qNumStr <- parsePred (/= '|')
  keyword ("|")
  qTypeStr <- parsePred (/= '|')
  keyword ("|")
  qCorrectStr <- parsePred (/= '\n')
  keyword "\n"
  -- Check that qNum, qtype and correct are not empty
  if (length qNumStr /= 0 && length qTypeStr /= 0 && length qCorrectStr /= 0) 
    then do
      let numValid = readMaybe qNumStr :: Maybe Int
      let typeValid = checkqType qTypeStr
      let correctValid = checkCorrect qCorrectStr
      -- Check that the types are correct, the qNum is consecutive and the list
      -- of correct answers contains valid answers
      if isJust numValid && fromJust numValid == prevQ + 1 && fromJust numValid > 0 
        && isJust typeValid && length (fst correctValid) == snd correctValid
        then return [Question {number = fromJust numValid, 
        qtype = fromJust typeValid, correct = fst correctValid}]

      else abort
  else abort

-- Checks that given string is either a radio or checkbox, and returns 
-- respective qtype or returns Nothing
checkqType :: String -> Maybe QuestionType
checkqType str 
  | str == "radio" = Just Radio
  | str == "checkbox" = Just CheckBox
  | otherwise = Nothing

-- Check that the correct answers list is valid, returns a tuple of the list of
-- valid answers and the number of total number of answers
checkCorrect :: String -> ([Int], Int)
checkCorrect [] = ([], 0)
-- Accounts for edge case of comma at the end
checkCorrect (',':xs) = ([], 1)
checkCorrect str = do
  -- Take the number until the next comma and check that the number is valid
  let correctStr = takeWhile (/= ',') str
  let correctInt = readMaybe correctStr :: Maybe Int
  -- Recurse with the current number and comma removed from the str
  let rest = checkCorrect (drop (dropAmt str correctStr) str)
  -- If the number is valid and positive, add the current number to 
  if isJust correctInt && fromJust correctInt > 0 
    then ([fromJust correctInt] ++ (fst rest), (snd rest) + 1)
  else (fst rest, (snd rest) + 1)

dropAmt :: String -> String -> Int
dropAmt wholeStr answerStr 
  | length wholeStr - length answerStr == 1 = length answerStr
  | otherwise = length answerStr + 1

{- And now for the business logic!

   `markQuestion q as` should assign marks
   to the answers `as` given to question `q`
   as follows:

   - If the question is single-choice,
     give 1 mark if the student supplied
     exactly one answer, which is also
     correct.
   - If the question is multiple-choice,
     give marks according to the
     following formula:

       max(0,(right - wrong)/correct)

     Where `right` is the number of correct
     answers in `as`, `wrong` is the number
     of incorrect answers in `as`,
     and `correct` is the number of correct
     answers in the answer sheet.

     Allow for the possibility that either
     the given set of answers, or the
     answer sheet, may contain duplicates.
     Duplicates should be ignored
     for purposes of the above tally.
 -}
markQuestion :: Question -> [Int] -> Double
markQuestion q as = do
  -- Empty as case
  if length as == 0 
    then 0.0
  else do 
    -- get list of correct answers, its length and the number of right answers
    -- in as (both lists are nubbed to account for duplicates)
    let correctAns = nub (correct q)
    let lenCorrectAns = fromIntegral (length correctAns)
    let right = fromIntegral (getRight correctAns (nub as))
    let lenAS = fromIntegral (length (nub as))

    case qtype q of 
      -- If radio, give one mark if there is exactly one answer and that one 
      -- answer is correct, else give 0
      Radio -> do
        if head as `elem` correctAns && length (nub as) == 1
          then 1.0
        else 0.0

      -- Else checkbox, calculate based on number of right and wrong and length
      -- of correct
      CheckBox -> do 
        let wrong = lenAS - right
        (max 0.0 ((right - wrong)/(lenCorrectAns)))

-- Gets all the right answers from the answer sheet, takes in correct and as
getRight :: [Int] -> [Int] -> Int 
getRight c (x:xs) = do 
  -- If x is correct 
  if x `elem` c 
    then do 
      -- Remove x from c and recurse
      let rest = getRight (filter (\y -> y /= x) c) xs
      rest + 1
  else do
    let rest = getRight c xs
    rest 
getRight c [] = 0

{- The mark assigned to a quiz submission is:
   - 0 if submitted after the deadline.
   - the sum of the marks for each question,
     if submitted at or before the deadline.
 -}
markSubmission :: Quiz -> Submission -> Double
-- markSubmission = error "TODO: implement marker"
markSubmission quiz sub = do
  -- Check if quiz is submitted after the deadline
  if time sub > deadline quiz 
    then 0.0
  else sumMarks (questions quiz) (answers sub)

sumMarks :: [Question] -> [[Int]] -> Double
sumMarks (currQuestion:restQuestions) (currAS:restAS) = do
  let questionMarks = markQuestion currQuestion currAS 
  questionMarks + sumMarks restQuestions restAS
sumMarks [] [] = 0.0
sumMarks _ [] = 0.0
sumMarks [] _ = 0.0

-- data Submission =
--   Submission { session :: String,
--                quizName :: String,
--                student :: String,
--                answers :: [[Int]],
--                time :: UTCTime
--              } deriving (Eq,Show)

-- data Question =
--   Question { number  :: Int,
--              qtype   :: QuestionType,
--              correct :: [Int]
--            } deriving (Eq,Show)

--  -}
-- data Quiz =
--   Quiz { deadline :: UTCTime,
--          questions :: [Question]
--        } deriving (Eq,Show)


{- `marker quizStr submissionsStr`
   combines the parsers and business logic as follows:

   If `quizStr` can be parsed to a quiz,
   and if `submissionsStr` can be parsed to
   a `[(String,Submission)]` using
   parseJSON and toResults,
   calculate quiz marks for each student
   and present them in the form of an
   sms update file.
   update files look like this:

     z1234567|quiz01|3
     z2345678|quiz01|7

   with each line being a | separated tuple
   of student ID, quiz name, and marks.
   No extra spaces beyond the newlines
   at the end of each line (including the
   last line).

   The order of the lines is not important.
 -}
marker :: String -> String -> Maybe String
-- marker = error "TODO: implement marker"
marker quizStr submissionsStr = do 
  -- Check that quizStr and submissionStr are valid
  case runParser parseQuiz quizStr of 
    Nothing -> Nothing
    Just quiz -> do

      case runParser parseJSON submissionsStr of 
        Nothing -> Nothing 
        Just submissionJSON -> do 

          case toSubmissions submissionJSON of 
            Nothing -> Nothing 
            Just submissions -> do 
              -- Return update file
              Just (markSubmissions quiz submissions)

-- Takes a quiz and a list of (zid, submissions) and marks each submission,
-- returns update file in correct format
markSubmissions :: Quiz -> [(String, Submission)] -> String 
markSubmissions quiz ((zid, submission):rest) = do 
  let studentMark = markSubmission quiz submission
  let line = (zid ++ "|" ++ (quizName submission) ++ "|" ++ (show studentMark) ++ "\n")
  line ++ (markSubmissions quiz rest)
markSubmissions quiz [] = ""

{- Use this to read a quiz key and submissions
   file from the file system, and print the
   updated file to stdOut.

   Note that FilePath is a type synonym for String.
 -}
runMarker :: FilePath -> FilePath -> IO ()
runMarker quizFile submissionsFile = do
  quiz <- readFile quizFile
  submissions <- readFile submissionsFile
  case marker quiz submissions of
    Nothing -> putStrLn "Something went wrong. But this error message is not helpful!"
    Just output -> putStrLn output

unshow :: String -> UTCTime
unshow = parseTimeOrError True defaultTimeLocale "%F %X %Z"

subSample :: Submission 
subSample = Submission {session = "23T2", quizName = "quiz01", 
                        student = "Jean-Baptiste Bernadotte", 
                        answers = [[1], [1]], time = unshow "2023-06-02 23:13:13 UTC"}

timeSample :: UTCTime 
timeSample = unshow "2023-06-02 23:13:13 UTC"

quizSample :: Quiz 
quizSample = Quiz {deadline = timeSample, 
             questions = [Question {number = 1, qtype = CheckBox, correct = [1,2,3,3]},
                          Question {number = 2, qtype = Radio, correct = [1,2]}]}

questionSample :: Question 
questionSample = Question {number = 1, qtype = CheckBox, correct = [1,2,3,3]}
