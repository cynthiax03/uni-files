/*
 * Declarations for file handle and file table management.
 */

#ifndef _FILE_H_
#define _FILE_H_

/*
 * Contains some file-related maximum length constants
 */
#include <limits.h>
#include <uio.h>

/*
 * Put your function declarations and data types here ...
 */

// File descriptor node, used to keep track the file descriptors within a
// process
struct open_file
{
    struct vnode *vnode; // ptr to the vnode of the file
    int flags;           // to track the permissions
    int num_fds;         // keeps track of how many fds are pointing to it
                         // if it reaches 0, we can remove it
    off_t offset;
    int oft_index;
};

// struct fd
// {
//     struct open_file *file;
//     off_t offset;
//     struct fd *prev_dup;
//     struct fd *next_dup;
// };

/*
    SYS functions
*/
// sys_open creates a fd which points to an of in the oft if inputs are valid,
// returns 0 on success, errno on error and updates retval if an fd was created
int sys_open(const char *filename, int flags, mode_t mode, int *retval);

// sys_read reads an open file pointed to by fd into buf if inputs are valid,
// on success returns 0 and updates retval to be the number of bytes read,
// returns errno if error
ssize_t sys_read(int fd, void *buf, size_t buflen, int *retval);

// sys_write writes buf to an open file pointed to by fd if inputs are valid,
// on success returns 0 and updates retval to be the number of bytes written,
// returns errno if error
ssize_t sys_write(int fd, const void *buf, size_t nbytes, int *retval);

// sys_lseek updates the offset position of the of that the fd points to if
// inputs are valid, on success returns 0 and sets retval to be the new offset
// returns errno on error
off_t sys_lseek(int fd, off_t pos, int whence, int *retval);

// sys_dup2 makes the newfd point to the same open file as oldfd points to, on
// success, newfd is returned, errno is returned on error
int sys_dup2(int oldfd, int newfd, int *retval);

// removes a fd from fdt, if the open file it points to is not reference by any other
// fds, removes the open file from oft & frees, on success 0 is returned, errno on error
int sys_close(int fd);

/*
    Helper functions
*/
// Returns true or false depending on whether a given fd is valid or not
bool fd_valid(int fd);

#endif /* _FILE_H_ */
