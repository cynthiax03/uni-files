#include <types.h>
#include <kern/errno.h>
#include <kern/fcntl.h>
#include <kern/limits.h>
#include <kern/stat.h>
#include <kern/seek.h>
#include <lib.h>
#include <uio.h>
#include <proc.h>
#include <current.h>
#include <synch.h>
#include <vfs.h>
#include <vnode.h>
#include <file.h>
#include <syscall.h>
#include <copyinout.h>

int num_open_files = 0;
struct open_file *oft[OPEN_MAX];

/*
 * Add your file-related functions here ...
 */

int sys_open(const char *filename, int flags, mode_t mode, int *retval)
{
    // Check if we have space for a file descriptor in the process fdt
    int fd_int = -1;
    for (int i = 0; i < OPEN_MAX; i++)
    {
        if (curproc->fds[i] == NULL)
        {
            fd_int = i;
            break;
        }
    }
    // If fdt is full, return error
    if (fd_int == -1)
        return EMFILE;

    // Checks whether number of open files has reached limit 128
    if (num_open_files == 128)
        return ENFILE;

    // Space is available, Finds space for new file
    int of_index = -1;
    for (int i = 0; i < 128; i++)
    {
        if (oft[i] == NULL)
        {
            of_index = i; // Space found
            break;
        }
    }

    // If oft full, return error
    if (of_index == -1) {
        return ENFILE;
    }

    // String checking
    char fn[NAME_MAX];
    size_t actual_fn_len;
    int err = copyinstr((const_userptr_t)filename, fn, NAME_MAX, &actual_fn_len);
    if (err != 0)
    {
        return ENOENT;
    }

    // Create an open file entry
    struct open_file *of = kmalloc(sizeof(struct open_file));
    struct vnode *vnode;

    if (of == NULL)
        return ENOMEM;

    err = vfs_open((char *)fn, flags, mode, &vnode);

    // If vfs open failed, return the error and free the open file struct
    if (err != 0)
    {
        kfree(of);
        of = NULL;
        return err;
    }

    // Populate data structure
    of->vnode = vnode;
    of->flags = flags;
    of->num_fds = 1;
    of->offset = 0;
    of->oft_index = of_index;

    num_open_files++;

    // Add file to global open file table
    oft[of_index] = of;

    // Make file descriptor point to open file, FD is now in use
    curproc->fds[fd_int] = of;
    *retval = fd_int;
    return 0;
}

ssize_t sys_read(int fd, void *buf, size_t buflen, int *retval)
{
    // Check file descriptor is valid
    if (!fd_valid(fd))
    {
        kprintf("In file read, fd is null\n");
        return EBADF;
    }

    // Get the file descriptor and vnode
    struct open_file *fd_entry = curproc->fds[fd];
    struct vnode *vn = fd_entry->vnode;

    // Check if file is open for reading
    if (fd_entry->flags == O_WRONLY)
    {
        return EBADF;
    }

    // Create the uio and iov structs
    struct uio *u = kmalloc(sizeof(struct uio));
    struct iovec *iov = kmalloc(sizeof(struct iovec));
    if (u == NULL || iov == NULL)
        return ENOMEM;

    uio_uinit(iov, u, (userptr_t)buf, buflen, fd_entry->offset, UIO_READ);

    int err = VOP_READ(vn, u);
    if (err != 0)
    {
        kprintf("error from VOP READ");
        return err;
    }

    // Get the amount that was read and update offset
    fd_entry->offset = u->uio_offset;
    *retval = buflen - u->uio_resid;

    kfree(u);
    kfree(iov);
    return 0;
}

ssize_t sys_write(int fd, const void *buf, size_t nbytes, int *retval)
{
    // Check if fd is valid
    if (!fd_valid(fd))
    {
        return EBADF;
    }

    struct open_file *fd_entry = curproc->fds[fd];
    struct vnode *vn = fd_entry->vnode;

    // Check that the file is open for writing
    if (fd_entry->flags == O_RDONLY)
    {
        return EBADF;
    }

    // Creat the uio and iov structs
    struct uio *u = kmalloc(sizeof(struct uio));
    struct iovec *iov = kmalloc(sizeof(struct iovec));
    if (u == NULL || iov == NULL)
        return ENOMEM;

    uio_uinit(iov, u, (userptr_t)buf, nbytes, fd_entry->offset, UIO_WRITE);

    int err = VOP_WRITE(vn, u);
    if (err != 0)
    {
        // kprintf("error");
        return err;
    }

    // Update offset of the open_file entry
    fd_entry->offset = u->uio_offset;

    // u->uio_reside is "Remaining amt of data to xfer", it is 0 if all bytes
    // transfered
    *retval = nbytes - u->uio_resid;
    kfree(u);
    kfree(iov);
    return 0;
}

int sys_close(int fd)
{
    // Checks if valid fd handle
    if (!fd_valid(fd))
        return EBADF;

    struct open_file *file = curproc->fds[fd];

    // Decrement number of fds
    file->num_fds--;

    // Removes if no more file descriptors point to the file
    if (file->num_fds == 0)
    {
        vfs_close(file->vnode);
        int of_index = file->oft_index;
        kfree(file);
        oft[of_index] = NULL;
        num_open_files--;
    }

    curproc->fds[fd] = NULL;

    return 0;
}

int sys_dup2(int oldfd, int newfd, int *retval)
{
    // Checks if oldfd is valid
    if (!fd_valid(oldfd))
        return EBADF;

    // fd only valid between 0 and 127
    if (newfd < 0 || newfd >= 128)
        return EBADF;

    // If oldfd and newfd are the same
    if (oldfd == newfd)
    {
        *retval = newfd;
        return 0;
    }

    // Checks if newfd already has an open file
    struct open_file *newfd_entry = curproc->fds[newfd];
    if (newfd_entry != NULL)
    {
        // Reduces num_fd count since redirecting newfd to new file
        newfd_entry->num_fds--;

        // If this open file has no more file descriptors pointing to it, close file
        if (newfd_entry->num_fds == 0)
        {
            vfs_close(newfd_entry->vnode);
            kfree(newfd_entry);
            num_open_files--;
        }
    }

    // // Assign newfd to the same open file entry as oldfd
    curproc->fds[newfd] = curproc->fds[oldfd];

    struct open_file *oldfd_entry = curproc->fds[oldfd];
    oldfd_entry->num_fds++;
    *retval = newfd;
    return 0;
}

off_t sys_lseek(int fd, off_t pos, int whence, int *retval)
{
    // Check if fd is valid
    if (!fd_valid(fd))
        return EBADF;

    // Get position of the current offset and vnode
    struct open_file *file_entry = curproc->fds[fd];
    off_t curr_off = file_entry->offset;
    struct vnode *vn = file_entry->vnode;
    off_t new_off;

    // If new position is pos
    if (whence == SEEK_SET)
    {
        new_off = pos;

        // If the new position is curr_off + pos
    }
    else if (whence == SEEK_CUR)
    {
        new_off = curr_off + pos;

        // If the new position is file_size + pos
    }
    else if (whence == SEEK_END)
    {
        struct stat *stat_buf = NULL;
        int err = VOP_STAT(vn, stat_buf);
        if (err)
            return err;

        new_off = stat_buf->st_size + pos;

        // If whence is none of these, return
    }
    else
    {
        return EINVAL;
    }

    // If new_off is positive, and offset is seekable, set it as new offset
    if (new_off >= 0)
    {
        if (VOP_ISSEEKABLE(vn))
        {
            file_entry->offset = new_off;
            *retval = new_off;
            return 0;
        }
        else
        {
            return ESPIPE;
        }
    }

    return EINVAL;
}

bool fd_valid(int fd)
{
    // fd only valid between 0 and 127
    if (fd < 0 || fd >= 128)
    {
        return false;
    }

    if (curproc->fds[fd] == NULL)
    {
        return false;
    }

    return true;
}
