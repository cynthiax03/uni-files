bswap.o: ../../lib/bswap.c ../../include/types.h \
 ../../include/kern/types.h includelinks/kern/machine/types.h \
 includelinks/machine/types.h ../../include/endian.h \
 ../../include/kern/endian.h includelinks/kern/machine/endian.h
